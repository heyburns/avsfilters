##### 1.3.0:
    Added field=-3/-4.
    Changed back the behavior of field=-2/-1.
    Set output GetParity.

##### 1.2.5:
    Fixed processing when BFF.

##### 1.2.4:
    Added parameter `pass`.

##### 1.2.3:
    Fixed double rate mode.

##### 1.2.2:
    Added parameter `thr`.
    Added parameter `debug`.
    Added support to read frame property _FieldBased.

##### 1.2.1:
    Set frame property _FieldBased to 0.

##### 1.2.0:
    Added parameter edeint.

##### 1.1.1:
    Fixed double rate.

##### 1.1.0:
    Added field option -2.

##### 1.0.0:
    Port of the VapourSynth plugin Bwdif.
