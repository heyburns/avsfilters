##### 0.9.4:
    Fixed overflow when `clip2` is used.

##### 0.9.3:
    Added parameter `thr`. (vinverse only)

##### 0.9.2:
    Added parameter `clip2`. (vinverse only)

##### 0.9.1:
    Changed MT mode from MT_NICE_FILTER to MT_MULTI_INSTANCE.
    Added support for 10..16-bit clips.
    Added AVX2 and AVX512 code.
    Added parameter `opt`.
    Added support for frame properties passthrough.
    Added version.

##### 0.9.0:
    Initial release.
