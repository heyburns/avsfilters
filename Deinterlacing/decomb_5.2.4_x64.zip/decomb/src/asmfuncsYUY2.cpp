/*
	Telecide plugin for Avisynth -- recovers original progressive
	frames from telecined streams. The filter operates by matching
	fields and automatically adapts to phase/pattern changes.

	Copyright (C) 2003-2008 Donald A. Graft

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include "version.h"

#ifdef DEINTERLACE_MMX_BUILD
#pragma warning(disable:4799)

#if !defined(_WIN64)
#define rax	eax
#define rbx	ebx
#define rcx	ecx
#define rdx	edx
#define rsi	esi
#define rdi	edi
#define rbp	ebp
#else
#define rax	rax
#define rbx	rbx
#define rcx	rcx
#define rdx	rdx
#define rsi	rsi
#define rdi	rdi
#define rbp	rbp
#endif

void asm_deinterlaceYUY2(const unsigned char *dstp, const unsigned char *p,
								  const unsigned char *n, unsigned char *fmask,
								  unsigned char *dmask, int thresh, int dthresh, int row_size)
{
	static const __int64 Mask0 = 0xFFFF0000FFFF0000i64;
	static const __int64 Mask2 = 0x00000000000000FFi64;
	static const __int64 Mask3 = 0x0000000000FF0000i64;
	static const __int64 Mask4 = 0x0000000000FF00FFi64;
	__asm
	{
		mov			rdx,dstp
		mov			rcx,p
		mov			rbx,n
		mov			rax,fmask
		mov			rsi,dmask
		movd		mm0,thresh
		movq		mm3,mm0
		psllq		mm3,32
		por			mm3,mm0
		movd		mm4,dthresh
		movq		mm5,mm4
		psllq		mm5,32
		por			mm5,mm4
		mov			edi,row_size
xloop:
		pxor		mm4,mm4
		movd		mm0,[rcx]		// load p
		punpcklbw	mm0,mm4			// unpack
		movd		mm2,[rdx]		// load dstp
		punpcklbw	mm2,mm4			// unpack
		movd		mm1,[rbx]		// load n
		punpcklbw	mm1,mm4			// unpack
		psubw		mm0,mm2			// pprev - curr = P
		psubw		mm1,mm2			// pnext - curr = N
		movq		mm6,Mask0
		pandn		mm6,mm0			// mm6 = 0 | P2 | 0 | P0
		pmaddwd		mm6,mm1			// mm6 = P2*N2  | P0*N0
		movq		mm0,mm6

		pcmpgtd		mm6,mm3			// mm6 = P2*N2<T | P0*N0<T
		movq		mm4,mm6			// save result
		pand		mm6,Mask2		// make 0x000000ff if P0*N0<T
		movq		mm7,mm6			// move it into result
		psrlq		mm4,32			// get P2*N2<T
		pand		mm4,Mask3		// make 0x00ff0000 if P2*N2<T
		por			mm7,mm4			// move it into the result
		movd		[rax],mm7		// save final result for fmask

		pcmpgtd		mm0,mm5			// mm0 = P2*N2<DT | P0*N0<DT
		movq		mm4,mm0			// save result
		pand		mm0,Mask2		// make 0x000000ff if P0*N0<DT
		movq		mm7,mm0			// move it into result
		psrlq		mm4,32			// get P2*N2<DT
		pand		mm4,Mask3		// make 0x00ff0000 if P2*N2<DT
		por			mm7,mm4			// move it into the result
		movq		[rsi],mm7			// save intermediate result

		pxor		mm4,mm4			// do chroma bytes now
		movd		mm0,[rcx]		// load p
		punpcklbw	mm0,mm4			// unpack
		movd		mm1,[rbx]		// load n
		punpcklbw	mm1,mm4			// unpack
		psubw		mm0,mm2			// pprev - curr = P
		psubw		mm1,mm2			// pnext - curr = N
		movq		mm6,Mask0
		pand		mm6,mm0			// mm6 = P3 | 0 | P1| 0
		pmaddwd		mm6,mm1			// mm6 = P3*N3  | P1*N1
		movq		mm0,mm6

		pcmpgtd		mm0,mm5			// mm0 = P3*N3<DT | P1*N1<DT
		movq		mm4,mm0			// save result
		pand		mm0,Mask4		// make 0x00ff00ff if P1*N1<DT
		movq		mm7,mm0			// move it into result
		psrlq		mm4,32			// get P3*N3<DT
		pand		mm4,Mask4		// make 0x00ff00ff if P3*N3<DT
		por			mm7,mm4			// move it into the result
		movd		mm4,[rsi]		// Pick up saved intermediate result
		por			mm4,mm7
		movd		[rsi],mm4		// Save final result for dmask

		add			rdx,4
		add			rcx,4
		add			rbx,4
		add			rax,4
		add			rsi,4
		dec			edi
		jnz			xloop

		emms
	};	
}

void asm_deinterlace_chromaYUY2(const unsigned char *dstp, const unsigned char *p,
								  const unsigned char *n, unsigned char *fmask,
								  unsigned char *dmask, int thresh, int dthresh, int row_size)
{
	static const __int64 Mask0 = 0xFFFF0000FFFF0000i64;
	static const __int64 Mask2 = 0x00000000000000FFi64;
	static const __int64 Mask3 = 0x0000000000FF0000i64;
	static const __int64 Mask4 = 0x0000000000FF00FFi64;
	__asm
	{
		mov			rdx,dstp
		mov			rcx,p
		mov			rbx,n
		mov			rax,fmask
		mov			rsi,dmask
		movd		mm0,thresh
		movq		mm3,mm0
		psllq		mm3,32
		por			mm3,mm0
		movd		mm4,dthresh
		movq		mm5,mm4
		psllq		mm5,32
		por			mm5,mm4
		mov			edi,row_size
xloop:
		pxor		mm4,mm4
		movd		mm0,[rcx]		// load p
		punpcklbw	mm0,mm4			// unpack
		movd		mm2,[rdx]		// load dstp
		punpcklbw	mm2,mm4			// unpack
		movd		mm1,[rbx]		// load n
		punpcklbw	mm1,mm4			// unpack
		psubw		mm0,mm2			// pprev - curr = P
		psubw		mm1,mm2			// pnext - curr = N
		movq		mm6,Mask0
		pandn		mm6,mm0			// mm6 = 0 | P2 | 0 | P0
		pmaddwd		mm6,mm1			// mm6 = P2*N2  | P0*N0
		movq		mm0,mm6

		pcmpgtd		mm6,mm3			// mm6 = P2*N2<T | P0*N0<T
		movq		mm4,mm6			// save result
		pand		mm6,Mask2		// make 0x000000ff if P0*N0<T
		movq		mm7,mm6			// move it into result
		psrlq		mm4,32			// get P2*N2<T
		pand		mm4,Mask3		// make 0x00ff0000 if P2*N2<T
		por			mm7,mm4			// move it into the result
		movd		[rax],mm7		// save intermediate result

		pcmpgtd		mm0,mm5			// mm0 = P2*N2<DT | P0*N0<DT
		movq		mm4,mm0			// save result
		pand		mm0,Mask2		// make 0x000000ff if P0*N0<DT
		movq		mm7,mm0			// move it into result
		psrlq		mm4,32			// get P2*N2<DT
		pand		mm4,Mask3		// make 0x00ff0000 if P2*N2<DT
		por			mm7,mm4			// move it into the result
		movd		[rsi],mm7		// save intermediate result

		pxor		mm4,mm4			// do chroma bytes now
		movd		mm0,[rcx]		// load p
		punpcklbw	mm0,mm4			// unpack
		movd		mm1,[rbx]		// load n
		punpcklbw	mm1,mm4			// unpack
		psubw		mm0,mm2			// pprev - curr = P
		psubw		mm1,mm2			// pnext - curr = N
		movq		mm6,Mask0
		pand		mm6,mm0			// mm6 = P3 | 0 | P1| 0
		pmaddwd		mm6,mm1			// mm6 = P3*N3  | P1*N1
		movq		mm0,mm6

		pcmpgtd		mm6,mm3			// mm6 = P3*N3<T | P1*N1<T
		movq		mm4,mm6			// save result
		pand		mm6,Mask4		// make 0x00ff00ff if P1*N1<T
		movq		mm7,mm6			// move it into result
		psrlq		mm4,32			// get P3*N3<T
		pand		mm4,Mask4		// make 0x00ff00ff if P3*N3<T
		por			mm7,mm4			// move it into the result
		movd		mm4,[rax]		// Pick up saved intermediate result
		por			mm4,mm7
		movd		[rax],mm4		// Save final result for fmask

		pcmpgtd		mm0,mm5			// mm0 = P3*N3<DT | P1*N1<DT
		movq		mm4,mm0			// save result
		pand		mm0,Mask4		// make 0x00ff00ff if P1*N1<DT
		movq		mm7,mm0			// move it into result
		psrlq		mm4,32			// get P3*N3<DT
		pand		mm4,Mask4		// make 0x00ff00ff if P3*N3<DT
		por			mm7,mm4			// move it into the result
		movd		mm4,[rsi]		// Pick up saved intermediate result
		por			mm4,mm7
		movd		[rsi],mm4		// Save final result for dmask

		add			rdx,4
		add			rcx,4
		add			rbx,4
		add			rax,4
		add			rsi,4
		dec			edi
		jnz			xloop

		emms
	};	
}
#pragma warning(default:4799)
#endif

#ifdef BLEND_MMX_BUILD
#pragma warning(disable:4799)
int blendYUY2(const unsigned char *dstp, const unsigned char *cprev,
								const unsigned char *cnext, unsigned char *finalp,
								unsigned char *dmaskp, int count)
{
	static const __int64 Mask1 = 0xFEFEFEFEFEFEFEFEi64;
	static const __int64 Mask2 = 0xFCFCFCFCFCFCFCFCi64;
	int i = count;
	__asm
	{
		mov			rdx,dstp
		mov			rcx,cprev
		mov			rbx,cnext
		mov			rax,finalp
		mov			rdi,dmaskp
#if defined(_WIN64)
		mov			r8d,count
#endif
		movq		mm7,Mask1
		movq		mm6,Mask2
xloop:
		mov			rsi,[rdi]
		or			rsi,rsi
		jnz			blend
		movq		mm0,[rdx]
		movq		[rax],mm0
		jmp			skip
blend:
		movq		mm0,[rdx]		// load dstp
		pand		mm0,mm7

		movq		mm1,[rcx]		// load cprev
		pand		mm1,mm6

		movq		mm2,[rbx]		// load cnext
		pand		mm2,mm6

		psrlq		mm0,1
		psrlq		mm1,2
		psrlq       mm2,2
		paddusb		mm0,mm1
		paddusb		mm0,mm2
		movq		[rax],mm0
skip:
		add			rdx,8
		add			rcx,8
		add			rbx,8
		add			rax,8
		add			rdi,8
#if !defined(_WIN64)
		dec			i
#else
		dec			r8d
#endif
		jnz			xloop

		emms
	};
}
#pragma warning(default:4799)
#endif

#ifdef INTERPOLATE_MMX_BUILD
#pragma warning(disable:4799)
int interpolateYUY2(const unsigned char *dstp, const unsigned char *cprev,
								const unsigned char *cnext, unsigned char *finalp,
								unsigned char *dmaskp, int count)
{
	static const __int64 Mask = 0xFEFEFEFEFEFEFEFEi64;
	int i = count;
		__asm
	{
		mov			rdx,dstp
		mov			rcx,cprev
		mov			rbx,cnext
		mov			rax,finalp
		mov			rdi,dmaskp
#if defined(_WIN64)
		mov			r8d,count
#endif
		movq		mm7,Mask
xloop:
		mov			rsi,[rdi]
		or			rsi,rsi
		jnz			blend
		movq		mm0,[rdx]
		movq		[rax],mm0
		jmp			skip
blend:
		movq		mm0,[rcx]		// load cprev
		pand		mm0,mm7

		movq		mm1,[rbx]		// load cnext
		pand		mm1,mm7

		psrlq		mm0,1
		psrlq       mm1,1
		paddusb		mm0,mm1
		movq		[rax],mm0
skip:
		add			rdx,8
		add			rcx,8
		add			rbx,8
		add			rax,8
		add			rdi,8
#if !defined(_WIN64)
		dec			i
#else
		dec			r8d
#endif
		jnz			xloop

		emms
	};
}
#pragma warning(default:4799)
#endif

