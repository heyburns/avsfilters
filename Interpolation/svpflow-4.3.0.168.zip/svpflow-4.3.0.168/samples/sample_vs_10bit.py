import vapoursynth as vs

core = vs.get_core(threads=9)

core.std.LoadPlugin("libsvpflow1.so")
core.std.LoadPlugin("libsvpflow2.so")
core.std.LoadPlugin("libffms2.so.3")

clip = core.ffms2.Source(source="path/to/video")
clip_p8 = clip.resize.Point(format=vs.YUV420P8)
clip_p10 = clip.resize.Bicubic(format=vs.YUV420P10)

super_params="{gpu:1}"
analyse_params="{}"
smoothfps_params="{rate:{num:5,den:2}}"

super  = core.svp1.Super(clip_p8,super_params)
vectors= core.svp1.Analyse(super["clip"],super["data"],clip_p8,analyse_params)
smooth = core.svp2.SmoothFps(clip_p10,super["clip"],super["data"],vectors["clip"],vectors["data"],smoothfps_params)
smooth = core.std.AssumeFPS(smooth,fpsnum=smooth.fps_num,fpsden=smooth.fps_den)

smooth.set_output()
