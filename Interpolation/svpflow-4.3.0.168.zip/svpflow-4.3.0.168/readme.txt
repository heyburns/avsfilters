SmoothVideo Project (SVP) v.4
=============================

svpflow1 - motion vectors search based on MVTools2 and x264 under GPL
svpflow2 - frame rendering + NVOF motion vectors

Binary files naming convention:
- *.dll - Avisynth 32-bit (Windows only)
- *_64.dll - Avisynth 64-bit (Windows only)
- *_vs.* - Vapoursynth 64-bit (Windows only)
- *.dll - Windows
- *.so - Linux
- *.dylib - Mac

svpflow1 sources: http://www.svp-team.com/files/gpl/svpflow1-src.zip

svpflow_cpu.dll - CPU rendering from svpflow2.dll, removed since 1.1.12
svpflow_gpu.dll - GPU rendering from svpflow2.dll, removed since 1.1.12

!!!!!!!!!!!!!!!!!
WARNING: SVPflow libs require a SVP Manager running, otherwise you'll see a red rectangle around the video frame.
You're free to disable SVP completely ("Temporarily disable SVP" + ui.disable_on_launch = true in All settings), however it still must be running in background.
!!!!!!!!!!!!!!!!!

Versions and changelog
======================

SVPflow 4.3.0.168
-----------------
= Avisynth: further improved HDR tone mapping in GPU mode: brighter, less yellowish, 1st SVP shader fixed

SVPflow 4.3.0.165
-----------------
= Avisynth: improved HDR tone mapping in GPU mode
= improved SAD masking and 13th SVP shader (thanks to Mystery)
= Linux: fixed memory leak in some cases

SVPflow 4.3.0.160
-----------------
+ added support for MVs calculation via NVIDIA Optical Flow API (Windows and Linux only)

SVPflow 4.3.0.155
-----------------
= possibly improved performance processing 4K with GPU acceleration on
+ Avisynth: added HDR colors recovery mode (8-bit tone mapping), only in GPU mode

SVPflow 4.3.0.147
-----------------
= Vapoursynth: fixed incorrect frame timestamps in some cases resulting in audio desync

SVPflow 4.2.0.142
-----------------
+ Vapoursynth: supports rendering in 10 bit color depth (vs.YUV420P10 format)
= fixed minor (?) error in the motion vectors search algorithm ("cross search")
= fixed video corruption with smooth.cubic=0
+ updated ASM code from x264 (supports AVX-512)
+ added macOS libraries
- Linux,macOS: removed Qt dependecy

SVPflow 4.0.0.128
-----------------
= bump versions to match SVP 4 multi-OS release
+ Vaporsynth/Windows 32-bit/64-bit builds
+ Vaporsynth/Linux 32-bit/64-bit builds
+ all filters now compatible with MT mode 1

SVPflow 1.1.17
--------------
svpflow2.dll 2.0.3
= fixed visual aritfacts on right and bottom edges with CPU rendering

SVPflow 1.1.16
--------------
svpflow1.dll 2.0.4, svpflow2.dll 2.0.2
= fixed crash in svpflow1

SVPflow 1.1.15a
---------------
+ 64-bit versions added 
(read this first - http://forum.doom9.org/showpost.php?p=1722352&postcount=266)

SVPflow 1.1.15
--------------
svpflow1.dll 2.0.3, svpflow2.dll 2.0.2
= fixed performance issues with the default main.search.coarse.width value (introduced in 1.1.12)

SVPflow 1.1.14
--------------
svpflow1.dll 2.0.2, svpflow2.dll 2.0.1
= up to 15% faster
= 2nd attempt to fix broken SVConvert function NOT fixed in 1.1.13

SVPflow 1.1.13
--------------
svpflow1.dll 2.0.1, svpflow2.dll 2.0.0
= fixed broken SVConvert function

SVPflow 1.1.12
--------------
svpflow1.dll 2.0.0, svpflow2.dll 2.0.0
= up to 20% faster
+ "64-bit ready" - assembler code ported/rewritten in intrinsics, target compiler is VC++2013
+ new option in SVAnalyse - search.main.coarse.width - to get more than one "finest" levels
+ SATD for 32-x blocks
= reduced memory usage for large number of small blocks
= refactoring - removed svpflow_cpu/gpu modules - merged with svpflow2

SVPflow 1.0.11
--------------
svpflow2.dll 1.5.8, svpflow_gpu.dll 1.8.4
= Fixed crash in CPU rendering mode with pel>1 and blend=true
= Fixed rounding error in GPU rendering mode

SVPflow 1.0.10
--------------
svpflow1.dll 1.3.5, svpflow2.dll 1.5.7, svflow_gpu.dll 1.8.3
+ GPU rendering in linear light by default
= SAD functions updated to the latest x264 code

SVPflow 1.0.9
--------------
svpflow2.dll 1.5.1, svflow_gpu.dll 1.7.9

+ SVSmoothFps switches to 13th SVP shader if scene quality 
  is below scene.m1 value
= GPU rendering was very slow for some "prime" 
  frame sizes (like 1916x1076) on some video cards
- removed workaround for a bug in early IvyBridge's drivers

SVPflow 1.0.8
--------------
svpflow2.dll 1.4.1, svpflow_gpu.dll 1.7.6

= fixed regression from 1.0.5 (low rendering precision in GPU mode)
= improved lighting quality (reduced color banding)

SVPflow 1.0.7
--------------
svpflow1.dll 1.3.2

+ improved scene change detection
= fixed crash after SVConvert, adjusted SAD values in MVTools' vectors field

SVPflow 1.0.6
--------------
svpflow1.dll 1.3.0, svpflow2.dll 1.4.0, 
svpflow_cpu.dll 1.7.2, svpflow_gpu.dll 1.7.5

+ super clip size reduced by 4 for pel=1 
  ('full' param in SVSuper and 'src' param in SVAnalyse)
= added workaround for OpenCL rendering on Intel's IvyBridge GPUs
+ "Ambilight" can now produce "glow" effect from all sides of the frame 
  ('light.zoom' param in SVSmoothFps)
= several small bugs fixed:
== crash with frame rate ratio < 2 (50->60, 60->50 and so on)
== arts near screen edges with CPU rendering and some frame / block sizes combination
== green lines with 21th shader and arts masking on CPU

SVPflow 1.0.5
--------------
svpflow_gpu.dll 1.7.2

= added compatibility with GTX680 (and may be with all other Kepler GPUs) - thanks to flagger

SVPflow 1.0.4
--------------
svpflow1.dll 1.2.0, svpflow2.dll 1.3.0, 

+ added special.delta param to SVAnalyse

SVPflow 1.0.3
--------------
svpflow1.dll 1.1.1, svpflow2.dll 1.2.1, 

= fixed random crash in MT mode
= fixed usage of invalid predictors from reverse vectors (thanks -Vit-)

SVPflow 1.0.2
--------------
svpflow1.dll 1.1.0, svpflow2.dll 1.2.0, 
svpflow_cpu.dll 1.7.1, svpflow_gpu.dll 1.7.1

= support for multiply SVSmoothFps instances needed for proper 3D handling
+ SVConvert function for integration with MVTools-based scripts
+ GPU selection for rendering
= updated SAD/SATD x264 code

SVPflow 1.0.1
--------------
svpflow1.dll 1.0.0, svpflow2.dll 1.1.1, 
svpflow_cpu.dll 1.7.0, svpflow_gpu.dll 1.6.2

Initial public release.


More info 
===========================
On SVP web-site: http://www.svp-team.com/wiki/Plugins:_SVPFlow
Discussion at Doom9: http://forum.doom9.org/showthread.php?t=164554
