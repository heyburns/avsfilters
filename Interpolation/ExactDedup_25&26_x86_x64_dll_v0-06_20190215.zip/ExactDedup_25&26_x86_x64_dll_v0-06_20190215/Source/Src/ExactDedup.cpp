/**
 * ExactDedup v0.03 (17 December 2011)
 * Copyright (c) 2011 Steve Melenchuk, Arick Chan
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 **/

/*
  v0.04, 16 Feb 2017. Bugfix Mod. Added Show arg. StainlessS.
  v0.05, Oct 5, 2017. Convert, Avs+ Header, VS 2008, add x64.
  v0.06, 15 Feb 2019. Added Version resource. MicroSoft broke W7+ relative pathnames, fixed.
*/

// ----------------------------------------------------------------
//	Compiling for Avisynth v2.58 & v2.60/x86, v2.60/x64, under VS2008
//
// For AVS+, also need additional Avisynth+ headers somewhere in an AVS directory,
//
// AVS
//   alignment.h
//   avisynth.h
//   capi.h
//   config.h
//   cpuid.h
//   minmax.h
//   types.h
//   win.h
//
// Point Menu/Tools/Options/Projects and Solutions/VC Directories/ :Include Files: Win32 and x64, to the AVS Parent.
//
// For x64, add '_WIN64' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//        (Do NOT delete any 'WIN32' entry).
// For Avs v2.5, Add 'AVISYNTH_PLUGIN_25' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//   Avs v2.5 includes AVISYNTH_INTERFACE_VERSION=3 as avisynth25.h
//   Avs+ v2.6/x86/x64 includes AVISYNTH_INTERFACE_VERSION=6 as avisynth.h
// ----------------------------------------------------------------


// Uncomment #define BUG to enable debug output via DRPINT(), *** Comment out for release ***

//#define BUG

#include "compiler.h"
#include <stdio.h>
#include <windows.h>

#ifdef AVISYNTH_PLUGIN_25
	#include "avisynth25.h"
#else 
	#include "avisynth.h"
#endif
#include "info.h"

//#ifdef BUG
	int dprintf(char* fmt, ...) {
		char printString[2048]="ExactDeDup: ";		// MUST NUL TERM THIS eg "Test: " or ""
		char *p=printString;
		while(*p++);		
		--p;                                        // @ nul term
		va_list argp;
		va_start(argp, fmt);
		vsprintf(p, fmt, argp);
		va_end(argp);
		while(*p++);
		--p;										// @ nul term
		if(printString == p || p[-1] != '\n') {
			p[0]='\n';								// append n/l if not there already
			p[1]='\0';
		}
		OutputDebugString(printString);
		return int(p-printString);						// strlen printString	
	}
//#endif

#define PATH_BUF_LEN  (MAX_PATH * 2 + 1)

class ExactDedup : public GenericVideoFilter {
private:
	// args:-
	const bool firstpass;
	char dupinfo[PATH_BUF_LEN];
	char times[PATH_BUF_LEN];
	const unsigned int maxdupcount;
	const bool keeplastframe;
	const bool show;
	//
	int prevframe;
	unsigned int curdupcount;
	int *framemap;
	bool IsWritten;
	//
	void LoadDupInfo(IScriptEnvironment* env);
	void SaveDupInfo(IScriptEnvironment* env);
public:
	ExactDedup(PClip _child, bool _firstpass, const char *_dupinfo,
		const char* _times, int _maxdupcount, bool _keeplastframe,bool _show,IScriptEnvironment* env);		
	~ExactDedup();
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
};

ExactDedup::ExactDedup(PClip _child, bool _firstpass, const char *_dupinfo,
           const char* _times, int _maxdupcount, bool _keeplastframe,bool _show,IScriptEnvironment* env)
       : GenericVideoFilter(_child),firstpass(_firstpass),
	     maxdupcount(_maxdupcount),keeplastframe(_keeplastframe),show(_show),
	     prevframe(0),curdupcount(0),framemap(NULL),IsWritten(false)
	   {
	DPRINTF("Constructor IN")
	strcpy(dupinfo,_dupinfo);
	strcpy(times  ,_times  );
    if (firstpass) {
		DPRINTF("Constructor firstpass allocating framemap")
		framemap = new int[vi.num_frames];
		if(framemap==NULL)	env->ThrowError("ExactDedup: failed allocating framemap"); 
	} else {
		DPRINTF("Constructor 2nd pass Calling LoadDupInfo")
		LoadDupInfo(env);
	}
	DPRINTF("Constructor OUT")
}

ExactDedup::~ExactDedup() {
	DPRINTF("Destructor IN")
	if (framemap) {
		DPRINTF("Destructor Freeing framemap")
		delete[] framemap;
		framemap = NULL;
	}
	if(firstpass) {
		if(IsWritten)		{ dprintf("Destructor, dupinfo written OK");  }
		else				{ dprintf("Destructor, dupinfo NOT written"); }
	}
	DPRINTF("Destructor OUT")
}

// Called only in firstpass on last frame in GetFrame().
void ExactDedup::SaveDupInfo(IScriptEnvironment* env) {
	DPRINTF("SaveDupInfo IN")
	unsigned int framecount = 0;
    FILE *dupfile = NULL;
	FILE *timesfile = NULL;
	DPRINTF("SaveDupInfo Opening files")
	if ((dupfile=fopen(dupinfo, "w"))==NULL)
		env->ThrowError("ExactDedup: failed to open dupinfo file for write");

	if ((timesfile=fopen(times, "w"))==NULL) {
		fclose(dupfile);
		env->ThrowError("ExactDedup: failed to open timecodes file for write");
	}
	DPRINTF("SaveDupInfo Writing files")
	fprintf(timesfile, "# timecode format v2\n");
	fflush(timesfile);
	int n;
	for(n=0;n<vi.num_frames;++n) {
		const int d = framemap[n];
		if (d>=0) {
			fprintf(dupfile, "%d\n", n);
			fflush(dupfile);
			__int64 timecode_whole =(1000 * (__int64)n * (__int64)vi.fps_denominator) / (__int64)vi.fps_numerator;

			__int64  timecode_frac = (__int64 )
					(((((((__int64)n * (__int64)1000
					* (__int64)vi.fps_denominator)
					- (timecode_whole * (__int64)vi.fps_numerator))
					* (__int64)2000000000)
					/ (__int64)vi.fps_numerator) + 1) / 2);
			fprintf(timesfile, "%I64d.%09I64d\n", timecode_whole, timecode_frac);
			fflush(timesfile);
			++framecount;
		}
	}
	dprintf("SaveDupInfo: dupinfo written, Framecount = %d",framecount);
	DPRINTF("SaveDupInfo closing files and delete [] framemap")
	fclose(dupfile);	
	fclose(timesfile);	
	delete [] framemap;	framemap=NULL;
	DPRINTF("SaveDupInfo OUT")
}


void ExactDedup::LoadDupInfo(IScriptEnvironment* env) {
	DPRINTF("LoadDupInfo IN")
	unsigned int framecount = 0, i = 0;
    FILE *dupfile = NULL;
	DPRINTF("LoadDupInfo Pre-Scanning dupinfo to get frame count")
	if ((dupfile=fopen(dupinfo, "r"))==NULL)
		env->ThrowError("ExactDedup: failed to open dupinfo file for reading"); 
	while (!feof(dupfile)) {
		fscanf(dupfile, "%d\n", &i);
		framecount++;    
	}
	vi.num_frames = framecount;
	fclose(dupfile);
	framemap = new int[framecount];
	if(framemap==NULL) {
		env->ThrowError("ExactDedup: failed allocating framemap"); 
	}
	DPRINTF("LoadDupInfo Re-Scanning dupinfo")
	i = 0;
	if ((dupfile=fopen(dupinfo, "r"))==NULL) {
		delete [] framemap;
		framemap=NULL;
		env->ThrowError("ExactDedup: failed to open dupinfo file for reading"); 
	}
	while (!feof(dupfile)) {
		fscanf(dupfile, "%d\n", &framemap[i++]);
	}
	dprintf("LoadDupInfo, read info for %d frames",framecount);
	fclose(dupfile);
	DPRINTF("LoadDupInfo OUT")
}



PVideoFrame __stdcall ExactDedup::GetFrame(int n, IScriptEnvironment* env) {
	n=(n<0)?0:(n>=vi.num_frames)?vi.num_frames-1:n;		// Range limit n frame to valid range
	if (firstpass) {
		PVideoFrame src = child->GetFrame(n  , env);
		if(framemap!=NULL) {							// FrameMap is still allocated and not yet written to files
			if(n==0&&prevframe==0) {
				framemap[n]=0;							// Special case frame 0
			} else if(n==prevframe) {
				dprintf("GetFrame(%d) n==prevframe, Repeat request for frame n",n);
			} else if (n != prevframe+1) {					// Must be strictly linear
				dprintf(" *** PrevFrame=%d n=%d *** n is not PrevFrame + 1",prevframe,n);
				delete [] framemap;
				framemap=NULL;
				env->ThrowError("ExactDedup: Trying to compute frames out of order. Did you try to seek during processing?");
			} else {
				prevframe = n;

				bool dup = true;

				PVideoFrame psrc			= child->GetFrame(n-1, env);
				const unsigned char *curp	= src->GetReadPtr(PLANAR_Y); 
				const unsigned int pitch	= src->GetPitch(PLANAR_Y);
				const unsigned int row_size = src->GetRowSize(PLANAR_Y);
				const unsigned int height	= src->GetHeight(PLANAR_Y);
				const unsigned char *prevp	= psrc->GetReadPtr(PLANAR_Y); 
				const unsigned int ppitch	= psrc->GetPitch(PLANAR_Y);

				//const unsigned int framesize = src->GetRowSize()*src->GetHeight();
				for (unsigned int y = 0; y < height; y++) {
					for (unsigned int x = 0; x < row_size; x++) {
						if (curp[x] != prevp[x]) {
							dup = false;
							break;
						}
					}
					if (!dup) {
						break;
					}
					curp  += pitch;
					prevp += ppitch;
				}
				if(!dup && vi.IsPlanar()) {
					const unsigned int row_sizeUV = src->GetRowSize(PLANAR_U);
					if(row_sizeUV>0) {
						const unsigned char *curpU  = src->GetReadPtr(PLANAR_U); 
						const unsigned char *curpV  = src->GetReadPtr(PLANAR_V); 
						const unsigned char *prevpU = psrc->GetReadPtr(PLANAR_U); 
						const unsigned char *prevpV = psrc->GetReadPtr(PLANAR_V); 
						const unsigned int pitchUV = src->GetPitch(PLANAR_U);
						const unsigned int heightUV = src->GetHeight(PLANAR_U);
						const unsigned int ppitchUV = psrc->GetPitch(PLANAR_U);
						for (unsigned int y = 0; y < heightUV; y++) {
							for (unsigned int x = 0; x < row_sizeUV; x++) {
								if (curpU[x] != prevpU[x] || curpV[x] != prevpV[x]) {
									dup = false;
									break;
								}
							}
							if (!dup) {
								break;
							}
							curpU  += pitchUV;
							curpV  += pitchUV;
							prevpU += ppitchUV;
							prevpV += ppitchUV;
						}
					}
				}

				if (dup) {
					curdupcount++;
					if ((maxdupcount > 0 && (curdupcount >= maxdupcount)) || (n == vi.num_frames-1 && keeplastframe)) {
						curdupcount = 0;
						dup = false;
					}
				}

				if(!dup) {
					if(curdupcount > 0 && keeplastframe) {
						framemap[n-1]=0;
					}
					framemap[n]=0;
					curdupcount = 0;
				} else {
					framemap[n]=-1;		
				}

			}
			if(n==vi.num_frames-1) {
				dprintf("GetFrame(%d) Pass 1, Last Frame, Calling SaveDupInfo",n);
				SaveDupInfo(env);
				IsWritten=true;
			}
		} else {
			DPRINTF("GetFrame(%d) Pass 1, framemap==NULL (OK if files were produced)",n)
		} // End framemap!=NULL
		return src;
	}
	int newn=framemap[n];
	PVideoFrame src = child->GetFrame(newn  , env);
	if(show) {
		env->MakeWritable(&src);
		char buf[256];
		sprintf(buf,"%d ] Using %d",n,newn);
		if(vi.IsPlanar())		DrawStringPlanar(src, 0,0, buf);
		else if(vi.IsYUY2())	DrawStringYUY2(src, 0,0, buf);
		else if(vi.IsRGB32())	DrawStringRGB32(src, 0,0, buf);
		else if(vi.IsRGB24())	DrawStringRGB24(src, 0,0, buf);
	}
	return src;
}

AVSValue __cdecl Create_ExactDedup(AVSValue args, void* user_data, IScriptEnvironment* env) {
	DPRINTF("Create_ExactDedup IN")
	const char *myName="ExactDeDup: ";
    bool firstpass = args[1].AsBool(true);
	//
	char DupeInfoFullPath[PATH_BUF_LEN];
	char TimesFullPath[PATH_BUF_LEN];
	//
    const char * dup_s = args[2].AsString("");			// dupinfo
    const char * tim_s = args[3].AsString("");			// times
	//
	if(dup_s[0]=='\0')		dup_s = "dupinfo.txt";
	if(tim_s[0]=='\0')		tim_s = "times.txt";
	if(_fullpath(DupeInfoFullPath, dup_s, PATH_BUF_LEN ) == NULL )		env->ThrowError("%sCannot get dupinfo full path.",myName);
	dprintf("FullPath Dupinfo ='%s",DupeInfoFullPath);
	if(_fullpath(TimesFullPath,    tim_s, PATH_BUF_LEN ) == NULL )		env->ThrowError("%sCannot get times full path.",myName);
	dprintf("FullPath Times ='%s",TimesFullPath);
	//
	if(firstpass) {
		dprintf("%sFirstPass, Deleting dupinfo '%s'",myName,DupeInfoFullPath);
		remove(DupeInfoFullPath);
		dprintf("%sFirstPass, Deleting times '%s'",myName,TimesFullPath);
		remove(TimesFullPath);
	}
	int maxdupcount = args[4].AsInt(20);
	maxdupcount = (maxdupcount < 0) ? 0 : maxdupcount;
	AVSValue ret = new ExactDedup(args[0].AsClip(),
        firstpass,										// firstpass
        DupeInfoFullPath,								// dupinfo
        TimesFullPath,									// times
        maxdupcount,									// maxdupcount
        args[5].AsBool(false),							// keeplastframe
        args[6].AsBool(false),							// show
        env);
	DPRINTF("Create_ExactDedup OUT")
	return ret;
}


// The following function is the function that actually registers the filter in AviSynth
// It is called automatically, when the plugin is loaded to see which functions this filter contains.
#ifdef AVISYNTH_PLUGIN_25
	extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) {
#else
	/* New 2.6 requirement!!! */
	// Declare and initialise server pointers static storage.
	const AVS_Linkage *AVS_linkage = 0;

	/* New 2.6 requirement!!! */
	// DLL entry point called from LoadPlugin() to setup a user plugin.
	extern "C" __declspec(dllexport) const char* __stdcall
			AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors) {

				/* New 2.6 requirment!!! */
				// Save the server pointers.
				AVS_linkage = vectors;
#endif
	env->AddFunction("ExactDeDup", "c[firstpass]b[dupinfo]s[times]s[maxdupcount]i[keeplastframe]b[show]b",
         Create_ExactDedup, 0);
	// The AddFunction has the following paramters:
	// AddFunction(Filtername , Arguments, Function to call,0);
    
	// Arguments is a string that defines the types and optional nicknames of the arguments for you filter.
	// c - Video Clip
	// i - Integer number
	// f - Float number
	// s - String
	// b - boolean
	// . - Any type (dot)
	//      Array Specifiers
	// i* - Integer Array, zero or more
	// i+ - Integer Array, one or more
	// .* - Any type Array, zero or more
	// .+ - Any type Array, one or more
	//      Etc
    return "'ExactDeDup' ExactDeDup plugin";
	// A freeform name of the plugin.
}
