RemapFrames for avisynth2.6/avisynth+

Requirements:
	- avisynth2.60/avisynth+r1576 or later.
	- WindowsVista sp2 or later.
	- Visual C++ Redistributable Packages for Visual Studio 2015.
