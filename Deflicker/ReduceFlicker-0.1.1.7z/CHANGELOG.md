##### 0.1.1:
    Separated SSE2 and AVX2 code.
    Registered as MT_NICE_FILTER.
    Added support for all planar formats.

##### 0.1.0:
    Added version.
    Added support for 10..32-bit.
    Fixed frame access when strength=2, raccess=false.
    Added "luma" parameter.
    Allowed AVX2 routine for AviSynth 2.6.

##### v0.0.1:
    Added support for AviSynth+ v8 interface.
    Removed /arch:AVX2 requirement to use the AVX2 routine.

##### v0.0.0:
    Initial release.