##### 0.6.1:
    Throw error if YUV420 height is not mod4.

##### 0.6.0:
    Added parameter opt.
    Applied the changes from VS SangNom r42.
    Separated SSE2 code.

##### 0.5.0:
    Fixed order=0.
    Added backward compatible SangNom function.

##### 0.4.0:
    Port of the VapourSynth plugin SangNom r41.