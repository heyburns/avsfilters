#include <windows.h>
#include <stdio.h>
#include <commctrl.h>

#include "ccd.h"
#include "math.h"
#include <process.h>

#include "vdvideofilt.h"
#include "vdplugin.h"

struct MyFilterData
{
    IVDXFilterPreview	*ifp;
    int Level;
    int Old_Level;
    int Disable;
    int Noise;
    int speed;
    int count;
	double Table [20];
};

typedef struct Data_t
{
    uint32 *src;
    uint32 *dst;
    int Porog;
    int th;
    int tw;
    int i_modulo;
	int count_thread; // ���-�� �������
    int number_thread; // ����� ������
//    int noise;
	MyFilterData *mfd2;
} Data_t;

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

int RunProc(const VDXFilterActivation *fa, const VDXFilterFunctions *ff);
long ParamProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff);
int configProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff, VDXHWND hwndParent);
void StringProc(const VDXFilterActivation *fa, const VDXFilterFunctions *ff, char *str);
static void script_config(IVDXScriptInterpreter *isi, void *lpVoid, VDXScriptValue *argv, int argc);
bool FssProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff, char *buf, int buflen);
int InitProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff);
unsigned __stdcall progres(void *d);
void progres_2(Data_t *d);
void progres_noise(Data_t *d);
int R_G_B(int r, int g, int b);
