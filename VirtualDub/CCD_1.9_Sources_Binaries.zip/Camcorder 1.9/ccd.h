#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif


#define IDD_FILTER 1000
#define IDC_GRP1 1002
#define IDC_GRP2 1003
#define IDC_GRP3 1012
#define IDC_SLIDER_LEVEL 1001
#define IDPREVIEW 1004
#define ID_OK 1005
#define ID_CANCEL 1006
#define IDC_NOISE 1007
#define IDC_DISABLE 1008
#define IDC_STC1 1009
#define IDC_SPEED 1010
#define IDC_LABEL 1011
#define IDC_STC2 1013

