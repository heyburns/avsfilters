#include "main.h"

int RunProc(const VDXFilterActivation *fa, const VDXFilterFunctions *ff) {
	MyFilterData *mfd = (MyFilterData *)fa->filter_data;
	uint32 *src, *dst;
	src = (uint32 *)fa->src.data;
	dst = (uint32 *)fa->dst.data;
	int i_modulo=((fa->src.modulo)>>2)+fa->src.w;
	unsigned threadID;
	int count=mfd->count;
	if (!mfd->speed)count=1;
	//count=1;
	HANDLE hThread1,hThread2,hThread3,hThread4;
	Data_t d1,d2,d3,d4;
	d1.dst=dst;
	d2.dst=dst;
	d3.dst=dst;
	d4.dst=dst;
	d1.src=src;
	d2.src=src;
	d3.src=src;
	d4.src=src;
	d1.Porog=mfd->Level*30;
	d2.Porog=mfd->Level*30;
	d3.Porog=mfd->Level*30;
	d4.Porog=mfd->Level*30;
	d1.th=fa->src.h;
	d2.th=fa->src.h;
	d3.th=fa->src.h;
	d4.th=fa->src.h;
	d1.tw=fa->src.w;
	d2.tw=fa->src.w;
	d3.tw=fa->src.w;
	d4.tw=fa->src.w;
	d1.i_modulo=i_modulo;
	d2.i_modulo=i_modulo;
	d3.i_modulo=i_modulo;
	d4.i_modulo=i_modulo;
	d1.count_thread=count;
	d2.count_thread=count;
	d3.count_thread=count;
	d4.count_thread=count;
	d1.number_thread=0;
	d2.number_thread=1;
	d3.number_thread=2;
	d4.number_thread=3;
	d1.mfd2=mfd;
	d2.mfd2=mfd;
	d3.mfd2=mfd;
	d4.mfd2=mfd;
	int mode=0;
	if (mfd->Noise)mode=1;
	if (mfd->Disable)mode=2;
	int th=fa->src.h;
	int tw=fa->src.w;
	int thtw=th*tw;

	switch (mode) {
		case 1:
			progres_noise((Data_t*) &d1);
			break;
		case 2:
			for (int g=0; g<thtw; g++) {
				dst[g]=src[g];
			}
			break;
		case 0:
			switch (count) {
				case 1:
					//         progres_2((Data_t*) &d1); // для без потоков

					hThread1 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d1, 0, &threadID);
					WaitForSingleObject( hThread1, INFINITE );
					CloseHandle( hThread1);


					break;
				case 2:
					hThread1 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d1, 0, &threadID);
					hThread2 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d2, 0, &threadID);
					WaitForSingleObject( hThread1, INFINITE );
					WaitForSingleObject( hThread2, INFINITE );
					CloseHandle( hThread1);
					CloseHandle( hThread2);
					break;
				case 3:
					hThread1 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d1, 0, &threadID);
					hThread2 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d2, 0, &threadID);
					hThread3 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d3, 0, &threadID);
					WaitForSingleObject( hThread1, INFINITE );
					WaitForSingleObject( hThread2, INFINITE );
					WaitForSingleObject( hThread3, INFINITE );
					CloseHandle( hThread1);
					CloseHandle( hThread2);
					CloseHandle( hThread3);
					break;
				case 4:
					hThread1 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d1, 0, &threadID);
					hThread2 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d2, 0, &threadID);
					hThread3 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d3, 0, &threadID);
					hThread4 = (HANDLE)_beginthreadex( NULL, 0, progres, (void *) &d4, 0, &threadID);
					WaitForSingleObject( hThread1, INFINITE );
					WaitForSingleObject( hThread2, INFINITE );
					WaitForSingleObject( hThread3, INFINITE );
					WaitForSingleObject( hThread4, INFINITE );
					CloseHandle( hThread1);
					CloseHandle( hThread2);
					CloseHandle( hThread3);
					CloseHandle( hThread4);
					break;
			}
	}
	return 0;
}
