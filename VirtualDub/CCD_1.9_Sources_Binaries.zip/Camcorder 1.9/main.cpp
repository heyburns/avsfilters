/*
Stolyarevskiy Sergey, acobw.narod.ru

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.



18.11.2007 V1.0 version.
24.11.2007 V1.1
26.11.2007 V1.2
28.11.2007 V1.3
10.11.2007 V1.4 �������� ��� � ��������������� �������� �����������
27.02.2009 V1.5 ���������������
25.04.2009 V1.6 �����������, ����������� ������
04.08.2018 V1.8 ������� �� minGW, 64 ���
27.06.2020 V1.9 ��������� ��������� �����
*/

#include "main.h"
HINSTANCE g_hInst;

BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        g_hInst=hInst;
//  InitCommonControls();
        break;
    case DLL_PROCESS_DETACH:
        break;
    case DLL_THREAD_ATTACH:
        break;
    case DLL_THREAD_DETACH:
        break;
    }
    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}

VDXScriptFunctionDef script_functions[] =
{
    { (VDXScriptFunctionPtr)script_config, "Config", "0ii" },
    { NULL, NULL, NULL },
};
VDXScriptObject script_obj = { NULL, script_functions, NULL };

static struct VDXFilterDefinition g_myFilterDef=
{
    0,0, NULL,       // next, prev, module
    "Camcorder color denoise 1.9",             // name
    "Removing the colour noise of the matrix of the video camera, multithreading version 1.9",     // desc
    "Stolyarevskiy Sergey", // maker
    NULL,                   // private_data
    sizeof(MyFilterData),   // inst_data_size
    InitProc,               // initProc
    NULL,                   // deinitProc
    RunProc,				// runProc
    NULL,				    // paramProc
    configProc,				// configProc
    StringProc,				// stringProc
    NULL,					// startProc
    NULL,					// endProc
    &script_obj,			// script_obj
    FssProc,				// fssProc
    NULL,
    NULL,
    NULL,
};

extern VDXFilterDefinition g_myFilterDef;
VDXFilterDefinition *g_registeredFilterDef;
///////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) int __cdecl VirtualdubFilterModuleInit2(struct VDXFilterModule *fm, const VDXFilterFunctions *ff, int& vdfd_ver, int& vdfd_compat)
{
    g_registeredFilterDef = ff->addFilter(fm, &g_myFilterDef, sizeof(VDXFilterDefinition));

    vdfd_ver        = VIRTUALDUB_FILTERDEF_VERSION;
    vdfd_compat     = 8;    // we need this version for copy constructor support

    return 0;
}

extern "C" __declspec(dllexport) void __cdecl VirtualdubFilterModuleDeinit(struct VDXFilterModule *fm, const VDXFilterFunctions *ff)
{
    // Note: This must be the pointer returned from addFilter(), NOT your original
    // declaration.
    ff->removeFilter(g_registeredFilterDef);
}

int InitProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff)
{
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    mfd->Level=30;
    mfd->Disable=0;
    mfd->Noise=0;
    mfd->Table[0]=1;
    SYSTEM_INFO siSysInfo;
    GetSystemInfo(&siSysInfo);
    mfd->count =siSysInfo.dwNumberOfProcessors;
    if (mfd->count>4) mfd->count=4;
    if (mfd->count>1)
    {
        mfd->speed=1;
    }
    else
    {
        mfd->speed=0;
    }
    for (int i=1;i<20;i++) mfd->Table[i]=1/(double)i;
    return 0;
}

INT_PTR CALLBACK ConfigDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    MyFilterData *mfd = (MyFilterData *)GetWindowLongPtr(hdlg, DWLP_USER);
    switch (msg)
    {

    case WM_INITDIALOG:
        SetWindowLongPtr(hdlg, DWLP_USER, (LONG_PTR)lParam);
        mfd = (MyFilterData *)lParam;

        SendDlgItemMessage (hdlg, IDC_SLIDER_LEVEL, TBM_SETTICFREQ, 5, 0);
        SendDlgItemMessage (hdlg, IDC_SLIDER_LEVEL, TBM_SETRANGE, false, MAKELONG (0, 100));
        SendDlgItemMessage (hdlg, IDC_SLIDER_LEVEL, TBM_SETPOS, true, mfd->Level);

        CheckDlgButton(hdlg, IDC_NOISE, mfd->Noise?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg, IDC_DISABLE, mfd->Disable?BST_CHECKED:BST_UNCHECKED);
        CheckDlgButton(hdlg, IDC_SPEED, mfd->speed?BST_CHECKED:BST_UNCHECKED);

        mfd->ifp->InitButton((VDXHWND)GetDlgItem(hdlg, IDPREVIEW));
        mfd->Old_Level=mfd->Level;
        if (mfd->count==1)
        {
            EnableWindow(GetDlgItem(hdlg, IDC_SPEED), FALSE);
        }
        SetDlgItemInt(hdlg, IDC_LABEL, mfd->count , FALSE);
        return TRUE;

    case WM_HSCROLL:
        if ((HWND) lParam == GetDlgItem(hdlg, IDC_SLIDER_LEVEL))
        {
            mfd->Level=SendDlgItemMessage (hdlg, IDC_SLIDER_LEVEL, TBM_GETPOS, 0, 0);
            mfd->ifp->RedoFrame();
        }

        break;
    case WM_COMMAND:

        switch (LOWORD(wParam))
        {
        case ID_OK:
            mfd->Noise= !!IsDlgButtonChecked(hdlg, IDC_NOISE);
            mfd->Level=SendDlgItemMessage (hdlg, IDC_SLIDER_LEVEL, TBM_GETPOS, 0, 0);
            EndDialog(hdlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        case IDPREVIEW:
            mfd->ifp->Toggle((VDXHWND)hdlg);
            mfd->ifp->RedoFrame();
            break;
        case IDC_NOISE:
            mfd->Noise= !!IsDlgButtonChecked(hdlg, IDC_NOISE);
            mfd->ifp->RedoFrame();
            break;
        case IDC_DISABLE:
            mfd->Disable = !!IsDlgButtonChecked(hdlg, IDC_DISABLE);
            mfd->ifp->RedoFrame();
            break;
        case IDC_SPEED:
            mfd->speed  = !!IsDlgButtonChecked(hdlg, IDC_SPEED);
            mfd->ifp->RedoFrame();
            break;
//            return TRUE;
        case ID_CANCEL:
            mfd->Level=mfd->Old_Level;
            EndDialog(hdlg, 1);
            return FALSE;
        }
        break;
    }
    return FALSE;
}

int configProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff, VDXHWND hwndParent)
{
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    mfd->ifp = fa->ifp;
    int res;
    res=DialogBoxParam(g_hInst, MAKEINTRESOURCE(IDD_FILTER), (HWND)hwndParent,
                       ConfigDlgProc, (LPARAM)mfd);
    return !res;
}
void StringProc(const VDXFilterActivation *fa, const VDXFilterFunctions *ff, char *str)
{
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    sprintf(str, " (level-%d, threads-%d)", mfd->Level,mfd->count);
}
static void script_config(IVDXScriptInterpreter *isi, void *lpVoid, VDXScriptValue *argv, int argc)
{
    VDXFilterActivation *fa = (VDXFilterActivation *)lpVoid;
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    mfd->Level=argv[0].asInt();
    mfd->speed=argv[1].asInt();
}
bool FssProc(VDXFilterActivation *fa, const VDXFilterFunctions *ff, char *buf, int buflen)
{
    MyFilterData *mfd = (MyFilterData *)fa->filter_data;
    _snprintf(buf, buflen, "Config(%d,%d)", mfd->Level,mfd->speed );
    return true;
}

int R_G_B(int r, int g, int b)
{
    return (r<<16 | g<<8 | b);
}
