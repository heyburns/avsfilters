#include "main.h"

void progres_noise(Data_t *d2)
{
    uint32 *src, *dst;

    src=d2->src;
    dst=d2->dst;
    int count_thread=1  ; // ���-�� �������
    int number_thread=0 ; // ����� ������

    int th=d2->th;
    int tw=d2->tw;

    for (int yt = number_thread; yt < th; yt+=count_thread)
    {
            int ys=yt>11?yt-12:yt;
            int ye=yt<th-12?yt+12:yt;

		for (int xt = 0; xt < tw; xt++)
        {

			int i=yt*d2->i_modulo+xt;
            int Pt=src[i];

            int R=(Pt>>16)&0xff;
            int G=(Pt>>8)&0xff;
            int B=Pt&0xff;

            int corR=R;
            int corG=G;
            int corB=B;

            int n=1;

                int xs=xt>11?xt-12:xt;
                int xe=xt<tw-12?xt+12:xt;

			for (int y=ys;y<=ye;y+=8)
            {
				int z=y*d2->i_modulo;
                for (int x=xs;x<=xe;x+=8)
                {
                    int corR1=((src[z+x])>>16)&0xff;
                    int corG1=((src[z+x])>>8)&0xff;
                    int corB1=(src[z+x])&0xff;
                    if (((corR1-R)*(corR1-R)+(corG1-G)*(corG1-G)+(corB1-B)*(corB1-B))<d2->Porog)
                    {
                        corR+=corR1;
                        corG+=corG1;
                        corB+=corB1;
                        n++;
                    }
                }
            }

            double CR=corR*d2->mfd2->Table[n];
            double CG=corG*d2->mfd2->Table[n];
            double CB=corB*d2->mfd2->Table[n];

            double YA=0.299*CR+0.587*CG+0.114*CB;
            double UA = -0.147*CR - 0.289*CG + 0.436*CB;
            double VA =  0.615*CR - 0.515*CG + 0.100*CB;
            double Y = 0.299*R + 0.587*G + 0.114*B;

            CR = 0.7720*Y -0.4633*UA + 1.1400*VA +0.5;
            CG = 1.1161*Y -0.1587*UA - 0.5806*VA +0.5;
            CB = 1.0001*Y +2.0322*UA - 0.0005*VA +0.5;

            CR=((double)R-CR)*10+127;
            CG=((double)G-CG)*10+127;
            CB=((double)B-CB)*10+127;

            if (CR<0) CR=0;
            else if (CR>255) CR=255;
            if (CG<0) CG=0;
            else if (CG>255) CG=255;
            if (CB<0) CB=0;
            else if (CB>255) CB=255;

            dst[i]=R_G_B((int)CR,(int)CG,(int)CB);
        }
    }
}
