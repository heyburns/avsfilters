// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// Format: https://msdn.microsoft.com/en-us/library/windows/desktop/ms647550%28v=vs.85%29.aspx
// Example: ds("pitch= %d, %p", pitch, ptr);

inline void ds(const char* format, ...)
{
	va_list args;
	char buf_1024[1024];
	va_start(args, format);
	wvsprintfA(buf_1024, format, args);
	va_end(args);
	OutputDebugStringA(buf_1024);
}

#define ba \
	LARGE_INTEGER time1; \
	LARGE_INTEGER time2; \
	LARGE_INTEGER ticks_per_second; \
	QueryPerformanceCounter(&time1);

#define bb \
	QueryPerformanceCounter(&time2); \
	QueryPerformanceFrequency(&ticks_per_second); \
	double seconds = (double)(time2.QuadPart - time1.QuadPart) / ticks_per_second.QuadPart; \
	ds("Time: %9d mcs, %9d fps\n", int(seconds*1000000.0), int(1.0/seconds));
