// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>

#include "clamp.hpp"
#include "dev.hpp"

namespace ClampHDR {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

struct Args {
	float a[3];
	float b[3];
	uint8_t a8[3];
	uint8_t b8[3];
	uint16_t a16[3];
	uint16_t b16[3];
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_yuv_8(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane);
		uint8_t* ptr = frame.src->GetWritePtr(plane);
		const uint8_t a = args->a8[p];
		const uint8_t b = args->b8[p];
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				ptr[x] = clamp_uint8(ptr[x], a, b);
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_yuv_88(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane);
		uint8_t* msb = frame.src->GetWritePtr(plane);
		uint8_t* lsb = msb + pitch*height;
		const uint16_t a = args->a16[p];
		const uint16_t b = args->b16[p];
		const uint8_t a8 = args->a8[p];
		const uint8_t b8 = args->b8[p];
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				const uint8_t msb_v = msb[x];
				if (not_need_clamp_uint88(msb_v, a8, b8)) // Up to 2x speedup for 88
					continue;
				const uint8_t lsb_v = lsb[x];
				const uint16_t out = clamp_uint88(msb_v, lsb_v, a, b);
				msb[x] = out >> 8;
				lsb[x] = (uint8_t)out;
			}
			msb += pitch;
			lsb += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_yuv_16(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane) >> 1;
		uint16_t* ptr = (uint16_t*)frame.src->GetWritePtr(plane);
		const uint16_t a = args->a16[p];
		const uint16_t b = args->b16[p];
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				ptr[x] = clamp_uint16(ptr[x], a, b);
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_yuv_32(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane) >> 2;
		float* ptr = (float*)frame.src->GetWritePtr(plane);
		const float a = args->a[p];
		const float b = args->b[p];
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				ptr[x] = clamp_float(ptr[x], a, b);
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("ClampHDR: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("ClampHDR: RGB is not supported.");

	int arg = 0;
	m_args.a[0] = (float)args[++arg].AsFloat(16.0);
	m_args.b[0] = (float)args[++arg].AsFloat(235.0);
	m_args.a[1] = (float)args[++arg].AsFloat(16.0);
	m_args.b[1] = (float)args[++arg].AsFloat(240.0);
	m_args.a[2] = (float)args[++arg].AsFloat(16.0);
	m_args.b[2] = (float)args[++arg].AsFloat(240.0);
	const int bitdepth = args[++arg].AsInt(8);

	const int pmax = vi.IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		// Both versions required for 88
		m_args.a16[p] = (uint16_t)(m_args.a[p] * 256.0f);
		m_args.b16[p] = (uint16_t)(m_args.b[p] * 256.0f);
		m_args.a8[p] = (uint8_t)m_args.a[p];
		m_args.b8[p] = (uint8_t)m_args.b[p];
	}

	if (bitdepth == 8) {
		m_filter = filter_yuv_8;
	} else if (bitdepth == 88) {
		m_filter = filter_yuv_88;
	} else if (bitdepth == 16) {
		m_filter = filter_yuv_16;
	} else if (bitdepth == 32) {
		m_filter = filter_yuv_32;
	} else {
		env->ThrowError("ClampHDR: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_ClampHDR(IScriptEnvironment* env)
{
	// ClampHDR(ay=16, by=235, au=16, bu=240, av=16, bv=240, bitdepth=8)
    env->AddFunction("ClampHDR", "c[ay]f[by]f[au]f[bu]f[av]f[bv]f[bitdepth]i", ClampHDR::Create_Filter, 0);
}
