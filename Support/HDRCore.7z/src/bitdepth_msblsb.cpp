// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>

#include "dev.hpp"

namespace BitdepthMsbLsb {

struct Frame {
	PVideoFrame msb;
	PVideoFrame lsb;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

typedef void (*ConvertFunc)(Frame&);

void convert_yuv_8(Frame& frame) {
	frame.dst = frame.msb;
}

void convert_yuv_88(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.msb->GetReadPtr(plane);
		const uint8_t* lsb = frame.lsb->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int msb_pitch = frame.msb->GetPitch(plane);
		const int lsb_pitch = frame.lsb->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int msb_rowsize = frame.msb->GetRowSize() >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int lsb_rowsize = frame.lsb->GetRowSize() >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		frame.env->BitBlt(dst, dst_pitch, msb, msb_pitch, msb_rowsize, height);
		const int half_pitch = dst_pitch*height;
		frame.env->BitBlt(dst+half_pitch, dst_pitch, lsb, lsb_pitch, lsb_rowsize, height);
	}
}

void convert_yuv_16(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.msb->GetReadPtr(plane);
		const uint8_t* lsb = frame.lsb->GetReadPtr(plane);
		uint16_t* dst = (uint16_t*)frame.dst->GetWritePtr(plane);
		const int msb_pitch = frame.msb->GetPitch(plane);
		const int lsb_pitch = frame.lsb->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 1;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = msb[x] << 8 | lsb[x];
			}
			msb += msb_pitch;
			lsb += lsb_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_32(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.msb->GetReadPtr(plane);
		const uint8_t* lsb = frame.lsb->GetReadPtr(plane);
		float* dst = (float*)frame.dst->GetWritePtr(plane);
		const int msb_pitch = frame.msb->GetPitch(plane);
		const int lsb_pitch = frame.lsb->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 2;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = float(msb[x] << 8 | lsb[x]) * (1.0f/256.0f);
			}
			msb += msb_pitch;
			lsb += lsb_pitch;
			dst += dst_pitch;
		}
	}
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	PClip m_lsb;
	ConvertFunc m_convert;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.msb = child->GetFrame(n, env);
	frame.lsb = m_lsb->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_convert(frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("BitdepthMsbLsb: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("BitdepthMsbLsb: RGB is not supported.");
	
	int arg = 0;
	m_lsb = args[++arg].AsClip();
	const int bitdepth = args[++arg].AsInt(88);

	switch (bitdepth) {
	case 8:
		m_convert = convert_yuv_8;
		break;
	case 88:
		vi.height = vi.height<<1;
		m_convert = convert_yuv_88;
		break;
	case 16:
		vi.width = vi.width<<1;
		m_convert = convert_yuv_16;
		break;
	case 32:
		vi.width = vi.width<<2;
		m_convert = convert_yuv_32;
		break;
	default:
		env->ThrowError("BitdepthMsbLsb: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_BitdepthMsbLsb(IScriptEnvironment* env)
{
	// BitdepthMsbLsb(msb, lsb, bitdepth=88)
    env->AddFunction("BitdepthMsbLsb", "c[lsb]c[bitdepth]i", BitdepthMsbLsb::Create_Filter, 0);
}
