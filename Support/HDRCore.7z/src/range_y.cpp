// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"

namespace RangeY {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

struct Args {
	float ki1;
	float ki2;
	float ko1;
	float ko2;
	float g;
	union { uint8_t* uint8; uint16_t* uint16; float* flt; } lut;
	Args() { lut.uint8 = nullptr; };
	~Args() { _aligned_free(lut.uint8); }
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_y_8_truncate_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			ptr[x] = args->lut.uint8[ptr[x]];
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_y_8_sierra_lut(Args* args, Frame& frame) {
	const size_t dither_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_w*2);
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	float* dither_a = dither+2;
	float* dither_b = dither+2+width;
	memset(dither_a, 0, dither_w);
	for (int y = 0; y < height; ++y) {
		memset(dither_b, 0, dither_w);
		for (int x = 0; x < width; ++x) {
			float out = args->lut.flt[ptr[x]];
			// Out Sierra 2-4A dithered
			out += dither_a[x+1];
			const uint8_t out_trunc = clamp8(out + 0.5f);
			const float dither_error = out - out_trunc;
			const float dither_error_050 = dither_error * 0.5f;
			const float dither_error_025 = dither_error * 0.25f;
			dither_a[x+2] += dither_error_050;
			dither_b[x]   += dither_error_025;
			dither_b[x+1] += dither_error_025;
			ptr[x] = out_trunc;
		}
		ptr += pitch;
		// Switch dither tables
		float* dither_temp = dither_b;
		dither_b = dither_a;
		dither_a = dither_temp;
	}
	frame.dst = frame.src;
}

void filter_y_88_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height >> 1;
	const int pitch = frame.src->GetPitch();
	uint8_t* msb = frame.src->GetWritePtr();
	uint8_t* lsb = msb + pitch*height;
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			uint16_t out = args->lut.uint16[msb[x]<<8 | lsb[x]];
			msb[x] = out >> 8;
			lsb[x] = (uint8_t)out;
		}
		msb += pitch;
		lsb += pitch;
	}
	frame.dst = frame.src;
}

void filter_y_16_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 1;
	uint16_t* ptr = (uint16_t*)frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			ptr[x] = args->lut.uint16[ptr[x]];
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_y_32_gamma(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 2;
	float* ptr = (float*)frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = ptr[x];
			out = out * args->ki1 + args->ki2; // 0..1
			out = (out < 0.0f) ? -powf(-out, args->g) : powf(out, args->g); // gamma
			out = out * args->ko1 + args->ko2; // ao..bo
			ptr[x] = out;
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_y_32_no_gamma(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 2;
	float* ptr = (float*)frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = ptr[x];
			out = out * args->ki1 + args->ki2; // 0..1
			out = out * args->ko1 + args->ko2; // ao..bo
			ptr[x] = out;
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("RangeY: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("RangeY: RGB is not supported.");

	int arg = 0;
	const float a = (float)args[++arg].AsFloat(16.0);
	const float b = (float)args[++arg].AsFloat(235.0);
	if (a == b)
		env->ThrowError("RangeY: Incorrect a==b\n");
	const float ao = (float)args[++arg].AsFloat(16.0);
	const float bo = (float)args[++arg].AsFloat(235.0);
	m_args.g = (float)args[++arg].AsFloat(1.0);
	if (fabs(m_args.g - 0.0f) <= FLT_EPSILON)
		env->ThrowError("RangeY: Incorrect g==0.0\n");
	m_args.g = 1.0f/m_args.g;
	int mode = args[++arg].AsInt(1);
	const int bitdepth = args[++arg].AsInt(8);

	if (bitdepth == 8) {
		if (mode == 0) { // Truncate
			m_args.ki1 = 1.0f/(b-a);
			m_args.ki2 = -a/(b-a);
			m_args.ko1 = bo-ao;
			m_args.ko2 = ao + 0.5f; // Fix rounding
			m_args.lut.uint8 = (uint8_t*)_aligned_malloc(256, 16);
			float i_float = 0.0f;
			for (int i=0; i<256; ++i) {
				float out = i_float;
				out = out * m_args.ki1 + m_args.ki2; // 0..1
				out = (out < 0.0f) ? -powf(-out, m_args.g) : powf(out, m_args.g); // gamma
				out = out * m_args.ko1 + m_args.ko2; // ao..bo
				m_args.lut.uint8[i] = clamp8(out);
				i_float += 1.0f;
			}
			m_filter = filter_y_8_truncate_lut;
		} else { // Dither
			m_args.ki1 = 1.0f/(b-a);
			m_args.ki2 = -a/(b-a);
			m_args.ko1 = bo-ao;
			m_args.ko2 = ao;
			m_args.lut.flt = (float*)_aligned_malloc(256*sizeof(float), 16);
			float i_float = 0.0f;
			for (int i=0; i<256; ++i) {
				float out = i_float;
				out = out * m_args.ki1 + m_args.ki2; // 0..1
				out = (out < 0.0f) ? -powf(-out, m_args.g) : powf(out, m_args.g); // gamma
				out = out * m_args.ko1 + m_args.ko2; // ao..bo
				m_args.lut.flt[i] = clamp_float(out, 0.0f, 255.0f);
				i_float += 1.0f;
			}
			m_filter = filter_y_8_sierra_lut;
		}
	} else if ((bitdepth == 88) || (bitdepth == 16)) {
		m_args.ki1 = 1.0f/256.0f/(b-a);
		m_args.ki2 = -a/(b-a);
		m_args.ko1 = (bo-ao)*256.0f;
		m_args.ko2 = ao*256.0f + 0.5f; // Fix rounding
		m_args.lut.uint16 = (uint16_t*)_aligned_malloc(256*256*2, 16);
		float i_float = 0.0f;
		for (int i=0; i<256*256; ++i) {
			float out = i_float;
			out = out * m_args.ki1 + m_args.ki2; // 0..1
			out = (out < 0.0f) ? -powf(-out, m_args.g) : powf(out, m_args.g); // gamma
			out = out * m_args.ko1 + m_args.ko2; // ao..bo
			m_args.lut.uint16[i] = clamp16(out);
			i_float += 1.0f;
		}
		if (bitdepth == 88)
			m_filter = filter_y_88_lut;
		else
			m_filter = filter_y_16_lut;
	} else if (bitdepth == 32) {
		m_args.ki1 = 1.0f/(b-a);
		m_args.ki2 = -a/(b-a);
		m_args.ko1 = bo-ao;
		m_args.ko2 = ao;
		if (fabs(m_args.g - 1.0f) <= FLT_EPSILON)
			m_filter = filter_y_32_no_gamma;
		else
			m_filter = filter_y_32_gamma;
	} else {
		env->ThrowError("RangeY: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_RangeY(IScriptEnvironment* env)
{
	// RangeY(a=16, b=235, ao=16, bo=235, g=1.0, mode=1, bitdepth=8)
    env->AddFunction("RangeY", "c[a]f[b]f[ao]f[bo]f[g]f[mode]i[bitdepth]i", RangeY::Create_Filter, 0);
}
