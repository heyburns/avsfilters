// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"

namespace RangeUV {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

struct Args {
	float ki1[2];
	float ki2[2];
	float ko1[2];
	float ko2[2];
	union { uint8_t* uint8; uint16_t* uint16; float* flt; } lut[2];
	Args() { lut[0].uint8 = nullptr; lut[1].uint8 = nullptr; };
	~Args() { _aligned_free(lut[0].uint8); _aligned_free(lut[1].uint8); }
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_uv_8_truncate_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_U, PLANAR_V};
	for (int p=0; p<2; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane);
		uint8_t* ptr = frame.src->GetWritePtr(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				ptr[x] = args->lut[p].uint8[ptr[x]];
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_uv_8_sierra_lut(Args* args, Frame& frame) {
	const int width_max = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(PLANAR_U);
	const size_t dither_w = (width_max+2)*sizeof(float);
	float* dither = (float*)alloca(dither_w*2);
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_U, PLANAR_V};
	for (int p=0; p<2; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane);
		uint8_t* ptr = frame.src->GetWritePtr(plane);
		float* dither_a = dither+2;
		float* dither_b = dither+2+width;
		memset(dither_a, 0, dither_w);
		for (int y = 0; y < height; ++y) {
			memset(dither_b, 0, dither_w);
			for (int x = 0; x < width; ++x) {
				float out = args->lut[p].flt[ptr[x]];
				// Out Sierra 2-4A dithered
				out += dither_a[x+1];
				const uint8_t out_trunc = clamp8(out + 0.5f);
				const float dither_error = out - out_trunc;
				const float dither_error_050 = dither_error * 0.5f;
				const float dither_error_025 = dither_error * 0.25f;
				dither_a[x+2] += dither_error_050;
				dither_b[x]   += dither_error_025;
				dither_b[x+1] += dither_error_025;
				ptr[x] = out_trunc;
			}
			ptr += pitch;
			// Switch dither tables
			float* dither_temp = dither_b;
			dither_b = dither_a;
			dither_a = dither_temp;
		}
	}
	frame.dst = frame.src;
}

void filter_uv_88_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_U, PLANAR_V};
	for (int p=0; p<2; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane);
		uint8_t* msb = frame.src->GetWritePtr(plane);
		uint8_t* lsb = msb + pitch*height;
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				uint16_t out = args->lut[p].uint16[msb[x]<<8 | lsb[x]];
				msb[x] = out >> 8;
				lsb[x] = (uint8_t)out;
			}
			msb += pitch;
			lsb += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_uv_16_lut(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_U, PLANAR_V};
	for (int p=0; p<2; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane) >> 1;
		uint16_t* ptr = (uint16_t*)frame.src->GetWritePtr(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				ptr[x] = args->lut[p].uint16[ptr[x]];
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

void filter_uv_32(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int planes[] = {PLANAR_U, PLANAR_V};
	for (int p=0; p<2; ++p) {
		const int plane = planes[p];
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int pitch = frame.src->GetPitch(plane) >> 2;
		float* ptr = (float*)frame.src->GetWritePtr(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				float out = ptr[x];
				out = out * args->ki1[p] + args->ki2[p]; // 0..1
				out = out * args->ko1[p] + args->ko2[p]; // ao..bo
				ptr[x] = out;
			}
			ptr += pitch;
		}
	}
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsY8())
		env->ThrowError("RangeUV: Y8 is not supported.");
	if (vi.IsYUY2())
		env->ThrowError("RangeUV: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("RangeUV: RGB is not supported.");

	float a[2];
	float b[2];
	float ao[2];
	float bo[2];
	
	int arg = 0;
	a[0] = (float)args[++arg].AsFloat(16.0);
	b[0] = (float)args[++arg].AsFloat(240.0);
	if (a[0] == b[0])
		env->ThrowError("RangeUV: Incorrect au==bu\n");
	ao[0] = (float)args[++arg].AsFloat(16.0);
	bo[0] = (float)args[++arg].AsFloat(240.0);
	a[1] = (float)args[++arg].AsFloat(16.0);
	b[1] = (float)args[++arg].AsFloat(240.0);
	if (a[1] == b[1])
		env->ThrowError("RangeUV: Incorrect av==bv\n");
	ao[1] = (float)args[++arg].AsFloat(16.0);
	bo[1] = (float)args[++arg].AsFloat(240.0);
	int mode = args[++arg].AsInt(1);
	const int bitdepth = args[++arg].AsInt(8);

	if (bitdepth == 8) {
		if (mode == 0) { // Truncate
			for (int p=0; p<2; ++p) {
				m_args.ki1[p] = 1.0f/(b[p]-a[p]);
				m_args.ki2[p] = -a[p]/(b[p]-a[p]);
				m_args.ko1[p] = bo[p]-ao[p];
				m_args.ko2[p] = ao[p] + 0.5f; // Fix rounding
				m_args.lut[p].uint8 = (uint8_t*)_aligned_malloc(256, 16);
				float i_float = 0.0f;
				for (int i=0; i<256; ++i) {
					float out = i_float;
					out = out * m_args.ki1[p] + m_args.ki2[p]; // 0..1
					out = out * m_args.ko1[p] + m_args.ko2[p]; // ao..bo
					m_args.lut[p].uint8[i] = clamp8(out);
					i_float += 1.0f;
				}
			}
			m_filter = filter_uv_8_truncate_lut;
		} else { // Dither
			for (int p=0; p<2; ++p) {
				m_args.ki1[p] = 1.0f/(b[p]-a[p]);
				m_args.ki2[p] = -a[p]/(b[p]-a[p]);
				m_args.ko1[p] = bo[p]-ao[p];
				m_args.ko2[p] = ao[p];
				m_args.lut[p].flt = (float*)_aligned_malloc(256*sizeof(float), 16);
				float i_float = 0.0f;
				for (int i=0; i<256; ++i) {
					float out = i_float;
					out = out * m_args.ki1[p] + m_args.ki2[p]; // 0..1
					out = out * m_args.ko1[p] + m_args.ko2[p]; // ao..bo
					m_args.lut[p].flt[i] = clamp_float(out, 0.0f, 255.0f);
					i_float += 1.0f;
				}
			}
			m_filter = filter_uv_8_sierra_lut;
		}
	} else if ((bitdepth == 88) || (bitdepth == 16)) {
		for (int p=0; p<2; ++p) {
			m_args.ki1[p] = 1.0f/256.0f/(b[p]-a[p]);
			m_args.ki2[p] = -a[p]/(b[p]-a[p]);
			m_args.ko1[p] = (bo[p]-ao[p])*256.0f;
			m_args.ko2[p] = ao[p]*256.0f + 0.5f; // Fix rounding
			m_args.lut[p].uint16 = (uint16_t*)_aligned_malloc(256*256*2, 16);
			float i_float = 0.0f;
			for (int i=0; i<256*256; ++i) {
				float out = i_float;
				out = out * m_args.ki1[p] + m_args.ki2[p]; // 0..1
				out = out * m_args.ko1[p] + m_args.ko2[p]; // ao..bo
				m_args.lut[p].uint16[i] = clamp16(out);
				i_float += 1.0f;
			}
		}
		if (bitdepth == 88)
			m_filter = filter_uv_88_lut;
		else
			m_filter = filter_uv_16_lut;
	} else if (bitdepth == 32) {
		for (int p=0; p<2; ++p) {
			m_args.ki1[p] = 1.0f/(b[p]-a[p]);
			m_args.ki2[p] = -a[p]/(b[p]-a[p]);
			m_args.ko1[p] = bo[p]-ao[p];
			m_args.ko2[p] = ao[p];
		}
		m_filter = filter_uv_32;
	} else {
		env->ThrowError("RangeUV: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_RangeUV(IScriptEnvironment* env)
{
	// RangeUV(au=16, bu=240, aou=16, bou=240, av=16, bv=240, aov=16, bov=240, mode=1, bitdepth=8)
    env->AddFunction("RangeUV", "c[au]f[bu]f[aou]f[bou]f[av]f[bv]f[aov]f[bov]f[mode]i[bitdepth]i", RangeUV::Create_Filter, 0);
}
