// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>

#include "clamp.hpp"
#include "dev.hpp"

namespace BitdepthMsb {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

typedef void (*ConvertFunc)(Frame&);

void convert_yuv_8(Frame& frame) {
	frame.dst = frame.src;
}

void convert_yuv_88(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* src = frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int src_rowsize = frame.src->GetRowSize() >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		frame.env->BitBlt(dst, dst_pitch, src, src_pitch, src_rowsize, height);
	}
}

void convert_yuv_16(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		uint8_t* src = (uint8_t*)frame.src->GetReadPtr(plane)+1;
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = src[x<<1];
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_32(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		float* src = (float*)frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 2;
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = clamp8(src[x]);
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	ConvertFunc m_convert;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_convert(frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("BitdepthMsb: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("BitdepthMsb: RGB is not supported.");

	int arg = 0;
	const int bitdepth = args[++arg].AsInt(88);

	switch (bitdepth) {
	case 8:
		m_convert = convert_yuv_8;
		break;
	case 88:
		vi.height = vi.height>>1;
		m_convert = convert_yuv_88;
		break;
	case 16:
		vi.width = vi.width>>1;
		m_convert = convert_yuv_16;
		break;
	case 32:
		vi.width = vi.width>>2;
		m_convert = convert_yuv_32;
		break;
	default:
		env->ThrowError("BitdepthMsb: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_BitdepthMsb(IScriptEnvironment* env)
{
	// BitdepthMsb(bitdepth=88)
    env->AddFunction("BitdepthMsb", "c[bitdepth]i", BitdepthMsb::Create_Filter, 0);
}
