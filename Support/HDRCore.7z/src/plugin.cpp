// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"

extern void Add_Bitdepth(IScriptEnvironment* env);
extern void Add_BitdepthMsbLsb(IScriptEnvironment* env);
extern void Add_BitdepthLsb(IScriptEnvironment* env);
extern void Add_BitdepthMsb(IScriptEnvironment* env);
extern void Add_ClampHDR(IScriptEnvironment* env);
extern void Add_RangeY(IScriptEnvironment* env);
extern void Add_RangeUV(IScriptEnvironment* env);

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env)
{
	Add_Bitdepth(env);
	Add_BitdepthMsbLsb(env);
	Add_BitdepthLsb(env);
	Add_BitdepthMsb(env);
	Add_ClampHDR(env);
	Add_RangeY(env);
	Add_RangeUV(env);
    return "HDRCore Library";
}
