// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>

#include "clamp.hpp"
#include "dev.hpp"

namespace Bitdepth {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

typedef void (*ConvertFunc)(Frame&);

void convert_yuv_copy(Frame& frame) {
	frame.dst = frame.src;
}

void convert_yuv_8_88(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* src = frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int src_rowsize = frame.src->GetRowSize() >> frame.vi->GetPlaneHeightSubsampling(plane);
		frame.env->BitBlt(dst, dst_pitch, src, src_pitch, src_rowsize, height);
		const int half_pitch = dst_pitch*height; 
		memset(dst+half_pitch, 0, half_pitch);
	}
}

void convert_yuv_8_16(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* src = frame.src->GetReadPtr(plane);
		uint16_t* dst = (uint16_t*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 1;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = src[x] << 8;
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_8_32(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* src = frame.src->GetReadPtr(plane);
		float* dst = (float*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 2;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = (float)src[x];
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_88_32(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.src->GetReadPtr(plane);
		float* dst = (float*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 2;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const uint8_t* lsb = msb + src_pitch*height;
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = float(msb[x] << 8 | lsb[x]) * (1.0f/256.0f);
			}
			msb += src_pitch;
			lsb += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_16_32(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint16_t* src = (uint16_t*)frame.src->GetReadPtr(plane);
		float* dst = (float*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 1;
		const int dst_pitch = frame.dst->GetPitch(plane) >> 2;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 2 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = (float)src[x] * (1.0f/256.0f);
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_32_16(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const float* src = (float*)frame.src->GetReadPtr(plane);
		uint16_t* dst = (uint16_t*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 2;
		const int dst_pitch = frame.dst->GetPitch(plane) >> 1;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = clamp16(src[x] * 256.0f);
			}
			src += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_32_88(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const float* src = (float*)frame.src->GetReadPtr(plane);
		uint8_t* msb = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 2;
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		uint8_t* lsb = msb + dst_pitch*(height);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				const uint16_t out = clamp16(src[x] * 256.0f);
				msb[x] = out >> 8;
				lsb[x] = (uint8_t)out;
			}
			src += src_pitch;
			msb += dst_pitch;
			lsb += dst_pitch;
		}
	} 
}

void convert_yuv_16_88(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint16_t* src = (uint16_t*)frame.src->GetReadPtr(plane);
		uint8_t* msb = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 1;
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> 1 >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		uint8_t* lsb = msb + dst_pitch*(height);
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				const uint16_t out = src[x];
				msb[x] = out >> 8;
				lsb[x] = (uint8_t)out;
			}
			src += src_pitch;
			msb += dst_pitch;
			lsb += dst_pitch;
		}
	} 
}

void convert_yuv_88_16(Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.src->GetReadPtr(plane);
		uint16_t* dst = (uint16_t*)frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane) >> 1;
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> 1 >> frame.vi->GetPlaneWidthSubsampling(plane);
		const uint8_t* lsb = msb + src_pitch*height;
		for (int y = 0; y < height; ++y) {
			for (int x = 0; x < width; ++x) {
				dst[x] = msb[x] << 8 | lsb[x];
			}
			msb += src_pitch;
			lsb += src_pitch;
			dst += dst_pitch;
		}
	}
}

void convert_yuv_32_8(Frame& frame) {
	const size_t dither_max_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_max_w*2);
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const float* src = (float*)frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 2;
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		float* dither_a = dither+2;
		float* dither_b = dither+2+width;
		const size_t dither_w = (width+2)*sizeof(float);
		memset(dither_a, 0, dither_w);
		for (int y = 0; y < height; ++y) {
			memset(dither_b, 0, dither_w);
			for (int x = 0; x < width; ++x) {
				float out = src[x];
				// Out Sierra 2-4A dithered
				out += dither_a[x+1];
				const uint8_t out_trunc = clamp8(out);
				const float dither_error = out - out_trunc;
				const float dither_error_050 = dither_error * 0.5f;
				const float dither_error_025 = dither_error * 0.25f;
				dither_a[x+2] += dither_error_050;
				dither_b[x]   += dither_error_025;
				dither_b[x+1] += dither_error_025;
				dst[x] = out_trunc;
			}
			src += src_pitch;
			dst += dst_pitch;
			// Switch dither tables
			float* dither_temp = dither_b;
			dither_b = dither_a;
			dither_a = dither_temp;
		}
	} 
}

void convert_yuv_16_8(Frame& frame) {
	const size_t dither_max_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_max_w*2);
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint16_t* src = (uint16_t*)frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane) >> 1;
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		float* dither_a = dither+2;
		float* dither_b = dither+2+width;
		const size_t dither_w = (width+2)*sizeof(float);
		memset(dither_a, 0, dither_w);
		for (int y = 0; y < height; ++y) {
			memset(dither_b, 0, dither_w);
			for (int x = 0; x < width; ++x) {
				float out = (float)src[x] * (1.0f/256.0f);
				// Out Sierra 2-4A dithered
				out += dither_a[x+1];
				const uint8_t out_trunc = clamp8(out);
				const float dither_error = out - out_trunc;
				const float dither_error_050 = dither_error * 0.5f;
				const float dither_error_025 = dither_error * 0.25f;
				dither_a[x+2] += dither_error_050;
				dither_b[x]   += dither_error_025;
				dither_b[x+1] += dither_error_025;
				dst[x] = out_trunc;
			}
			src += src_pitch;
			dst += dst_pitch;
			// Switch dither tables
			float* dither_temp = dither_b;
			dither_b = dither_a;
			dither_a = dither_temp;
		}
	} 
}

void convert_yuv_88_8(Frame& frame) {
	const size_t dither_max_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_max_w*2);
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int planes[] = {PLANAR_Y, PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 1 : 3;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		const uint8_t* msb = frame.src->GetReadPtr(plane);
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int src_pitch = frame.src->GetPitch(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int height = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		const int width = frame.vi->width >> frame.vi->GetPlaneWidthSubsampling(plane);
		const uint8_t* lsb = msb + src_pitch*height;
		float* dither_a = dither+2;
		float* dither_b = dither+2+width;
		const size_t dither_w = (width+2)*sizeof(float);
		memset(dither_a, 0, dither_w);
		for (int y = 0; y < height; ++y) {
			memset(dither_b, 0, dither_w);
			for (int x = 0; x < width; ++x) {
				float out = float(msb[x] << 8 | lsb[x]) * (1.0f/256.0f);
				// Out Sierra 2-4A dithered
				out += dither_a[x+1];
				const uint8_t out_trunc = clamp8(out);
				const float dither_error = out - out_trunc;
				const float dither_error_050 = dither_error * 0.5f;
				const float dither_error_025 = dither_error * 0.25f;
				dither_a[x+2] += dither_error_050;
				dither_b[x]   += dither_error_025;
				dither_b[x+1] += dither_error_025;
				dst[x] = out_trunc;
			}
			msb += src_pitch;
			lsb += src_pitch;
			dst += dst_pitch;
			// Switch dither tables
			float* dither_temp = dither_b;
			dither_b = dither_a;
			dither_a = dither_temp;
		}
	} 
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	ConvertFunc m_convert;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_convert(frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("Bitdepth: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("Bitdepth: RGB is not supported.");
	
	int arg = 0;
	const int bitdepth1 = args[++arg].AsInt(8);
	const int bitdepth2 = args[++arg].AsInt(16);

	if ((bitdepth1 == 8) && (bitdepth2 == 88)) {
		vi.height = vi.height << 1;
		m_convert = convert_yuv_8_88;
		return;
	} else if ((bitdepth1 == 88) && (bitdepth2 == 8)) {
		vi.height = vi.height >> 1;
		m_convert = convert_yuv_88_8;
		return;
	} else if ((bitdepth1 == 8) && (bitdepth2 == 16)) {
		vi.width = vi.width << 1;
		m_convert = convert_yuv_8_16;
		return;
	} else if ((bitdepth1 == 16) && (bitdepth2 == 8)) {
		vi.width = vi.width >> 1;
		m_convert = convert_yuv_16_8;
		return;
	} else if ((bitdepth1 == 16) && (bitdepth2 == 88)) {
		vi.height = vi.height << 1;
		vi.width = vi.width >> 1;
		m_convert = convert_yuv_16_88;
		return;
	} else if ((bitdepth1 == 88) && (bitdepth2 == 16)) {
		vi.height = vi.height >> 1;
		vi.width = vi.width << 1;
		m_convert = convert_yuv_88_16;
		return;
	} else if ((bitdepth1 == 8) && (bitdepth2 == 32)) {
		vi.width = vi.width << 2;
		m_convert = convert_yuv_8_32;
		return;
	} else if ((bitdepth1 == 32) && (bitdepth2 == 8)) {
		vi.width = vi.width >> 2;
		m_convert = convert_yuv_32_8;
		return;
	} else if ((bitdepth1 == 88) && (bitdepth2 == 32)) {
		vi.height = vi.height >> 1;
		vi.width = vi.width << 2;
		m_convert = convert_yuv_88_32;
		return;
	} else if ((bitdepth1 == 16) && (bitdepth2 == 32)) {
		vi.width = vi.width << 1;
		m_convert = convert_yuv_16_32;
		return;
	} else if ((bitdepth1 == 32) && (bitdepth2 == 16)) {
		vi.width = vi.width >> 1;
		m_convert = convert_yuv_32_16;
		return;
	} else if ((bitdepth1 == 32) && (bitdepth2 == 88)) {
		vi.height = vi.height << 1;
		vi.width = vi.width >> 2;
		m_convert = convert_yuv_32_88;
		return;
	} else if (bitdepth1 == bitdepth2) {
		m_convert = convert_yuv_copy;
		return;
	}
	env->ThrowError("Bitdepth: Unsupported convert from %d to %d\n", bitdepth1, bitdepth2);
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_Bitdepth(IScriptEnvironment* env)
{
	// Bitdepth(from=8, to=16)
    env->AddFunction("Bitdepth", "c[from]i[to]i", Bitdepth::Create_Filter, 0);
}
