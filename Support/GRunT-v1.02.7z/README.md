# GRunT - Gavino's Run-Time for AviSynth

History
- v1.0.2 (20200430 - pinterf)
  AVS 2.6 Interface
  Register as NICE_FILTER for Avs+
- v1.0.1 (Gavino, 27th September 2008) 
  an Avisynth 2.5 CPP plugin
