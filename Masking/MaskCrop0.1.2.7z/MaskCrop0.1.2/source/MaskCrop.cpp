/*
MaskCrop for Avisynth -- an accelerator works with a mask.

MaskCrop is a non clip filter that returns a coordinate value of a square including a mask.
This filter is consisted of four functions, i.e. MaskCropT(), MaskCropL(), MaskCropB() and MaskCropR() that return
top, left, nottom and right values respectively. Crop() function with these valuses returns cropped clip including a mask.
This cropped mask provides a possibility to accelerate filtering.
If the sum of costs of MaskCrop, cropping a mask clip, cropping a processing clip and overlay is less than
the sum of differences of filtering and mt_merge() between full frame and cropped frame, MaskCrop could accelerate filtering.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Usage:
scriptclip("
#
xMul=4# 
yMul=2#
mask=mt_motion(20)#an arbitrary mask
#

input=last
top = mask.MaskCropT(yMul)
left= mask.MaskCropL(xMul)
bottom = mask.MaskCropB(yMul)
right = mask.MaskCropR(xMul)
cmask=(bottom<=top+xMul||right<=left+yMul)?mask:mask.crop(left,top,right-left,bottom-top)
cropped=(bottom<=top+xMul||right<=left+yMul)?input:input.crop(left,top,right-left,bottom-top)

#
filted=cropped.dfttest()#filters
#

cmereged=mt_merge(cropped,filted,cmask,Y=3,U=3,V=3)
(bottom<=top+xMul||right<=left+yMul)?input:overlay(input,cmereged,left,top)
")
*/


#include "avisynth.h"

AVSValue __cdecl MaskCropT(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	if (!args[0].IsClip())
		env->ThrowError("MaskCropT: No clip supplied!");

	PClip child = args[0].AsClip();
	int mul = args[1].AsInt(2);			// multiple
	bool chroma = args[2].AsBool(true);	

	// Get clip video information
	VideoInfo vi = child->GetVideoInfo();

	if (!vi.IsPlanar())
		env->ThrowError("MaskCropT: Only planar images (as YV12) supported!");

	// get current frame number

	AVSValue cfn = env->GetVar("current_frame");
	if (!cfn.IsInt())
		env->ThrowError("MaskCropT: This filter can only be used within Conditional Filter");

	int fn = cfn.AsInt(); // frame number

	// Get source frame and its properties

	PVideoFrame src = child->GetFrame(fn, env); // source frame (smart pointer)

	int plane[] = { PLANAR_Y, PLANAR_U, PLANAR_V }; 
	int top;
	int temp = 108000;	// smallest top would be returned, so start with large value
	int c = 1;

	if (chroma){
		c = 3;
	}
	for (int p = 0; p < c; p++){
		const BYTE* srcp = src->GetReadPtr(plane[p]); // pointer to plane data (framebuffer)
		int height = src->GetHeight(plane[p]);
		int width = src->GetRowSize(plane[p]);
		int pitch = src->GetPitch(plane[p]);
		top = 0;

		unsigned int lum = 0;

		for (int h = p; h <= height - mul; h++) {
			for (int w = 0; w < width; w++) {
				lum += srcp[w];          // sum each byte from source
			}
			if (lum > 0){
				top = h;
				break;
			}
			else{
				srcp += pitch; // to next line
				top = h;
			}
		}
		if (p > 0){
			top = top * 2;	//chroma plane
		}
		if (temp > top){
			temp = top;		//smaller one
		}
	}
	top = int(temp / mul) * mul;	// trim top to be multiple of mul
	// return int result as AVSValue
	return (AVSValue)top;
}


AVSValue __cdecl MaskCropL(AVSValue args, void* user_data, IScriptEnvironment* env)
{

	if (!args[0].IsClip()) 
		env->ThrowError("MaskCropL: No clip supplied!");

	PClip child = args[0].AsClip(); 
	int mul = args[1].AsInt(4);
	bool chroma = args[2].AsBool(true);


	VideoInfo vi = child->GetVideoInfo();

	if (!vi.IsPlanar())
		env->ThrowError("MaskCropL: Only planar images (as YV12) supported!");



	AVSValue cfn = env->GetVar("current_frame");
	if (!cfn.IsInt())
		env->ThrowError("MaskCropL: This filter can only be used within Conditional Filter");

	int fn = cfn.AsInt(); 



	PVideoFrame src = child->GetFrame(fn, env);

	int plane[] = { PLANAR_Y, PLANAR_U, PLANAR_V };
	int left;
	int temp=192000;
	int c = 1;
	if (chroma){
		c = 3;
	}
	for (int p = 0; p < c; p++){

		const BYTE* srcp = src->GetReadPtr(plane[p]); 
		int height = src->GetHeight(plane[p]);
		int width = src->GetRowSize(plane[p]);
		int pitch = src->GetPitch(plane[p]);
		left = 0;


		if (mul <= 0 || mul > width)
			env->ThrowError("MaskCropL: mul must be positive int and less than width");



		unsigned int lum = 0;

		for (int w = 0; w <= width - mul; w++) {
			for (int h = 0; h < height; h++) {
				lum += srcp[h*pitch];
			}
			if (lum > 0){
				left = w;
				break;
			}
			else{
				left = w;
				srcp++;
				lum = 0;
			}
		}
		if (p > 0){
			left = left * 2;
		}
		if (temp > left){
			temp = left;
		}
	}
	//
	left = int(temp / mul)*mul;
	return (AVSValue)left;
}

AVSValue __cdecl MaskCropB(AVSValue args, void* user_data, IScriptEnvironment* env)
{

	if (!args[0].IsClip()) 
		env->ThrowError("MaskCropB: No clip supplied!");

	PClip child = args[0].AsClip(); 
	int mul = args[1].AsInt(2);
	bool chroma = args[2].AsBool(true);


	VideoInfo vi = child->GetVideoInfo();

	if (!vi.IsPlanar())
		env->ThrowError("MaskCropB: Only planar images (as YV12) supported!");



	AVSValue cfn = env->GetVar("current_frame");
	if (!cfn.IsInt())
		env->ThrowError("MaskCropB: This filter can only be used within Conditional Filter");

	int fn = cfn.AsInt(); 


	PVideoFrame src = child->GetFrame(fn, env); 

	int plane[] = { PLANAR_Y,PLANAR_U,PLANAR_V };
	int bottom;
	int temp = 0;	//largest bottom would be returned, so start with 0
	int c = 1;
	if (chroma){
		c = 3;
	}
	for (int p = 0; p < c; p++){
		const BYTE* srcp = src->GetReadPtr(plane[p]); 
		int height = src->GetHeight(plane[p]);
		int width = src->GetRowSize(plane[p]);
		int pitch = src->GetPitch(plane[p]);
		bottom = 0;

		if (mul <= 0 || mul>height)
			env->ThrowError("MaskCropB: mul must be even, positive int and less than height");



		unsigned int lum = 0; 

		srcp += (height - 1)*pitch;

		for (int h = height - 1; h >= mul; h--) {
			for (int w = 0; w < width; w++) {
				lum += srcp[w];         
			}
			if (lum > 0){
				bottom = h;
				break;
			}
			else{
				srcp -= pitch; 
				bottom = h;
			}
		}
		if (p > 0){
			bottom = bottom * 2;
		}
		if (temp < bottom){
			temp = bottom;
		}
	}
	if (temp % mul > 0){
		bottom = int(temp / mul + 1) * mul;	// pile bottom up to be multiple of mul
	}
	else{
		bottom = int(temp / mul)* mul;
	}

	return (AVSValue)bottom;
}

AVSValue __cdecl MaskCropR(AVSValue args, void* user_data, IScriptEnvironment* env)
{


	if (!args[0].IsClip()) 
		env->ThrowError("MaskCropR: No clip supplied!");

	PClip child = args[0].AsClip(); 
	int mul = args[1].AsInt(4);
	bool chroma = args[2].AsBool(true);

	VideoInfo vi = child->GetVideoInfo();

	if (!vi.IsPlanar())
		env->ThrowError("MaskCropR: Only planar images (as YV12) supported!");



	AVSValue cfn = env->GetVar("current_frame");
	if (!cfn.IsInt())
		env->ThrowError("MaskCropR: This filter can only be used within Conditional Filter");

	int fn = cfn.AsInt(); 



	PVideoFrame src = child->GetFrame(fn, env); 

	int plane[] = { PLANAR_Y, PLANAR_U, PLANAR_V };
	int right;
	int temp = 0;
	int c = 1;
	if (chroma){
		c = 3;
	}
	for (int p = 0; p < c; p++){

		const BYTE* srcp = src->GetReadPtr(plane[p]); 
		const BYTE* srcpi = srcp;
		int height = src->GetHeight(plane[p]);
		int width = src->GetRowSize(plane[p]);
		int pitch = src->GetPitch(plane[p]);
		right = 0;


		if (mul <= 0 || mul>width)
			env->ThrowError("MaskCropR: mul must be positive int and less than width");



		unsigned int lum = 0; 

		for (int w = width - 1; w >= mul; w--) {
			srcp = srcpi + w;
			for (int h = 0; h < height; h++) {
				lum += srcp[h*pitch];
			}
			if (lum > 0){
				right = w;
				break;
			}
			else{
				right = w;
				lum = 0;
			}
		}
		if (p > 0){
			right = right * 2;
		}
		if (temp < right){
			temp = right;
		}
	}

	if (temp % mul > 0){
		right = int(temp / mul + 1) * mul;
	}
	else{
		right = int(temp / mul)* mul;
	}

	return (AVSValue)right;
}



const AVS_Linkage* AVS_linkage = 0;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors) {
	AVS_linkage = vectors;
	env->AddFunction("MaskCropT", "c[mul]i[chroma]b", MaskCropT, 0);
	env->AddFunction("MaskCropL", "c[mul]i[chroma]b", MaskCropL, 0);
	env->AddFunction("MaskCropB", "c[mul]i[chroma]b", MaskCropB, 0);
	env->AddFunction("MaskCropR", "c[mul]i[chroma]b", MaskCropR, 0);

	return "MaskCrop plugin";

}
