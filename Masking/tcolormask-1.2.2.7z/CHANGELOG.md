##### 1.2.2:
    `grayscale` and `onlyY` cannot be true in the same time.
    Added AVX512 code.

##### 1.2.1:
    Registered as MT_NICE_FILTER. (tp7)
    Disabled internal MT by default. (tp7)
    Fixed YV12 processing. (tp7)
    Added support for frame properties passthrough. (Asd-g)
    Fixed the right side when width is not mod16. (Asd-g)
    Non-mod2 chroma height for YV12 and mt=true are not allowed. (Asd-g)
    Added C and AVX2 code. (Asd-g)
    Added `opt` parameter. (Asd-g)
    Added support for 16-bit clips. (Asd-g)
    Added `onlyY` parameter. (Asd-g)
    Added binary version. (Asd-g)

##### 1.2:
    x64 build added. (tp7)

##### 1.1:
    This plugin now only works with AviSynth 2.6 alpha 4. If you need support for older versions, download v1.0.1.
    Also, YV16 colorspace is now supported. (tp7)

##### 1.0.1:
    Initial release. (tp7)
