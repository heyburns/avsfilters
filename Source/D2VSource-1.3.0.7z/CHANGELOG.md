##### 1.3.0:
    Changed `_SARDen`, `_SARNum` to display MPEG-4 PAR. (videoh)
    Changed `_AspectRatio` type to array int.

##### 1.2.6:
    Restored previous behavior of frame property `_FieldBased`.
    Fixed frame properties `_DurationNum` and `_DurationDen`.
    Added frame properties `_SARDen`, `_SARNum`, `_FieldOrder`, `_FieldOperation`, `_TFF`, `_RFF`, `_Film`, `_ProgressiveFrame`, `_ChromaLocation`, `_AbsoluteTime`. (videoh)
    Added parameters `nocrop` and `rff`.

##### 1.2.5:
    Fixed frame property `_FieldBased`.

##### 1.2.4:
    Fixed regression for relative file paths.

##### 1.2.3:
    Fixed FFSAR_NUM, FFSAR_DEN, FFSAR.

##### 1.2.2:
    Fixed values of frame properties _Quants* when info=0.

##### 1.2.1:
    Added support for path with forward slash (Windows).

##### 1.2.0:
    Added variables (ffms2 like) - FFSAR_NUM, FFSAR_DEN, FFSAR.

##### 1.1.0:
    Set frame properties - _DurationNum, _DurationDen, _FieldBased, _AspectRatio, _GOPNumber, _GOPPosition, _GOPClosed, _EncodedFrameTop, _EncodedFrameBottom, _PictType, _Matrix, _QuantsAverage, _QuantsAverage, _QuantsMax.

##### 1.0.0:
    Renamed the plugin and function to D2VSource.
