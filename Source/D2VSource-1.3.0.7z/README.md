## D2VSource

This is a project (previously named as MPEG2DecPlus) to modify DGDecode.dll for AviSynth+.

### Requirements:

- AviSynth 2.60 / AviSynth+ 3.4 or later

- Microsoft VisualC++ Redistributable Package 2022 (can be downloaded from [here](https://github.com/abbodi1406/vcredist/releases))

### Usage:

 ```
 D2VSource(string "d2v", int "idct", bool "showQ", int "info", int "upConv", bool "i420", bool "iCC", bool "nocrop", int "rff")
 ```

### Parameters:

- d2v\
    The path of the dv2 file.

- idct\
    The iDCT algorithm to use.\
    0: Follow the d2v specification.\
    1,2,3,6,7: AP922 integer (same as SSE2/MMX).\
    4: SSE2/AVX2 LLM (single precision floating point, SSE2/AVX2 determination is automatic).\
    5: IEEE 1180 reference (double precision floating point).\
    Default: -1.

- showQ\
    It displays macroblock quantizers..\
    Default: False.

- info\
    It prints debug information.\
    0: Do not display.\
    1: Overlay on video frame.\
    2: Output with OutputDebugString(). (The contents are confirmed by DebugView.exe).\
    3: Embed hints in 64 bytes of the frame upper left corner.\
    Default: 0.

- upConv\
    The output format.\
    0: No conversion. YUV420 output is YV12, YUV422 output is YV16.\
    1: Output YV16.\
    2: Output YV24.\
    Default: 0.

- i420\
    It determinates what is the output of YUV420.\
    True: The output is i410.\
    False: The output is YV12.\
    Default: False.

- iCC\
    It determinates how YUV420 is upscaled when upConv=true.\
    True: Force field-based upsampling.\
    False: Forse progressive upsampling.\
    Default: Auto determination based on the frame flag.

- nocrop\
    Use direct-rendered buffer, which may need cropping.\
    It could provide a speedup when you know you need to crop your image anyway, by avoiding extra memcpy calls.\
    Default: False.

- rff\
    Changes Field_Operation without the need of editing d2v or rescanning with different Field Operation.\
    0: Honor Pulldowns Flags.\
    1: Forced Film.\
    2: Ignored Pulldowns Flags.\
    Default: -1 - read the value from d2v.

### Exported variables:

FFSAR_NUM, FFSAR_DEN, FFSAR (these indicate Generic PAR).

### Frame properties

_AbsoluteTime [float]\
The frame’s absolute timestamp in seconds.

_AspectRatio [int]\
An array giving the display aspect ratio.

_ChromaLocation [int]\
Chroma sample position in YUV formats:
0=left, 1=center, 2=topleft, 3=top, 4=bottomleft, 5=bottom.

_DurationNum [int], _DurationDen [int]\
The frame’s duration in seconds as a rational number.

_EncodedFrameTop [int], _EncodedFrameBottom [int]\
Frame number (before pulldown) used to generate this frame's
top/bottom field.

_FieldBased [int]\
Describes the composition of the frame:\
0=frame based (progressive), 1=bottom field first, 2=top field first.\
Note that the GOP progressive flag is used to determine whether the frame is progressive.

_FieldOperation [int]\
Describes the field operation option in effect:\
0=honor pulldown, 1=force film, 2=ignore pulldown.

_FieldOrder [int]\
Display field order of the frame:\
0=bottom field first, 1=top field first.

_Film [int]\
Set if the frame is part of a 3:2 soft pulldown section.\
Note that this uses the RFF history of several preceding\
frames, and so is valid only when doing linear access.

_GOPClosed [int]\
Set if the current GOP is closed.

_GOPNumber [int]\
The 0-based GOP number that contains the frame. Note that\
if this is set as the value x, then propShow displays it as\
[x, y] where y is the 0-based frame number of the first frame\
in the GOP.

_GOPPosition [int]\
The GOP position field from the D2V file for the GOP containing\
the frame.

_Matrix [int]\
The matrix number field from the D2V file for the GOP containing\
the frame.

_PictType [data]\
A single character describing the frame type. It uses the common\
IPB characters but others may also be used for formats with\
additional frame types.

_ProgressiveFrame [int]\
Set if the progress_frame flag is set for this frame.

_QuantsAverage [int]\
The average quantizer value for the frame.

_QuantsMax [int]\
The maximum quantizer value for the frame.

_QuantsMin [int]\
The minimum quantizer value for the frame.

_RFF [int]\
If _FieldOperation is 2 (ignore pulldown) then _RFF describes whether the stream specifies that a repeat field operation is to be performed on this frame. If _FieldOperation is 0 (honor pulldown) or 1 (force film) then _RFF describes whether the frame was composed with field repetition.

_SARDen [int]
The denominator of the "pixel size" (MPEG-4 PAR), also called the\
Sample Aspect Ratio (SAR).

_SARNum [int]
The numerator of the "pixel size" (MPEG-4 PAR), also called the\
Sample Aspect Ratio (SAR).

_TFF [int]\
If _FieldOperation is 2 (ignore pulldown) and _RFF is set, then _TFF\
describes whether the stream specifies that the top field is to be repeated, otherwise the bottom field is to be repeated. If _FieldOperation is 0 (honor pulldown) or 1 (force film) then _TFF is inapplicable and is set to -1.

### Building:

- Windows\
    Use solution files.

- Linux
    ```
    Requirements:
        - Git
        - C++17 compiler
        - CMake >= 3.16
    ```
    ```
    git clone https://github.com/Asd-g/MPEG2DecPlus && \
    cd MPEG2DecPlus && \
    mkdir build && \
    cd build && \

    cmake ..
    make -j$(nproc)
    sudo make install
    ```
