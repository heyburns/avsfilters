#### original author:Ernst Peché, 2005-10-13

#### modified by Oka Motofumi, 2011-06-14

`Version 2016-07-07 - Modified RawSource26 to Avisynth+ plugin.`

`Version 2016-08-14 - Update for Avisynth+ r2150 or later.`

`Version 2020-05-13 - Fixed 10/12/14-bit input, v8 interface.`

`Version 0.0.1 - Set few frame properties.`

```
Version 1.0.0
- Used reserved frame property names.
- Added parameters sarnum and sarden.
- Set frame properties _SARNum and _SARDen.
- Set variables FFSAR_NUM, FFSAR_DEN, FFSAR.
```

```
Version 1.0.1
- Fixed frame properties _DurationNum and _DurationDen.
```

```
Version 1.1.0
- Added pixel_types UYVY10le and UYVY10be. (DTL2020)
```

```
Version 1.2.0
- Added pixel_types UYVY12le, UYVY12be, UYVY14le, UYVY14be, UYVY16le, UYVY16be.
```

```
Version 1.3.0
- Added pixel_types YUV422P10be, YUV422P12be, YUV422P14be, YUV422P16be. (DTL2020)
```

```
Version 1.3.1
- Fixed the error message for supported formats.
```

```
Version 1.3.2
- Added support for pipe input.
```

```
Version 1.3.3
- Fixed opening file in some cases (ACP).
- Set frame properties _FieldBased, _ColorRange, _ChromaLocation, if YUV4MPEG2 header has the required info.
```
