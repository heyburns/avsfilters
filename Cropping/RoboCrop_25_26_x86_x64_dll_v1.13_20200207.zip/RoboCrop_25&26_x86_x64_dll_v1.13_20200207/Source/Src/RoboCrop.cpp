/*
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

// ----------------------------------------------------------------
//	Compiling for Avisynth v2.58 & v2.60/x86, v2.60/x64, under VS2008
//
// For AVS+, also need additional Avisynth+ headers somewhere in an AVS directory,
//
// AVS
//   alignment.h
//   avisynth.h
//   capi.h
//   config.h
//   cpuid.h
//   minmax.h
//   types.h
//   win.h
//
// Point Menu/Tools/Options/Projects and Solutions/VC Directories/ :Include Files: Win32 and x64, to the AVS Parent.
//
// For x64, add '_WIN64' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//        (Do NOT delete any 'WIN32' entry).
// For Avs v2.5, Add 'AVISYNTH_PLUGIN_25' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//   Avs v2.5 includes AVISYNTH_INTERFACE_VERSION=3 as avisynth25.h
//   Avs+ v2.6/x86/x64 includes AVISYNTH_INTERFACE_VERSION=6 as avisynth.h
// ----------------------------------------------------------------


/*
	Some parts may or may not be liberated from Avisynth source code.
	http://avisynth2.cvs.sourceforge.net/avisynth2/

	v0.20, Changed, range massage switch on frames to below 1500 (from 1000).
	v0.21, Autothresh Massaging changed minimum to -1.5 from -0.5.
	v1.00, Added ATM arg.
	v1.02, Added Start & End args, Changed default rec709 switch to width > 1100 || height > 600.
	v1.03, Minor mods.
	v1.04, Added User adjustments to detected border edges.
	v1.05, Addef LeftSkip, RightSkip, TopSkip, BotSkip (also shown when Show). Changed default Ignore from 0.2 to 0.4.
	v1.06, Changed Default WMod to 4, avoid possible problems in Avisynth v2.58, some media players and VDubMod.
		   Changed Default AutoThresh to -40.0, been wanting to do this for some time.
		   Changed default Samples to 40, paranoia.
	v1.07, Changed to recognise AutoThresh of both -32.0 and -40.0 as DEFAULT AUTOTHRESH (both old and new version args).
	v1.08, wmod,hmod limited max 16. Fixed crop centering.
	v1.09, Added reticule when Show=true..
	v1.10, Added Exact line marker when show.
	v1.11, 07 Jan  2019. Added Version Resource, Move to VS2008, Added x64, Changed default Align=True.
	v1.12, 06 Feb  2020. Added ScanPerc arg.
	v1.13, 07 Feb  2020. Added Prefix arg.

*/

//#define BUG

#define VERS "RoboCrop: v1.13 - 07 Feb 2020"

#include "Compiler.h"

#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#ifdef AVISYNTH_PLUGIN_25
	#include "avisynth25.h"
#else
	#include "avisynth.h"
#endif

#include "info.h"

int dprintf(char* fmt, ...) {
	char printString[512]="";					// MUST NUL TERM THIS, minimum "", or eg "Test: "
	char *p=printString;
	for(;*p++;);
	--p;										// @ null term
	va_list argp;
	va_start(argp, fmt);
	vsprintf(p, fmt, argp);
	va_end(argp);
	for(;*p++;);
	--p;										// @ null term
	if(printString == p || p[-1] != '\n') {
		p[0]='\n';								// append n/l if not there already
		p[1]='\0';
	}
	OutputDebugString(printString);
	return int(p-printString);					// strlen printString	
}

AVSValue __cdecl GetVar(IScriptEnvironment* env, const char* name) {
    try {return env->GetVar(name);} catch (IScriptEnvironment::NotFound) {} return AVSValue();
}

class RoboCrop : public GenericVideoFilter {   
	// args
	int		samples;
	double	thresh;
	bool	laced;
	int		wmod;
	int		hmod;
	int		rlbt;
	bool	debug;
	double	ignore;
	int		matrix;
	int		baffle;
	bool	scalergb;
	bool	scaleyuv;
	int		cropmode;
	bool	blank;
	bool	blankpc;
	bool	align;
	bool	show;
	const char *logfn;
	bool	logappend;
	double	atm;
	int LeftAdd,TopAdd,RightAdd,BotAdd;
	int LeftSkip,TopSkip,RightSkip,BotSkip;
	double ScanPerc;
	// constructor vars
	const char *	myName;								// Name for errors and debug info
	int		org_x1,org_x2,org_y1,org_y2;				// bidir comms with ScanPlanar etc
	int		x1,x2,y1,y2;								// bidir comms with ScanPlanar etc
	int		rgt,bot,lft,top,gotf,gotn;
	int		xmod,ymod;
	bool	Added;
	// GetFrame vars
	int crop_x,crop_y,crop_w,crop_h;
	int xSubS,ySubS;
	VideoInfo svi;
	//
private:
	void DrawString(PVideoFrame &dst,int x,int y,const char *s);
	void ScanPlanar(int n,int sampnum,IScriptEnvironment* env);
	void ScanYUY2(int n,int sampnum,IScriptEnvironment* env);
	void ScanRGB(int n,int sampnum,IScriptEnvironment* env);
	int YPMin(int n,IScriptEnvironment* env);
public:
	RoboCrop(PClip _child,AVSValue args,IScriptEnvironment* env);
	~RoboCrop();
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
};


RoboCrop::~RoboCrop(){}


RoboCrop::RoboCrop(PClip _child,AVSValue args,IScriptEnvironment* env) : GenericVideoFilter(_child) {
	
	myName="RoboCrop: ";
	double start_time =  double(clock()) / double(CLOCKS_PER_SEC);

	if(vi.width==0 || vi.num_frames==0)			env->ThrowError("%sClip has no video",myName);
	# ifdef AVISYNTH_PLUGIN_25
		if(vi.IsPlanar() && vi.pixel_type != 0xA0000008) {
			// Here Planar but NOT YV12, If v2.5 Plugin Does NOT support ANY v2.6+ ColorSpaces
			env->ThrowError("%sColorSpace unsupported in v2.5 plugin",myName);
		}
	# endif

	bool isyuv=false,isplanar=false,isyuy2=false,isrgb=false,isy8=false;
	xmod=1,ymod=1;

	if(isyuv=vi.IsYUV()) {
		if(isplanar=vi.IsPlanar()) {
			PVideoFrame	src	= child->GetFrame(0, env);					// get frame 0
			int	rowsizeUV=src->GetRowSize(PLANAR_U);
			if(rowsizeUV!=0) {											// Not Y8
				const int ywid=src->GetRowSize(PLANAR_Y);
				const int yhit=src->GetHeight(PLANAR_Y);
				const int uhit=src->GetHeight(PLANAR_U);
				xmod=ywid/rowsizeUV;
				ymod=yhit/uhit;
			} else {
				isy8=true;
			}
		} else {
			isyuy2=true;
			xmod=2;
		}
	} else {
		isrgb=true;
	}

	xSubS=xmod;		// for Planar GetFrame
	ySubS=ymod;

	const int	w=vi.width;
	const int	h=vi.height;
	const int	frames=vi.num_frames;

	samples			=	args[1].AsInt(40);
	laced			=	args[3].AsBool(true);
	ymod			=   (laced)? ymod*2 : ymod;
	wmod			=	args[4].AsInt(max(xmod,4));
	hmod			=	args[5].AsInt(ymod);
	rlbt			=	args[6].AsInt(0x0F);
	debug			=	args[7].AsBool(false);
	ignore			=	args[8].AsFloat(0.4f);
	matrix			=	args[9].AsInt(vi.width > 1100 || vi.height > 600 ? 3 : 2);
	baffle			=	args[10].AsInt(4);
	scalergb		=	args[11].AsBool(true);
	scaleyuv		=	args[12].AsBool(false);
	cropmode		=	args[13].AsInt(2);			// CropMore
	blank			=	args[14].AsBool(false);
	blankpc			=	args[15].AsBool(false);
	align			=	args[16].AsBool(true);
	show			=	args[17].AsBool(false);
	logfn			=	args[18].AsString("");
	logappend		=	args[19].AsBool(false);
	atm				=	args[20].AsFloat(4.0);

	// Start And End here args [21 & 22]

	LeftAdd			=	args[23].AsInt(0);
	TopAdd			=	args[24].AsInt(0);
	RightAdd		=	args[25].AsInt(0);
	BotAdd			=	args[26].AsInt(0);
	LeftSkip		=	args[27].AsInt(0);
	TopSkip			=	args[28].AsInt(0);
	RightSkip		=	args[29].AsInt(0);
	BotSkip			=	args[30].AsInt(0);

	ScanPerc		=	args[31].AsFloat(49.0);
	const char *prefix = args[32].AsString("ROBOCROP_");


	ScanPerc=(ScanPerc<1.0) ? 1.0 : (ScanPerc>99.0) ? 99.0 : ScanPerc;	// Silent limit
	rgt=int(w*(100.0-ScanPerc)/100.0);
	bot=int(h*(100.0-ScanPerc)/100.0);
	lft=int(w*ScanPerc/100.0);
	top=int(h*ScanPerc/100.0);
	
	if(debug) {
		dprintf("");
		dprintf("%s - By StainlessS",VERS);
		dprintf("Input: Width=%d Height=%d FrameCount=%d",w,h,frames);
		dprintf("");
	}



    if(isrgb && (matrix & 0xFFFFFFFC))			env->ThrowError("%sRGB matrix 0 to 3 Only",myName);
	if(cropmode<1 || cropmode>2)				env->ThrowError("%sCropMode 1 -> 2",myName);

	if(samples==0) {
		samples=frames;
		if(debug)	dprintf("Samples=0 Converted to FrameCount(%d)",samples);
	} else if(samples>frames) {
		if(debug)	dprintf("Samples (%d) limited to FrameCount(%d)",samples,frames);
		samples=frames;
	}

	bool IsDefaultAutoThresh=false;

	if(args[2].Defined()) {
		thresh	=	args[2].AsFloat();
		IsDefaultAutoThresh=(thresh== -40.0f || thresh== -32.0f);
		if(debug)	dprintf("Thresh set to user supplied %.2f",thresh);
	} else {
		thresh		=	-40.0f;
		IsDefaultAutoThresh=true;
		if(debug)	dprintf("Thresh defaulting to DEFAULT AUTOTHRESH %.2f",thresh);
	}

	if(debug && IsDefaultAutoThresh) {
		dprintf("Thresh %.2f recognised as DEFAULT AUTOTHRESH",thresh);
	}

	if(samples<1)								env->ThrowError("%sRequires Samples>=1",myName);

	if(wmod<xmod)								env->ThrowError("%sWMod, Must be at least %d",myName,xmod);
	if(hmod<ymod)								env->ThrowError("%sHMod, Must be at least %d",myName,ymod);
	if(wmod%xmod)								env->ThrowError("%sWMod must be a multiple of XMod(%d)",myName,xmod);
	if(hmod%ymod)								env->ThrowError("%sHMod must be a multiple of YMod(%d)",myName,ymod);

	if(wmod>16)									env->ThrowError("%sWMod, %d -> 16 (%d)",myName,xmod,wmod);
	if(hmod>16)									env->ThrowError("%sHMod, %d -> 16 (%d)",myName,ymod,hmod);

	if(rlbt<1 || rlbt>0xF)						env->ThrowError("%sRLBT 1->15 Only",myName);
	if(baffle<=0||baffle>16)					env->ThrowError("%sBaffle 1 -> 16",myName);
	if(baffle>w/2 || baffle>h/2)				env->ThrowError("%sBaffle Cannot be greater than 1/2 width or height",myName);

	if(TopSkip  < 0 || TopSkip   > h/4)			env->ThrowError("%sTopSkip range 0 -> h/4(%d)",myName,h/4);
	if(BotSkip  < 0 || BotSkip   > h/4)			env->ThrowError("%sBotSkip range 0 -> h/4(%d)",myName,h/4);
	if(LeftSkip < 0 || LeftSkip  > w/4)			env->ThrowError("%sLeftSkip range 0 -> w/4(%d)",myName,w/4);
	if(RightSkip< 0 || RightSkip > w/4)			env->ThrowError("%sRightSkip range 0 -> w/4(%d)",myName,w/4);

	x1= LeftSkip; y1=TopSkip; x2=w-1-RightSkip; y2=h-1-BotSkip;

	if(TopAdd   < 0)							env->ThrowError("%sTopAdd cannot be -ve",myName);
	if(BotAdd   < 0)							env->ThrowError("%sBotAdd cannot be -ve",myName);
	if(LeftAdd  < 0)							env->ThrowError("%sLeftAdd cannot be -ve",myName);
	if(RightAdd < 0)							env->ThrowError("%sRightAdd cannot be -ve",myName);

	if(x1+LeftAdd+baffle >= lft)				env->ThrowError("%sCheck LeftSkip : LeftAdd : Baffle",myName);
	if(y1+TopAdd+baffle  >= top)				env->ThrowError("%sCheck TopSkip : TopAdd : Baffle",myName);
	if(x2-RightAdd-baffle<= rgt)				env->ThrowError("%sCheck RightSkip : RightAdd : Baffle",myName);
	if(y2-BotAdd-baffle  <= bot)				env->ThrowError("%sCheck BotSkip : BotAdd : Baffle",myName);

	if(atm<0.0)			atm = -atm;				// in case supplied as -ve
	if(atm<0.5)			atm=0.5;				// silently limit
	else if(IsDefaultAutoThresh && atm>fabs(thresh))	atm=fabs(thresh);

	int SampStart=0,SampEnd=frames-1;
	
	const int skipfs	= int(frames * 0.05 + 0.5); 					// Skip 5%  BLACK intro framenum
	const int skipfe	= int(frames * 0.90 + 0.5) - 1;					// Skip 10% BLACK End Credits framenum

	char *smp=NULL;
	if(args[21].Defined()) {											// Start arg
		if((SampStart = args[21].AsInt()) < 0)	SampStart=0;
		if(args[22].Defined()) {										// End
			if(((SampEnd = args[22].AsInt()) <= 0) || SampEnd >= frames)		SampEnd=frames-1;
			smp="User set Start(%d) and End(%d) : Range=%d";
		} else {
			// Try not to use artificial black END credits in auto thresh and crop sampling
			if(skipfe-SampStart+1 >= 250 && skipfe-SampStart+1 >= samples) {
				SampEnd	= skipfe;	// Skip 10% BLACK End Credits
				smp="User set Start(%d), Skip End(%d) : Range=%d";
			} else	smp="User Set Start(%d), No Skip End(%d) : Range=%d";
		}
	} else if(args[22].Defined()) {											// End arg
		if(((SampEnd = args[22].AsInt()) <= 0) || SampEnd >= frames)		SampEnd=frames-1;
		// Try not to use artificial black Intro credits in auto thresh and crop sampling
		if(SampEnd-skipfs+1 >= 250 && SampEnd-skipfs+1 >= samples) {
			SampStart	= skipfs;	// Skip 5% BLACK Intro Credits
			smp="Skip Start(%d), User set End(%d) : Range=%d";
		} else	smp="No Skip Start(%d), User set End(%d) : Range=%d";
	} else {																// Start,End NOT supplied
		if(skipfe-skipfs+1 >= 250 && skipfe-skipfs+1 >= samples) {// Try not to use artificial black credits in auto thresh & crop sampling
			SampStart	= skipfs; 	// Skip 5%  BLACK intro
			SampEnd		= skipfe;	// Skip 10% BLACK End Credits
			smp="Skip Start(%d) and End(%d) : Range=%d";
		} else if(skipfe-skipfs+1 < 250)	smp="No Skip Start(%d), No Skip End(%d) : Range=%d [Skip range < 250]";
		else								smp="No Skip Start(%d), No Skip End(%d) : Range=%d [Not enough for Samples]";
	}

	const int SampRange = SampEnd - SampStart + 1;		// frame range of sampled frames

	if(debug) {
		dprintf("Potential Auto Credits Skip Start@5%%=%d End @90%%=%d : Range=%d",skipfs,skipfe,skipfe-skipfs+1);
		if(smp!=NULL)	dprintf(smp,SampStart,SampEnd,SampRange);
	}

	if(samples > SampRange) {
		samples = SampRange;
		if(debug)	dprintf("User set Start and/or End, Reducing Samples to %d",samples);
	}

	if(SampStart<0 || SampStart >=frames || SampEnd<SampStart || SampEnd>=frames) {
		if(debug) dprintf("Illegal frame Start(%d) or End(%d)",SampStart,SampEnd);
		env->ThrowError("%sIllegal frame Start(%d) or End(%d)",myName,SampStart,SampEnd);
	}

	if(IsDefaultAutoThresh && atm < fabs(thresh)) {
		double samples_massage 	=(samples>=20)				? 1.0 : (samples-1)		* (1.0/(20-1));
		double range_massage	=(SampRange >= (250*20))	? 1.0 : (SampRange-1)	* (1.0/((250*20)-1));
		double inthresh = thresh;
		thresh = -(((samples_massage * range_massage) * (fabs(thresh) - atm)) + atm);
		if(fabs(thresh - inthresh) > 0.0005) {
			if(debug) {
				if(samples_massage<1.0)
					dprintf("Low Samples count(%d), Massaging Auto Thresh(samples scaler=%.6f)",samples,samples_massage);
				if(range_massage<1.0)
					dprintf("Low Frames Range(%d), Massaging Auto Thresh(range scaler=%.6f)",SampRange,range_massage);
				if(samples_massage<1.0 && range_massage<1.0)
					dprintf("Combined Thresh Massage Scaler=%.6f",samples_massage * range_massage);
				dprintf("Auto Thresh reduced from DEFAULT %f to %.6f",inthresh,thresh);
			}
		}		
	}

	if(thresh<0.0) {											// no point in scaling Thresh==0.0
		if(isyuv && scaleyuv) {
			thresh=thresh *(255.0/(235.0-16.0));				// Auto Thresh is scaled relative to YplaneMin @ PCLevels
			if(debug)
				dprintf("AutoThresh: YUV, TV Thresh Scaled to PC %.3f",thresh);
		}else if(isrgb && scalergb) {
			if(matrix<2)				env->ThrowError("%sRGB ScaleAutoThreshRGB, Matrix NOT @ PC levels - Check!",myName);
			thresh=thresh *(255.0/(235.0-16.0));				// Auto Thresh is scaled relative to YplaneMin @ PCLevels
			if(debug)
				dprintf("AutoThresh: RGB, TV Thresh Scaled to PC %.3f",thresh);
		}
	}

	if(debug){
		dprintf("");
		dprintf("Samples=%d Thresh=%.3f Laced=%s Matrix=%d",samples,thresh,(laced)?"True":"False",matrix);
		dprintf("WMod=%d HMod=%d {Colorspace/Laced Restricted XMod=%d YMod=%d}",wmod,hmod,xmod,ymod);
		dprintf("RLBT=%d Ignore=%.3f Baffle=%d", rlbt,ignore,baffle);
		dprintf("ScaleAutoThreshRGB=%s ScaleAutoThreshYUV=%s ",(scalergb)?"Yes":"No",(scaleyuv)?"Yes":"No");
		dprintf("CropMode=%d(%s) Blank=%s Align=%s Show=%s Log=%s",cropmode,(cropmode==1)?"CropLess":"CropMore",(blank)? \
			"Yes":"No",(align)?"Yes":"No",(show)?"Yes":"No",logfn!=""?"Yes":"No");
		dprintf("Atm=%.3f SampStart=%d SampEnd=%d SampRange=%d",atm,SampStart,SampEnd,SampRange);
		dprintf("LeftAdd=%d TopAdd=%d RightAdd=%d BotAdd=%d",LeftAdd,TopAdd,RightAdd,BotAdd);
		dprintf("LeftSkip=%d TopSkip=%d RightSkip=%d BotSkip=%d",LeftSkip,TopSkip,RightSkip,BotSkip);
		dprintf("ScanPerc=%f",ScanPerc);
		dprintf("Prefix='%s'",prefix);
		dprintf("");
	}

	ignore /= 100.0;
	ignore=(ignore<0.0) ? 0.0 : (ignore>1.0) ? 1.0 : ignore;

	double SampMul = (samples <= 1) ? 0.0 : ((SampRange-1) / (samples-1.0));
	// Find MINLUMA (also for Thresh==0.0)
	int samp;
	if(thresh <= 0.0) {
		int thmin = 255;
		for(samp = 1;samp<=samples;++samp) {
			const int frm = int((samp - 1)	* SampMul + 0.5) + SampStart;

			const int th=YPMin(frm,env);

			if(thmin>th)	thmin=th;
			if(debug)		dprintf("AutoThresh %3d) [%6d] YPlaneMin =%3d (%d)",samp,frm,th,thmin);
			if(thmin==0)	break;		// No smaller possible
		}
		thresh = thmin + (-thresh);
		if(debug) {
			dprintf("");
			dprintf("YPlaneMin=%d : Automatic set Thresh=%.3f",thmin,thresh);
			dprintf("");
		}
	}

	// Border detect
	gotf=-1,gotn=0;										// Track Number of frames where coords 1st found
	for(samp = 1;samp<=samples;++samp) {
		const int frm = int((samp - 1)	* SampMul + 0.5) + SampStart;

		
		(isplanar) ? ScanPlanar(frm,samp,env) : (isrgb) ? ScanRGB(frm,samp,env) : ScanYUY2(frm,samp,env);

		if(
			(top==TopSkip		|| !(rlbt&0x01)) && 
			(bot==h-1-BotSkip	|| !(rlbt&0x02)) &&
			(lft==LeftSkip		|| !(rlbt&0x04)) && 
			(rgt==w-1-RightSkip	|| !(rlbt&0x08))
		)
			break;											// No further cropping possible, Break.
	}

	if(debug){
		dprintf("");
		dprintf("Active Frames (where image coords first found) = %d",gotn);
		dprintf("Sampled ImageEdge:  X1=%d  Y1=%d  X2=%d(W=%d,%d)  Y2=%d(H=%d,%d)",
			x1,y1,x2,x2-x1+1,x2-w+1,y2,y2-y1+1,y2-h+1);
		dprintf("");
	}

	org_x1=x1;	org_y1=y1;	org_x2=x2;	org_y2=y2;

	Added = (LeftAdd!=0 || TopAdd !=0 || RightAdd !=0 || BotAdd!=0);

	if(Added) {
		x1 += LeftAdd;	y1 += TopAdd;	x2 -= RightAdd;	y2 -= BotAdd;
		if(debug) {
			dprintf("User Adjust:   X1=%d  Y1=%d  X2=%d(W=%d,%d)  Y2=%d(H=%d,%d)",
				x1,y1,x2,x2-x1+1,x2-w+1,y2,y2-y1+1,y2-h+1);
			dprintf("");
		}
		if(x2 - x1 < wmod*2 || y2 - y1 < hmod*2)	env->ThrowError("%sIllegal user added offsets",myName);
	}

	int cw = x2-x1+1;
	int ch = y2-y1+1;

	if(cropmode==1) {
		int wrem = (cw % wmod == 0) ? 0 : wmod - (cw % wmod);
		int cxL = max(int(x1 - 0.5*wrem),0) / xmod * xmod;
		int cwL = (cw + (x1-cxL) + wmod-1) / wmod * wmod;
        while(cxL+cwL>vi.width) {cwL -= wmod;}                   // Too wide, reduce mod WMOD
		crop_x=cxL;	crop_w=cwL;	

		int hrem = (ch % hmod == 0) ? 0 : hmod - (ch % hmod);
		int cyL = max(int(y1 - 0.5*hrem),0) / ymod * ymod;
		int chL = (ch + (y1-cyL) + hmod-1) / hmod * hmod;
        while(cyL+chL>vi.height) {chL -= hmod;}                   // Too tall, reduce mod HMOD
		crop_y=cyL;	crop_h=chL; 
	} else {												// CropMore
	    int cxM = int(x1 + 0.5*(cw % wmod) + xmod-1) / xmod * xmod;
		int cwM = (cw - (cxM-x1)) / wmod * wmod;
		int cyM = int(y1 + 0.5*(ch % hmod) + ymod-1) / ymod * ymod;
		int chM = (ch - (cyM-y1)) / hmod * hmod;
		crop_x=cxM;	crop_y=cyM;	crop_w=cwM;	crop_h=chM;
	}

	if(*logfn != '\0') {
		char *omode=(logappend)?"a+t":"wt";
		FILE * fp;
		// we use write in text mode, let C insert '\r'.
		if((fp=fopen(logfn, omode ))!=NULL) {
			fprintf(fp,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d \n",
					crop_x,crop_y,crop_w,crop_h,
					xmod,ymod,wmod,hmod,
					vi.width,vi.height,
					org_x1,org_y1,org_x2,org_y2,
					cropmode,
					x1,y1,x2,y2
					);
			fclose(fp);
		}
	}

	svi=vi;

	if(!show && !blank) {
		vi.width  = crop_w;
		vi.height = crop_h;
	}

	if(debug) {
		dprintf("Crop(ModW/H):  X =%3d   Y =%3d   W =%3d(%d)   H =%3d(%d)",
			crop_x,crop_y,crop_w,crop_x+crop_w-w,crop_h,crop_y+crop_h-h);
		dprintf("Input: Width=%d Height=%d",w,h);
		dprintf("Crop(%d,%d,%d,%d)",crop_x,crop_y,crop_w,crop_h);
		dprintf("Crop(%d,%d,%d,%d)",crop_x,crop_y,crop_x+crop_w-w,crop_y+crop_h-h);
		if(isplanar && crop_w % 4)
			dprintf("*** WARNING *** Some players and VDubMod may require WMod=4");
		double duration =  (double(clock()) / double(CLOCKS_PER_SEC)) - start_time;
		dprintf("Constructor Scan Total Time=%.3f secs",duration);
	}
	if(prefix !="") {
		const char *p;
		int pfixlen=int(strlen(prefix));
		if(pfixlen>128)
			pfixlen=128;
		char bf[128+32];
		memcpy(bf,prefix,pfixlen);
		char *d;
		AVSValue var;

		d=bf+pfixlen;
		for(p="X";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_x);

		d=bf+pfixlen;
		for(p="Y";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_y);

		d=bf+pfixlen;
		for(p="W";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_w);

		d=bf+pfixlen;
		for(p="H";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_h);

		d=bf+pfixlen;
		for(p="W2";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_x+crop_w-w);

		d=bf+pfixlen;
		for(p="H2";*d++=*p++;);			// strcat variable name part
		var  =	GetVar(env,bf);
		env->SetVar(var.Defined()?bf:env->SaveString(bf),crop_y+crop_h-h);
	}
}


void RoboCrop::DrawString(PVideoFrame &dst,int x,int y,const char *s) {
	if(vi.IsPlanar())     DrawStringPlanar(dst,x,y,s);
	else if(vi.IsYUY2())  DrawStringYUY2(dst,x,y,s);
	else if(vi.IsRGB32()) DrawStringRGB32(dst,x,y,s);
	else if(vi.IsRGB24()) DrawStringRGB24(dst,x,y,s);
}

PVideoFrame __stdcall RoboCrop::GetFrame(int n, IScriptEnvironment* env) {
	n  = (n<0)	? 0 : (n>= vi.num_frames) ? vi.num_frames - 1 : n;	// Range limit frame n
	PVideoFrame dst = child->GetFrame(n, env);						// get read only source frame n
	if(show) {
		env->MakeWritable(&dst);
		int gx1=crop_x;
		int gy1=crop_y;
		int gx2=gx1+crop_w-1;
		int gy2=gy1+crop_h-1;
		const int   rowsize     = dst->GetRowSize(PLANAR_Y);
		const int   height	    = dst->GetHeight(PLANAR_Y);
		const int   pitch       = dst->GetPitch(PLANAR_Y);
		BYTE  *dp				= dst->GetWritePtr(PLANAR_Y);
		const int px2 = pitch*2;
		const int px3 = pitch*3;
		const int px5 = pitch*5;
		const int gxmax=vi.width-1;
		const int gymax=height-1;
		BYTE *rp,*rp2,*rp3;
		int xr,yr,xr2;
		if(vi.IsPlanar()) {
												// CropMore/CropLess
			rp = dp + gy1 * pitch;				// Top horizontal
			for(xr=rowsize;(xr-=5)>=0;) {
				rp[xr] = 235;
			}

			rp = dp + gy2 * pitch;				// Bot horizontal
			for(xr=rowsize;(xr-=5)>=0;) {
				rp[xr] = 235;
			}

			rp = dp;							// Verticals
			xr = gx1;	xr2=gx2;
			for(yr=height;(yr-=5)>=0;) {
				rp[xr]  = 235;
				rp[xr2] = 235;
				rp+= px5;
			}
														// Pre User Adds and CropMore/Less rounding
			if(org_y1!=gy1) {				// TopAdd
				rp = dp + org_y1 * pitch;
				for(xr=rowsize;(xr-=3)>=0;) {
					rp[xr] = 235;
				}
			}

			if(org_y2!=gy2) {				// BotAdd
				rp = dp + org_y2 * pitch;
				for(xr=rowsize;(xr-=3)>=0;) {
					rp[xr] = 235;
				}
			}

			if(org_x1!=gx1) {				// LeftAdd
				rp = dp;
				xr = org_x1;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr] = 235;
					rp+=px3;
				}
			}

			if(org_x2!=gx2) {			// RightAdd
				rp = dp;
				xr = org_x2;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr] = 235;
					rp+=px3;
				}
			}

															// Skip Start positions
			if(TopSkip!=0 && TopSkip!=gy1 && TopSkip!=org_y1) {
				rp = dp + TopSkip * pitch;
				for(xr=rowsize;(xr-=2)>=0;) {
					rp[xr] = 235;
				}
			}

			if(BotSkip!=0 && height-1-BotSkip!=gy2 && height-1-BotSkip!=org_y2) {
				rp = dp + (height-1-BotSkip) * pitch;
				for(xr=rowsize;(xr-=2)>=0;) {
					rp[xr] = 235;
				}
			}

			if(LeftSkip!=0 && LeftSkip!=gx1 && LeftSkip!=org_x1) {
				rp = dp;
				xr = LeftSkip;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr]  = 235;
					rp += px2;
				}
			}

			if(RightSkip!=0 && vi.width-1-RightSkip!=gx2 && vi.width-1-RightSkip!=org_x2) {
				rp = dp;
				xr= vi.width-1-RightSkip;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr] = 235;
					rp += px2;
				}
			}

			rp = dp + (gy1+gy2) / 2 * pitch;	// Mid horizontal crosshair
			int xgap = vi.width / (4*10) * 2;
			for(xr=0;xr<=xgap;++xr) {
				const int x5=xr*5;
				rp[x5] = 235;
				rp[gxmax-x5] = 235;
				if((xr&0x01) == 0) {
					rp[x5-pitch*2] = 235;
					rp[x5-pitch]   = 235;
					rp[x5+pitch]   = 235;
					rp[x5+pitch*2] = 235;
					rp[gxmax-x5-pitch*2] = 235;
					rp[gxmax-x5-pitch]   = 235;
					rp[gxmax-x5+pitch]   = 235;
					rp[gxmax-x5+pitch*2] = 235;
				}
			}

			rp = dp + (gx1+gx2) / 2;			// Mid vertical crosshair
			int ygap = height / (4*10) * 2;
			for(yr=0;yr<=ygap;++yr) {
				const int y5=yr*5;
				rp2=rp + y5*pitch;
				rp3=rp + (gymax-y5)*pitch;
				rp2[0] = 235;
				rp3[0] = 235;
				if((yr&0x01) == 0) {
					rp2[-2]  = 235;
					rp2[-1]  = 235;
					rp2[ 1]  = 235;
					rp2[ 2]  = 235;
					rp3[-2]  = 235;
					rp3[-1]  = 235;
					rp3[ 1]  = 235;
					rp3[ 2]  = 235;
				}
			}
														// Exact found coords, pre user Adds

		} else if(vi.IsYUY2()) {
													// CropMore/Less
			rp = dp + gy1 * pitch;					// Top horiztonal
			for(xr=rowsize;(xr-=(5*2))>=0;) {
				rp[xr] = 235;
			}

			rp = dp + gy2 * pitch;					// Bot Horizontal
			for(xr=rowsize;(xr-=(5*2))>=0;) {
				rp[xr] = 235;
			}

			rp = dp;								// Verticals
			xr = gx1*2;	xr2=gx2*2;
			for(yr=height;(yr-=5)>=0;) {
				rp[xr]  = 235;
				rp[xr2] = 235;
				rp+= px5;
			}

			if(org_y1!=gy1) {							// TopAdd
				rp = dp + org_y1 * pitch;
				for(xr=rowsize;(xr-=(3*2))>=0;) {
					rp[xr] = 235;
				}
			}

			if(org_y2!=gy2) {							// BotAdd
				rp = dp + org_y2 * pitch;
				for(xr=rowsize;(xr-=(3*2))>=0;) {
					rp[xr] = 235;
				}
			}

			if(org_x1!=gx1) {							// LeftAdd
				rp = dp;
				xr = org_x1*2;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr] = 235;
					rp+=px3;
				}
			}

			if(org_x2!=gx2) {							// RightAdd
				rp = dp;
				xr = org_x2*2;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr] = 235;
					rp+=px3;
				}
			}

															// Skip Start positions
			if(TopSkip!=0 && TopSkip!=gy1 && TopSkip!=org_y1) {
				rp = dp + TopSkip * pitch;
				for(xr=rowsize;(xr-=(2*2))>=0;)
					rp[xr] = 235;
			}

			if(BotSkip!=0 && height-1-BotSkip!=gy2 && height-1-BotSkip!=org_y2) {
				rp = dp + (height-1-BotSkip) * pitch;
				for(xr=rowsize;(xr-=2*2)>=0;)
					rp[xr] = 235;
			}

			if(LeftSkip!=0 && LeftSkip!=gx1 && LeftSkip!=org_x1) {
				rp = dp;
				xr = LeftSkip*2;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr]  = 235;
					rp += px2;
				}
			}
			if(RightSkip!=0 && vi.width-1-RightSkip!=gx2 && vi.width-1-RightSkip!=org_x2) {
				rp = dp;
				xr= (vi.width-1-RightSkip)*2;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr] = 235;
					rp += px2;
				}
			}
													// Crosshairs
			rp = dp + (gy1+gy2) / 2 * pitch;		// Mid horizontal
			int xgap = vi.width / (4*10) * 2;
			for(xr=0;xr<=xgap;++xr) {
				const int x5=xr*5;
				rp[x5*2] = 235;
				rp[(gxmax-x5)*2] = 235;
				if((xr&0x01) == 0) {
					rp[x5*2-pitch*2] = 235;
					rp[x5*2-pitch]   = 235;
					rp[x5*2+pitch]   = 235;
					rp[x5*2+pitch*2] = 235;
					rp[(gxmax-x5)*2-pitch*2] = 235;
					rp[(gxmax-x5)*2-pitch]   = 235;
					rp[(gxmax-x5)*2+pitch]   = 235;
					rp[(gxmax-x5)*2+pitch*2] = 235;
				}
			}

			rp = dp + (gx1+gx2) / 2 * 2;			// Mid vertical
			int ygap = height / (4*10) * 2;
			for(yr=0;yr<=ygap;++yr) {
				const int y5=yr*5;
				rp2=rp+y5 * pitch;
				rp3=rp+(gymax-y5) * pitch;
				rp2[0] = 235;
				rp3[0] = 235;
				if((yr&0x01) == 0) {
					rp2[-2*2]  = 235;
					rp2[-1*2]  = 235;
					rp2[1*2]   = 235;
					rp2[2*2]   = 235;
					rp3[-2*2]  = 235;
					rp3[-1*2]  = 235;
					rp3[1*2]   = 235;
					rp3[2*2]   = 235;
				}
			}

		} else { 
			const int xstep=(vi.IsRGB32()) ?4:3;
			const int xstep2=xstep*2;
			const int xstep3=xstep*3;
			const int xstep5=xstep*5;
															// CropMore/Less
			rp = dp + (height-1-gy1)*pitch;					// Top Horizontal
			for(xr=rowsize;(xr-=xstep5)>=0;) {
				rp[xr]	 = 255;
				rp[xr+1] = 255;
				rp[xr+2] = 255;
			}

			rp = dp + (height-1-gy2)*pitch;					// Bot Horizontal
			for(xr=rowsize;(xr-=xstep5)>=0;) {
				rp[xr]  = 255;
				rp[xr+1]= 255;
				rp[xr+2]= 255;
			}

			rp = dp + (height-1)*pitch;						// Verticals
			xr = gx1*xstep;	xr2=gx2*xstep;
			for(yr=height;(yr-=5)>=0;) {
				rp[xr]   = 255;
				rp[xr+1] = 255;
				rp[xr+2] = 255;
				rp[xr2]  = 255;
				rp[xr2+1]= 255;
				rp[xr2+2]= 255;
				rp -= px5;
			}

														// Pre User Adds and CropMore/Less rounding
			if(org_y1!=gy1) {							// TopAdd
				rp = dp + (height-1-org_y1)*pitch;
				for(xr=vi.width * xstep;(xr-=xstep3)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
				}
			}

			if(org_y2!=gy2) {							// BotAdd
				rp = dp + (height-1-org_y2)*pitch;
				for(xr=vi.width * xstep;(xr-=xstep3)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
				}
			}

			if(org_x1!=gx1) {							// LeftAdd
				rp = dp + (height-1) * pitch;
				xr = org_x1*xstep;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
					rp -= px3;
				}
			}

			if(org_x2!=gx2) {							// RightAdd
				rp = dp + (height-1) * pitch;
				xr= org_x2*xstep;
				for(yr=height;(yr-=3)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
					rp -= px3;
				}
			}

			if(TopSkip!=0 && TopSkip!=gy1 && TopSkip!=org_y1) {
				rp = dp + (height-1-TopSkip)*pitch;
				for(xr=vi.width*xstep;(xr-=xstep2)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
				}
			}

			if(BotSkip!=0 && height-1-BotSkip!=gy2 && height-1-BotSkip!=org_y2) {
				rp = dp + BotSkip * pitch;
				for(xr=vi.width*xstep;(xr-=xstep2)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
				}
			}

			if(LeftSkip!=0 && LeftSkip!=gx1 && LeftSkip!=org_x1) {
				rp = dp + (height-1)*pitch;
				xr = LeftSkip*xstep;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
					rp -= px2;
				}
			}

			if(RightSkip!=0 && vi.width-1-RightSkip!=gx2 && vi.width-1-RightSkip!=org_x2) {
				rp = dp + (height-1)*pitch;
				xr= (vi.width-1-RightSkip)*xstep;
				for(yr=height;(yr-=2)>=0;) {
					rp[xr  ] = 255;
					rp[xr+1] = 255;
					rp[xr+2] = 255;
					rp -= px2;
				}
			}
			
															// Crosshairs
			rp = dp + (height-1-(gy1+gy2)/2)*pitch;			// Mid Horizontals
			int xgap = vi.width / (4*10) * 2;
			for(xr=0;xr<=xgap;++xr) {
				const int x5=xr*5;
				rp2=rp+x5*xstep;
				rp2[0]=255;	rp2[1]=255;	rp2[2]=255;
				rp3=rp-x5*xstep;
				rp3[0]=255;	rp3[1]=255;	rp3[2]=255;
				if((xr&0x01) == 0) {
					rp2[-pitch*2 + 0] = 255;	rp2[-pitch*2 + 1] = 255;	rp2[-pitch*2 + 2] = 255;
					rp2[-pitch   + 0] = 255;	rp2[-pitch   + 1] = 255;	rp2[-pitch   + 2] = 255;
					rp2[+pitch   + 0] = 255;	rp2[+pitch   + 1] = 255;	rp2[+pitch   + 2] = 255;
					rp2[+pitch*2 + 0] = 255;	rp2[+pitch*2 + 1] = 255;	rp2[+pitch*2 + 2] = 255;
					rp3[-pitch*2 + 0] = 255;	rp3[-pitch*2 + 1] = 255;	rp3[-pitch*2 + 2] = 255;
					rp3[-pitch   + 0] = 255;	rp3[-pitch   + 1] = 255;	rp3[-pitch   + 2] = 255;
					rp3[+pitch   + 0] = 255;	rp3[+pitch   + 1] = 255;	rp3[+pitch   + 2] = 255;
					rp3[+pitch*2 + 0] = 255;	rp3[+pitch*2 + 1] = 255;	rp3[+pitch*2 + 2] = 255;
				}
			}

			rp = dp + (height-1)*pitch + (gx1+gx2) / 2 * xstep;	// Mid vertical
			int ygap = height / (4*10) * 2;
			for(yr=0;yr<=ygap;++yr) {
				const int y5=yr*5;
				rp2=rp-y5*pitch;
				rp3=rp-(gymax-y5)*pitch;
				rp2[0]=255;	rp2[1]=255;	rp2[2]=255;
				rp3[0]=255;	rp3[1]=255;	rp3[2]=255;
				if((yr&0x01) == 0) {
					rp2[-2*xstep + 0] = 255;	rp2[-2*xstep + 1] = 255;	rp2[-2*xstep + 2] = 255;
					rp2[-1*xstep + 0] = 255;	rp2[-1*xstep + 1] = 255;	rp2[-1*xstep + 2] = 255;
					rp2[+1*xstep + 0] = 255;	rp2[+1*xstep + 1] = 255;	rp2[+1*xstep + 2] = 255;
					rp2[+2*xstep + 0] = 255;	rp2[+2*xstep + 1] = 255;	rp2[+2*xstep + 2] = 255;
					rp3[-2*xstep + 0] = 255;	rp3[-2*xstep + 1] = 255;	rp3[-2*xstep + 2] = 255;
					rp3[-1*xstep + 0] = 255;	rp3[-1*xstep + 1] = 255;	rp3[-1*xstep + 2] = 255;
					rp3[+1*xstep + 0] = 255;	rp3[+1*xstep + 1] = 255;	rp3[+1*xstep + 2] = 255;
					rp3[+2*xstep + 0] = 255;	rp3[+2*xstep + 1] = 255;	rp3[+2*xstep + 2] = 255;
				}
			}
		}
		DrawString(dst,gx1+8,gy1+8,VERS);
		char bf[256];
		sprintf(bf,"XMod=%d YMod=%d WMod=%d HMod=%d",xmod,ymod,wmod,hmod);
		DrawString(dst,gx1+8,gy1+8+(1*20),bf);
		sprintf(bf,"x1=%d y1=%d x2=%d(W=-%d) y2=%d(H=-%d)\n",gx1,gy1,gx2,abs(gx2+1-vi.width),gy2,abs(gy2+1-vi.height));
		DrawString(dst,gx1+8,gy1+8+(2*20),bf);
		sprintf(bf,"Crop(%d,%d,%d,%d) [%s]\n",crop_x,crop_y,crop_w,crop_h,cropmode==1?"CropLess":"CropMore");
		DrawString(dst,gx1+8,gy1+8+(3*20),bf);
		sprintf(bf," ----------------");
		DrawString(dst,gx1+8,gy1+8+(4*20),bf);		
		sprintf(bf,"Exact ImageEdge:");
		DrawString(dst,gx1+8,gy1+8+(5*20),bf);
		sprintf(bf," x1=%d y1=%d x2=%d y2=%d",org_x1,org_y1,org_x2,org_y2);
		DrawString(dst,gx1+8,gy1+8+(6*20),bf);
		if(org_x1 != x1 || org_x2 != x2 || org_y1 != y1 || org_y2 != y2) {
			sprintf(bf,"User Adjust:");
			DrawString(dst,gx1+8,gy1+8+(7*20),bf);
			sprintf(bf," x1=%d y1=%d x2=%d y2=%d",x1,y1,x2,y2);
			DrawString(dst,gx1+8,gy1+8+(8*20),bf);
		}


	} else if(svi.width != vi.width || svi.height != vi.height) {
		const int pitch = dst->GetPitch(PLANAR_Y);
		if(!align) {
			if(svi.IsYUY2()) {
					dst = env->Subframe(
						dst,										// source frame
						pitch * crop_y + crop_x * 2,				// rel_offset
						pitch,										// new_pitch
						crop_w*2,									// new_rowsize
						crop_h										// new_height
						);
			} else if (svi.IsPlanar()) {
				const int rowsizeUV = dst->GetRowSize(PLANAR_U);
				if(rowsizeUV==0) {					// Y8
					dst = env->Subframe(
						dst,										// source frame
						pitch * crop_y + crop_x,					// rel_offset
						pitch,										// new_pitch
						crop_w,										// new_rowsize
						crop_h										// new_height
						);
				} else {
					const int pitchUV = dst->GetPitch(PLANAR_U);
					dst=env->SubframePlanar(
						dst, 										// source frame
						pitch * crop_y + crop_x,					// rel_offset
						pitch, 										// new_pitch
						crop_w,										// new_rowsize
						crop_h,										// new_height
						pitchUV * (crop_y/ySubS) + (crop_x/xSubS), 
						pitchUV * (crop_y/ySubS) + (crop_x/xSubS),
						pitchUV);
					}
			} else {
				const int sz=(svi.IsRGB32())?4:3;
				const int hit=dst->GetHeight();
				const int off= (hit - crop_h - crop_y) * pitch + crop_x * sz;
				dst = env->Subframe(
					dst,											// source frame
					off,											// rel_offset
					pitch,											// new_pitch
					crop_w*sz,										// new_rowsize
					crop_h											// new_height
					);
			}
		} else {
			PVideoFrame newf	= env->NewVideoFrame(vi);
			int newpitch	= newf->GetPitch(PLANAR_Y);
			if(svi.IsYUY2()) {
				env->BitBlt( 
					newf->GetWritePtr(PLANAR_Y), 
					newpitch, 
					dst->GetReadPtr(PLANAR_Y) + pitch * crop_y + crop_x * 2, 
					pitch, 
					crop_w * 2, 
					crop_h
					);
			} else if (svi.IsPlanar()) {
				env->BitBlt( 
					newf->GetWritePtr(PLANAR_Y), 
					newpitch, 
					dst->GetReadPtr(PLANAR_Y) + pitch * crop_y + crop_x, 
					pitch, 
					crop_w, 
					crop_h
					);
				const int rowsizeUV = dst->GetRowSize(PLANAR_U);
				if(rowsizeUV) {							// NOT Y8
					const int pitchUV = dst->GetPitch(PLANAR_U);
					newpitch	= newf->GetPitch(PLANAR_U);
					env->BitBlt( 
						newf->GetWritePtr(PLANAR_U), 
						newpitch, 
						dst->GetReadPtr(PLANAR_U) + pitchUV*(crop_y/ySubS) + (crop_x/xSubS), 
						pitchUV, 
						crop_w/xSubS, 
						crop_h/ySubS
						);
					env->BitBlt( 
						newf->GetWritePtr(PLANAR_V), 
						newpitch, 
						dst->GetReadPtr(PLANAR_V) + pitchUV*(crop_y/ySubS) + (crop_x/xSubS), 
						pitchUV, 
						crop_w/xSubS, 
						crop_h/ySubS
						);
				}
			} else {
				const int sz= (svi.IsRGB32()) ? 4 : 3;
				env->BitBlt( 
					newf->GetWritePtr(PLANAR_Y),
					newpitch, 
					dst->GetReadPtr(PLANAR_Y) + (dst->GetHeight() - crop_h - crop_y) * pitch + crop_x * sz,
					pitch, 
					crop_w * sz, 
					crop_h
					);
			}
			return newf;
		}
	} else if(blank) {
		env->MakeWritable(&dst);
		int gx1=crop_x, gy1=crop_y, gx2=gx1+crop_w-1, gy2=gy1+crop_h-1;
		const int   rowsize     = dst->GetRowSize(PLANAR_Y);
		const int   height	    = dst->GetHeight(PLANAR_Y);
		const int   pitch       = dst->GetPitch(PLANAR_Y);
		BYTE  *rp,*dp			= dst->GetWritePtr(PLANAR_Y);
		int xr,yr,xrstop;
		int K=(blankpc) ? 0 : 16;
		if(svi.IsYUY2()) {		
			rp = dp;
			for(yr=0;yr<gy1;++yr) {
				for(xr=rowsize;(xr-=4)<=0;)	{rp[xr+0] = K;	rp[xr+1] = 128;	rp[xr+2] = K;	rp[xr+3] = 128;}
				rp+=pitch;
			}
			rp = dp + (gy2 + 1) * pitch;
			for(yr=gy2+1;yr<height;++yr) {
				for(xr=rowsize;(xr-=4)<=0;)	{rp[xr+0] = K;	rp[xr+1] = 128;	rp[xr+2] = K;	rp[xr+3] = 128;}
				rp+=pitch;
			}
			rp = dp + gy1  * pitch;
			for(yr=gy1;yr<=gy2;++yr) {
				for(xr=gx1*2;(xr-=4)>=0;)				{rp[xr+0] = K;	rp[xr+1] = 128;	rp[xr+2] = K;	rp[xr+3] = 128;}
				for(xr=(gx2+1)*2;xr<rowsize;xr+=4)		{rp[xr+0] = K;	rp[xr+1] = 128;	rp[xr+2] = K;	rp[xr+3] = 128;}
				rp+=pitch;
			}
		} else if (svi.IsPlanar()) {
			rp = dp;
			for(yr=0;yr<gy1;++yr) {
				for(xr=rowsize;--xr>=0;) {rp[xr]=K;}
				rp+=pitch;
			}
			rp = dp + (gy2 + 1) * pitch;
			for(yr=gy2+1;yr<height;++yr) {
				for(xr=rowsize;--xr>=0;) {rp[xr]=K;}
				rp+=pitch;
			}
			rp = dp + gy1  * pitch;
			for(yr=gy1;yr<=gy2;++yr) {
				for(xr=0;xr<gx1;++xr)			{rp[xr+0] = K;}
				for(xr=gx2+1;xr<rowsize;++xr)	{rp[xr+0] = K;}
				rp+=pitch;
			}
			const int rowsizeUV = dst->GetRowSize(PLANAR_U);

			if(rowsizeUV!=0) {					// Y8
				dp					= dst->GetWritePtr(PLANAR_U);
				const int heightUV  = dst->GetHeight(PLANAR_U);
				const int pitchUV	= dst->GetPitch(PLANAR_U);
				BYTE *rpv,*dpv		= dst->GetWritePtr(PLANAR_V);
				gx1 /= xSubS; gx2 /= xSubS; gy1 /= ySubS; gy2 /= ySubS;
				rp	= dp;
				rpv	= dpv;
				for(yr=0;yr<gy1;++yr) {
					for(xr=0;xr<rowsizeUV;++xr) {
						rp [xr]	=128;
						rpv[xr]	=128;
					}
					rp +=pitchUV;
					rpv+=pitchUV;
				}

				rp	= dp	+ (gy2 + 1) * pitchUV;
				rpv	= dpv	+ (gy2 + 1) * pitchUV;
				for(yr=gy2+1;yr<heightUV;++yr) {
					for(xr=0;xr<rowsizeUV;++xr) {
						rp [xr]	= 128;
						rpv[xr]	= 128;
					}
					rp	+=pitchUV;
					rpv	+=pitchUV;
				}

				rp = dp		+ gy1  * pitchUV;
				rpv= dpv	+ gy1  * pitchUV;
				for(yr=gy1;yr<=gy2;++yr) {
					for(xr=0;xr<gx1;++xr)			{rp [xr] = 128;}
					for(xr=gx2+1;xr<rowsizeUV;++xr) {rp [xr] = 128;}
					for(xr=0;xr<gx1;++xr)			{rpv[xr] = 128;}
					for(xr=gx2+1;xr<rowsizeUV;++xr) {rpv[xr] = 128;}
					rp	+=pitchUV;
					rpv	+=pitchUV;
				}
			}
		} else if(svi.IsRGB32()){
			dp += (height - 1) * pitch;
			rp = dp;
			for(yr=0;yr<gy1;++yr) {
				for(xr=0;xr<rowsize;xr+=4) {rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;	rp[xr+3] = 0;}
				rp -= pitch;
			}
			rp = dp - (gy2 + 1) * pitch;
			for(yr=gy2+1;yr<height;++yr) {
				for(xr=0;xr<rowsize;xr+=4) {rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;	rp[xr+3] = 0;}
				rp -= pitch;
			}
			rp = dp - gy1  * pitch;
			for(yr=gy1;yr<=gy2;++yr) {
				for(xrstop=gx1*4,xr=0;xr<xrstop;xr+=4)	{rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;	rp[xr+3] = 0;}
				for(xr=(gx2+1)*4;xr<rowsize;xr+=4)		{rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;	rp[xr+3] = 0;}
				rp -= pitch;
			}
		} else {
			dp += (height - 1) * pitch;
			rp = dp;
			for(yr=0;yr<gy1;++yr) {
				for(xr=0;xr<rowsize;xr+=3) {rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;}
				rp -= pitch;
			}
			rp = dp - (gy2 + 1) * pitch;
			for(yr=gy2+1;yr<height;++yr) {
				for(xr=0;xr<rowsize;xr+=3) {rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;}
				rp -= pitch;
			}
			rp = dp - gy1  * pitch;
			for(yr=gy1;yr<=gy2;++yr) {
				for(xrstop=gx1*3,xr=0;xr<xrstop;xr+=3)	{rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;}
				for(xr=(gx2+1)*3;xr<rowsize;xr+=3)		{rp[xr+0] = 0;	rp[xr+1] = 0;	rp[xr+2] = 0;}
				rp -= pitch;
			}
		}
	}
	return dst;
}



	
int RoboCrop::YPMin(int n,IScriptEnvironment* env) {
    n = (n<0) ? 0 : (n>=vi.num_frames)?vi.num_frames-1:n;					// Range limit frame n

    PVideoFrame src         = child->GetFrame(n,env);
    const int   pitch       = src->GetPitch(PLANAR_Y);					// PLANAR_Y no effect on non-Planar (equates to 0)
    const BYTE  *srcp       = src->GetReadPtr(PLANAR_Y);
	const int	ww=vi.width;
	const int	hh=vi.height;
	unsigned int cnt[256];
	int x, y,i;

	for(i=256; --i>=0 ; cnt[i]=0);

	const int bh = hh - TopSkip  - BotSkip;
	const int bw = ww - LeftSkip - RightSkip;

	if(vi.IsYUY2()) {
		srcp += TopSkip * pitch + LeftSkip*2;
		for(y=bh ; --y>=0; ) {                       
			for (x=bw ; --x>=0 ; ++cnt[srcp[x*2]]);
			srcp += pitch;
		}
	} else if(vi.IsPlanar()) {
		srcp += TopSkip * pitch + LeftSkip;
		for(y=bh ; --y>=0; ) {                       
			for (x=bw ; --x>=0 ; ++cnt[srcp[x]]);
			srcp += pitch;
		}
	} else {
		// RGB to YUV-Y Conversion
		srcp += ((vi.height-1-TopSkip) * pitch);	// Upside down RGB, height-1 is top line, -yy is top line of yy coord
		// Matrix: Default=0=REC601 : 1=REC709 : 2 = PC601 : 3 = PC709
		//
		double				Kr,Kb;
		int					Sy,offset_y;
		if(matrix & 0x01)	{Kr = 0.2126; Kb        = 0.0722;}			// 709  1 or 3
		else                {Kr = 0.2990; Kb        = 0.1140;}			// 601  0 or 2
		if(matrix & 0x02)	{Sy = 255   ; offset_y  = 0;}				// PC   2 or 3
		else                {Sy = 219   ; offset_y  = 16;}				// TV   0 or 1
		const int			shift	=   15;
		const int           half    =   1 << (shift - 1);
		const double        mulfac  =   double(1<<shift);
		double              Kg      =   1.0 - Kr - Kb;
		const int           Srgb    =   255;
		const int			Yb = int(Sy  * Kb        * mulfac / Srgb + 0.5); //B
		const int			Yg = int(Sy  * Kg        * mulfac / Srgb + 0.5); //G
		const int			Yr = int(Sy  * Kr        * mulfac / Srgb + 0.5); //R
		const int			OffyPlusHalf = (offset_y<<shift) + half;
		//
		
		if(vi.IsRGB24()) {
			const int ww3 = bw*3;
			srcp += LeftSkip*3;
			for(y=0 ; y < bh; ++y) {                       
				for (x=ww3 ; x-=3, x>=0 ; ) {
					++cnt[(srcp[x] * Yb + srcp[x+1] * Yg + srcp[x+2] * Yr + OffyPlusHalf) >> shift];
				}
				srcp -= pitch;
			}
		} else {
			const int ww4 = bw*4;
			srcp += LeftSkip*4;
			for(y=0 ; y < bh; ++y) {                       
				for (x=ww4 ; x-=4, x>=0 ; ) {
					++cnt[(srcp[x] * Yb + srcp[x+1] * Yg + srcp[x+2] * Yr + OffyPlusHalf) >> shift];
				}
				srcp -= pitch;
			}
		}

	}
	int rmin=255;
	const unsigned int lim = (unsigned int)((bw * bh) * ignore);
	unsigned int acc = 0;
	for(i=0;i<256;++i) {
		acc = acc + cnt[i];
		if(acc > lim) {
			rmin=i;break;
		}
	}
	return rmin;
}



void RoboCrop::ScanPlanar(int n,int sampnum,IScriptEnvironment* env) {
    n = (n<0) ? 0 : (n>=vi.num_frames)?vi.num_frames-1:n;					// Range limit frame n
    PVideoFrame src         = child->GetFrame(n,env);
    const int   pitch       = src->GetPitch(PLANAR_Y);					// PLANAR_Y no effect on non-Planar (equates to 0)
    const BYTE  *srcp       = src->GetReadPtr(PLANAR_Y);
	
    unsigned int sum=0,sumrem=0;
	int SCur,MCur,ECur,i,j;

	const int w=vi.width;
	const int h=vi.height;
	const int wid = x2 - x1 + 1;
	const unsigned int  iythresh=int(wid*thresh+0.5);					// avoid double in thresh comparisons
	const int baffpitch=baffle*pitch;
	if((rlbt&0x01) && top>=(TopSkip+baffle-1)) {						// Top Edge
		SCur=TopSkip; MCur=SCur; ECur=SCur+(baffle-1);
		const BYTE *rp = srcp + ECur * pitch + x1;
		while(ECur<=top) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,j=wid;--j>=0;sum+=rp[j]);
				if(sum>iythresh) {
					if(SCur==MCur)	{
						sumrem=sum; // Only store most recent threm if 1st part of potentially 2 sweep scan (2nd part, SCur!=MCur)
					}
					--i;
					rp -= pitch;
				} else 
					break;
			}
			if(i<MCur)	{ // successfully scanned full single sweep OR 2nd of 2 sweep scan
				y1=SCur;
				top=(y1==TopSkip)?TopSkip:ECur-1;
				if(bot<SCur) {
					bot = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;			
				}
				if(debug)	{
					dprintf("Top %3d) [%6d]  AveY=%6.2f  Y1=%3d",sampnum,n,(double)sumrem/wid,y1);
				}
				break;
			} else { // New scan if fail on ECur(i==ECur), else 2nd sweep
				SCur=i+1;MCur=ECur+1;ECur=i+baffle;rp+=baffpitch;
			}
		}
	}

	if((rlbt&0x02) && bot<=(h-BotSkip-baffle)) {						// Bottom Edge
		SCur=(h-1)-BotSkip; MCur=SCur; ECur=SCur-(baffle-1);
		const BYTE *rp = srcp + ECur * pitch + x1;
		while(ECur>=bot) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,j=wid;--j>=0;sum+=rp[j]);
				if(sum>iythresh) {
					if(SCur==MCur) {
						sumrem=sum;
					}
					++i;
					rp += pitch;
				} else
					break;
			}
			if(i>MCur)	{
				y2= SCur;
				bot=(y2==(h-1)-BotSkip)?(h-1)-BotSkip:ECur+1;
				if(top>SCur) {
					top = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Bot %3d) [%6d]  AveY=%6.2f  Y2=%3d",sampnum,n,(double)sumrem/wid,y2);
				break;
			} else {
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;rp-=baffpitch;
			}
		}
	}

    int run;
	const int hit = y2-y1 + 1;
	const int off = y1 * pitch;
	const unsigned int  ixthresh=int(hit*thresh+0.5);			// avoid double in thresh comparisons
	if((rlbt&0x04) && lft>=(LeftSkip+baffle-1)) {				// Left Edge
		SCur=LeftSkip; MCur=SCur; ECur=SCur+(baffle-1);
		while(ECur<=lft) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,run=off+i,j=hit;--j>=0 ;) {
					sum+=srcp[run];
					run += pitch;
				}
				if(sum>ixthresh) {
					if(SCur==MCur) {
						sumrem=sum;
					}
					--i;
				} else
					break;
			}
			if(i<MCur)	{
				x1=SCur;
				lft=(x1==LeftSkip)?LeftSkip:ECur-1;
				if(rgt<SCur) {
					rgt = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Lft %3d) [%6d]  AveY=%6.2f  X1=%3d",sampnum,n,(double)sumrem/hit,x1);
				break;
			}else 	{
				SCur=i+1; MCur=ECur+1; ECur=i+baffle;
			}
		}
	}

	if((rlbt&0x08) && rgt<=(w-RightSkip-baffle)) {							// Right Edge
		SCur=(w-1)-RightSkip; MCur=SCur; ECur=SCur-(baffle-1);
		while(ECur>=rgt) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,run=off+i,j=hit;--j>=0 ;) {
					sum+=srcp[run];
					run += pitch;
				}
				if(sum>ixthresh) {
					if(SCur==MCur) {
						sumrem=sum;
					}
					++i;
				} else
					break;
			}
			if(i>MCur)	{
				x2= SCur;
				rgt=(x2==(w-1)-RightSkip)?(w-1)-RightSkip:ECur+1;
				if(lft>SCur) {
					lft = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug) dprintf("Rgt %3d) [%6d]  AveY=%6.2f  X2=%3d",sampnum,n,(double)sumrem/hit,x2);
				break;
			}else	{
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;
			}
		}
	}
}


void RoboCrop::ScanYUY2(int n,int sampnum,IScriptEnvironment* env) {
    n = (n<0) ? 0 : (n>=vi.num_frames)?vi.num_frames-1:n;					// Range limit frame n
    PVideoFrame src         = child->GetFrame(n,env);
    const int   pitch       = src->GetPitch(PLANAR_Y);					// PLANAR_Y no effect on non-Planar (equates to 0)
    const BYTE  *srcp       = src->GetReadPtr(PLANAR_Y);

    unsigned long sum=0,sumrem=0;
	int SCur,MCur,ECur,i,j;

	const int w=vi.width;
	const int h=vi.height;
	const int wid = x2 - x1 + 1;
	const unsigned long  iythresh=int(wid*thresh+0.5);					// avoid double in thresh comparisons
	const int baffpitch=baffle*pitch;

	if((rlbt&0x01) && top>=(TopSkip+baffle-1)) {						// Top Edge
		SCur=TopSkip; MCur=SCur; ECur=SCur+(baffle-1);
		const BYTE *rp = srcp + ECur * pitch + x1*2;
		while(ECur<=top) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,j=wid*2; j-=2, j>=0; sum+=rp[j]);
				if(sum>iythresh) {
					if(SCur==MCur)	
						sumrem=sum; // Only store most recent threm if 1st part of potentially 2 sweep scan (2nd part, SCur!=MCur)
					--i;
					rp -= pitch;
				} else 
					break;
			}
			if(i<MCur)	{ // successfully scanned full single sweep OR 2nd of 2 sweep scan
				y1=SCur;
				top=(y1==TopSkip)?TopSkip:ECur-1;
				if(bot<SCur) {
					bot = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;			
				}
				if(debug)	{
					dprintf("Top %3d) [%6d]  AveY=%6.2f  Y1=%3d",sampnum,n,(double)sumrem/wid,y1);
				}
				break;
			} else { // New scan if fail on ECur(i==ECur), else 2nd sweep
				SCur=i+1;MCur=ECur+1;ECur=i+baffle;rp+=baffpitch;
			}
		}
	}


	if((rlbt&0x02) && bot<=(h-BotSkip-baffle)) {						// Bottom Edge
		SCur=(h-1)-BotSkip; MCur=SCur; ECur=SCur-(baffle-1);
		const BYTE *rp = srcp + ECur * pitch + x1*2;
		while(ECur>=bot) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,j=wid*2; (j-=2)>=0;) {
					 sum+=rp[j];
				}
				if(sum>iythresh) {
					if(SCur==MCur)
						sumrem=sum;
					++i;
					rp += pitch;
				} else
					break;
			}
			if(i>MCur)	{
				y2= SCur;
				bot=(y2==(h-1)-BotSkip)?(h-1)-BotSkip:ECur+1;
				if(top>SCur) {
					top = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Bot %3d) [%6d]  AveY=%6.2f  Y2=%3d",sampnum,n,(double)sumrem/wid,y2);
				break;
			}else 	{
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;rp-=baffpitch;
			}
		}
	}


    int run;
	const int hit = y2-y1 + 1;
	const int off = y1 * pitch;
	const unsigned long  ixthresh=int(hit*thresh+0.5);		// avoid double in thresh comparisons

	if((rlbt&0x04) && lft>=(LeftSkip+baffle-1)) {					// Left Edge
		SCur=LeftSkip; MCur=SCur; ECur=SCur+(baffle-1);
		while(ECur<=lft) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,run=off+i*2,j=hit;--j>=0 ;) {
					sum+=srcp[run];
					run += pitch;
				}
				if(sum>ixthresh) {
					if(SCur==MCur)
						sumrem=sum;
					--i;
				} else
					break;
			}
			if(i<MCur)	{
				x1=SCur;
				lft=(x1==LeftSkip)?LeftSkip:ECur-1;
				if(rgt<SCur) {
					rgt = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Lft %3d) [%6d]  AveY=%6.2f  X1=%3d",sampnum,n,(double)sumrem/hit,x1);
				break;
			}else 	{
				SCur=i+1; MCur=ECur+1; ECur=i+baffle;
			}
		}
	}

	if((rlbt&0x08) && rgt<=(w-RightSkip-baffle)) {							// Right Edge
		SCur=(w-1)-RightSkip; MCur=SCur; ECur=SCur-(baffle-1);
		while(ECur>=rgt) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,run=off+i*2,j=hit;--j>=0 ;) {
					sum+=srcp[run];
					run += pitch;
				}
				if(sum>ixthresh) {
					if(SCur==MCur)
						sumrem=sum;
					++i;
				} else
					break;
			}
			if(i>MCur)	{
				x2= SCur;
				rgt=(x2==(w-1)-RightSkip)?(w-1)-RightSkip:ECur+1;
				if(lft>SCur) {
					lft = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug) dprintf("Rgt %3d) [%6d]  AveY=%6.2f  X2=%3d",sampnum,n,(double)sumrem/hit,x2);
				break;
			}else	{
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;
			}
		}
	}
}





void RoboCrop::ScanRGB(int n,int sampnum,IScriptEnvironment* env) {
    n = (n<0) ? 0 : (n>=vi.num_frames)?vi.num_frames-1:n;			// Range limit frame n
    PVideoFrame src         = child->GetFrame(n,env);
    const int   pitch       = src->GetPitch();						// PLANAR_Y no effect on non-Planar (equates to 0)
    const BYTE  *srcp       = src->GetReadPtr() + ((vi.height-1) * pitch);
	const int rgbstride		= - pitch;
	// RGB to YUV-Y Conversion
	// Matrix: Default=0=REC601 : 1=REC709 : 2 = PC601 : 3 = PC709
	//
	double				Kr,Kb;
	int					Sy,offset_y;
	if(matrix & 0x01)	{Kr = 0.2126; Kb        = 0.0722;}			// 709  1 or 3
	else                {Kr = 0.2990; Kb        = 0.1140;}			// 601  0 or 2
	if(matrix & 0x02)	{Sy = 255   ; offset_y  = 0;}				// PC   2 or 3
	else                {Sy = 219   ; offset_y  = 16;}				// TV   0 or 1
	const int			shift	=   15;
	const int           half    =   1 << (shift - 1);
	const double        mulfac  =   double(1<<shift);
	double              Kg      =   1.0 - Kr - Kb;
	const int           Srgb    =   255;
	const int			Yb = int(Sy  * Kb        * mulfac / Srgb + 0.5); //B
	const int			Yg = int(Sy  * Kg        * mulfac / Srgb + 0.5); //G
	const int			Yr = int(Sy  * Kr        * mulfac / Srgb + 0.5); //R
	const int			OffyPlusHalf = (offset_y<<shift) + half;
	//
	const int			xstep = (vi.IsRGB24()) ? 3 : 4;


    unsigned long sum=0,sumrem=0;
	int SCur,MCur,ECur,i,j;

	const int w=vi.width;
	const int h=vi.height;
	const int wid = x2 - x1 + 1;
	const unsigned long  iythresh=int(wid*thresh+0.5);					// avoid double in thresh comparisons
	const int baffpitch=baffle*rgbstride;

	if((rlbt&0x01) && top>=(TopSkip+baffle-1)) {						// Top Edge
		SCur=TopSkip; MCur=SCur; ECur=SCur+(baffle-1);
		const BYTE *rp = srcp + ECur * rgbstride + x1*xstep;
		while(ECur<=top) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,j=wid*xstep; (j-=xstep)>=0;) {
					sum += ((rp[j] * Yb + rp[j+1] * Yg + rp[j+2] * Yr + OffyPlusHalf) >> shift);
				}
				if(sum>iythresh) {
					if(SCur==MCur)	
						sumrem=sum; // Only store most recent threm if 1st part of potentially 2 sweep scan (2nd part, SCur!=MCur)
					--i;
					rp -= rgbstride;
				} else 
					break;
			}
			if(i<MCur)	{ // successfully scanned full single sweep OR 2nd of 2 sweep scan
				y1=SCur;
				top=(y1==TopSkip)?TopSkip:ECur-1;
				if(bot<SCur) {
					bot = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;			
				}
				if(debug)	dprintf("Top %3d) [%6d]  AveY=%6.2f  Y1=%3d",sampnum,n,(double)sumrem/wid,y1);
				break;
			} else { // New scan if failed on ECur(i==ECur), else 2nd sweep scan.
				SCur=i+1; MCur=ECur+1; ECur=i+baffle;rp+=baffpitch;
			}
		}
	}

	if((rlbt&0x02) && bot<=(h-BotSkip-baffle)) {						// Bottom Edge
		SCur=(h-1)-BotSkip; MCur=SCur; ECur=SCur-(baffle-1);
		const BYTE *rp = srcp + ECur * rgbstride + x1*xstep;
		while(ECur>=bot) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,j=wid*xstep; (j-=xstep)>=0; ) {
					sum += ((rp[j] * Yb + rp[j+1] * Yg + rp[j+2] * Yr + OffyPlusHalf) >> shift);
				}
				if(sum>iythresh) {
					if(SCur==MCur)
						sumrem=sum;
					++i;
					rp += rgbstride;
				} else
					break;
			}
			if(i>MCur)	{
				y2= SCur;
				bot=(y2==(h-1)-BotSkip)?(h-1)-BotSkip:ECur+1;
				if(top>SCur) {
					top = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Bot %3d) [%6d]  AveY=%6.2f  Y2=%3d",sampnum,n,(double)sumrem/wid,y2);
				break;
			}else 	{
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;rp-=baffpitch;
			}
		}
	}

    int run;
	const int hit = y2-y1 + 1;
	const int off = y1 * rgbstride;
	const unsigned long  ixthresh=int(hit*thresh+0.5);		// avoid double in thresh comparisons

	if((rlbt&0x04) && lft>=LeftSkip+(baffle-1)) {					// Left Edge
		SCur=LeftSkip; MCur=SCur; ECur=SCur+(baffle-1);
		while(ECur<=lft) {
			i=ECur;
			while(i>=MCur) {
				for(sum=0,run=off+i*xstep,j=hit;--j>=0 ;) {
					sum += ((srcp[run] * Yb + srcp[run+1] * Yg + srcp[run+2] * Yr + OffyPlusHalf) >> shift);
					run += rgbstride;
				}
				if(sum>ixthresh) {
					if(SCur==MCur)
						sumrem=sum;
					--i;
				} else
					break;
			}
			if(i<MCur)	{
				x1=SCur;
				lft=(x1==LeftSkip)?LeftSkip:ECur-1;
				if(rgt<SCur) {
					rgt = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug)	dprintf("Lft %3d) [%6d]  AveY=%6.2f  X1=%3d",sampnum,n,(double)sumrem/hit,x1);
				break;
			}else 	{
				SCur=i+1; MCur=ECur+1; ECur=i+baffle;
			}
		}
	}

	if((rlbt&0x08) && rgt<=(w-RightSkip-baffle)) {							// Right Edge
		SCur=(w-1)-RightSkip; MCur=SCur; ECur=SCur-(baffle-1);
		while(ECur>=rgt) {
			i=ECur;
			while(i<=MCur) {
				for(sum=0,run=off+i*xstep,j=hit;--j>=0 ;) {
					sum += ((srcp[run] * Yb + srcp[run+1] * Yg + srcp[run+2] * Yr + OffyPlusHalf) >> shift);
					run += rgbstride;
				}
				if(sum>ixthresh) {
					if(SCur==MCur)
						sumrem=sum;
					++i;
				} else
					break;
			}
			if(i>MCur)	{
				x2= SCur;
				rgt=(x2==(w-1)-RightSkip)?(w-1)-RightSkip:ECur+1;
				if(lft>SCur) {
					lft = SCur;
				}
				if(n!=gotf) {
					gotf=n;
					++gotn;
				}
				if(debug) dprintf("Rgt %3d) [%6d]  AveY=%6.2f  X2=%3d",sampnum,n,(double)sumrem/hit,x2);
				break;
			}else	{
				SCur=i-1; MCur=ECur-1; ECur=i-baffle;
			}
		}
	}
}

AVSValue __cdecl Create_RoboCrop(AVSValue args, void* user_data, IScriptEnvironment* env) {
	return new RoboCrop(args[0].AsClip(),args,env);
}


#ifdef AVISYNTH_PLUGIN_25
	extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) {
#else
	/* New 2.6 requirement!!! */
	// Declare and initialise server pointers static storage.
	const AVS_Linkage *AVS_linkage = 0;

	/* New 2.6 requirement!!! */
	// DLL entry point called from LoadPlugin() to setup a user plugin.
	extern "C" __declspec(dllexport) const char* __stdcall
			AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors) {

	/* New 2.6 requirment!!! */
	// Save the server pointers.
	AVS_linkage = vectors;
#endif
	env->AddFunction("RoboCrop", "c[Samples]i[Thresh]f[Laced]b[wMod]i[hMod]i[RLBT]i[Debug]b[Ignore]f[Matrix]i[Baffle]i"
		"[ScaleAutoThreshRGB]b[ScaleAutoThreshYUV]b[CropMode]i[Blank]b[BlankPC]b[Align]b[Show]b"
		"[LogFn]s[LogAppend]b[ATM]f[Start]i[End]i"
		"[LeftAdd]i[TopAdd]i[RightAdd]i[BotAdd]i"
		"[LeftSkip]i[TopSkip]i[RightSkip]i[BotSkip]i"
		"[ScanPerc]f[Prefix]s"
		,Create_RoboCrop, 0);
	return "`RoboCrop' RoboCrop plugin";
	// A freeform name of the plugin.
}

