/*
 *  AutoYUY2()
 *
 *  Adaptive YV12 upsampling. Progressive picture areas are upsampled
 *  progressively and interlaced areas are upsampled interlaced.
 *  Copyright (C) 2005-2007 Donald A. Graft
 *  Optimizations by Jean-Philippe Scotto Di Rinaldi
 *	
 *  AutoYUY2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *   
 *  AutoYUY2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *   
 *  You should have received a copy of the GNU General Public License
 *  along with GNU Make; see the file COPYING.  If not, write to
 *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA. 
 *
 */

#include <windows.h>
#include <winreg.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include "avisynth2.h"

#define VERSION "AutoYUY2 1.0.1"

#define Interlaced_Tab_Size 3

class AutoYUY2 : public GenericVideoFilter
{
	int threshold;
	int mode;
	unsigned short *lookup_3,*lookup_5,*lookup_7;
	bool *interlaced_tab[Interlaced_Tab_Size];
public:
	AutoYUY2(PClip _child, int _threshold, int _mode, IScriptEnvironment* env);
	~AutoYUY2();
    PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	void Convert_Progressive(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV);
	void Convert_Interlaced(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV);
	void Convert_Automatic(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV);
	void Convert_Map(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV);
};

AutoYUY2::AutoYUY2(PClip _child, int _mode, int _threshold, IScriptEnvironment* env) :
										GenericVideoFilter(_child), mode(_mode), threshold(_threshold)
											
{
	bool ok;
	unsigned short i;

	lookup_3=(unsigned short*)malloc(256*sizeof(unsigned short));
	lookup_5=(unsigned short*)malloc(256*sizeof(unsigned short));
	lookup_7=(unsigned short*)malloc(256*sizeof(unsigned short));
	for (i=0; i<Interlaced_Tab_Size; i++)
	{
		interlaced_tab[i]=(bool*)malloc(vi.width*sizeof(bool));
	}

	ok=true;
	ok=ok && (lookup_3!=NULL);
	ok=ok && (lookup_5!=NULL);
	ok=ok && (lookup_7!=NULL);
	for (i=0; i<Interlaced_Tab_Size; i++)
	{
		ok=ok && (interlaced_tab[i]!=NULL);
	}

	if (!ok)
		env->ThrowError("AutoYUY2: Memory allocation error.");
	if (!vi.IsYV12())
		env->ThrowError("AutoYUY2: input format must be YV12 or I420");
	if (vi.width & 3)
		env->ThrowError("AutoYUY2: input width must be a multiple of 4.");
	if (vi.height & 3)
		env->ThrowError("AutoYUY2: input height must be a multiple of 4.");
	if (vi.height < 8)
		env->ThrowError("AutoYUY2: input height must be at least 8.");
	if ((mode<0) || (mode>3))
		env->ThrowError("AutoYUY2: [mode] must be 0-3.");

	if (ok)
	{
		for (i=0; i<256; i++)
		{
			lookup_3[i]=3*i;
			lookup_5[i]=5*i;
			lookup_7[i]=7*i;
		}
	}
		
	vi.pixel_type = VideoInfo::CS_YUY2;
}

AutoYUY2::~AutoYUY2() 
{
	signed short i;
	
	for (i=Interlaced_Tab_Size-1; i>=0; i--)
	{
		free(interlaced_tab[i]);
	}
	free(lookup_7);
	free(lookup_5);
	free(lookup_3);
}

void AutoYUY2::Convert_Progressive(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV)
{
	const unsigned char *srcUpp, *srcUpn;
	const unsigned char *srcVpp, *srcVpn;
	int x, y,x_4,x_2,dst_h_2;

	srcUpp = srcUp - src_pitchUV;
	srcUpn = srcUp + src_pitchUV;
	srcVpp = srcVp - src_pitchUV;
	srcVpn = srcVp + src_pitchUV;

	dst_h_2=dst_h-2;

	for (y=0; y<2; y+=2)
	{
		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpn[x_4]+2) >> 2;
			dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpn[x_4]+2) >> 2;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV;
		srcUpp += src_pitchUV;
		srcUpn += src_pitchUV;
		srcVp += src_pitchUV;
		srcVpp += src_pitchUV;
		srcVpn += src_pitchUV;
	}

	for (y = 2; y < dst_h_2; y+=2)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpp[x_4]+2) >> 2;
			dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpp[x_4]+2) >> 2;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpn[x_4]+2) >> 2;
			dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpn[x_4]+2) >> 2;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		srcUp += src_pitchUV;
		srcUpp += src_pitchUV;
		srcUpn += src_pitchUV;
		srcVp += src_pitchUV;
		srcVpp += src_pitchUV;
		srcVpn += src_pitchUV;	
	}

	for (y = dst_h_2; y < dst_h; y+=2)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpp[x_4]+2) >> 2;
			dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpp[x_4]+2) >> 2;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		srcUp += src_pitchUV;
		srcUpp += src_pitchUV;
		srcUpn += src_pitchUV;
		srcVp += src_pitchUV;
		srcVpp += src_pitchUV;
		srcVpn += src_pitchUV;	
	}
}

void AutoYUY2::Convert_Interlaced(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY, int src_pitchUV)
{
	const unsigned char *srcUpp, *srcUpn, *srcUpnn, *srcUpnnn,*srcUppp;
	const unsigned char *srcVpp, *srcVpn, *srcVpnn, *srcVpnnn,*srcVppp;
	int x, y,x_4,x_2,dst_h_2,dst_h_4,src_pitchUV_2;

	srcUpp = srcUp - src_pitchUV;
	srcUppp = srcUp - (2*src_pitchUV);
	srcUpn = srcUp + src_pitchUV;
	srcUpnn = srcUp + (2 * src_pitchUV);
	srcUpnnn = srcUp + (3 * src_pitchUV);
	srcVpp = srcVp - src_pitchUV;
	srcVppp = srcVp - (2*src_pitchUV);
	srcVpn = srcVp + src_pitchUV;
	srcVpnn = srcVp + (2 * src_pitchUV);
	srcVpnnn = srcVp + (3 * src_pitchUV);
	
	src_pitchUV_2=src_pitchUV << 1;
	dst_h_2=dst_h-2;
	dst_h_4=dst_h-4;

	for (y=0; y<4; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=(lookup_3[srcUpnn[x_4]]+lookup_5[srcUp[x_4]]+4)>>3;
			dstp[x+3]=(lookup_3[srcVpnn[x_4]]+lookup_5[srcVp[x_4]]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=(lookup_7[srcUpn[x_4]]+(unsigned short)srcUpnnn[x_4]+4)>>3;
			dstp[x+3]=(lookup_7[srcVpn[x_4]]+(unsigned short)srcVpnnn[x_4]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;
	}

	for (y = 4; y < dst_h_4; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_7[srcUp[x_4]]+(unsigned short)srcUppp[x_4]+4) >> 3;
			dstp[x+3]=(lookup_7[srcVp[x_4]]+(unsigned short)srcVppp[x_4]+4) >> 3;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUpp[x_4]]+lookup_5[srcUpn[x_4]]+4) >> 3;
			dstp[x+3]=(lookup_3[srcVpp[x_4]]+lookup_5[srcVpn[x_4]]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUpnn[x_4]]+lookup_5[srcUp[x_4]]+4) >> 3;
			dstp[x+3]=(lookup_3[srcVpnn[x_4]]+lookup_5[srcVp[x_4]]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_7[srcUpn[x_4]]+(unsigned short)srcUpnnn[x_4]+4) >> 3;
			dstp[x+3]=(lookup_7[srcVpn[x_4]]+(unsigned short)srcVpnnn[x_4]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;	
	}

	for (y = dst_h_4; y < dst_h; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_7[srcUp[x_4]]+(unsigned short)srcUppp[x_4]+4) >> 3;
			dstp[x+3]=(lookup_7[srcVp[x_4]]+(unsigned short)srcVppp[x_4]+4) >> 3;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUpp[x_4]]+lookup_5[srcUpn[x_4]]+4) >> 3;
			dstp[x+3]=(lookup_3[srcVpp[x_4]]+lookup_5[srcVpn[x_4]]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;	
	}
}


void AutoYUY2::Convert_Automatic(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY,int src_pitchUV)
{
	const unsigned char *srcUpp, *srcUpn, *srcUpnn, *srcUpnnn,*srcUppp;
	const unsigned char *srcVpp, *srcVpn, *srcVpnn, *srcVpnnn,*srcVppp;
	int x, y,x_4,x_2,dst_h_2,dst_h_4,src_pitchUV_2;
	unsigned char index_tab_0,index_tab_1,index_tab_2;

	srcUpp = srcUp - src_pitchUV;
	srcUppp = srcUp - (2*src_pitchUV);
	srcUpn = srcUp + src_pitchUV;
	srcUpnn = srcUp + (2 * src_pitchUV);
	srcUpnnn = srcUp + (3 * src_pitchUV);
	srcVpp = srcVp - src_pitchUV;
	srcVppp = srcVp - (2*src_pitchUV);
	srcVpn = srcVp + src_pitchUV;
	srcVpnn = srcVp + (2 * src_pitchUV);
	srcVpnnn = srcVp + (3 * src_pitchUV);
	
	src_pitchUV_2=src_pitchUV << 1;
	dst_h_2=dst_h-2;
	dst_h_4=dst_h-4;

	for (y=0; y<4; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=(lookup_3[srcUpnn[x_4]]+lookup_5[srcUp[x_4]]+4)>>3;
			dstp[x+3]=(lookup_3[srcVpnn[x_4]]+lookup_5[srcVp[x_4]]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];
			
			if (((abs((signed short)srcUpn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				(abs((signed short)srcUpnnn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				((srcUpn[x_4]>srcUpnn[x_4]) && (srcUpnnn[x_4]>srcUpnn[x_4]) ||
				(srcUpn[x_4]<srcUpnn[x_4]) && (srcUpnnn[x_4]<srcUpnn[x_4]))) ||
				((abs((signed short)srcVpn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				(abs((signed short)srcVpnnn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				((srcVpn[x_4]>srcVpnn[x_4]) && (srcVpnnn[x_4]>srcVpnn[x_4]) ||
				(srcVpn[x_4]<srcVpnn[x_4]) && (srcVpnnn[x_4]<srcVpnn[x_4]))))
				interlaced_tab[1][x_4]=true;
			else interlaced_tab[1][x_4]=false;
			if (((abs((signed short)srcUp[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				(abs((signed short)srcUpnn[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				((srcUp[x_4]>srcUpn[x_4]) && (srcUpnn[x_4]>srcUpn[x_4]) ||
				(srcUp[x_4]<srcUpn[x_4]) && (srcUpnn[x_4]<srcUpn[x_4]))) ||
				((abs((signed short)srcVp[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				(abs((signed short)srcVpnn[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				((srcVp[x_4]>srcVpn[x_4]) && (srcVpnn[x_4]>srcVpn[x_4]) ||
				(srcVp[x_4]<srcVpn[x_4]) && (srcVpnn[x_4]<srcVpn[x_4]))))
				interlaced_tab[0][x_4]=true;
			else interlaced_tab[0][x_4]=false;
			
			dstp[x+1]=(lookup_7[srcUpn[x_4]]+(unsigned short)srcUpnnn[x_4]+4)>>3;
			dstp[x+3]=(lookup_7[srcVpn[x_4]]+(unsigned short)srcVpnnn[x_4]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;
	}
	
	index_tab_0=0;
	index_tab_1=1;
	index_tab_2=2;
	
	for (y = 4; y < dst_h_4; y+=4)
	{
		x_2=0;
		x_4=0;
		
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_0][x_4]))
			{
				dstp[x+1]=(lookup_7[srcUp[x_4]]+(unsigned short)srcUppp[x_4]+4) >> 3;
				dstp[x+3]=(lookup_7[srcVp[x_4]]+(unsigned short)srcVppp[x_4]+4) >> 3;
			}
			else
			{
				dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpp[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpp[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];
			
			if (((abs((signed short)srcUp[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				(abs((signed short)srcUpnn[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				((srcUp[x_4]>srcUpn[x_4]) && (srcUpnn[x_4]>srcUpn[x_4]) ||
				(srcUp[x_4]<srcUpn[x_4]) && (srcUpnn[x_4]<srcUpn[x_4]))) ||
				((abs((signed short)srcVp[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				(abs((signed short)srcVpnn[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				((srcVp[x_4]>srcVpn[x_4]) && (srcVpnn[x_4]>srcVpn[x_4]) ||
				(srcVp[x_4]<srcVpn[x_4]) && (srcVpnn[x_4]<srcVpn[x_4]))))
				interlaced_tab[index_tab_2][x_4]=true;
			else interlaced_tab[index_tab_2][x_4]=false;			

			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_2][x_4]))
			{
				dstp[x+1]=(lookup_3[srcUpp[x_4]]+lookup_5[srcUpn[x_4]]+4) >> 3;
				dstp[x+3]=(lookup_3[srcVpp[x_4]]+lookup_5[srcVpn[x_4]]+4) >> 3;
			}
			else
			{
				dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpn[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpn[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_2][x_4]))
			{
				dstp[x+1]=(lookup_3[srcUpnn[x_4]]+lookup_5[srcUp[x_4]]+4) >> 3;
				dstp[x+3]=(lookup_3[srcVpnn[x_4]]+lookup_5[srcVp[x_4]]+4) >> 3;
			}
			else
			{
				dstp[x+1]=(lookup_3[srcUpn[x_4]]+(unsigned short)srcUp[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVpn[x_4]]+(unsigned short)srcVp[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];
			
			if (((abs((signed short)srcUpn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				(abs((signed short)srcUpnnn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				((srcUpn[x_4]>srcUpnn[x_4]) && (srcUpnnn[x_4]>srcUpnn[x_4]) ||
				(srcUpn[x_4]<srcUpnn[x_4]) && (srcUpnnn[x_4]<srcUpnn[x_4]))) ||
				((abs((signed short)srcVpn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				(abs((signed short)srcVpnnn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				((srcVpn[x_4]>srcVpnn[x_4]) && (srcVpnnn[x_4]>srcVpnn[x_4]) ||
				(srcVpn[x_4]<srcVpnn[x_4]) && (srcVpnnn[x_4]<srcVpnn[x_4]))))
				interlaced_tab[index_tab_0][x_4]=true;
			else interlaced_tab[index_tab_0][x_4]=false;

			// Upsample as needed.
			if ((interlaced_tab[index_tab_2][x_4]) || (interlaced_tab[index_tab_0][x_4]))
			{
				dstp[x+1]=(lookup_7[srcUpn[x_4]]+(unsigned short)srcUpnnn[x_4]+4) >> 3;
				dstp[x+3]=(lookup_7[srcVpn[x_4]]+(unsigned short)srcVpnnn[x_4]+4) >> 3;
			}
			else
			{
				dstp[x+1]=(lookup_3[srcUpn[x_4]]+(unsigned short)srcUpnn[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVpn[x_4]]+(unsigned short)srcVpnn[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		index_tab_0=(index_tab_0+2)%Interlaced_Tab_Size;
		index_tab_1=(index_tab_1+2)%Interlaced_Tab_Size;
		index_tab_2=(index_tab_2+2)%Interlaced_Tab_Size;
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;	
	}

	for (y = dst_h_4; y < dst_h; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_7[srcUp[x_4]]+(unsigned short)srcUppp[x_4]+4) >> 3;
			dstp[x+3]=(lookup_7[srcVp[x_4]]+(unsigned short)srcVppp[x_4]+4) >> 3;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUpp[x_4]]+lookup_5[srcUpn[x_4]]+4) >> 3;
			dstp[x+3]=(lookup_3[srcVpp[x_4]]+lookup_5[srcVpn[x_4]]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;
	}
}

void AutoYUY2::Convert_Map(const unsigned char *srcYp, const unsigned char *srcUp,
		const unsigned char *srcVp, unsigned char *dstp, int dst_h, int dst_w,
		int dst_pitch, int src_pitchY,int src_pitchUV)	
{
	const unsigned char *srcUpp, *srcUpn, *srcUpnn, *srcUpnnn,*srcUppp;
	const unsigned char *srcVpp, *srcVpn, *srcVpnn, *srcVpnnn,*srcVppp;
	int x, y,x_4,x_2,dst_h_2,dst_h_4,src_pitchUV_2;
	unsigned char index_tab_0,index_tab_1,index_tab_2;

	srcUpp = srcUp - src_pitchUV;
	srcUppp = srcUp - (2*src_pitchUV);
	srcUpn = srcUp + src_pitchUV;
	srcUpnn = srcUp + (2 * src_pitchUV);
	srcUpnnn = srcUp + (3 * src_pitchUV);
	srcVpp = srcVp - src_pitchUV;
	srcVppp = srcVp - (2*src_pitchUV);
	srcVpn = srcVp + src_pitchUV;
	srcVpnn = srcVp + (2 * src_pitchUV);
	srcVpnnn = srcVp + (3 * src_pitchUV);
	
	src_pitchUV_2=src_pitchUV << 1;
	dst_h_2=dst_h-2;
	dst_h_4=dst_h-4;

	for (y=0; y<4; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];

			dstp[x+1]=(lookup_3[srcUpnn[x_4]]+lookup_5[srcUp[x_4]]+4)>>3;
			dstp[x+3]=(lookup_3[srcVpnn[x_4]]+lookup_5[srcVp[x_4]]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x=0; x<dst_w; x+=4)
		{
			dstp[x]=srcYp[x_2];
			dstp[x+2]=srcYp[x_2+1];
			
			if (((abs((signed short)srcUpn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				(abs((signed short)srcUpnnn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				((srcUpn[x_4]>srcUpnn[x_4]) && (srcUpnnn[x_4]>srcUpnn[x_4]) ||
				(srcUpn[x_4]<srcUpnn[x_4]) && (srcUpnnn[x_4]<srcUpnn[x_4]))) ||
				((abs((signed short)srcVpn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				(abs((signed short)srcVpnnn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				((srcVpn[x_4]>srcVpnn[x_4]) && (srcVpnnn[x_4]>srcVpnn[x_4]) ||
				(srcVpn[x_4]<srcVpnn[x_4]) && (srcVpnnn[x_4]<srcVpnn[x_4]))))
				interlaced_tab[1][x_4]=true;
			else interlaced_tab[1][x_4]=false;
			if (((abs((signed short)srcUp[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				(abs((signed short)srcUpnn[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				((srcUp[x_4]>srcUpn[x_4]) && (srcUpnn[x_4]>srcUpn[x_4]) ||
				(srcUp[x_4]<srcUpn[x_4]) && (srcUpnn[x_4]<srcUpn[x_4]))) ||
				((abs((signed short)srcVp[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				(abs((signed short)srcVpnn[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				((srcVp[x_4]>srcVpn[x_4]) && (srcVpnn[x_4]>srcVpn[x_4]) ||
				(srcVp[x_4]<srcVpn[x_4]) && (srcVpnn[x_4]<srcVpn[x_4]))))
				interlaced_tab[0][x_4]=true;
			else interlaced_tab[0][x_4]=false;
			
			dstp[x+1]=(lookup_7[srcUpn[x_4]]+(unsigned short)srcUpnnn[x_4]+4)>>3;
			dstp[x+3]=(lookup_7[srcVpn[x_4]]+(unsigned short)srcVpnnn[x_4]+4)>>3;

			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;
	}
	
	index_tab_0=0;
	index_tab_1=1;
	index_tab_2=2;
	
	for (y = 4; y < dst_h_4; y+=4)
	{
		x_2=0;
		x_4=0;
		
		for (x = 0; x < dst_w; x+=4)
		{
			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_0][x_4]))
			{
				dstp[x] = 180;
				dstp[x+2] = 180;
				
				dstp[x+1]=128;
				dstp[x+3]=128;
			}
			else
			{
				dstp[x] = srcYp[x_2];
				dstp[x+2] = srcYp[x_2+1];
				
				dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpp[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpp[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			if (((abs((signed short)srcUp[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				(abs((signed short)srcUpnn[x_4]-(signed short)srcUpn[x_4])>=threshold) &&
				((srcUp[x_4]>srcUpn[x_4]) && (srcUpnn[x_4]>srcUpn[x_4]) ||
				(srcUp[x_4]<srcUpn[x_4]) && (srcUpnn[x_4]<srcUpn[x_4]))) ||
				((abs((signed short)srcVp[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				(abs((signed short)srcVpnn[x_4]-(signed short)srcVpn[x_4])>=threshold) &&
				((srcVp[x_4]>srcVpn[x_4]) && (srcVpnn[x_4]>srcVpn[x_4]) ||
				(srcVp[x_4]<srcVpn[x_4]) && (srcVpnn[x_4]<srcVpn[x_4]))))
				interlaced_tab[index_tab_2][x_4]=true;
			else interlaced_tab[index_tab_2][x_4]=false;			

			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_2][x_4]))
			{
				dstp[x] = 180;
				dstp[x+2] = 180;
				
				dstp[x+1]=128;
				dstp[x+3]=128;
			}
			else
			{
				dstp[x] = srcYp[x_2];
				dstp[x+2] = srcYp[x_2+1];
				
				dstp[x+1]=(lookup_3[srcUp[x_4]]+(unsigned short)srcUpn[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVp[x_4]]+(unsigned short)srcVpn[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Upsample as needed.
			if ((interlaced_tab[index_tab_1][x_4]) || (interlaced_tab[index_tab_2][x_4]))
			{
				dstp[x] = 180;
				dstp[x+2] = 180;
				
				dstp[x+1]=128;
				dstp[x+3]=128;
			}
			else
			{
				dstp[x] = srcYp[x_2];
				dstp[x+2] = srcYp[x_2+1];
				
				dstp[x+1]=(lookup_3[srcUpn[x_4]]+(unsigned short)srcUp[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVpn[x_4]]+(unsigned short)srcVp[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			if (((abs((signed short)srcUpn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				(abs((signed short)srcUpnnn[x_4]-(signed short)srcUpnn[x_4])>=threshold) &&
				((srcUpn[x_4]>srcUpnn[x_4]) && (srcUpnnn[x_4]>srcUpnn[x_4]) ||
				(srcUpn[x_4]<srcUpnn[x_4]) && (srcUpnnn[x_4]<srcUpnn[x_4]))) ||
				((abs((signed short)srcVpn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				(abs((signed short)srcVpnnn[x_4]-(signed short)srcVpnn[x_4])>=threshold) &&
				((srcVpn[x_4]>srcVpnn[x_4]) && (srcVpnnn[x_4]>srcVpnn[x_4]) ||
				(srcVpn[x_4]<srcVpnn[x_4]) && (srcVpnnn[x_4]<srcVpnn[x_4]))))
				interlaced_tab[index_tab_0][x_4]=true;
			else interlaced_tab[index_tab_0][x_4]=false;

			// Upsample as needed.
			if ((interlaced_tab[index_tab_2][x_4]) || (interlaced_tab[index_tab_0][x_4]))
			{
				dstp[x] = 180;
				dstp[x+2] = 180;
				
				dstp[x+1]=128;
				dstp[x+3]=128;
			}
			else
			{
				dstp[x] = srcYp[x_2];
				dstp[x+2] = srcYp[x_2+1];
				
				dstp[x+1]=(lookup_3[srcUpn[x_4]]+(unsigned short)srcUpnn[x_4]+2) >> 2;
				dstp[x+3]=(lookup_3[srcVpn[x_4]]+(unsigned short)srcVpnn[x_4]+2) >> 2;
			}
						
			x_2+=2;
			x_4++;
		}
		
		index_tab_0=(index_tab_0+2)%Interlaced_Tab_Size;
		index_tab_1=(index_tab_1+2)%Interlaced_Tab_Size;
		index_tab_2=(index_tab_2+2)%Interlaced_Tab_Size;
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;	
	}

	for (y = dst_h_4; y < dst_h; y+=4)
	{
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			// Luma.
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_7[srcUp[x_4]]+(unsigned short)srcUppp[x_4]+4) >> 3;
			dstp[x+3]=(lookup_7[srcVp[x_4]]+(unsigned short)srcVppp[x_4]+4) >> 3;
				
			x_2+=2;
			x_4++;
		}

		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=(lookup_3[srcUpp[x_4]]+lookup_5[srcUpn[x_4]]+4) >> 3;
			dstp[x+3]=(lookup_3[srcVpp[x_4]]+lookup_5[srcVpn[x_4]]+4) >> 3;
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;
		
		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUp[x_4];
			dstp[x+3]=srcVp[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		x_2=0;
		x_4=0;
		for (x = 0; x < dst_w; x+=4)
		{
			//Luma
			dstp[x] = srcYp[x_2];
			dstp[x+2] = srcYp[x_2+1];

			// Upsample as needed.
			dstp[x+1]=srcUpn[x_4];
			dstp[x+3]=srcVpn[x_4];
						
			x_2+=2;
			x_4++;
		}
		
		dstp += dst_pitch;
		srcYp += src_pitchY;

		srcUp += src_pitchUV_2;
		srcUpp += src_pitchUV_2;
		srcUppp += src_pitchUV_2;
		srcUpn += src_pitchUV_2;
		srcUpnn += src_pitchUV_2;
		srcUpnnn += src_pitchUV_2;
		srcVp += src_pitchUV_2;
		srcVpp += src_pitchUV_2;
		srcVppp += src_pitchUV_2;
		srcVpn += src_pitchUV_2;
		srcVpnn += src_pitchUV_2;
		srcVpnnn += src_pitchUV_2;
	}
}
		

PVideoFrame __stdcall AutoYUY2::GetFrame(int n, IScriptEnvironment* env) 
{
	PVideoFrame src = child->GetFrame(n,env);
	PVideoFrame dst = env->NewVideoFrame(vi);
	unsigned char *dstp = dst->GetWritePtr(PLANAR_Y);
	const unsigned char *srcYp = src->GetReadPtr(PLANAR_Y);
	const unsigned char *srcUp = src->GetReadPtr(PLANAR_U);
	const unsigned char *srcVp = src->GetReadPtr(PLANAR_V);
	int dst_h,dst_w,dst_pitch;
	int src_pitchY, src_pitchUV;

	dst_h = dst->GetHeight();
	dst_w = dst->GetRowSize();
	dst_pitch = dst->GetPitch();
	src_pitchY = src->GetPitch(PLANAR_Y);
	src_pitchUV = src->GetPitch(PLANAR_U);

	switch(mode)
	{
	case 0:
        Convert_Automatic(srcYp,srcUp,srcVp,dstp,dst_h,dst_w,dst_pitch,src_pitchY, src_pitchUV);
        break;
    case 1:
        Convert_Map(srcYp,srcUp,srcVp,dstp,dst_h,dst_w,dst_pitch,src_pitchY, src_pitchUV);
        break;
	case 2:
        Convert_Progressive(srcYp,srcUp,srcVp,dstp,dst_h,dst_w,dst_pitch,src_pitchY, src_pitchUV);
        break;
	case 3:
        Convert_Interlaced(srcYp,srcUp,srcVp,dstp,dst_h,dst_w,dst_pitch,src_pitchY, src_pitchUV);
        break;
	}

	return dst;
}

AVSValue __cdecl Create_AutoYUY2(AVSValue args, void* user_data, IScriptEnvironment* env) {
  return new AutoYUY2(args[0].AsClip(), args[1].AsInt(0), args[2].AsInt(7), env);
}

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) {
    env->AddFunction("AutoYUY2", "c[mode]i[threshold]i", Create_AutoYUY2, 0);
    return 0;
}
