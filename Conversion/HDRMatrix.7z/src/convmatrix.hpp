// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// http://en.wikipedia.org/wiki/YUV

const float u_range_for_matrix = 0.436f;
const float v_range_for_matrix = 0.615f;

__declspec(align(16)) const float matrix_601_rgb_to_yuv[9] = {
	0.299f,		0.587f,		0.114f,
	-0.14713f,	-0.28886f,	0.436f,
	0.615f,		-0.51499f,	-0.10001f
};
__declspec(align(16)) const float matrix_601_yuv_to_rgb[9] = {
	1.0f,		0.0f,		1.13983f,
	1.0f,		-0.39465f,	-0.58060f,
	1.0f,		2.03211f,	0.0f
};
__declspec(align(16)) const float matrix_709_rgb_to_yuv[9] = {
	0.2126f,	0.7152f,	0.0722f,
	-0.09991f,	-0.33609f,	0.436f,
	0.615f,		-0.55861f,	-0.05639f
};
__declspec(align(16)) const float matrix_709_yuv_to_rgb[9] = {
	1.0f,		0.0f,		1.28033f,
	1.0f,		-0.21482f,	-0.38059f,
	1.0f,		2.12798f,	0.0f
};