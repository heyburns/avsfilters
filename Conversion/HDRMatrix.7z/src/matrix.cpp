// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"
#include "yuvfilter.hpp"
#include "convmatrix.hpp"

namespace Matrix {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

struct Args {
	float ki1;
	float ki2;
	float ko1;
	float ko2;
	float kic1;
	float kic2_u;
	float kic2_v;
	float koc1_u;
	float koc1_v;
	float koc2;
	const float* torgb;
	const float* toyuv;
	float rg;
	float gg;
	float bg;
};

void filter_operation(float* ym, float* um, float* vm, Args* args) {
	// Normalize
	float y = *ym * args->ki1 + args->ki2;
	float u = (*um - args->kic1) * args->kic2_u;
	float v = (*vm - args->kic1) * args->kic2_v;
	// Convert to rgb
	float r = (y*args->torgb[0]+u*args->torgb[1]+v*args->torgb[2]) * args->rg;
	float g = (y*args->torgb[3]+u*args->torgb[4]+v*args->torgb[5]) * args->gg;
	float b = (y*args->torgb[6]+u*args->torgb[7]+v*args->torgb[8]) * args->bg;
	// Convert back to yuv
	y = r*args->toyuv[0]+g*args->toyuv[1]+b*args->toyuv[2];
	u = r*args->toyuv[3]+g*args->toyuv[4]+b*args->toyuv[5];
	v = r*args->toyuv[6]+g*args->toyuv[7]+b*args->toyuv[8];
	// Store back
	*ym = y * args->ko1 + args->ko2;
	*um = u * args->koc1_u + args->koc2;
	*vm = v * args->koc1_v + args->koc2;
}

typedef void (*FilterFunc)(Args*, Frame&);

void filter_none(Args* args, Frame& frame) {
	(void)args;
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsY8())
		env->ThrowError("Matrix: Y8 is not supported.");
	if (vi.IsYUY2())
		env->ThrowError("Matrix: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("Matrix: RGB is not supported.");

	int arg = 0;
	const int fm = args[++arg].AsInt(601);
	const int tm = args[++arg].AsInt(709);
	const float rg = (float)args[++arg].AsFloat(1.0);
	const float gg = (float)args[++arg].AsFloat(1.0);
	const float bg = (float)args[++arg].AsFloat(1.0);
	const float a = (float)args[++arg].AsFloat(16.0);
	const float b = (float)args[++arg].AsFloat(235.0);
	const float ao = (float)args[++arg].AsFloat(16.0);
	const float bo = (float)args[++arg].AsFloat(235.0);
	const int bitdepth = args[++arg].AsInt(8);

	m_args.rg = rg;
	m_args.gg = gg;
	m_args.bg = bg;

	if (bitdepth == 8) {
		m_args.ki1 = 1.0f/(b-a);
		m_args.ki2 = -a/(b-a);
		m_args.ko1 = bo-ao;
		m_args.ko2 = ao + 0.5f; // Rounding error
		m_args.kic1 = 128.0f;
		m_args.kic2_u = 1.0f / 128.0f * u_range_for_matrix;
		m_args.kic2_v = 1.0f / 128.0f * v_range_for_matrix;
		m_args.koc1_u = 128.0f * (1.0f / u_range_for_matrix);
		m_args.koc1_v = 128.0f * (1.0f / v_range_for_matrix);
		m_args.koc2 = 128.0f + 0.5f;  // Rounding error
	} else if ((bitdepth == 88) || (bitdepth == 16)) {
		m_args.ki1 = 1.0f/256.0f/(b-a);
		m_args.ki2 = -a/(b-a);
		m_args.ko1 = (bo-ao)*256.0f;
		m_args.ko2 = ao*256.0f + 0.5f; // Rounding error
		m_args.kic1 = 128.0f*256.0f;
		m_args.kic2_u = 1.0f / (128.0f*256.0f) * u_range_for_matrix;
		m_args.kic2_v = 1.0f / (128.0f*256.0f) * v_range_for_matrix;
		m_args.koc1_u = 128.0f*256.0f * (1.0f / u_range_for_matrix);
		m_args.koc1_v = 128.0f*256.0f * (1.0f / v_range_for_matrix);
		m_args.koc2 = 128.0f*256.0f + 0.5f; // Rounding error
	} else {
		m_args.ki1 = 1.0f/(b-a);
		m_args.ki2 = -a/(b-a);
		m_args.ko1 = bo-ao;
		m_args.ko2 = ao;
		m_args.kic1 = 128.0f;
		m_args.kic2_u = 1.0f / 128.0f * u_range_for_matrix;
		m_args.kic2_v = 1.0f / 128.0f * v_range_for_matrix;
		m_args.koc1_u = 128.0f * (1.0f / u_range_for_matrix);
		m_args.koc1_v = 128.0f * (1.0f / v_range_for_matrix);
		m_args.koc2 = 128.0f;
	}

	if (fm==601) {
		m_args.torgb = matrix_601_yuv_to_rgb;
	} else {
		m_args.torgb = matrix_709_yuv_to_rgb;
	}
	if (tm==601) {
		m_args.toyuv = matrix_601_rgb_to_yuv;
	} else {
		m_args.toyuv = matrix_709_rgb_to_yuv;
	}

	if (bitdepth == 8) {
		if (vi.IsYV24()) {
			m_filter = filter_8_24_truncate<Args, Frame, filter_operation>;
		} else if (vi.IsYV16()) {
			m_filter = filter_8_16_truncate<Args, Frame, filter_operation>;
		} else {
			m_filter = filter_8_12_truncate<Args, Frame, filter_operation>;
		}
	} else if (bitdepth == 16) {
		if (vi.IsYV24()) {
			m_filter = filter_16_24<Args, Frame, filter_operation>;
		} else if (vi.IsYV16()) {
			m_filter = filter_16_16<Args, Frame, filter_operation>;
		} else {
			m_filter = filter_16_12<Args, Frame, filter_operation>;
		}
	} else if (bitdepth == 32) {
		if (vi.IsYV24()) {
			m_filter = filter_32_24<Args, Frame, filter_operation>;
		} else if (vi.IsYV16()) {
			m_filter = filter_32_16<Args, Frame, filter_operation>;
		} else {
			m_filter = filter_32_12<Args, Frame, filter_operation>;
		}
	} else {
		env->ThrowError("Matrix: Unsupported bitdepth %d\n", bitdepth);
	}
	
	//if (fm == tm)
	//	m_filter = filter_none;
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_Matrix(IScriptEnvironment* env)
{
	// Matrix(from=601, to=709, rg=1.0, gg=1.0, bg=1.0, a=16, b=235, ao=16, bo=235, bitdepth=8)
    env->AddFunction("Matrix", "c[from]i[to]i[rg]f[gg]f[bg]f[a]f[b]f[ao]f[bo]f[bitdepth]i", Matrix::Create_Filter, 0);
}
