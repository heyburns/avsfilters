// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"

extern void Add_Matrix(IScriptEnvironment* env);

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env)
{
	Add_Matrix(env);
    return "HDRMatrix Library";
}
