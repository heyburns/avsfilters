// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_8_24_truncate(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr_y = frame.src->GetWritePtr(PLANAR_Y);
	uint8_t* ptr_u = frame.src->GetWritePtr(PLANAR_U);
	uint8_t* ptr_v = frame.src->GetWritePtr(PLANAR_V);
	for (int yy = 0; yy < height; ++yy) {
		for (int x = 0; x < width; ++x) {
			float y = (float)ptr_y[x];
			float u = (float)ptr_u[x];
			float v = (float)ptr_v[x];
			Function(&y, &u, &v, args);
			ptr_y[x] = clamp8(y);
			ptr_u[x] = clamp8(u);
			ptr_v[x] = clamp8(v);
		}
		ptr_y += pitch;
		ptr_u += pitch;
		ptr_v += pitch;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_8_16_truncate(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1; // 4:2:2
	const int height = frame.vi->height;
	const int pitch_y = frame.src->GetPitch();
	const int pitch_uv = frame.src->GetPitch(PLANAR_U);
	uint8_t* ptr_y = frame.src->GetWritePtr(PLANAR_Y);
	uint8_t* ptr_u = frame.src->GetWritePtr(PLANAR_U);
	uint8_t* ptr_v = frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u0 = (float)(*(ptr_u+x));
			float v0 = (float)(*(ptr_v+x));
			float u1 = u0;
			float v1 = v0;
			float y0 = (float)(*(ptr_y+(x<<1)+0));
			float y1 = (float)(*(ptr_y+(x<<1)+1));
			Function(&y0, &u0, &v0, args);
			Function(&y1, &u1, &v1, args);
			u0 = (u0+u1) * 0.5f;
			v0 = (v0+v1) * 0.5f;
			*(ptr_y+(x<<1)+0) = clamp8(y0);
			*(ptr_y+(x<<1)+1) = clamp8(y1);
			*(ptr_u+x) = clamp8(u0);
			*(ptr_v+x) = clamp8(v0);
		}
		ptr_y += pitch_y;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_8_12_truncate(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1;		// 4:2:0
	const int height = frame.vi->height >> 1;	// 4:2:0
	const int pitch_y = frame.src->GetPitch();
	const int pitch_uv = frame.src->GetPitch(PLANAR_U);
	uint8_t* ptr_y = frame.src->GetWritePtr(PLANAR_Y);
	uint8_t* ptr_u = frame.src->GetWritePtr(PLANAR_U);
	uint8_t* ptr_v = frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u00 = (float)(*(ptr_u+x));
			float v00 = (float)(*(ptr_v+x));
			float u01 = u00;
			float v01 = v00;
			float u10 = u00;
			float v10 = v00;
			float u11 = u00;
			float v11 = v00;
			float y00 = (float)(*(ptr_y+(x<<1)+0));
			float y01 = (float)(*(ptr_y+(x<<1)+1));
			float y10 = (float)(*(ptr_y+(x<<1)+0+pitch_y));
			float y11 = (float)(*(ptr_y+(x<<1)+1+pitch_y));
			Function(&y00, &u00, &v00, args);
			Function(&y01, &u01, &v01, args);
			Function(&y10, &u10, &v10, args);
			Function(&y11, &u11, &v11, args);
			u00 = (u00+u01+u10+u11) * 0.25f;
			v00 = (v00+v01+v10+v11) * 0.25f;
			*(ptr_y+(x<<1)+0) = clamp8(y00);
			*(ptr_y+(x<<1)+1) = clamp8(y01);
			*(ptr_y+(x<<1)+0+pitch_y) = clamp8(y10);
			*(ptr_y+(x<<1)+1+pitch_y) = clamp8(y11);
			*(ptr_u+x) = clamp8(u00);
			*(ptr_v+x) = clamp8(v00);
		}
		ptr_y += pitch_y << 1;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_16_24(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 1;
	uint16_t* ptr_y = (uint16_t*)frame.src->GetWritePtr(PLANAR_Y);
	uint16_t* ptr_u = (uint16_t*)frame.src->GetWritePtr(PLANAR_U);
	uint16_t* ptr_v = (uint16_t*)frame.src->GetWritePtr(PLANAR_V);
	for (int yy = 0; yy < height; ++yy) {
		for (int x = 0; x < width; ++x) {
			float y = (float)ptr_y[x];
			float u = (float)ptr_u[x];
			float v = (float)ptr_v[x];
			Function(&y, &u, &v, args);
			ptr_y[x] = clamp16(y);
			ptr_u[x] = clamp16(u);
			ptr_v[x] = clamp16(v);
		}
		ptr_y += pitch;
		ptr_u += pitch;
		ptr_v += pitch;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_16_16(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1 >> 1; // 4:2:2
	const int height = frame.vi->height;
	const int pitch_y = frame.src->GetPitch() >> 1;
	const int pitch_uv = frame.src->GetPitch(PLANAR_U) >> 1;
	uint16_t* ptr_y = (uint16_t*)frame.src->GetWritePtr(PLANAR_Y);
	uint16_t* ptr_u = (uint16_t*)frame.src->GetWritePtr(PLANAR_U);
	uint16_t* ptr_v = (uint16_t*)frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u0 = (float)(*(ptr_u+x));
			float v0 = (float)(*(ptr_v+x));
			float u1 = u0;
			float v1 = v0;
			float y0 = (float)(*(ptr_y+(x<<1)+0));
			float y1 = (float)(*(ptr_y+(x<<1)+1));
			Function(&y0, &u0, &v0, args);
			Function(&y1, &u1, &v1, args);
			u0 = (u0+u1) * 0.5f;
			v0 = (v0+v1) * 0.5f;
			*(ptr_y+(x<<1)+0) = clamp16(y0);
			*(ptr_y+(x<<1)+1) = clamp16(y1);
			*(ptr_u+x) = clamp16(u0);
			*(ptr_v+x) = clamp16(v0);
		}
		ptr_y += pitch_y;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_16_12(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1 >> 1;	// 4:2:0
	const int height = frame.vi->height >> 1;		// 4:2:0
	const int pitch_y = frame.src->GetPitch() >> 1;
	const int pitch_uv = frame.src->GetPitch(PLANAR_U) >> 1;
	uint16_t* ptr_y = (uint16_t*)frame.src->GetWritePtr(PLANAR_Y);
	uint16_t* ptr_u = (uint16_t*)frame.src->GetWritePtr(PLANAR_U);
	uint16_t* ptr_v = (uint16_t*)frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u00 = (float)(*(ptr_u+x));
			float v00 = (float)(*(ptr_v+x));
			float u01 = u00;
			float v01 = v00;
			float u10 = u00;
			float v10 = v00;
			float u11 = u00;
			float v11 = v00;
			float y00 = (float)(*(ptr_y+(x<<1)+0));
			float y01 = (float)(*(ptr_y+(x<<1)+1));
			float y10 = (float)(*(ptr_y+(x<<1)+0+pitch_y));
			float y11 = (float)(*(ptr_y+(x<<1)+1+pitch_y));
			Function(&y00, &u00, &v00, args);
			Function(&y01, &u01, &v01, args);
			Function(&y10, &u10, &v10, args);
			Function(&y11, &u11, &v11, args);
			u00 = (u00+u01+u10+u11) * 0.25f;
			v00 = (v00+v01+v10+v11) * 0.25f;
			*(ptr_y+(x<<1)+0) = clamp16(y00);
			*(ptr_y+(x<<1)+1) = clamp16(y01);
			*(ptr_y+(x<<1)+0+pitch_y) = clamp16(y10);
			*(ptr_y+(x<<1)+1+pitch_y) = clamp16(y11);
			*(ptr_u+x) = clamp16(u00);
			*(ptr_v+x) = clamp16(v00);
		}
		ptr_y += pitch_y << 1;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_32_24(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 2;
	float* ptr_y = (float*)frame.src->GetWritePtr(PLANAR_Y);
	float* ptr_u = (float*)frame.src->GetWritePtr(PLANAR_U);
	float* ptr_v = (float*)frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			Function(ptr_y+x, ptr_u+x, ptr_v+x, args);
		}
		ptr_y += pitch;
		ptr_u += pitch;
		ptr_v += pitch;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_32_16(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2 >> 1; // 4:2:2
	const int height = frame.vi->height;
	const int pitch_y = frame.src->GetPitch() >> 2;
	const int pitch_uv = frame.src->GetPitch(PLANAR_U) >> 2;
	float* ptr_y = (float*)frame.src->GetWritePtr(PLANAR_Y);
	float* ptr_u = (float*)frame.src->GetWritePtr(PLANAR_U);
	float* ptr_v = (float*)frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u0 = *(ptr_u+x);
			float v0 = *(ptr_v+x);
			float u1 = u0;
			float v1 = v0;
			Function(ptr_y+(x<<1)+0, &u0, &v0, args);
			Function(ptr_y+(x<<1)+1, &u1, &v1, args);
			u0 = (u0+u1) * 0.5f;
			v0 = (v0+v1) * 0.5f;
			*(ptr_u+x) = u0;
			*(ptr_v+x) = v0;
		}
		ptr_y += pitch_y;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}

template <class Args, class Frame, void(*Function)(float*, float*, float*, Args*)>
void filter_32_12(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2 >> 1;	// 4:2:0
	const int height = frame.vi->height >> 1;		// 4:2:0
	const int pitch_y = frame.src->GetPitch() >> 2;
	const int pitch_uv = frame.src->GetPitch(PLANAR_U) >> 2;
	float* ptr_y = (float*)frame.src->GetWritePtr(PLANAR_Y);
	float* ptr_u = (float*)frame.src->GetWritePtr(PLANAR_U);
	float* ptr_v = (float*)frame.src->GetWritePtr(PLANAR_V);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float u00 = *(ptr_u+x);
			float v00 = *(ptr_v+x);
			float u01 = u00;
			float v01 = v00;
			float u10 = u00;
			float v10 = v00;
			float u11 = u00;
			float v11 = v00;
			Function(ptr_y+(x<<1)+0, &u00, &v00, args);
			Function(ptr_y+(x<<1)+1, &u01, &v01, args);
			Function(ptr_y+(x<<1)+0+pitch_y, &u10, &v10, args);
			Function(ptr_y+(x<<1)+1+pitch_y, &u11, &v11, args);
			u00 = (u00+u01+u10+u11) * 0.25f;
			v00 = (v00+v01+v10+v11) * 0.25f;
			*(ptr_u+x) = u00;
			*(ptr_v+x) = v00;
		}
		ptr_y += pitch_y << 1;
		ptr_u += pitch_uv;
		ptr_v += pitch_uv;
	}
	frame.dst = frame.src;
}
