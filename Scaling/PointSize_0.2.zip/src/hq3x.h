
// HQ3x header for PointSize

#ifndef __HQ3X_H
#define __HQ3X_H

#include "interp.h"

void hq3x_32_def(u32* dst0, u32* dst1, u32* dst2, const u32* src0, const u32* src1, const u32* src2, unsigned count);
void hq3x32(u8 *srcPtr, u32 srcPitch, u8 *dstPtr, u32 dstPitch, int width, int height);

#endif
