// ****************************************************************************
// * This file is part of the HqMAME project. It is distributed under         *
// * GNU General Public License: http://www.gnu.org/licenses/gpl-3.0          *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved          *
// ****************************************************************************

#ifndef XBRZ_CONFIG_HEADER_284578425345
#define XBRZ_CONFIG_HEADER_284578425345

//do NOT include any headers here! used by xBRZ_dll!!!

namespace xbrz
{
struct ScalerCfg
{
    ScalerCfg() :
        luminanceWeight(1),
        equalColorTolerance(30),
        dominantDirectionThreshold(3.6),
        steepDirectionThreshold(2.2),
        newTestAttribute(0) {}

    double luminanceWeight;
    double equalColorTolerance;
    double dominantDirectionThreshold;
    double steepDirectionThreshold;
    double newTestAttribute; //unused; test new parameters
};
}

#endif
