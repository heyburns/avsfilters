/*
PointSize - Collection of resizers for AviSynth
Copyright (C) 2016 `Orum @ forum.doom9.org

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "avisynth.h"
#include "windows.h"

#include "ps.h"

scalex::scalex(PClip _child, int _scale, IScriptEnvironment* env) : GenericVideoFilter(_child) {
	if(!vi.HasVideo())				env->ThrowError("scalex: No video input.");
	if(!vi.IsRGB32())					env->ThrowError("scalex: Input must be RGB32.");
	if(vi.height < 2)					env->ThrowError("scalex: Height must be > 1.");
	if(vi.width < 2)					env->ThrowError("scalex: Width must be > 1.");
	if(_scale < 2 || _scale > 3)	env->ThrowError("scalex: scale must be between 2 and 3 (inclusive)");

	scale = _scale - 2;	// Index hack! :)
	src_width = vi.width;	src_height = vi.height;
	vi.width *= _scale;		vi.height *= _scale;
}

LQx::LQx(PClip _child, int _scale, IScriptEnvironment* env) : GenericVideoFilter(_child) {
	if(!vi.HasVideo())				env->ThrowError("LQx: No video input.");
	if(!vi.IsRGB32())					env->ThrowError("LQx: Input must be RGB32.");
	if(vi.height < 2)					env->ThrowError("LQx: Height must be > 1.");
	if(vi.width < 2)					env->ThrowError("LQx: Width must be > 1.");
	if(_scale < 2 || _scale > 4)	env->ThrowError("LQx: scale must be between 2 and 4 (inclusive)");

	scale = _scale - 2;	// Index hack! :)
	src_width = vi.width;	src_height = vi.height;
	vi.width *= _scale;		vi.height *= _scale;
}

HQx::HQx(PClip _child, int _scale, IScriptEnvironment* env) : GenericVideoFilter(_child) {
	if(!vi.HasVideo())				env->ThrowError("HQx: No video input.");
	if(!vi.IsRGB32())					env->ThrowError("HQx: Input must be RGB32.");
	if(vi.height < 2)					env->ThrowError("HQx: Height must be > 1.");
	if(vi.width < 2)					env->ThrowError("HQx: Width must be > 1.");
	if(_scale < 2 || _scale > 4)	env->ThrowError("HQx: scale must be between 2 and 4 (inclusive)");

	scale = _scale - 2;	// Index hack! :)
	src_width = vi.width;	src_height = vi.height;
	vi.width *= _scale;		vi.height *= _scale;
}

xBRZ::xBRZ(PClip _child, int _scale, double Yweight, double EqColorTol, double DomDirThresh, double SteepDirThresh, IScriptEnvironment* env) : GenericVideoFilter(_child) {
	if(!vi.HasVideo())				env->ThrowError("xBRZ: No video input.");
	if(!vi.IsRGB32())					env->ThrowError("xBRZ: Input must be RGB32.");
	if(vi.height < 2)					env->ThrowError("xBRZ: Height must be > 1.");
	if(vi.width < 2)					env->ThrowError("xBRZ: Width must be > 1.");
	if(_scale < 2 || _scale > 6)	env->ThrowError("xBRZ: scale must be between 2 and 6 (inclusive)");

	scale = _scale;	// NOT a hack (filter supports parameter)
	src_width = vi.width;	src_height = vi.height;
	vi.width *= _scale;		vi.height *= _scale;

	// Filter params
	sc.luminanceWeight = Yweight; sc.equalColorTolerance = EqColorTol; sc.dominantDirectionThreshold = DomDirThresh; sc.steepDirectionThreshold = SteepDirThresh;
}

PVideoFrame __stdcall scalex::GetFrame(int n, IScriptEnvironment* env) { PVideoFrame src = child->GetFrame(n, env); PVideoFrame dst = env->NewVideoFrame(vi);
	scalefn[scale]	((u8*)src->GetReadPtr(), src->GetPitch(), dst->GetWritePtr(), dst->GetPitch(), src_width, src_height);										return dst; }
PVideoFrame __stdcall LQx::GetFrame(	int n, IScriptEnvironment* env) { PVideoFrame src = child->GetFrame(n, env); PVideoFrame dst = env->NewVideoFrame(vi);
	LQfn[scale]		((u8*)src->GetReadPtr(), src->GetPitch(), dst->GetWritePtr(), dst->GetPitch(), src_width, src_height);										return dst; }
PVideoFrame __stdcall HQx::GetFrame(	int n, IScriptEnvironment* env) { PVideoFrame src = child->GetFrame(n, env); PVideoFrame dst = env->NewVideoFrame(vi);
	HQfn[scale]		((u8*)src->GetReadPtr(), src->GetPitch(), dst->GetWritePtr(), dst->GetPitch(), src_width, src_height);										return dst; }
PVideoFrame __stdcall xBRZ::GetFrame(	int n, IScriptEnvironment* env) { PVideoFrame src = child->GetFrame(n, env); PVideoFrame dst = env->NewVideoFrame(vi);
	xbrz::scale(scale, (uint32_t*)src->GetReadPtr(), src_width, src_height, src->GetPitch(), (uint32_t*)dst->GetWritePtr(), dst->GetPitch(), xbrz::ARGB, sc);	return dst; }

AVSValue __cdecl Create_scalex(	AVSValue args, void* user_data, IScriptEnvironment* env) { return new scalex(	args[0].AsClip(),	args[1].AsInt(2),																															env);	}
AVSValue __cdecl Create_LQx(		AVSValue args, void* user_data, IScriptEnvironment* env) { return new LQx(		args[0].AsClip(),	args[1].AsInt(2),																															env); }
AVSValue __cdecl Create_HQx(		AVSValue args, void* user_data, IScriptEnvironment* env) { return new HQx(		args[0].AsClip(),	args[1].AsInt(2),																															env); }
AVSValue __cdecl Create_xBRZ(		AVSValue args, void* user_data, IScriptEnvironment* env) { return new xBRZ(	args[0].AsClip(),	args[1].AsInt(2),	args[2].AsFloat(1),	args[3].AsFloat(30),	args[4].AsFloat(3.6),	args[5].AsFloat(2.2),	env); }

const AVS_Linkage *AVS_linkage = 0;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, AVS_Linkage* vectors) {
	env->AddFunction("scalex",	"c[scale]i",																			Create_scalex,	0);
	env->AddFunction("LQx",		"c[scale]i",																			Create_LQx,		0);
	env->AddFunction("HQx",		"c[scale]i",																			Create_HQx,		0);
	env->AddFunction("xBRZ",	"c[scale]i[Yweight]f[EqColorTol]f[DomDirThresh]f[SteepDirThresh]f",	Create_xBRZ,	0);
	AVS_linkage = vectors;

	return "`PointSize' Collection of resizers for low-res, 2D video game captures and pixel art.";
}
