
// LQ4x header for PointSize

#ifndef __LQ4X_H
#define __LQ4X_H

#include "interp.h"

void lq4x_32_def(u32* dst0, u32* dst1, u32* dst2, u32* dst3, const u32* src0, const u32* src1, const u32* src2, unsigned count);
void lq4x32(u8 *srcPtr, u32 srcPitch, u8 *dstPtr, u32 dstPitch, int width, int height);

#endif
