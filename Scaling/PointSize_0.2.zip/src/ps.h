/*
PointSize - Collection of resizers for AviSynth
Copyright (C) 2016 `Orum @ forum.doom9.org

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "scale2x.h"
#include "scale3x.h"
#include "lq2x.h"
#include "lq3x.h"
#include "lq4x.h"
#include "hq2x.h"
#include "hq3x.h"
#include "hq4x.h"
#include "xbrz.h"

class scalex : public GenericVideoFilter {   
	int src_width, src_height, scale;
	void (*scalefn[2])(u8 *srcPtr, u32 srcPitch, u8 *dstPtr, u32 dstPitch, int width, int height)
		= { scale2x32, scale3x32 };

public:
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
	scalex(PClip _child, int _scale, IScriptEnvironment* env);
};

class LQx : public GenericVideoFilter {   
	int src_width, src_height, scale;
	void (*LQfn[3])(u8 *srcPtr, u32 srcPitch, u8 *dstPtr, u32 dstPitch, int width, int height)
		= { lq2x32, lq3x32, lq4x32 };

public:
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
	LQx(PClip _child, int _scale, IScriptEnvironment* env);
};

class HQx : public GenericVideoFilter {   
	int src_width, src_height, scale;
	void (*HQfn[3])(u8 *srcPtr, u32 srcPitch, u8 *dstPtr, u32 dstPitch, int width, int height)
		= { hq2x32, hq3x32, hq4x32 };

public:
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
	HQx(PClip _child, int _scale, IScriptEnvironment* env);
};

class xBRZ : public GenericVideoFilter {
	int src_width, src_height, scale;
	xbrz::ScalerCfg sc;

public:
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
	xBRZ(PClip _child, int _scale, double Yweight, double EqColorTol, double DomDirThresh, double SteepDirThresh, IScriptEnvironment* env);
};
