##### 1.0.1:
    Fixed error message for `opt`.

##### 1.0.0:
    Added support for 10..16-bit clips.
    Frame properties passthrough.

##### 0.0.0:
    Initial release. (2017/03/17) (chikuzen)
