/*
	YUV conversion table generator
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "../resamplehq/targetver.hpp"

#include <iostream>
#include "colorx.hpp"

template<typename Coefficients, typename Range>
inline void print(const char *name)
{
	std::cout
		<< "color::yuv_table const color::" << name << " =" << std::endl
		<< color::detail::yuv_table<Coefficients, Range>() << ";" << std::endl
		<< std::endl;
}

int main()
{
	print<color::detail::rec601, color::detail::tv_range>("tv601");
	print<color::detail::rec709, color::detail::tv_range>("tv709");
	print<color::detail::smpte240m, color::detail::tv_range>("tv240");
	print<color::detail::fcc, color::detail::tv_range>("tvfcc");
	print<color::detail::rec601, color::detail::pc_range>("pc601");
	print<color::detail::rec709, color::detail::pc_range>("pc709");
	print<color::detail::smpte240m, color::detail::pc_range>("pc240");
	print<color::detail::fcc, color::detail::pc_range>("pcfcc");

	return 0;
}
