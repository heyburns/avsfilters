/*
	Colorspace conversions
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_COLORX_HPP
#define INT64_ORG_RESAMPLER_COLORX_HPP

#ifdef _MSC_VER
#pragma once
#endif

#pragma once

#include <cmath>
#include <ostream>
#include <iomanip>
#include <type_traits>

namespace color
{

namespace detail
{
	struct linear
	{
		inline static double to_linear(double c) { return c; }
		inline static double from_linear(double c) { return c; }
	};

	struct srgb
	{
		inline static double to_linear(double c)
		{
			return (c <= 0.04045) ? (c / 12.92) : std::pow((c + 0.055) / 1.055, 2.4);
		}

		inline static double from_linear(double c)
		{
			if(c <= 0.0)
			{
				return 0.0;
			}

			if(c <= 0.0031308)
			{
				return c * 12.92;
			}

			if(c < 1.0)
			{
				return std::pow(c, 1.0 / 2.4) * 1.055 - 0.055;
			}

			return 1.0;
		}
	};

	template<typename Derived>
	struct rec_base
	{
		inline static double g_scale_r() { return 1.0 / Derived::g_scale(); }

		inline static double pb_mul() { return 0.5 / (1.0 - Derived::b_scale()); }
		inline static double pb_mul_r() { return 1.0 / pb_mul(); }
		inline static double pr_mul() { return 0.5 / (1.0 - Derived::r_scale()); }
		inline static double pr_mul_r() { return 1.0 / pr_mul(); }
	};

	template<typename Derived>
	struct range_base
	{
		inline static double y_mul() { return Derived::y_max() - Derived::y_min(); }
		inline static double y_mul_r() { return 1.0 / y_mul(); }

		inline static double y_add() { return Derived::y_min(); }
		inline static double y_madd() { return y_add() * y_mul(); }
		inline static double y_madd_r() { return y_add() / y_mul(); }

		inline static double c_mul() { return Derived::c_max() - Derived::c_min(); }
		inline static double c_mul_r() { return 1.0 / c_mul(); }
		
		inline static double c_add() { return c_mul() * 0.5 + Derived::c_min(); }
		inline static double c_madd() { return c_add() * c_mul(); }
		inline static double c_madd_r() { return c_add() / c_mul(); }
	};

	struct rec601 : rec_base<rec601>
	{
		inline static double r_scale() { return 0.299; }
		inline static double g_scale() { return 0.587; }
		inline static double b_scale() { return 0.114; }
	};

	struct rec709 : rec_base<rec709>
	{
		inline static double r_scale() { return 0.2125; }
		inline static double g_scale() { return 0.7154; }
		inline static double b_scale() { return 0.0721; }
	};

	typedef rec601 rec470;
	typedef rec601 smpte170m;

	struct smpte240m : rec_base<smpte240m>
	{
		inline static double r_scale() { return 0.212; }
		inline static double g_scale() { return 0.701; }
		inline static double b_scale() { return 0.087; }
	};

	struct fcc : rec_base<fcc>
	{
		inline static double r_scale() { return 0.3; }
		inline static double g_scale() { return 0.59; }
		inline static double b_scale() { return 0.11; }
	};

	struct tv_range : range_base<tv_range>
	{
		inline static double y_min() { return 16.0; }
		inline static double y_max() { return 235.0; }

		inline static double c_min() { return 16.0; }
		inline static double c_max() { return 240.0; }
	};

	struct pc_range : range_base<pc_range>
	{
		inline static double y_min() { return 0.0; }
		inline static double y_max() { return 255.0; }

		inline static double c_min() { return 0.0; }
		inline static double c_max() { return 255.0; }
	};

	struct yuv_table_base
	{
	};

	template<typename Coefficients, typename Range>
	struct yuv_table : Coefficients, Range, yuv_table_base
	{
		inline static double pbc_mul() { return Coefficients::pb_mul() * Range::c_mul(); }
		inline static double pbc_mul_r() { return 1.0 / pbc_mul(); }
		inline static double prc_mul() { return Coefficients::pr_mul() * Range::c_mul(); }
		inline static double prc_mul_r() { return 1.0 / prc_mul(); }
		
		inline static double pbc_madd() { return Range::c_add() * pbc_mul(); }
		inline static double pbc_madd_r() { return Range::c_add() / pbc_mul(); }
		inline static double prc_madd() { return Range::c_add() * prc_mul(); }
		inline static double prc_madd_r() { return Range::c_add() / prc_mul(); }
	};

	struct xyz;

	template<typename Gamma>
	struct basic_rgb;

	template<typename Gamma>
	struct basic_rgb8;

	template<typename Gamma, typename Coefficients>
	struct basic_yuv;

	template<typename Gamma, typename Coefficients>
	struct basic_ypbpr;

	template<typename Gamma, typename Coefficients, typename Range>
	struct basic_ycbcr;

	struct color_base
	{
	};

	struct xyz : color_base
	{
		double x, y, z;

		inline xyz() {}
		inline xyz(double x, double y, double z) :x(x),y(y),z(z) {}

		template<typename Gamma>
		inline explicit xyz(basic_rgb<Gamma> const &c)
		{
			double r = Gamma::to_linear(c.r);
			double g = Gamma::to_linear(c.g);
			double b = Gamma::to_linear(c.b);

			x = r * 0.4124 + g * 0.3576 + b * 0.1805;
			y = r * 0.2126 + g * 0.7152 + b * 0.0722;
			z = r * 0.0193 + g * 0.1192 + b * 0.9505;
		}

		template<typename Color>
		inline explicit xyz(Color const &c)
		{
			*this = basic_xyz(basic_rgb<linear>(c));
		}
	};

	template<typename Gamma>
	struct basic_rgb : color_base
	{
		double r, g, b;

		inline basic_rgb() {}
		inline basic_rgb(double r, double g, double b) : r(r),g(g),b(b) {}

		inline explicit basic_rgb(xyz const &c)
		{
			r = Gamma::from_linear(c.x * 3.2406 - c.y * 1.5372 - c.z * 0.4986);
			g = Gamma::from_linear(c.x * -0.9689 + c.y * 1.8758 + c.z * 0.0416);
			b = Gamma::from_linear(c.x * 0.0557 - c.y * 0.2040 + c.z * 1.0570);
		}

		template<typename AGamma>
		inline explicit basic_rgb(basic_rgb<AGamma> const &c)
			: r(Gamma::from_linear(AGamma::to_linear(c.r)))
			, g(Gamma::from_linear(AGamma::to_linear(c.g)))
			, b(Gamma::from_linear(AGamma::to_linear(c.b)))
		{
		}

		inline explicit basic_rgb(basic_rgb8<Gamma> const &c)
			: r(c.r / 255.0)
			, g(c.g / 255.0)
			, b(c.b / 255.0)
		{
		}

		template<typename AGamma>
		inline explicit basic_rgb(basic_rgb8<AGamma> const &c)
		{
			*this = basic_rgb<Gamma>(basic_rgb<AGamma>(c));
		}

		template<typename Coefficients>
		inline explicit basic_rgb(basic_yuv<Gamma, Coefficients> const &c)
		{
			r = c.v + c.y;
			b = c.u + c.y;
			g = (c.y - r * Coefficients::r_scale() - b * Coefficients::b_scale()) * Coefficients::g_scale_r();
		}

		template<typename AGamma, typename Coefficients>
		inline explicit basic_rgb(basic_yuv<AGamma, Coefficients> const &c)
		{
			*this = basic_rgb<Gamma>(basic_rgb<AGamma>(c));
		}

		template<typename AGamma, typename Coefficients>
		inline explicit basic_rgb(basic_ypbpr<AGamma, Coefficients> const &c)
		{
			*this = basic_rgb<Gamma>(basic_yuv<AGamma, Coefficients>(c));
		}

		template<typename AGamma, typename Coefficients, typename Range>
		inline explicit basic_rgb(basic_ycbcr<AGamma, Coefficients, Range> const &c)
		{
			*this = basic_rgb<Gamma>(basic_yuv<AGamma, Coefficients>(c));
		}
	};

	template<typename Gamma>
	struct basic_rgb8 : color_base
	{
		double r, g, b;

		inline basic_rgb8() {}
		inline basic_rgb8(double r, double g, double b) : r(r),g(g),b(b) {}

		inline explicit basic_rgb8(basic_rgb<Gamma> const &c)
			: r(c.r * 255.0)
			, g(c.g * 255.0)
			, b(c.b * 255.0)
		{
		}

		template<typename Color>
		inline explicit basic_rgb8(Color const &c)
		{
			*this = basic_rgb8<Gamma>(basic_rgb<Gamma>(c));
		}
	};

	template<typename Gamma, typename Coefficients>
	struct basic_yuv : color_base
	{
		double y, u, v;

		inline basic_yuv() {}
		inline basic_yuv(double y, double u, double v) : y(y),u(u),v(v) {}

		inline explicit basic_yuv(xyz const &c)
		{
			*this = basic_yuv<Gamma, Coefficients>(basic_rgb<Gamma>(c));
		}

		inline explicit basic_yuv(basic_rgb<Gamma> const &c)
			: y(c.r * Coefficients::r_scale() + c.g * Coefficients::g_scale() + c.b * Coefficients::b_scale())
			, u(c.b - y)
			, v(c.r - y)
		{
		}

		template<typename Color>
		inline explicit basic_yuv(Color const &c)
		{
			*this = basic_yuv<Gamma, Coefficients>(basic_rgb<Gamma>(c));
		}

		inline explicit basic_yuv(basic_ypbpr<Gamma, Coefficients> const &c)
			: y(c.y)
			, u(c.pb * Coefficients::pb_mul_r())
			, v(c.pr * Coefficients::pr_mul_r())
		{
		}

		template<typename AGamma, typename ACoefficients>
		inline explicit basic_yuv(basic_ypbpr<AGamma, ACoefficients> const &c)
		{
			*this = basic_yuv<Gamma, Coefficients>(basic_yuv<AGamma, ACoefficients>(c));
		}

		template<typename Range>
		inline explicit basic_yuv(basic_ycbcr<Gamma, Coefficients, Range> const &c)
		{
			typedef yuv_table<Coefficients, Range> table;

			y = c.y * table::y_mul_r() - table::y_madd_r();
			u = c.cb * table::pbc_mul_r() - table::pbc_madd_r();
			v = c.cr * table::prc_mul_r() - table::prc_madd_r();
		}

		template<typename AGamma, typename ACoefficients, typename Range>
		inline explicit basic_yuv(basic_ycbcr<AGamma, ACoefficients, Range> const &c)
		{
			*this = basic_yuv<Gamma, Coefficients>(basic_yuv<AGamma, ACoefficients>(c));
		}
	};

	template<typename Gamma, typename Coefficients>
	struct basic_ypbpr : color_base
	{
		double y, pb, pr;

		inline basic_ypbpr() {}
		inline basic_ypbpr(double y, double pb, double pr) : y(y),pb(pb),pr(pr) {}

		template<typename Color>
		inline explicit basic_ypbpr(Color const &c)
		{
			*this = basic_ypbpr<Gamma, Coefficients>(basic_yuv<Gamma, Coefficients>(c));
		}

		inline explicit basic_ypbpr(basic_yuv<Gamma, Coefficients> const &c)
			: y(c.y)
			, pb(c.u * Coefficients::pb_mul())
			, pr(c.v * Coefficients::pr_mul())
		{
		}

		template<typename Range>
		inline explicit basic_ypbpr(basic_ycbcr<Gamma, Coefficients, Range> const &c)
		{
			typedef yuv_table<Coefficients, Range> table;

			y = c.y * table::y_mul_r() - table::y_madd_r();
			pb = c.cb * table::c_mul_r() - table::c_madd_r();
			pr = c.cr * table::c_mul_r() - table::c_madd_r();
		}
	};

	template<typename Gamma, typename Coefficients, typename Range>
	struct basic_ycbcr : color_base
	{
		typedef yuv_table<Coefficients, Range> table;

		double y, cb, cr;

		inline basic_ycbcr() {}
		inline basic_ycbcr(double y, double cb, double cr) : y(y),cb(cb),cr(cr) {}

		template<typename Color>
		inline explicit basic_ycbcr(Color const &c)
		{
			*this = basic_ycbcr<Gamma, Coefficients, Range>(basic_yuv<Gamma, Coefficients>(c));
		}

		inline explicit basic_ycbcr(basic_yuv<Gamma, Coefficients> const &c)
			: y(c.y * table::y_mul() + table::y_add())
			, cb(c.u * table::pbc_mul() + table::c_add())
			, cr(c.v * table::prc_mul() + table::c_add())
		{

		}

		inline explicit basic_ycbcr(basic_ypbpr<Gamma, Coefficients> const &c)
			: y(c.y * table::y_mul() + table::y_add())
			, cb(c.pb * table::c_mul() + table::c_add())
			, cr(c.pr * table::c_mul() + table::c_add())
		{
		}
	};

	inline double get_0(detail::xyz const &c) { return c.x; }
	inline double get_1(detail::xyz const &c) { return c.y; }
	inline double get_2(detail::xyz const &c) { return c.z; }

	template<typename Gamma> inline double get_0(detail::basic_rgb<Gamma> const &c) { return c.r; }
	template<typename Gamma> inline double get_1(detail::basic_rgb<Gamma> const &c) { return c.g; }
	template<typename Gamma> inline double get_2(detail::basic_rgb<Gamma> const &c) { return c.b; }

	template<typename Gamma> inline double get_0(detail::basic_rgb8<Gamma> const &c) { return c.r; }
	template<typename Gamma> inline double get_1(detail::basic_rgb8<Gamma> const &c) { return c.g; }
	template<typename Gamma> inline double get_2(detail::basic_rgb8<Gamma> const &c) { return c.b; }

	template<typename Gamma, typename Coefficients> inline double get_0(detail::basic_yuv<Gamma, Coefficients> const &c) { return c.y; }
	template<typename Gamma, typename Coefficients> inline double get_1(detail::basic_yuv<Gamma, Coefficients> const &c) { return c.u; }
	template<typename Gamma, typename Coefficients> inline double get_2(detail::basic_yuv<Gamma, Coefficients> const &c) { return c.v; }

	template<typename Gamma, typename Coefficients> inline double get_0(detail::basic_ypbpr<Gamma, Coefficients> const &c) { return c.y; }
	template<typename Gamma, typename Coefficients> inline double get_1(detail::basic_ypbpr<Gamma, Coefficients> const &c) { return c.pb; }
	template<typename Gamma, typename Coefficients> inline double get_2(detail::basic_ypbpr<Gamma, Coefficients> const &c) { return c.pr; }

	template<typename Gamma, typename Coefficients, typename Range> inline double get_0(detail::basic_ycbcr<Gamma, Coefficients, Range> const &c) { return c.y; }
	template<typename Gamma, typename Coefficients, typename Range> inline double get_1(detail::basic_ycbcr<Gamma, Coefficients, Range> const &c) { return c.cb; }
	template<typename Gamma, typename Coefficients, typename Range> inline double get_2(detail::basic_ycbcr<Gamma, Coefficients, Range> const &c) { return c.cr; }

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator+(Color const &a, Color const &b)
	{
		return Color(get_0(a) + get_0(b), get_1(a) + get_1(b), get_2(a) + get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator+(Color const &a, double b)
	{
		return Color(get_0(a) + b, get_1(a) + b, get_2(a) + b);
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator+(double a, Color const &b)
	{
		return Color(a + get_0(b), a + get_1(b), a + get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator-(Color const &a, Color const &b)
	{
		return Color(get_0(a) - get_0(b), get_1(a) - get_1(b), get_2(a) - get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator-(Color const &a, double b)
	{
		return Color(get_0(a) - b, get_1(a) - b, get_2(a) - b);
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator-(double a, Color const &b)
	{
		return Color(a - get_0(b), a - get_1(b), a - get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator*(Color const &a, Color const &b)
	{
		return Color(get_0(a) * get_0(b), get_1(a) * get_1(b), get_2(a) * get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator*(Color const &a, double b)
	{
		return Color(get_0(a) * b, get_1(a) * b, get_2(a) * b);
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator*(double a, Color const &b)
	{
		return Color(a * get_0(b), a * get_1(b), a * get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator/(Color const &a, Color const &b)
	{
		return Color(get_0(a) / get_0(b), get_1(a) / get_1(b), get_2(a) / get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator/(Color const &a, double b)
	{
		return Color(get_0(a) / b, get_1(a) / b, get_2(a) / b);
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, Color>::type
		operator/(double a, Color const &b)
	{
		return Color(a / get_0(b), a / get_1(b), a / get_2(b));
	}

	template<typename Color>
	inline typename std::enable_if<std::is_base_of<color_base, Color>::value, std::ostream&>::type
		operator<<(std::ostream &os, Color const &c)
	{
		return os << '(' << get_0(c) << ", " << get_1(c) << ", " << get_2(c) << ')';
	}

	struct m4
	{
		m4(double f) :f(f) {}
		double const f;
	};

	struct m8
	{
		m8(double f) :f(f) {}
		double const f;
	};

	inline std::ostream& operator<<(std::ostream &os, m4 const &m)
	{
		return os << "{ " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f }";
	}

	inline std::ostream& operator<<(std::ostream &os, m8 const &m)
	{
		return os << "{ " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f, " << m.f << "f }";
	}

	template<typename Table>
	inline typename std::enable_if<std::is_base_of<yuv_table_base, Table>::value, std::ostream&>::type
		operator<<(std::ostream &os, Table)
	{
		auto oldf = os.setf(std::ios_base::scientific);
		auto oldp = os.precision(std::numeric_limits<float>::digits10 + 1);

		os
			<< "{" << std::endl
			<< '\t' << m8(Table::r_scale()) << ',' << std::endl
			<< '\t' << m8(Table::g_scale()) << ',' << std::endl
			<< '\t' << m8(Table::b_scale()) << ',' << std::endl
			<< '\t' << m8(Table::g_scale_r()) << ',' << std::endl
			<< '\t' << m8(Table::y_mul()) << ',' << std::endl
			<< '\t' << m8(Table::y_add()) << ',' << std::endl
			<< '\t' << m8(Table::pbc_mul()) << ',' << std::endl
			<< '\t' << m8(Table::prc_mul()) << ',' << std::endl
			<< '\t' << m8(Table::c_add()) << ',' << std::endl
			<< '\t' << m8(Table::y_mul_r()) << ',' << std::endl
			<< '\t' << m8(Table::y_madd_r()) << ',' << std::endl
			<< '\t' << m8(Table::pbc_mul_r()) << ',' << std::endl
			<< '\t' << m8(Table::pbc_madd_r()) << ',' << std::endl
			<< '\t' << m8(Table::prc_mul_r()) << ',' << std::endl
			<< '\t' << m8(Table::prc_madd_r()) << ',' << std::endl
			<< std::endl
			<< '\t' << m4(Table::r_scale()) << ',' << std::endl
			<< '\t' << m4(Table::g_scale()) << ',' << std::endl
			<< '\t' << m4(Table::b_scale()) << ',' << std::endl
			<< '\t' << m4(Table::g_scale_r()) << ',' << std::endl
			<< '\t' << m4(Table::y_mul()) << ',' << std::endl
			<< '\t' << m4(Table::y_add()) << ',' << std::endl
			<< '\t' << m4(Table::pbc_mul()) << ',' << std::endl
			<< '\t' << m4(Table::prc_mul()) << ',' << std::endl
			<< '\t' << m4(Table::c_add()) << ',' << std::endl
			<< '\t' << m4(Table::y_mul_r()) << ',' << std::endl
			<< '\t' << m4(Table::y_madd_r()) << ',' << std::endl
			<< '\t' << m4(Table::pbc_mul_r()) << ',' << std::endl
			<< '\t' << m4(Table::pbc_madd_r()) << ',' << std::endl
			<< '\t' << m4(Table::prc_mul_r()) << ',' << std::endl
			<< '\t' << m4(Table::prc_madd_r()) << ',' << std::endl
			<< std::endl
			<< "\t" << Table::r_scale()
			<< "f, " << Table::g_scale()
			<< "f, " << Table::b_scale()
			<< "f, " << Table::g_scale_r()
			<< "f," << std::endl
			<< "\t" << Table::y_mul()
			<< "f, " << (Table::y_add() + 0.5)
			<< "f, " << Table::pbc_mul()
			<< "f, " << Table::prc_mul()
			<< "f, " << (Table::c_add() + 0.5)
			<< "f," << std::endl
			<< "\t" << Table::y_mul_r()
			<< "f, " << Table::y_madd_r()
			<< "f, " << Table::pbc_mul_r()
			<< "f, " << Table::pbc_madd_r()
			<< "f, " << Table::prc_mul_r()
			<< "f, " << Table::prc_madd_r()
			<< "f" << std::endl
			<< std::endl
			<< "}";

		os.setf(oldf);
		os.precision(oldp);

		return os;
	}
}

using detail::xyz;

typedef detail::basic_rgb<detail::linear> linear_rgb;
typedef detail::basic_yuv<detail::linear, detail::rec709> linear_yuv;

typedef detail::basic_rgb<detail::srgb> rgb;
typedef detail::basic_rgb8<detail::srgb> rgb8;
typedef detail::basic_yuv<detail::srgb, detail::rec601> yuv601;
typedef detail::basic_yuv<detail::srgb, detail::rec709> yuv709;
typedef detail::basic_ypbpr<detail::srgb, detail::rec601> ypbpr601;
typedef detail::basic_ypbpr<detail::srgb, detail::rec709> ypbpr709;
typedef detail::basic_ycbcr<detail::srgb, detail::rec601, detail::tv_range> ycbcr601tv;
typedef detail::basic_ycbcr<detail::srgb, detail::rec601, detail::pc_range> ycbcr601pc;
typedef detail::basic_ycbcr<detail::srgb, detail::rec709, detail::tv_range> ycbcr709tv;
typedef detail::basic_ycbcr<detail::srgb, detail::rec709, detail::pc_range> ycbcr709pc;

using detail::get_0;
using detail::get_1;
using detail::get_2;

}

#endif
