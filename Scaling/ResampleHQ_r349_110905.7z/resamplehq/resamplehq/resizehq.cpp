/*
	ResampleHQ Avisynth resampler
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "alloc.hpp"
#include "color.hpp"
#include "resizehq.hpp"

static int arg_stricmp_next(const char* &str)
{
	int ch;

	do
	{
		ch = (unsigned char)*(str++);

		if(ch >= 'A' && ch <= 'Z')
		{
			ch -= ('A' - 'a');
		}
	}
	while(ch && (ch < 'a' || ch > 'z') && (ch < '0' && ch > '9'));

	return ch;
}

static int arg_stricmp(const char *dst, const char *src)
{
	int d, s;

	do
	{
		d = arg_stricmp_next(dst);
		s = arg_stricmp_next(src);
	}
	while(d && d == s);

	return d - s;
}

resample::ResizeHQ::ResizeHQ(IScriptEnvironment *env, PClip const &child, char const *src_matrix_str, char const *dest_colorspace_str, char const *dest_matrix_str, boost::optional<int> dest_width, boost::optional<int> dest_height, bool dither, boost::optional<double> src_left, boost::optional<double> src_top, boost::optional<double> src_width, boost::optional<double> src_height, char const *kernel_str, boost::optional<double> karg1, boost::optional<double> karg2, double kblur_x, double kblur_y, char const *chroma_kernel_str, boost::optional<double> chroma_karg1, boost::optional<double> chroma_karg2)
	: GenericVideoFilter(child)
{
	try
	{
		VideoInfo const &srcvi = child->GetVideoInfo();

		// find destination width/height.

		if(!dest_width)
		{
			dest_width = srcvi.width;
		}

		if(get(dest_width) < 1)
		{
			env->ThrowError("Destination width must be at least 1.");
		}

		if(!dest_height)
		{
			dest_height = srcvi.height;
		}

		if(get(dest_height) < 1)
		{
			env->ThrowError("Destination height must be at least 1.");
		}

		// find cropping.

		if(!src_left)
		{
			src_left = 0.0;
		}

		if(!src_top)
		{
			src_top = 0.0;
		}

		if(!src_width || std::abs(get(src_width)) == 0.0)
		{
			src_width = srcvi.width - get(src_left);
		}
		else if(get(src_width) < 0.0)
		{
			src_width = srcvi.width + get(src_width) - get(src_left);
		}

		if(!src_height || std::abs(get(src_height)) == 0.0)
		{
			src_height = srcvi.height - get(src_top);
		}
		else if(src_height < 0.0)
		{
			src_height = srcvi.height + get(src_height) - get(src_top);
		}

		// find source colorspace.

		colorspace src_colorspace, dest_colorspace;
		dimension_type src_chroma_width = 0, src_chroma_height = 0, dst_chroma_width = 0, dst_chroma_height = 0;
		double src_chroma_crop_offset_x = get(src_left), src_chroma_crop_offset_y = get(src_top), src_chroma_crop_width = get(src_width), src_chroma_crop_height = get(src_height);
		double chroma_blur_x = kblur_x, chroma_blur_y = kblur_y;

		src_colorspace = get_colorspace(srcvi);
		dest_colorspace = get_colorspace(dest_colorspace_str);

		if(dest_colorspace == cs_unspecified)
		{
			dest_colorspace = src_colorspace;
		}

		switch(src_colorspace)
		{
		case cs_rgb24:
			m_read_func = &ResizeHQ::read_rgb24;
			src_chroma_width = srcvi.width;
			src_chroma_height = srcvi.height;
			break;
		case cs_rgb32:
			m_read_func = (dest_colorspace == cs_rgb32) ? &ResizeHQ::read_rgba32 : &ResizeHQ::read_rgb32;
			src_chroma_width = srcvi.width;
			src_chroma_height = srcvi.height;
			break;
		case cs_yv12:
			m_read_func = &ResizeHQ::read_yv12;
			src_chroma_width = srcvi.width / 2;
			src_chroma_height = srcvi.height / 2;
			src_chroma_crop_offset_x *= 0.5;
			src_chroma_crop_offset_y *= 0.5;
			src_chroma_crop_width *= 0.5;
			src_chroma_crop_height *= 0.5;
			if(chroma_blur_x <= 0.0) chroma_blur_x *= 0.5;
			if(chroma_blur_y <= 0.0) chroma_blur_y *= 0.5;
			break;
		case cs_yuy2:
			m_read_func = &ResizeHQ::read_yuy2;
			src_chroma_width = srcvi.width / 2;
			src_chroma_height = srcvi.height;
			src_chroma_crop_offset_x *= 0.5;
			src_chroma_crop_width *= 0.5;
			if(chroma_blur_x <= 0.0) chroma_blur_x *= 0.5;
			break;
		default:
			env->ThrowError("Unsupported source colorspace.");
			break;
		}

		// find destination colorspace.

		switch(dest_colorspace)
		{
		case cs_rgb24:
			m_write_func = dither ? &ResizeHQ::dither_rgb24 : &ResizeHQ::write_rgb24;
			vi.pixel_type = VideoInfo::CS_BGR24;
			dst_chroma_width = get(dest_width);
			dst_chroma_height = get(dest_height);
			break;
		case cs_rgb32:
			if(src_colorspace == cs_rgb32)
			{
				m_write_func = dither ? &ResizeHQ::dither_rgba32 : &ResizeHQ::write_rgba32;
			}
			else
			{
				m_write_func = dither ? &ResizeHQ::dither_rgb32 : &ResizeHQ::write_rgb32;
			}

			vi.pixel_type = VideoInfo::CS_BGR32;
			dst_chroma_width = get(dest_width);
			dst_chroma_height = get(dest_height);
			break;
		case cs_yv12:
			m_write_func = &ResizeHQ::write_yv12;
			vi.pixel_type = VideoInfo::CS_YV12;
			dst_chroma_width = get(dest_width) / 2;
			dst_chroma_height = get(dest_height) / 2;

			if((get(dest_width) % 2) || (get(dest_height) % 2))
			{
				env->ThrowError("Width and height of YV12 must be multiples of 2.");
			}
			break;
		case cs_yuy2:
			m_write_func = &ResizeHQ::write_yuy2;
			vi.pixel_type = VideoInfo::CS_YUY2;
			dst_chroma_width = get(dest_width) / 2;
			dst_chroma_height = get(dest_height);

			if(get(dest_width) % 2)
			{
				env->ThrowError("Width of YUY2 must be a multiple of 2.");
			}
			break;
		default:
			env->ThrowError("Unsupported target colorspace.");
			break;
		}

		// find color matrix.

		m_matrix_in = get_matrix(src_matrix_str);

		if(!m_matrix_in)
		{
			env->ThrowError("Unsupported input color matrix.");
		}

		m_matrix_out = get_matrix(dest_matrix_str);

		if(!m_matrix_out)
		{
			m_matrix_out = m_matrix_in;
		}

		// get resize kernel.

		std::unique_ptr<kernel> k = get_kernel(kernel_str, karg1, karg2);

		if(!k)
		{
			env->ThrowError("Unsupported kernel \"%s\".", kernel_str);
		}

		// create resizers.

		m_resize_x.reset(srcvi.width, get(src_left), get(src_width), get(dest_width), kblur_x, *k);
		m_resize_y.reset(srcvi.height, get(src_top), get(src_height), get(dest_height), kblur_y, *k);

		if(src_colorspace == cs_yv12 || src_colorspace == cs_yuy2 || dest_colorspace == cs_yv12 || dest_colorspace == cs_yuy2)
		{
			k = get_kernel(chroma_kernel_str, chroma_karg1, chroma_karg2);

			if(!k)
			{
				env->ThrowError("Unsupported kernel \"%s\".", chroma_kernel_str);
			}

			if(src_colorspace == cs_yv12 || src_colorspace == cs_yuy2)
			{
				m_resize_src_chroma_x.reset(src_chroma_width, 0.0, src_chroma_width, srcvi.width, 1.0, *k);
				m_resize_src_chroma_y.reset(src_chroma_height, 0.0, src_chroma_height, srcvi.height, 1.0, *k);
			}

			if(dest_colorspace == cs_yv12 || dest_colorspace == cs_yuy2)
			{
				m_resize_target_chroma_x.reset(get(dest_width), 0.0, get(dest_width), dst_chroma_width, 1.0, *k);
				m_resize_target_chroma_y.reset(get(dest_height), 0.0, get(dest_height), dst_chroma_height, 1.0, *k);
			}
		}

		// setup avisynth video info.

		vi.width = get(dest_width);
		vi.height = get(dest_height);
	}
	catch(std::exception &ex)
	{
		env->ThrowError("ResampleHQ internal error: %s", ex.what());
	}
	catch(...)
	{
		env->ThrowError("Unknown ResampleHQ internal error.");
	}
}

PVideoFrame __stdcall resample::ResizeHQ::GetFrame(int n, IScriptEnvironment *env)
{
	try
	{
		std::unique_ptr<frame_state> state = get_state();

		// read

		(this->*m_read_func)(child->GetFrame(n, env), *state);

		// resize

		state->resampler.resample(state->r.src, state->r.resized);
		state->resampler.resample(state->g.src, state->g.resized);
		state->resampler.resample(state->b.src, state->b.resized);
		
		if(!state->a.src.empty())
		{
			state->resampler.resample(state->a.src, state->a.resized);
		}

		// write

		PVideoFrame ret = env->NewVideoFrame(vi, 64); // 64-byte alignment, for AVX and to avoid false sharing.
		(this->*m_write_func)(*state, ret);

		return_state(std::move(state));

		return ret;
	}
	catch(std::exception &ex)
	{
		env->ThrowError("ResampleHQ internal error: %s", ex.what());
		return 0;
	}
	catch(...)
	{
		env->ThrowError("Unknown ResampleHQ internal error.");
		return 0;
	}
}

std::unique_ptr<resample::ResizeHQ::frame_state> resample::ResizeHQ::get_state()
{
	std::unique_ptr<frame_state> ret;

	{
		critical_section::scoped_lock lock(m_cachelock);

		if(!m_cache.empty())
		{
			ret = std::move(m_cache.top());
			m_cache.pop();
			return ret;
		}
	}

	dimension_type
		src_width = m_resize_x.source_length(),
		src_height = m_resize_y.source_length(),
		target_width = m_resize_x.dest_length(),
		target_height = m_resize_y.dest_length(),
		src_chroma_width = m_resize_src_chroma_x.empty() ? 0 : m_resize_src_chroma_x.source_length(),
		src_chroma_height = m_resize_src_chroma_y.empty() ? 0 : m_resize_src_chroma_y.source_length(),
		target_chroma_width = m_resize_target_chroma_x.empty() ? 0 : m_resize_target_chroma_x.dest_length(),
		target_chroma_height = m_resize_target_chroma_y.empty() ? 0 : m_resize_target_chroma_y.dest_length();

	ret = std::unique_ptr<frame_state>(new frame_state);

	ret->resampler.reset(m_resize_x, m_resize_y);

	ret->r.src.reset(src_width, src_height);
	ret->r.resized.reset(target_width, target_height);

	ret->g.src.reset(src_width, src_height);
	ret->g.resized.reset(target_width, target_height);

	ret->b.src.reset(src_width, src_height);
	ret->b.resized.reset(target_width, target_height);

	if(m_write_func == &ResizeHQ::write_rgba32 || m_write_func == &ResizeHQ::dither_rgba32)
	{
		ret->a.src.reset(src_width, src_height);
		ret->a.resized.reset(target_width, target_height);
	}

	if(src_chroma_width)
	{
		ret->cb_in.src.reset(src_chroma_width, src_chroma_height);
		ret->cr_in.src.reset(src_chroma_width, src_chroma_height);
		ret->in_chroma_resampler.reset(m_resize_src_chroma_x, m_resize_src_chroma_y);
	}

	if(target_chroma_width)
	{
		ret->cb_out.resized.reset(target_chroma_width, target_chroma_height);
		ret->cr_out.resized.reset(target_chroma_width, target_chroma_height);
		ret->out_chroma_resampler.reset(m_resize_target_chroma_x, m_resize_target_chroma_y);
	}

	return ret;
}

void resample::ResizeHQ::return_state(std::unique_ptr<frame_state> state)
{
	critical_section::scoped_lock lock(m_cachelock);
	m_cache.push(std::move(state));
}

void resample::ResizeHQ::read_rgb24(PVideoFrame const &src, frame_state &dst)
{
	color::srgb24_to_linear_rgb(
		color::bitmap<std::uint8_t const>(src->GetReadPtr(), child->GetVideoInfo().width, child->GetVideoInfo().height, src->GetPitch(), 3),
		dst.r.src, dst.g.src, dst.b.src);
}

void resample::ResizeHQ::read_rgb32(PVideoFrame const &src, frame_state &dst)
{
	color::srgb32_to_linear_rgb(
		color::bitmap<std::uint8_t const>(src->GetReadPtr(), child->GetVideoInfo().width, child->GetVideoInfo().height, src->GetPitch(), 4),
		dst.r.src, dst.g.src, dst.b.src);
}

void resample::ResizeHQ::read_rgba32(PVideoFrame const &src, frame_state &dst)
{
	color::srgb32_to_linear_rgba(
		color::bitmap<std::uint8_t const>(src->GetReadPtr(), child->GetVideoInfo().width, child->GetVideoInfo().height, src->GetPitch(), 4),
		dst.r.src, dst.g.src, dst.b.src, dst.a.src);
}

void resample::ResizeHQ::read_yv12(PVideoFrame const &src, frame_state &dst)
{
	VideoInfo const &vi = child->GetVideoInfo();

	color::yv12_to_yuv(
		*m_matrix_in,
		color::bitmap<std::uint8_t const>(src->GetReadPtr(PLANAR_Y), vi.width, vi.height, src->GetPitch(PLANAR_Y), 1),
		color::bitmap<std::uint8_t const>(src->GetReadPtr(PLANAR_U), vi.width / 2, vi.height / 2, src->GetPitch(PLANAR_U), 1),
		color::bitmap<std::uint8_t const>(src->GetReadPtr(PLANAR_V), vi.width / 2, vi.height / 2, src->GetPitch(PLANAR_V), 1),
		dst.r.src, dst.cb_in.src, dst.cr_in.src);
	
	dst.in_chroma_resampler.resample(dst.cb_in.src, dst.g.src);
	dst.in_chroma_resampler.resample(dst.cr_in.src, dst.b.src);

	color::yuv_to_linear_rgb(*m_matrix_in, dst.r.src, dst.g.src, dst.b.src);
}

void resample::ResizeHQ::read_yuy2(PVideoFrame const &src, frame_state &dst)
{
	color::yuy2_to_yuv(
		*m_matrix_in,
		color::bitmap<std::uint8_t const>(src->GetReadPtr(), child->GetVideoInfo().width, child->GetVideoInfo().height, src->GetPitch(), 2),
		dst.r.src, dst.cb_in.src, dst.cr_in.src);

	dst.in_chroma_resampler.resample(dst.cb_in.src, dst.g.src);
	dst.in_chroma_resampler.resample(dst.cr_in.src, dst.b.src);

	color::yuv_to_linear_rgb(*m_matrix_in, dst.r.src, dst.g.src, dst.b.src);
}

void resample::ResizeHQ::write_rgb24(frame_state &src, PVideoFrame &dst)
{
	color::linear_rgb_to_srgb24(src.r.resized, src.g.resized, src.b.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 3));
}

void resample::ResizeHQ::write_rgb32(frame_state &src, PVideoFrame &dst)
{
	color::linear_rgb_to_srgb32(src.r.resized, src.g.resized, src.b.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 4));
}

void resample::ResizeHQ::write_rgba32(frame_state &src, PVideoFrame &dst)
{
	color::linear_rgba_to_srgb32(src.r.resized, src.g.resized, src.b.resized, src.a.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 4));
}

void resample::ResizeHQ::write_yv12(frame_state &src, PVideoFrame &dst)
{
	color::linear_rgb_to_yuv(*m_matrix_out, src.r.resized, src.g.resized, src.b.resized);

	src.out_chroma_resampler.resample(src.g.resized, src.cb_out.resized);
	src.out_chroma_resampler.resample(src.b.resized, src.cr_out.resized);

	color::yuv_to_yv12(*m_matrix_out, src.r.resized, src.cb_out.resized, src.cr_out.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(PLANAR_Y), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(PLANAR_Y), 1),
		color::bitmap<std::uint8_t>(dst->GetWritePtr(PLANAR_U), src.cb_out.resized.width(), src.cb_out.resized.height(), dst->GetPitch(PLANAR_U), 1),
		color::bitmap<std::uint8_t>(dst->GetWritePtr(PLANAR_V), src.cr_out.resized.width(), src.cr_out.resized.height(), dst->GetPitch(PLANAR_V), 1));
}

void resample::ResizeHQ::write_yuy2(frame_state &src, PVideoFrame &dst)
{
	color::linear_rgb_to_yuv(*m_matrix_out, src.r.resized, src.g.resized, src.b.resized);

	src.out_chroma_resampler.resample(src.g.resized, src.cb_out.resized);
	src.out_chroma_resampler.resample(src.b.resized, src.cr_out.resized);

	color::yuv_to_yuy2(*m_matrix_out, src.r.resized, src.cb_out.resized, src.cr_out.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 2));
}

void resample::ResizeHQ::dither_rgb24(frame_state &src, PVideoFrame &dst)
{
	color::dither_linear_rgb_to_srgb(src.r.resized, src.g.resized, src.b.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 3));
}

void resample::ResizeHQ::dither_rgb32(frame_state &src, PVideoFrame &dst)
{
	color::dither_linear_rgb_to_srgb(src.r.resized, src.g.resized, src.b.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 4));
}

void resample::ResizeHQ::dither_rgba32(frame_state &src, PVideoFrame &dst)
{
	color::dither_linear_rgb_to_srgb32(src.r.resized, src.g.resized, src.b.resized, src.a.resized,
		color::bitmap<std::uint8_t>(dst->GetWritePtr(), src.r.resized.width(), src.r.resized.height(), dst->GetPitch(), 4));
}

resample::ResizeHQ::colorspace resample::ResizeHQ::get_colorspace(VideoInfo const &vi)
{
	if(vi.IsRGB24())
	{
		return cs_rgb24;
	}

	if(vi.IsRGB32())
	{
		return cs_rgb32;
	}

	if(vi.IsYV12())
	{
		return cs_yv12;
	}

	if(vi.IsYUY2())
	{
		return cs_yuy2;
	}

	return cs_unspecified;
}

resample::ResizeHQ::colorspace resample::ResizeHQ::get_colorspace(char const *name)
{
	if(!arg_stricmp(name, "RGB24"))
	{
		return cs_rgb24;
	}

	if(!arg_stricmp(name, "RGB32"))
	{
		return cs_rgb32;
	}

	if(!arg_stricmp(name, "YV12"))
	{
		return cs_yv12;
	}

	if(!arg_stricmp(name, "YUY2"))
	{
		return cs_yuy2;
	}

	if(!arg_stricmp(name, ""))
	{
		return cs_unspecified;
	}

	return cs_unknown;
}

color::yuv_table const* resample::ResizeHQ::get_matrix(char const *name)
{
	if(!arg_stricmp(name, "TV.601"))
	{
		return &color::tv601;
	}

	if(!arg_stricmp(name, "TV.709"))
	{
		return &color::tv709;
	}

	if(!arg_stricmp(name, "TV.240"))
	{
		return &color::tv240;
	}

	if(!arg_stricmp(name, "TV.FCC"))
	{
		return &color::tvfcc;
	}

	if(!arg_stricmp(name, "PC.601"))
	{
		return &color::pc601;
	}

	if(!arg_stricmp(name, "PC.709"))
	{
		return &color::pc709;
	}

	if(!arg_stricmp(name, "PC.240"))
	{
		return &color::pc240;
	}

	if(!arg_stricmp(name, "PC.FCC"))
	{
		return &color::pcfcc;
	}

	return 0;
}

std::unique_ptr<resample::kernel> resample::ResizeHQ::get_kernel(char const *name, boost::optional<double> arg1, boost::optional<double> arg2)
{
	kernel *ret;

	if(!arg_stricmp(name, "Bilinear"))
	{
		ret = new bilinear_kernel;
	}
	else if(!arg_stricmp(name, "Bicubic"))
	{
		ret = new bicubic_kernel(arg1, arg2);
	}
	else if(!arg_stricmp(name, "CatmullRom"))
	{
		ret = new catmull_rom_kernel();
	}
	else if(!arg_stricmp(name, "MitchellNetravali") || !arg_stricmp(name, "MitchellNetraveli"))
	{
		ret = new mitchell_netravali_kernel();
	}
	else if(!arg_stricmp(name, "SoftCubic"))
	{
		ret = new softcubic_kernel(arg1);
	}
	else if(!arg_stricmp(name, "Hermite"))
	{
		ret = new hermite_kernel();
	}
	else if(!arg_stricmp(name, "Robidoux"))
	{
		ret = new robidoux_kernel();
	}
	else if(!arg_stricmp(name, "Spline16"))
	{
		ret = new spline16_kernel;
	}
	else if(!arg_stricmp(name, "Spline36"))
	{
		ret = new spline36_kernel;
	}
	else if(!arg_stricmp(name, "Spline64"))
	{
		ret = new spline64_kernel;
	}
	else if(!arg_stricmp(name, "Lanczos"))
	{
		ret = new lanczos_kernel(arg1);
	}
	else if(!arg_stricmp(name, "Blackman"))
	{
		ret = new blackman_kernel(arg1);
	}
	else if(!arg_stricmp(name, "Gaussian"))
	{
		ret = new gaussian_kernel(arg1);
	}
	else if(!arg_stricmp(name, "Sinc"))
	{
		ret = new sinc_kernel(arg1);
	}
	else
	{
		return std::unique_ptr<kernel>();
	}

	return std::unique_ptr<kernel>(ret);
}

inline boost::optional<int> get_int(AVSValue const &v)
{
	return v.IsInt() ? boost::optional<int>(v.AsInt()) : boost::optional<int>();
}

inline boost::optional<double> get_double(AVSValue const &v)
{
	return v.IsFloat() ? boost::optional<double>(v.AsFloat()) : boost::optional<double>();
}

static AVSValue __cdecl CreateResizeHQ(AVSValue args, void*, IScriptEnvironment *env)
{
	const PClip &clip = args[0].AsClip();
	boost::optional<int> width = get_int(args[1]);
	boost::optional<int> height = get_int(args[2]);
	char const *dstcolorspace = args[3].AsString("");
	char const *srcmatrix = args[4].AsString("TV.601");
	char const *dstmatrix = args[5].AsString(srcmatrix);
	bool dither = args[6].AsBool(false);
	boost::optional<double> src_left = get_double(args[7]);
	boost::optional<double> src_top = get_double(args[8]);
	boost::optional<double> src_width = get_double(args[9]);
	boost::optional<double> src_height = get_double(args[10]);
	char const *kernel = args[11].AsString("Spline36");
	boost::optional<double> karg1 = get_double(args[12]);
	boost::optional<double> karg2 = get_double(args[13]);
	double kblur_x = args[14].AsFloat(1.0);
	double kblur_y = args[15].AsFloat(1.0);
	char const *chroma_kernel = args[16].AsString("Bilinear");
	boost::optional<double> chroma_karg1 = get_double(args[17]);
	boost::optional<double> chroma_karg2 = get_double(args[18]);

	return new resample::ResizeHQ(env, clip, srcmatrix, dstcolorspace, dstmatrix, width, height, dither, src_left, src_top, src_width, src_height, kernel, karg1, karg2, kblur_x, kblur_y, chroma_kernel, chroma_karg1, chroma_karg2);
}

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment *env)
{
	color::init();

	env->AddFunction("ResampleHQ", "c[WIDTH]i[HEIGHT]i[DSTCOLORSPACE]s[SRCMATRIX]s[DSTMATRIX]s[DITHER]b[SRC_LEFT]f[SRC_TOP]f[SRC_WIDTH]f[SRC_HEIGHT]f[KERNEL]s[KARG1]f[KARG2]f[KBLUR_X]f[KBLUR_Y]f[CHROMA_KERNEL]s[CHROMA_KARG1]f[CHROMA_KARG2]f", CreateResizeHQ, 0);

	return "`ResampleHQ' ResampleHQ plugin";
}
