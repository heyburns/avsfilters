/*
	Colorspace conversions
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_COLOR_HPP
#define INT64_ORG_RESAMPLER_COLOR_HPP

#ifdef _MSC_VER
#pragma once
#endif

#ifdef INT64_RESAMPLER_EXPORTS
#define INT64_COLOR_EXPORT __declspec(dllexport)
#else
#define INT64_COLOR_EXPORT __declspec(dllimport)
#endif

#include <immintrin.h>

#include <cstdint>

#include "alloc.hpp"

namespace color
{

// constants for YUV conversions.  values with _r are reciprocals of other values.
struct yuv_table
{
	// RGB -> YUV
	__m256 mm256_rscale, mm256_gscale, mm256_bscale, mm256_gscale_r;

	// YUV -> Y'CbCr.
	__m256 mm256_ymul, mm256_yadd, mm256_cbmul, mm256_crmul, mm256_cadd;

	// Y'CbCr -> YUV
	__m256 mm256_ymul_r, mm256_ysub, mm256_cbmul_r, mm256_cbsub, mm256_crmul_r, mm256_crsub;
	
	// RGB -> YUV
	__m128 mm_rscale, mm_gscale, mm_bscale, mm_gscale_r;

	// YUV -> Y'CbCr.
	__m128 mm_ymul, mm_yadd, mm_cbmul, mm_crmul, mm_cadd;

	// Y'CbCr -> YUV
	__m128 mm_ymul_r, mm_ysub, mm_cbmul_r, mm_cbsub, mm_crmul_r, mm_crsub;

	// RGB -> YUV
	float rscale, gscale, bscale, gscale_r;

	// YUV -> Y'CbCr.
	float ymul, yadd, cbmul, crmul, cadd;

	// Y'CbCr -> YUV
	float ymul_r, ysub, cbmul_r, cbsub, crmul_r, crsub;
};

INT64_COLOR_EXPORT extern yuv_table const tv601;
INT64_COLOR_EXPORT extern yuv_table const tv709;
INT64_COLOR_EXPORT extern yuv_table const tv240;
INT64_COLOR_EXPORT extern yuv_table const tvfcc;
INT64_COLOR_EXPORT extern yuv_table const pc601;
INT64_COLOR_EXPORT extern yuv_table const pc709;
INT64_COLOR_EXPORT extern yuv_table const pc240;
INT64_COLOR_EXPORT extern yuv_table const pcfcc;

///////////////////////////////////////////////////////////
/// Bitmap conversion functions

using alloc::bitmap;
typedef std::uint_fast32_t dimension_type;

void srgb24_to_linear_rgb(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b);
void srgb32_to_linear_rgb(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b);
void srgb32_to_linear_rgba(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b, bitmap<float> const &out_a);
void yv12_to_yuv(yuv_table const &table, bitmap<std::uint8_t const> const &in_y, bitmap<std::uint8_t const> const &in_cb, bitmap<std::uint8_t const> const &in_cr, bitmap<float> const &out_y, bitmap<float> const &out_u, bitmap<float> const &out_v);
void yuy2_to_yuv(yuv_table const &table, bitmap<std::uint8_t const> const &in_yuy2, bitmap<float> const &out_y, bitmap<float> const &out_u, bitmap<float> const &out_v);
void yuv_to_linear_rgb(yuv_table const &table, bitmap<float> const &inout_y_r, bitmap<float> const &inout_u_g, bitmap<float> const &inout_v_b);

void linear_rgb_to_srgb24(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<std::uint8_t> const &out_srgb);
void linear_rgb_to_srgb32(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<std::uint8_t> const &out_srgb);
void linear_rgba_to_srgb32(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<float const> const &in_a, bitmap<std::uint8_t> const &out_srgb);
void yuv_to_yv12(yuv_table const &table, bitmap<float const> const &in_y, bitmap<float const> const &in_u, bitmap<float const> const &in_v, bitmap<std::uint8_t> const &out_y, bitmap<std::uint8_t> const &out_cb, bitmap<std::uint8_t> const &out_cr);
void yuv_to_yuy2(yuv_table const &table, bitmap<float const> const &in_y, bitmap<float const> const &in_u, bitmap<float const> const &in_v, bitmap<std::uint8_t> const &out_yuy2);
void linear_rgb_to_yuv(yuv_table const &table, bitmap<float> const &inout_r_y, bitmap<float> const &inout_g_u, bitmap<float> const &inout_b_v);

void dither_linear_rgb_to_srgb(bitmap<float> const &in_r, bitmap<float> const &in_g, bitmap<float> const &in_b, bitmap<std::uint8_t> const &out_srgb);
void dither_linear_rgb_to_srgb32(bitmap<float> const &in_r, bitmap<float> const &in_g, bitmap<float> const &in_b, bitmap<float> const &in_a, bitmap<std::uint8_t> const &out_srgb);

///////////////////////////////////////////////////////////
/// Row conversion functions.

INT64_COLOR_EXPORT void srgb24_to_linear_rgb_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);
INT64_COLOR_EXPORT void srgb24_to_linear_rgb_row_ssse3(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);
INT64_COLOR_EXPORT void srgb24_to_linear_rgb_row_avx(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);
INT64_COLOR_EXPORT void srgb24_to_linear_rgb_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);

INT64_COLOR_EXPORT void srgb32_to_linear_rgb_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, color::dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgb_row_sse2(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgb_row_avx(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgb_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width);

INT64_COLOR_EXPORT void srgb32_to_linear_rgba_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgba_row_sse2(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgba_row_avx(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width);
INT64_COLOR_EXPORT void srgb32_to_linear_rgba_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width);

INT64_COLOR_EXPORT void yv12_to_yuv_row_c(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width);
INT64_COLOR_EXPORT void yv12_to_yuv_row_sse2(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width);
INT64_COLOR_EXPORT void yv12_to_yuv_row_avx(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width);
INT64_COLOR_EXPORT void yv12_to_yuv_row_fma4(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width);

INT64_COLOR_EXPORT void yuy2_to_yuv_row_c(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width);
INT64_COLOR_EXPORT void yuy2_to_yuv_row_sse2(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width);
INT64_COLOR_EXPORT void yuy2_to_yuv_row_avx(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width);
INT64_COLOR_EXPORT void yuy2_to_yuv_row_fma4(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width);

INT64_COLOR_EXPORT void yuv_to_linear_rgb_row_c(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_linear_rgb_row_sse2(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_linear_rgb_row_avx(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_linear_rgb_row_fma4(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width);

INT64_COLOR_EXPORT void linear_rgb_to_srgb24_row_c(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb24_row_ssse3(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb24_row_avx(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb24_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);

INT64_COLOR_EXPORT void linear_rgb_to_srgb32_row_c(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb32_row_sse2(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb32_row_avx(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_srgb32_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width);

INT64_COLOR_EXPORT void linear_rgba_to_srgb32_row_c(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgba_to_srgb32_row_sse2(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgba_to_srgb32_row_avx(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width);
INT64_COLOR_EXPORT void linear_rgba_to_srgb32_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width);

INT64_COLOR_EXPORT void yuv_to_yv12_row_c(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yv12_row_sse2(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yv12_row_avx(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yv12_row_fma4(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width);

INT64_COLOR_EXPORT void yuv_to_yuy2_row_c(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yuy2_row_sse2(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yuy2_row_avx(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width);
INT64_COLOR_EXPORT void yuv_to_yuy2_row_fma4(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width);

INT64_COLOR_EXPORT void linear_rgb_to_yuv_row_c(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_yuv_row_sse2(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_yuv_row_avx(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width);
INT64_COLOR_EXPORT void linear_rgb_to_yuv_row_fma4(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width);

///////////////////////////////////////////////////////////
/// Feature detection functions.

enum
{
	sse = 1,
	sse2 = 2,
	sse3 = 4,
	ssse3 = 8,
	sse41 = 16,
	sse42 = 32,
	avx = 64,
	fma4 = 128, // AMD's FMA4
	avx2_fma3 = 256, // AVX2 and FMA3.
};

typedef std::uint_fast8_t feature_flags;

INT64_COLOR_EXPORT feature_flags get_features();

void init(); // initializes SSE/AVX versions.

}

#endif
