/*
	AVX resampler
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Note: These are put in a separate file because they need to be compiled with /arch:AVX or VC++
	will mix AVX with SSE instructions which results in a terrible performance penalty!
*/

#include "targetver.hpp"
#include <intrin.h>
#include "resample.hpp"

void resample::resampler_1d::resample_vertical_avx(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	// pixel positions along the Y axis are flipped, or cropping from src_top will crop from bottom.

	assert(!empty());
	assert(src.width() == dst.width());
	assert(src.height() == source_length());
	assert(dst.height() == dest_length());

	auto viter = m_program.cbegin();

	for(dimension_type y = 0; y < dst.height(); ++y)
	{
		auto iter = viter;

		for(dimension_type x = 0; x < (src.width() & ~(dimension_type)15); x += 16)
		{
			iter = viter;
			
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			__m256 value1 = _mm256_setzero_ps();
			__m256 value2 = _mm256_setzero_ps();
			
			do
			{
				__m256 const weight = _mm256_broadcast_ss(&iter->f); ++iter;
				float const* const psrc = src.get_pixel(x, src.height() - srcfirst - 1);

				value1 = _mm256_add_ps(value1, _mm256_mul_ps(_mm256_load_ps(psrc), weight));
				value2 = _mm256_add_ps(value2, _mm256_mul_ps(_mm256_load_ps(psrc + 8), weight));
			}
			while(++srcfirst != srclast);

			__m256 const weight = _mm256_broadcast_ss(&iter->f); ++iter;
			float* const pdst = dst.get_pixel(x, dst.height() - y - 1);

			_mm256_stream_ps(pdst, _mm256_mul_ps(value1, weight));
			_mm256_stream_ps(pdst + 8, _mm256_mul_ps(value2, weight));
		}

		for(dimension_type x = src.width() & ~(dimension_type)15; x < src.width(); ++x)
		{
			iter = viter;
			
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			float value = 0.0f;

			do
			{
				float weight = iter->f; ++iter;
				float const* const psrc = src.get_pixel(x, src.height() - srcfirst - 1);

				value += psrc[0] * weight;
			}
			while(++srcfirst != srclast);

			float weight = iter->f; ++iter;
			float* const pdst = dst.get_pixel(x, dst.height() - y - 1);

			pdst[0] = value * weight;
		}

		viter = iter;
	}

	_mm_sfence(); // ensure streamed values are flushed.
}
