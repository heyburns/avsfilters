/*
	SSE/AVX pow()
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_XMMPOW_HPP
#define INT64_ORG_RESAMPLER_XMMPOW_HPP

#ifdef _MSC_VER
#pragma once
#endif

#include <intrin.h>

// computes x^0.8, imprecise.
inline __m128 fastpow_4_5i(__m128 x)
{
	x = _mm_mul_ps(x, _mm_set1_ps(5.417433904e9f)); // 2^(127/0.8 - 127) * 1.3831618672225916485^(5/4) * x
	x = _mm_cvtepi32_ps(_mm_castps_si128(x)); // log x
	x = _mm_mul_ps(x, _mm_set1_ps(0.8f)); // x * pow
	return _mm_castsi128_ps(_mm_cvtps_epi32(x)); // exp x
}

// computes x^0.8, imprecise.
inline __m256 fastpow_4_5i(__m256 x)
{
	x = _mm256_mul_ps(x, _mm256_set1_ps(5.417433904e9f)); // 2^(127/0.8 - 127) * 1.3831618672225916485^(5/4) * x
	x = _mm256_cvtepi32_ps(_mm256_castps_si256(x)); // log x
	x = _mm256_mul_ps(x, _mm256_set1_ps(0.8f)); // x * pow
	return _mm256_castsi256_ps(_mm256_cvtps_epi32(x)); // exp x
}

// computes x^2.4, somewhat precise.
inline __m128 fastpow_12_5(__m128 x)
{
	__m128 xf = fastpow_4_5i(x); // x^0.8
	__m128 xfm4 = _mm_rsqrt_ps(xf); // x^-0.4
	__m128 xf4 = _mm_mul_ps(xf, xfm4); // x^0.4
	__m128 xfm2 = _mm_rsqrt_ps(xf4); // x^-0.2

	__m128 x2 = _mm_mul_ps(x, x); // x^2
	__m128 x3 = _mm_mul_ps(x2, x); // x^3

	x2 = _mm_mul_ps(x2, xf4); // x^2 * x^0.4
	x3 = _mm_mul_ps(_mm_mul_ps(x3, xfm4), xfm2); // x^3 * x^-0.4 * x^-0.2

	return _mm_mul_ps(_mm_add_ps(x2, x3), _mm_set1_ps(5.101187832e-1f)); // average x2,x3
}

// computes x^2.4, somewhat precise.
inline __m256 fastpow_12_5(__m256 x)
{
	__m256 xf = fastpow_4_5i(x); // x^0.8
	__m256 xfm4 = _mm256_rsqrt_ps(xf); // x^-0.4
	__m256 xf4 = _mm256_mul_ps(xf, xfm4); // x^0.4
	__m256 xfm2 = _mm256_rsqrt_ps(xf4); // x^-0.2

	__m256 x2 = _mm256_mul_ps(x, x); // x^2
	__m256 x3 = _mm256_mul_ps(x2, x); // x^3

	x2 = _mm256_mul_ps(x2, xf4); // x^2 * x^0.4
	x3 = _mm256_mul_ps(_mm256_mul_ps(x3, xfm4), xfm2); // x^3 * x^-0.4 * x^-0.2

	return _mm256_mul_ps(_mm256_add_ps(x2, x3), _mm256_set1_ps(5.101187832e-1f)); // average x2,x3
}

// computes x^(2/3), imprecise.
inline __m128 fastpow_2_3i(__m128 x)
{
	x = _mm_mul_ps(x, _mm_set1_ps(6.521908912e18f)); // 2^(127 / (2/3) - 127) * 0.629960524947436582384^(3/2) * x
	x = _mm_cvtepi32_ps(_mm_castps_si128(x)); // log x
	x = _mm_mul_ps(x, _mm_set1_ps(0.6666666666f)); // x * pow
	return _mm_castsi128_ps(_mm_cvtps_epi32(x)); // exp x
}

// computes x^(2/3), imprecise.
inline __m256 fastpow_2_3i(__m256 x)
{
	x = _mm256_mul_ps(x, _mm256_set1_ps(6.521908912e18f)); // 2^(127 / (2/3) - 127) * 0.629960524947436582384^(3/2) * x
	x = _mm256_cvtepi32_ps(_mm256_castps_si256(x)); // log x
	x = _mm256_mul_ps(x, _mm256_set1_ps(0.6666666666f)); // x * pow
	return _mm256_castsi256_ps(_mm256_cvtps_epi32(x)); // exp x
}

// computes x^(1/2.4), somewhat precise.
inline __m128 fastpow_5_12(__m128 x)
{
	__m128 xf = fastpow_2_3i(x);
	__m128 xover = _mm_mul_ps(x, xf);
	__m128 xfm1 = _mm_rsqrt_ps(xf);
	__m128 x2 = _mm_mul_ps(x, x);
	__m128 xunder = _mm_mul_ps(x2, xfm1);

	__m128 xavg = _mm_mul_ps(_mm_add_ps(xover, xunder), _mm_set1_ps(5.290278572e-1f));

	xavg = _mm_mul_ps(xavg, _mm_rsqrt_ps(xavg));
	return _mm_mul_ps(xavg, _mm_rsqrt_ps(xavg));
}

// computes x^(1/2.4), somewhat precise.
inline __m256 fastpow_5_12(__m256 x)
{
	__m256 xf = fastpow_2_3i(x);
	__m256 xover = _mm256_mul_ps(x, xf);
	__m256 xfm1 = _mm256_rsqrt_ps(xf);
	__m256 x2 = _mm256_mul_ps(x, x);
	__m256 xunder = _mm256_mul_ps(x2, xfm1);

	__m256 xavg = _mm256_mul_ps(_mm256_add_ps(xover, xunder), _mm256_set1_ps(5.290278572e-1f));

	xavg = _mm256_mul_ps(xavg, _mm256_rsqrt_ps(xavg));
	return _mm256_mul_ps(xavg, _mm256_rsqrt_ps(xavg));
}

#endif
