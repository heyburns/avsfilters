/*
	FMA4 colorspace conversions
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Note: These are put in a separate file because they need to be compiled with /arch:AVX or VC++
	will mix AVX with SSE instructions which results in a terrible performance penalty!
*/

#define INT64_RESAMPLER_EXPORTS

#include "targetver.hpp"
#include <immintrin.h>
#include <ammintrin.h>
#include "color.hpp"
#include "xmmpow.hpp"

///////////////////////////////////////////////////////////
// Vector FMA functions
//

inline __m256 mm_muladd_ps(__m256 mul1, __m256 mul2, __m256 add)
{
	return _mm256_macc_ps(mul1, mul2, add);
}

inline __m256 mm_mulsub_ps(__m256 mul1, __m256 mul2, __m256 sub)
{
	return _mm256_msub_ps(mul1, mul2, sub);
}

///////////////////////////////////////////////////////////
// sRGB <-> linear RGB conversion
//

// xi must be 8 ints with range 0...255
inline __m256 srgb8_to_linear_unsafe(__m256i xi)
{
	__m256 x = _mm256_cvtepi32_ps(xi);

	__m256 is_linear = _mm256_cmp_ps(x, _mm256_set1_ps(0.04045f), _CMP_LE_OS);
	__m256 linear = _mm256_mul_ps(x, _mm256_set1_ps(1.0f / (12.92f * 255.0f)));
	__m256 curved = fastpow_12_5(mm_muladd_ps(x, _mm256_set1_ps(1.0f / (1.055f * 255.0f)), _mm256_set1_ps(1.0f / (1.055f * 255.0f) * 0.055f)));

	return _mm256_blendv_ps(curved, linear, is_linear);
}

inline __m256 srgb_to_linear(__m256 x)
{
	__m256 is_linear = _mm256_cmp_ps(x, _mm256_set1_ps(0.04045f), _CMP_LE_OS);
	__m256 linear = _mm256_mul_ps(_mm256_max_ps(x, _mm256_setzero_ps()), _mm256_set1_ps(1.0f / 12.92f));
	__m256 curved = fastpow_12_5(mm_muladd_ps(_mm256_min_ps(x, _mm256_set1_ps(1.0f)), _mm256_set1_ps(1.0f / 1.055f), _mm256_set1_ps(1.0f / 1.055f * 0.055f)));

	return _mm256_blendv_ps(curved, linear, is_linear);
}

inline __m256 linear_to_srgb(__m256 x)
{
	__m256 is_linear = _mm256_cmp_ps(x, _mm256_set1_ps(0.0031308f), _CMP_LE_OS);
	__m256 linear = _mm256_mul_ps(_mm256_max_ps(x, _mm256_setzero_ps()), _mm256_set1_ps(12.92f));
	__m256 curved = mm_mulsub_ps(fastpow_5_12(_mm256_min_ps(x, _mm256_set1_ps(1.0f))), _mm256_set1_ps(1.055f), _mm256_set1_ps(0.055f));

	return _mm256_blendv_ps(curved, linear, is_linear);
}

// returns 8 ints with range 0...255
inline __m256i linear_to_srgb8(__m256 x)
{
	__m256 is_linear = _mm256_cmp_ps(x, _mm256_set1_ps(0.0031308f), _CMP_LE_OS);
	__m256 linear = _mm256_mul_ps(_mm256_max_ps(x, _mm256_setzero_ps()), _mm256_set1_ps(12.92f * 255.0f));
	__m256 curved = mm_mulsub_ps(fastpow_5_12(_mm256_min_ps(x, _mm256_set1_ps(1.0f))), _mm256_set1_ps(1.055f * 255.0f), _mm256_set1_ps(0.055f * 255.0f));
	
	return _mm256_cvtps_epi32(_mm256_blendv_ps(curved, linear, is_linear));
}

/*
	These check if input can be used with aligned loads.  It is possible for Avisynth
	filters (such as Crop) to produce unaligned images, so it must be checked.
*/

template<typename T1>
inline bool sse_misaligned(T1 *a)
{
	return ((std::intptr_t)a & 15) != 0;
}

template<typename T1, typename T2, typename T3, typename T4>
inline bool sse_misaligned(T1 *a, T2 *b, T3 *c, T4 *d)
{
	return (((std::intptr_t)a | (std::intptr_t)b | (std::intptr_t)c | (std::intptr_t)d) & 15) != 0;
}

///////////////////////////////////////////////////////////
// srgb24_to_linear_rgb
//

void color::srgb24_to_linear_rgb_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	__m128i const maskb = _mm_set_epi8(-128, -128, -128, 9, -128, -128, -128, 6, -128, -128, -128, 3, -128, -128, -128, 0);
	__m128i const maskg = _mm_set_epi8(-128, -128, -128, 10, -128, -128, -128, 7, -128, -128, -128, 4, -128, -128, -128, 1);
	__m128i const maskr = _mm_set_epi8(-128, -128, -128, 11, -128, -128, -128, 8, -128, -128, -128, 5, -128, -128, -128, 2);

	__m128i const maskb4 = _mm_set_epi8(-128, -128, -128, 13, -128, -128, -128, 10, -128, -128, -128, 7, -128, -128, -128, 4);
	__m128i const maskg4 = _mm_set_epi8(-128, -128, -128, 14, -128, -128, -128, 11, -128, -128, -128, 8, -128, -128, -128, 5);
	__m128i const maskr4 = _mm_set_epi8(-128, -128, -128, 15, -128, -128, -128, 12, -128, -128, -128, 9, -128, -128, -128, 6);

	if(sse_misaligned(in_srgb))
	{
		srgb24_to_linear_rgb_row_c(in_srgb, out_r, out_g, out_b, width);
		return;
	}

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m128i part1 = _mm_load_si128((__m128i const*)&in_srgb[x * 3]);
		__m128i part2 = _mm_load_si128((__m128i const*)&in_srgb[x * 3 + 16]);
		__m128i px2 = _mm_alignr_epi8(part2, part1, 12);

		__m256i b1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(part1, maskb)), _mm_shuffle_epi8(px2, maskb), 1);
		__m256i g1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(part1, maskg)), _mm_shuffle_epi8(px2, maskg), 1);
		__m256i r1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(part1, maskr)), _mm_shuffle_epi8(px2, maskr), 1);

		_mm256_store_ps(out_b + x, srgb8_to_linear_unsafe(b1));
		_mm256_store_ps(out_g + x, srgb8_to_linear_unsafe(g1));
		_mm256_store_ps(out_r + x, srgb8_to_linear_unsafe(r1));

		__m128i part3 = _mm_load_si128((__m128i const*)&in_srgb[x * 3 + 32]);
		__m128i px3 = _mm_alignr_epi8(part3, part2, 8);

		__m256i b2 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(px3, maskb)), _mm_shuffle_epi8(part3, maskb4), 1);
		__m256i g2 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(px3, maskg)), _mm_shuffle_epi8(part3, maskg4), 1);
		__m256i r2 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_shuffle_epi8(px3, maskr)), _mm_shuffle_epi8(part3, maskr4), 1);

		_mm256_store_ps(out_b + x + 8, srgb8_to_linear_unsafe(b2));
		_mm256_store_ps(out_g + x + 8, srgb8_to_linear_unsafe(g2));
		_mm256_store_ps(out_r + x + 8, srgb8_to_linear_unsafe(r2));
	}

	if(x < width)
	{
		srgb24_to_linear_rgb_row_c(in_srgb + x * 3, out_r + x, out_g + x, out_b + x, width - x);
	}
}

///////////////////////////////////////////////////////////
// srgb32_to_linear_rgb
//

void color::srgb32_to_linear_rgb_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	__m128i const mask = _mm_set1_epi32(0xFF);

	if(sse_misaligned(in_srgb))
	{
		srgb32_to_linear_rgb_row_c(in_srgb, out_r, out_g, out_b, width);
		return;
	}

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m128i pxa = _mm_load_si128((__m128i const*)&in_srgb[x * 4]);
		__m128i pxb = _mm_load_si128((__m128i const*)&in_srgb[x * 4 + 16]);

		__m128i a = _mm_and_si128(pxa, mask);
		__m128i b = _mm_and_si128(pxb, mask);
		__m256i px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_b + x, srgb8_to_linear_unsafe(px));

		a = _mm_and_si128(_mm_srli_epi32(pxa, 8), mask);
		b = _mm_and_si128(_mm_srli_epi32(pxb, 8), mask);
		px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_g + x, srgb8_to_linear_unsafe(px));

		a = _mm_and_si128(_mm_srli_epi32(pxa, 16), mask);
		b = _mm_and_si128(_mm_srli_epi32(pxb, 16), mask);
		px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_r + x, srgb8_to_linear_unsafe(px));
	}

	if(x < width)
	{
		srgb32_to_linear_rgb_row_c(in_srgb + x * 4, out_r + x, out_g + x, out_b + x, width - x);
	}
}

///////////////////////////////////////////////////////////
// srgb32_to_linear_rgba
//

void color::srgb32_to_linear_rgba_row_fma4(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width)
{
	__m128i const mask = _mm_set1_epi32(0xFF);
	__m256 const r255 = _mm256_set1_ps(1.0f / 255.0f);

	if(sse_misaligned(in_srgb))
	{
		srgb32_to_linear_rgba_row_c(in_srgb, out_r, out_g, out_b, out_a, width);
		return;
	}

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m128i pxa = _mm_load_si128((__m128i const*)&in_srgb[x * 4]);
		__m128i pxb = _mm_load_si128((__m128i const*)&in_srgb[x * 4 + 16]);

		__m128i a = _mm_and_si128(pxa, mask);
		__m128i b = _mm_and_si128(pxb, mask);
		__m256i px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_b + x, srgb8_to_linear_unsafe(px));

		a = _mm_and_si128(_mm_srli_epi32(pxa, 8), mask);
		b = _mm_and_si128(_mm_srli_epi32(pxb, 8), mask);
		px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_g + x, srgb8_to_linear_unsafe(px));

		a = _mm_and_si128(_mm_srli_epi32(pxa, 16), mask);
		b = _mm_and_si128(_mm_srli_epi32(pxb, 16), mask);
		px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_r + x, srgb8_to_linear_unsafe(px));

		a = _mm_srli_epi32(pxa, 16);
		b = _mm_srli_epi32(pxb, 16);
		px = _mm256_insertf128_si256(_mm256_castsi128_si256(a), b, 1);

		_mm256_store_ps(out_a + x, _mm256_mul_ps(_mm256_cvtepi32_ps(px), r255));
	}

	if(x < width)
	{
		srgb32_to_linear_rgb_row_c(in_srgb + x * 4, out_r + x, out_g + x, out_b + x, width - x);
	}
}

///////////////////////////////////////////////////////////
// yv12_to_yuv
//

inline void yv12_to_yuv_cluster_fma4(float* const out, std::uint8_t const* const in, __m256 const sub, __m256 const mul)
{
	__m128i const zero = _mm_setzero_si128();

	__m128i px = _mm_load_si128((__m128i const*)in);
	__m128i lo = _mm_unpacklo_epi8(px, zero);
	__m128i hi = _mm_unpackhi_epi8(px, zero);
	__m256i px1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_unpacklo_epi16(lo, zero)), _mm_unpackhi_epi16(lo, zero), 1);
	__m256i px2 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_unpacklo_epi16(hi, zero)), _mm_unpackhi_epi16(hi, zero), 1);
	
	_mm256_store_ps(out, mm_mulsub_ps(_mm256_cvtepi32_ps(px1), mul, sub));
	_mm256_store_ps(out + 8, mm_mulsub_ps(_mm256_cvtepi32_ps(px1), mul, sub));
}

void color::yv12_to_yuv_row_fma4(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width)
{
	if(sse_misaligned(in_y1, in_y2, in_cb, in_cr))
	{
		yv12_to_yuv_row_c(table, in_y1, in_y2, in_cb, in_cr, out_y1, out_y2, out_u, out_v, width);
		return;
	}

	__m256 const
		ymul_r = table.mm256_ymul_r, ysub = table.mm256_ysub,
		cbmul_r = table.mm256_cbmul_r, cbsub = table.mm256_cbsub,
		crmul_r = table.mm256_crmul_r, crsub = table.mm256_crsub;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)31); x += 32)
	{
		yv12_to_yuv_cluster_fma4(out_y2 + x, in_y1 + x, ysub, ymul_r);
		yv12_to_yuv_cluster_fma4(out_y2 + x + 16, in_y1 + x + 16, ysub, ymul_r);

		yv12_to_yuv_cluster_fma4(out_y1 + x, in_y2 + x, ysub, ymul_r);
		yv12_to_yuv_cluster_fma4(out_y1 + x + 16, in_y2 + x + 16, ysub, ymul_r);

		yv12_to_yuv_cluster_fma4(out_u + x / 2, in_cb + x / 2, cbsub, cbmul_r);
		yv12_to_yuv_cluster_fma4(out_v + x / 2, in_cr + x / 2, crsub, crmul_r);
	}

	if(x < width)
	{
		yv12_to_yuv_row_c(table, in_y1 + x, in_y2 + x, in_cb + x / 2, in_cr + x / 2, out_y1 + x, out_y2 + x, out_u + x / 2, out_v + x / 2, width - x);
	}
}

///////////////////////////////////////////////////////////
// yuy2_to_yuv
//

void color::yuy2_to_yuv_row_fma4(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width)
{
	__m128i const zero = _mm_setzero_si128();
	__m128i const ymask = _mm_set_epi8(0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1);
	__m128i const cmask = _mm_set_epi8(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1);

	if(sse_misaligned(in_yuy2))
	{
		yuy2_to_yuv_row_c(table, in_yuy2, out_y, out_u, out_v, width);
		return;
	}
	
	__m256 const
		ymul_r = table.mm256_ymul_r, ysub = table.mm256_ysub,
		cbmul_r = table.mm256_cbmul_r, cbsub = table.mm256_cbsub,
		crmul_r = table.mm256_crmul_r, crsub = table.mm256_crsub;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m128i px1 = _mm_load_si128((__m128i const*)(in_yuy2 + x * 2));

		__m128i ya = _mm_and_si128(px1, ymask);
		__m256i y1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_unpacklo_epi16(ya, zero)), _mm_unpackhi_epi16(ya, zero), 1);

		_mm256_store_ps(out_y + x, mm_mulsub_ps(_mm256_cvtepi32_ps(y1), ymul_r, ysub));

		__m128i px2 = _mm_load_si128((__m128i const*)(in_yuy2 + x * 2 + 16));

		__m128i yb = _mm_and_si128(px2, ymask);
		__m256i y2 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_unpacklo_epi16(yb, zero)), _mm_unpackhi_epi16(yb, zero), 1);

		_mm256_store_ps(out_y + x + 8, mm_mulsub_ps(_mm256_cvtepi32_ps(y2), ymul_r, ysub));

		__m256i u1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_and_si128(_mm_srli_epi32(px1, 8), cmask)), _mm_and_si128(_mm_srli_epi32(px2, 8), cmask), 1);
		__m256i v1 = _mm256_insertf128_si256(_mm256_castsi128_si256(_mm_and_si128(_mm_srli_epi32(px1, 24), cmask)), _mm_and_si128(_mm_srli_epi32(px2, 24), cmask), 1);

		_mm256_store_ps(out_u + x / 2, mm_mulsub_ps(_mm256_cvtepi32_ps(u1), cbmul_r, cbsub));
		_mm256_store_ps(out_v + x / 2, mm_mulsub_ps(_mm256_cvtepi32_ps(v1), crmul_r, crsub));
	}

	if(x < width)
	{
		yuy2_to_yuv_row_c(table, in_yuy2 + x * 2, out_y + x, out_u + x / 2, out_v + x / 2, width - x);
	}
}

///////////////////////////////////////////////////////////
// yuv_to_linear_rgb
//

void color::yuv_to_linear_rgb_row_fma4(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width)
{
	__m256 const rscale = table.mm256_rscale, bscale = table.mm256_bscale, gscale_r = table.mm256_gscale_r;
	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m256 cy = _mm256_load_ps(inout_y_r + x);
		__m256 cu = _mm256_load_ps(inout_u_g + x);
		__m256 cv = _mm256_load_ps(inout_v_b + x);

		__m256 r = _mm256_add_ps(cv, cy);
		__m256 b = _mm256_add_ps(cu, cy);
		__m256 g = _mm256_mul_ps(_mm256_sub_ps(_mm256_sub_ps(cy, _mm256_mul_ps(r, rscale)), _mm256_mul_ps(b, bscale)), gscale_r);

		_mm256_store_ps(inout_y_r + x, srgb_to_linear(r));
		_mm256_store_ps(inout_u_g + x, srgb_to_linear(g));
		_mm256_store_ps(inout_v_b + x, srgb_to_linear(b));
	}

	if(x < width)
	{
		yuv_to_linear_rgb_row_c(table, inout_y_r + x, inout_u_g + x, inout_v_b + x, width - x);
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_srgb24
//

void color::linear_rgb_to_srgb24_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	__m128i const mask1 = _mm_set_epi8(-1, -1, -1, -1, 14, 13, 12, 10, 9, 8, 6, 5, 4, 2, 1, 0);
	__m128i const mask2 = _mm_set_epi8(4, 2, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	__m128i const mask3 = _mm_set_epi8(-1, -1, -1, -1, -1, -1, -1, -1, 14, 13, 12, 10, 9, 8, 6, 5);
	__m128i const mask4 = _mm_set_epi8(9, 8, 6, 5, 4, 2, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1);
	__m128i const mask5 = _mm_set_epi8(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 14, 13, 12, 10);
	__m128i const mask6 = _mm_set_epi8(14, 13, 12, 10, 9, 8, 6, 5, 4, 2, 1, 0, -1, -1, -1, -1);

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m128i *out = (__m128i*)(out_srgb + x * 3);

		__m256i b1 = linear_to_srgb8(_mm256_load_ps(in_b + x));
		__m256i g1 = linear_to_srgb8(_mm256_load_ps(in_g + x));
		__m256i r1 = linear_to_srgb8(_mm256_load_ps(in_r + x));

		__m128i p1 = _mm_or_si128(_mm_or_si128(_mm256_castsi256_si128(b1), _mm_slli_epi32(_mm256_castsi256_si128(g1), 8)), _mm_slli_epi32(_mm256_castsi256_si128(r1), 16));
		__m128i p2 = _mm_or_si128(_mm_or_si128(_mm256_extractf128_si256(b1, 1), _mm_slli_epi32(_mm256_extractf128_si256(g1, 1), 8)), _mm_slli_epi32(_mm256_extractf128_si256(r1, 1), 16));

		_mm_store_si128(out, _mm_or_si128(_mm_shuffle_epi8(p1, mask1), _mm_shuffle_epi8(p2, mask2)));

		__m256i b2 = linear_to_srgb8(_mm256_load_ps(in_b + x + 8));
		__m256i g2 = linear_to_srgb8(_mm256_load_ps(in_g + x + 8));
		__m256i r2 = linear_to_srgb8(_mm256_load_ps(in_r + x + 8));

		__m128i p3 = _mm_or_si128(_mm_or_si128(_mm256_castsi256_si128(b2), _mm_slli_epi32(_mm256_castsi256_si128(g2), 8)), _mm_slli_epi32(_mm256_castsi256_si128(r2), 16));

		_mm_store_si128(out + 1, _mm_or_si128(_mm_shuffle_epi8(p2, mask3), _mm_shuffle_epi8(p3, mask4)));

		__m128i p4 = _mm_or_si128(_mm_or_si128(_mm256_extractf128_si256(b2, 1), _mm_slli_epi32(_mm256_extractf128_si256(g2, 1), 8)), _mm_slli_epi32(_mm256_extractf128_si256(r2, 1), 16));

		_mm_store_si128(out + 2, _mm_or_si128(_mm_shuffle_epi8(p3, mask5), _mm_shuffle_epi8(p4, mask6)));
	}

	if(x < width)
	{
		linear_rgb_to_srgb24_row_c(in_r + x, in_g + x, in_b + x, out_srgb + x * 3, width - x);
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_srgb32
//

void color::linear_rgb_to_srgb32_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	__m128i const malpha = _mm_set1_epi32(std::int32_t(std::uint32_t(0xFF) << 24));

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		std::uint8_t *out = out_srgb + x * 4;

		__m256i b = linear_to_srgb8(_mm256_load_ps(in_b + x));
		__m128i ba = _mm256_castsi256_si128(b);
		__m128i bb = _mm256_extractf128_si256(b, 1);

		__m256i g = linear_to_srgb8(_mm256_load_ps(in_g + x));
		__m128i ga = _mm_slli_epi32(_mm256_castsi256_si128(g), 8);
		__m128i gb = _mm_slli_epi32(_mm256_extractf128_si256(g, 1), 8);

		__m256i r = linear_to_srgb8(_mm256_load_ps(in_r + x));
		__m128i ra = _mm_slli_epi32(_mm256_castsi256_si128(r), 16);
		__m128i rb = _mm_slli_epi32(_mm256_extractf128_si256(r, 1), 16);

		__m128i pxa = _mm_or_si128(_mm_or_si128(ba, ga), _mm_or_si128(ra, malpha));
		__m128i pxb = _mm_or_si128(_mm_or_si128(bb, gb), _mm_or_si128(rb, malpha));

		_mm256_store_si256((__m256i*)(out_srgb + x * 4), _mm256_insertf128_si256(_mm256_castsi128_si256(pxa), pxb, 1));
	}

	if(x < width)
	{
		linear_rgb_to_srgb32_row_c(in_r + x, in_g + x, in_b + x, out_srgb + x * 4, width - x);
	}
}

///////////////////////////////////////////////////////////
// linear_rgba_to_srgb32
//

void color::linear_rgba_to_srgb32_row_fma4(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width)
{
	__m256 const m255 = _mm256_set1_ps(255.0f);

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		std::uint8_t *out = out_srgb + x * 4;

		__m256i b = linear_to_srgb8(_mm256_load_ps(in_b + x));
		__m128i ba = _mm256_castsi256_si128(b);
		__m128i bb = _mm256_extractf128_si256(b, 1);

		__m256i g = linear_to_srgb8(_mm256_load_ps(in_g + x));
		__m128i ga = _mm_slli_epi32(_mm256_castsi256_si128(g), 8);
		__m128i gb = _mm_slli_epi32(_mm256_extractf128_si256(g, 1), 8);

		__m256i r = linear_to_srgb8(_mm256_load_ps(in_r + x));
		__m128i ra = _mm_slli_epi32(_mm256_castsi256_si128(r), 16);
		__m128i rb = _mm_slli_epi32(_mm256_extractf128_si256(r, 1), 16);

		__m256i a = _mm256_cvtps_epi32(_mm256_mul_ps(_mm256_load_ps(in_a + x), m255));
		__m128i aa = _mm_slli_epi32(_mm256_castsi256_si128(a), 24);
		__m128i ab = _mm_slli_epi32(_mm256_extractf128_si256(a, 1), 24);

		__m128i pxa = _mm_or_si128(_mm_or_si128(ba, ga), _mm_or_si128(ra, aa));
		__m128i pxb = _mm_or_si128(_mm_or_si128(bb, gb), _mm_or_si128(rb, ab));

		_mm256_store_si256((__m256i*)(out_srgb + x * 4), _mm256_insertf128_si256(_mm256_castsi128_si256(pxa), pxb, 1));
	}

	if(x < width)
	{
		linear_rgb_to_srgb32_row_c(in_r + x, in_g + x, in_b + x, out_srgb + x * 4, width - x);
	}
}

///////////////////////////////////////////////////////////
// yuv_to_yv12
//

inline void yuv_to_yv12_cluster_fma4(std::uint8_t* const out, float const* const in, __m256 mul, __m256 add)
{
	__m256i a = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in), mul, add));
	__m256i b = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in + 8), mul, add));

	_mm_store_si128((__m128i*)out, _mm_packus_epi16(_mm_packs_epi32(_mm256_castsi256_si128(a), _mm256_extractf128_si256(a, 1)), _mm_packs_epi32(_mm256_castsi256_si128(b), _mm256_extractf128_si256(b, 1))));
}

void color::yuv_to_yv12_row_fma4(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width)
{
	__m256 const yadd = table.mm256_yadd, ymul = table.mm256_ymul, cadd = table.mm256_cadd, cbmul = table.mm256_cbmul, crmul = table.mm256_crmul;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)31); x += 32)
	{
		yuv_to_yv12_cluster_fma4(out_y2 + x, in_y1 + x, ymul, yadd);
		yuv_to_yv12_cluster_fma4(out_y2 + x + 16, in_y1 + x + 16, ymul, yadd);

		yuv_to_yv12_cluster_fma4(out_y1 + x, in_y2 + x, ymul, yadd);
		yuv_to_yv12_cluster_fma4(out_y1 + x + 16, in_y2 + x + 16, ymul, yadd);

		yuv_to_yv12_cluster_fma4(out_cb + x / 2, in_u + x / 2, cbmul, cadd);
		yuv_to_yv12_cluster_fma4(out_cr + x / 2, in_v + x / 2, crmul, cadd);
	}

	if(x < width)
	{
		yuv_to_yv12_row_c(table, in_y1 + x, in_y2 + x, in_u + x / 2, in_v + x / 2, out_y1 + x, out_y2 + x, out_cb + x / 2, out_cr + x / 2, width - x);
	}
}

///////////////////////////////////////////////////////////
// yuv_to_yuy2
//

void color::yuv_to_yuy2_row_fma4(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width)
{
	__m256 const yadd = table.mm256_yadd, ymul = table.mm256_ymul, cadd = table.mm256_cadd, cbmul = table.mm256_cbmul, crmul = table.mm256_crmul;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m256i ya = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in_y + x), ymul, yadd));
		__m256i cb = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in_u + x / 2), cbmul, cadd));
		__m256i cr = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in_v + x / 2), crmul, cadd));

		__m128i y1 = _mm_packs_epi32(_mm256_castsi256_si128(ya), _mm256_extractf128_si256(ya, 1));
		__m128i px1 = _mm_or_si128(_mm_or_si128(y1, _mm_slli_epi32(_mm256_castsi256_si128(cb), 8)), _mm_slli_epi32(_mm256_castsi256_si128(cr), 24));

		_mm_store_si128((__m128i*)(out_yuy2 + x * 2), px1);

		__m256i yb = _mm256_cvtps_epi32(mm_muladd_ps(_mm256_load_ps(in_y + x + 8), ymul, yadd));
		__m128i y2 = _mm_packs_epi32(_mm256_castsi256_si128(yb), _mm256_extractf128_si256(yb, 1));
		__m128i px2 = _mm_or_si128(_mm_or_si128(y2, _mm_slli_epi32(_mm256_extractf128_si256(cb, 1), 8)), _mm_slli_epi32(_mm256_extractf128_si256(cr, 1), 24));

		_mm_store_si128((__m128i*)(out_yuy2 + x * 2 + 16), px2);
	}

	if(x < width)
	{
		yuv_to_yuy2_row_c(table, in_y + x, in_u + x / 2, in_v + x / 2, out_yuy2 + x * 2, width - x);
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_yuv
//

void color::linear_rgb_to_yuv_row_fma4(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width)
{
	__m256 const rscale = table.mm256_rscale, gscale = table.mm256_gscale, bscale = table.mm256_bscale;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m256 r = linear_to_srgb(_mm256_load_ps(inout_r_y + x));
		__m256 g = linear_to_srgb(_mm256_load_ps(inout_g_u + x));
		__m256 b = linear_to_srgb(_mm256_load_ps(inout_b_v + x));

		__m256 cy = mm_muladd_ps(b, bscale, mm_muladd_ps(r, rscale, _mm256_mul_ps(g, gscale)));
		__m256 cu = _mm256_sub_ps(b, cy);
		__m256 cv = _mm256_sub_ps(r, cy);

		_mm256_store_ps(inout_r_y + x, cy);
		_mm256_store_ps(inout_g_u + x, cu);
		_mm256_store_ps(inout_b_v + x, cv);
	}

	if(x < width)
	{
		linear_rgb_to_yuv_row_c(table, inout_r_y + x, inout_g_u + x, inout_b_v + x, width - x);
	}
}
