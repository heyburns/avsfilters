/*
	Colorspace conversions
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "color.hpp"
#include "xmmpow.hpp"

// YUV conversion tables.  See the gentables app to see how they're computed.

#include "tables.hpp"

///////////////////////////////////////////////////////////
// Vector select()
//

inline __m128 mm_select_ps(__m128 a, __m128 b, __m128 mask)
{
	// return mask ? b : a;
	return _mm_or_ps(_mm_and_ps(b, mask), _mm_andnot_ps(mask, a));
}

///////////////////////////////////////////////////////////
// sRGB <-> linear RGB conversion
//

// xi must be 4 ints with range 0...255
inline __m128 srgb8_to_linear_unsafe(__m128i xi)
{
	__m128 x = _mm_cvtepi32_ps(xi);

	__m128 is_linear = _mm_cmple_ps(x, _mm_set1_ps(0.04045f * 255.0f));
	__m128 linear = _mm_mul_ps(x, _mm_set1_ps(1.0f / (12.92f * 255.0f)));
	__m128 curved = fastpow_12_5(_mm_mul_ps(_mm_add_ps(x, _mm_set1_ps(0.055f * 255.0f)), _mm_set1_ps(1.0f / (1.055f * 255.0f))));

	return mm_select_ps(curved, linear, is_linear);
}

inline __m128 srgb_to_linear(__m128 x)
{	
	__m128 is_linear = _mm_cmple_ps(x, _mm_set1_ps(0.04045f));
	__m128 linear = _mm_mul_ps(_mm_max_ps(x, _mm_setzero_ps()), _mm_set1_ps(1.0f / 12.92f));
	__m128 curved = fastpow_12_5(_mm_mul_ps(_mm_add_ps(_mm_min_ps(x, _mm_set1_ps(1.0f)), _mm_set1_ps(0.055f)), _mm_set1_ps(1.0f / 1.055f)));

	return mm_select_ps(curved, linear, is_linear);
}

inline __m128 linear_to_srgb(__m128 x)
{
	__m128 is_linear = _mm_cmple_ps(x, _mm_set1_ps(0.0031308f));
	__m128 linear = _mm_mul_ps(_mm_max_ps(x, _mm_setzero_ps()), _mm_set1_ps(12.92f));
	__m128 curved = _mm_sub_ps(_mm_mul_ps(fastpow_5_12(_mm_min_ps(x, _mm_set1_ps(1.0f))), _mm_set1_ps(1.055f)), _mm_set1_ps(0.055f));

	return mm_select_ps(curved, linear, is_linear);
}

// returns 4 ints with range 0...255
inline __m128i linear_to_srgb8(__m128 x)
{
	__m128 is_linear = _mm_cmple_ps(x, _mm_set1_ps(0.0031308f));
	__m128 linear = _mm_mul_ps(_mm_max_ps(x, _mm_setzero_ps()), _mm_set1_ps(12.92f * 255.0f));
	__m128 curved = _mm_sub_ps(_mm_mul_ps(fastpow_5_12(_mm_min_ps(x, _mm_set1_ps(1.0f))), _mm_set1_ps(1.055f * 255.0f)), _mm_set1_ps(0.055f * 255.0f));

	return _mm_cvtps_epi32(mm_select_ps(curved, linear, is_linear));
}

inline float srgb8_to_linear_unsafe(std::uint8_t c)
{
	return (c < 11) ? (c / (12.92f * 255.f)) : std::pow((c + (0.055f * 255.0f)) / (1.055f * 255.0f), 2.4f);
}

inline float srgb_to_linear(float c)
{
	if(c <= 0.0f)
	{
		return 0.0f;
	}

	if(c <= 0.04045f)
	{
		return c / 12.92f;
	}

	if(c < 1.0f)
	{
		return std::pow((c + 0.055f) / 1.055f, 2.4f);
	}

	return 1.0f;
}

inline float linear_to_srgb(float c)
{
	if(c <= 0.0f)
	{
		return 0.0f;
	}

	if(c <= 0.0031308f)
	{
		return c * 12.92f;
	}

	if(c < 1.0f)
	{
		return std::pow(c, 1.0f / 2.4f) * 1.055f - 0.055f;
	}

	return 1.0f;
}

inline std::uint8_t linear_to_srgb8(float c)
{
	if(c <= 0.0f)
	{
		return 0;
	}

	if(c <= 0.0031308f)
	{
		return std::uint8_t(c * (12.92f * 255.0f) + 0.5f);
	}

	if(c < 1.0f)
	{
		return std::uint8_t(std::pow(c, 1.0f / 2.4f) * (1.055f * 255.0f) - (0.055f * 255.0f - 0.5f));
	}

	return 255;
}

/*
	These check if input can be used with aligned loads.  It is possible for Avisynth
	filters (such as Crop) to produce unaligned images, so it must be checked.
*/

template<typename T1>
inline bool sse_misaligned(T1 *a)
{
	return ((std::intptr_t)a & 15) != 0;
}

template<typename T1, typename T2, typename T3, typename T4>
inline bool sse_misaligned(T1 *a, T2 *b, T3 *c, T4 *d)
{
	return (((std::intptr_t)a | (std::intptr_t)b | (std::intptr_t)c | (std::intptr_t)d) & 15) != 0;
}

///////////////////////////////////////////////////////////
// srgb24_to_linear_rgb
//

void color::srgb24_to_linear_rgb_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		out_b[x] = srgb8_to_linear_unsafe(in_srgb[x * 3]);
		out_g[x] = srgb8_to_linear_unsafe(in_srgb[x * 3 + 1]);
		out_r[x] = srgb8_to_linear_unsafe(in_srgb[x * 3 + 2]);
	}
}

void color::srgb24_to_linear_rgb_row_ssse3(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	__m128i const maskb = _mm_set_epi8(-128, -128, -128, 9, -128, -128, -128, 6, -128, -128, -128, 3, -128, -128, -128, 0);
	__m128i const maskg = _mm_set_epi8(-128, -128, -128, 10, -128, -128, -128, 7, -128, -128, -128, 4, -128, -128, -128, 1);
	__m128i const maskr = _mm_set_epi8(-128, -128, -128, 11, -128, -128, -128, 8, -128, -128, -128, 5, -128, -128, -128, 2);

	__m128i const maskb4 = _mm_set_epi8(-128, -128, -128, 13, -128, -128, -128, 10, -128, -128, -128, 7, -128, -128, -128, 4);
	__m128i const maskg4 = _mm_set_epi8(-128, -128, -128, 14, -128, -128, -128, 11, -128, -128, -128, 8, -128, -128, -128, 5);
	__m128i const maskr4 = _mm_set_epi8(-128, -128, -128, 15, -128, -128, -128, 12, -128, -128, -128, 9, -128, -128, -128, 6);

	if(sse_misaligned(in_srgb))
	{
		srgb24_to_linear_rgb_row_c(in_srgb, out_r, out_g, out_b, width);
		return;
	}

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m128i part1 = _mm_load_si128((__m128i const*)&in_srgb[x * 3]);

		_mm_store_ps(out_b + x, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part1, maskb)));
		_mm_store_ps(out_g + x, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part1, maskg)));
		_mm_store_ps(out_r + x, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part1, maskr)));

		__m128i part2 = _mm_load_si128((__m128i const*)&in_srgb[x * 3 + 16]);
		__m128i px2 = _mm_alignr_epi8(part2, part1, 12);

		_mm_store_ps(out_b + x + 4, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px2, maskb)));
		_mm_store_ps(out_g + x + 4, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px2, maskg)));
		_mm_store_ps(out_r + x + 4, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px2, maskr)));

		__m128i part3 = _mm_load_si128((__m128i const*)&in_srgb[x * 3 + 32]);
		__m128i px3 = _mm_alignr_epi8(part3, part2, 8);

		_mm_store_ps(out_b + x + 8, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px3, maskb)));
		_mm_store_ps(out_g + x + 8, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px3, maskg)));
		_mm_store_ps(out_r + x + 8, srgb8_to_linear_unsafe(_mm_shuffle_epi8(px3, maskr)));

		_mm_store_ps(out_b + x + 12, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part3, maskb4)));
		_mm_store_ps(out_g + x + 12, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part3, maskg4)));
		_mm_store_ps(out_r + x + 12, srgb8_to_linear_unsafe(_mm_shuffle_epi8(part3, maskr4)));
	}

	if(x < width)
	{
		srgb24_to_linear_rgb_row_c(in_srgb + x * 3, out_r + x, out_g + x, out_b + x, width - x);
	}
}

static void (*srgb24_to_linear_rgb_row)(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, color::dimension_type const width) = color::srgb24_to_linear_rgb_row_c;

void color::srgb24_to_linear_rgb(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b)
{
	for(dimension_type y = 0; y < in_srgb.height(); ++y)
	{
		srgb24_to_linear_rgb_row(in_srgb.get_row(y), out_r.get_row(y), out_g.get_row(y), out_b.get_row(y), in_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// srgb32_to_linear_rgb
//

void color::srgb32_to_linear_rgb_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		out_b[x] = srgb8_to_linear_unsafe(in_srgb[x * 4]);
		out_g[x] = srgb8_to_linear_unsafe(in_srgb[x * 4 + 1]);
		out_r[x] = srgb8_to_linear_unsafe(in_srgb[x * 4 + 2]);
	}
}

void color::srgb32_to_linear_rgb_row_sse2(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, dimension_type const width)
{
	__m128i const mask = _mm_set1_epi32(0xFF);

	if(sse_misaligned(in_srgb))
	{
		srgb32_to_linear_rgb_row_c(in_srgb, out_r, out_g, out_b, width);
		return;
	}

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128i px = _mm_load_si128((__m128i const*)&in_srgb[x * 4]);

		_mm_store_ps(out_b + x, srgb8_to_linear_unsafe(_mm_and_si128(px, mask)));
		_mm_store_ps(out_g + x, srgb8_to_linear_unsafe(_mm_and_si128(_mm_srli_epi32(px, 8), mask)));
		_mm_store_ps(out_r + x, srgb8_to_linear_unsafe(_mm_and_si128(_mm_srli_epi32(px, 16), mask)));
	}

	if(x < width)
	{
		srgb32_to_linear_rgb_row_c(in_srgb + x * 4, out_r + x, out_g + x, out_b + x, width - x);
	}
}

static void (*srgb32_to_linear_rgb_row)(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, color::dimension_type const width) = color::srgb32_to_linear_rgb_row_c;

void color::srgb32_to_linear_rgb(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b)
{
	for(dimension_type y = 0; y < in_srgb.height(); ++y)
	{
		srgb32_to_linear_rgb_row(in_srgb.get_row(y), out_r.get_row(y), out_g.get_row(y), out_b.get_row(y), in_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// srgb32_to_linear_rgba
//

void color::srgb32_to_linear_rgba_row_c(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		out_b[x] = srgb8_to_linear_unsafe(in_srgb[x * 4]);
		out_g[x] = srgb8_to_linear_unsafe(in_srgb[x * 4 + 1]);
		out_r[x] = srgb8_to_linear_unsafe(in_srgb[x * 4 + 2]);
		out_a[x] = in_srgb[x * 4 + 3] / 255.0f;
	}
}

void color::srgb32_to_linear_rgba_row_sse2(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, dimension_type const width)
{
	__m128i const mask = _mm_set_epi32(0xFF, 0xFF, 0xFF, 0xFF);
	__m128 const r255 = _mm_set1_ps(1.0f / 255.0f);

	color::dimension_type x = 0;

	if(sse_misaligned(in_srgb))
	{
		srgb32_to_linear_rgba_row_c(in_srgb, out_r, out_g, out_b, out_a, width);
		return;
	}

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128i px = _mm_load_si128((__m128i const*)&in_srgb[x * 4]);

		_mm_store_ps(out_b + x, srgb8_to_linear_unsafe(_mm_and_si128(px, mask)));
		_mm_store_ps(out_g + x, srgb8_to_linear_unsafe(_mm_and_si128(_mm_srli_epi32(px, 8), mask)));
		_mm_store_ps(out_r + x, srgb8_to_linear_unsafe(_mm_and_si128(_mm_srli_epi32(px, 16), mask)));
		_mm_store_ps(out_a + x, _mm_mul_ps(_mm_cvtepi32_ps(_mm_srli_epi32(px, 24)), r255));
	}

	if(x < width)
	{
		srgb32_to_linear_rgba_row_c(in_srgb + x * 4, out_r + x, out_g + x, out_b + x, out_a + x, width - x);
	}
}

static void (*srgb32_to_linear_rgba_row)(std::uint8_t const* const in_srgb, float* const out_r, float* const out_g, float* const out_b, float* const out_a, color::dimension_type const width) = color::srgb32_to_linear_rgba_row_c;

void color::srgb32_to_linear_rgba(bitmap<std::uint8_t const> const &in_srgb, bitmap<float> const &out_r, bitmap<float> const &out_g, bitmap<float> const &out_b, bitmap<float> const &out_a)
{
	for(dimension_type y = 0; y < in_srgb.height(); ++y)
	{
		srgb32_to_linear_rgba_row(in_srgb.get_row(y), out_r.get_row(y), out_g.get_row(y), out_b.get_row(y), out_a.get_row(y), in_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// yv12_to_yuv
//

void color::yv12_to_yuv_row_c(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width)
{
	for(color::dimension_type x = 0; x < (width - 1); x += 2)
	{
		out_y2[x] = in_y1[x] * table.ymul_r - table.ysub;
		out_y2[x + 1] = in_y1[x + 1] * table.ymul_r - table.ysub;
		out_y1[x] = in_y2[x] * table.ymul_r - table.ysub;
		out_y1[x + 1] = in_y2[x + 1] * table.ymul_r - table.ysub;
		out_u[x / 2] = in_cb[x / 2] * table.cbmul_r - table.cbsub;
		out_v[x / 2] = in_cr[x / 2] * table.crmul_r - table.crsub;
	}
}

inline void yv12_to_yuv_cluster_sse2(float* const out, std::uint8_t const* const in, __m128 sub, __m128 mul)
{
	__m128i const zero = _mm_setzero_si128();

	__m128i px = _mm_load_si128((__m128i const*)in);
	__m128i lo = _mm_unpacklo_epi8(px, zero);
	__m128i hi = _mm_unpackhi_epi8(px, zero);

	_mm_store_ps(out, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpacklo_epi16(lo, zero)), sub), mul));
	_mm_store_ps(out + 4, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpackhi_epi16(lo, zero)), sub), mul));	
	_mm_store_ps(out + 8, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpacklo_epi16(hi, zero)), sub), mul));
	_mm_store_ps(out + 12, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpackhi_epi16(hi, zero)), sub), mul));
}

void color::yv12_to_yuv_row_sse2(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, dimension_type const width)
{
	if(sse_misaligned(in_y1, in_y2, in_cb, in_cr))
	{
		yv12_to_yuv_row_c(table, in_y1, in_y2, in_cb, in_cr, out_y1, out_y2, out_u, out_v, width);
		return;
	}

	__m128 const yadd = table.mm_yadd, ymul_r = table.mm_ymul_r, cadd = table.mm_cadd, cbmul_r = table.mm_cbmul_r, crmul_r = table.mm_crmul_r;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)31); x += 32)
	{
		yv12_to_yuv_cluster_sse2(out_y2 + x, in_y1 + x, yadd, ymul_r);
		yv12_to_yuv_cluster_sse2(out_y2 + x + 16, in_y1 + x + 16, yadd, ymul_r);

		yv12_to_yuv_cluster_sse2(out_y1 + x, in_y2 + x, yadd, ymul_r);
		yv12_to_yuv_cluster_sse2(out_y1 + x + 16, in_y2 + x + 16, yadd, ymul_r);

		yv12_to_yuv_cluster_sse2(out_u + x / 2, in_cb + x / 2, cadd, cbmul_r);
		yv12_to_yuv_cluster_sse2(out_v + x / 2, in_cr + x / 2, cadd, crmul_r);
	}

	if(x < width)
	{
		yv12_to_yuv_row_c(table, in_y1 + x, in_y2 + x, in_cb + x / 2, in_cr + x / 2, out_y1 + x, out_y2 + x, out_u + x / 2, out_v + x / 2, width - x);
	}
}

static void (*yv12_to_yuv_row)(color::yuv_table const &table, std::uint8_t const* const in_y1, std::uint8_t const* const in_y2, std::uint8_t const* const in_cb, std::uint8_t const* const in_cr, float* const out_y1, float* const out_y2, float* const out_u, float* const out_v, color::dimension_type const width) = color::yv12_to_yuv_row_c;

void color::yv12_to_yuv(yuv_table const &table, bitmap<std::uint8_t const> const &in_y, bitmap<std::uint8_t const> const &in_cb, bitmap<std::uint8_t const> const &in_cr, bitmap<float> const &out_y, bitmap<float> const &out_u, bitmap<float> const &out_v)
{
	for(dimension_type y = 0; y < in_y.height(); y += 2)
	{
		dimension_type invy = in_y.height() - y - 2;
		yv12_to_yuv_row(table, in_y.get_row(y), in_y.get_row(y + 1), in_cb.get_row(y / 2), in_cr.get_row(y / 2), out_y.get_row(invy), out_y.get_row(invy + 1), out_u.get_row(invy / 2), out_v.get_row(invy / 2), in_y.width());
	}
}

///////////////////////////////////////////////////////////
// yuy2_to_yuv
//

void color::yuy2_to_yuv_row_c(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width)
{
	for(color::dimension_type x = 0; x < (width - 1); x += 2)
	{
		std::uint8_t const* const px = in_yuy2 + x * 2;

		out_y[x] = px[0] * table.ymul_r - table.ysub;
		out_u[x / 2] = px[1] * table.cbmul_r - table.cbsub;
		out_y[x + 1] = px[2] * table.ymul_r - table.ysub;
		out_v[x / 2] = px[3] * table.crmul_r - table.crsub;
	}
}

void color::yuy2_to_yuv_row_sse2(yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, dimension_type width)
{
	__m128i const zero = _mm_setzero_si128();
	__m128i const ymask = _mm_set_epi8(0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1);
	__m128i const cmask = _mm_set_epi8(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1);

	if(sse_misaligned(in_yuy2))
	{
		yuy2_to_yuv_row_c(table, in_yuy2, out_y, out_u, out_v, width);
		return;
	}

	__m128 const yadd = table.mm_yadd, ymul_r = table.mm_ymul_r, cadd = table.mm_cadd, cbmul_r = table.mm_cbmul_r, crmul_r = table.mm_crmul_r;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m128i px = _mm_load_si128((__m128i const*)(in_yuy2 + x * 2));
		__m128i y = _mm_and_si128(px, ymask);

		_mm_store_ps(out_y + x, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpacklo_epi16(y, zero)), yadd), ymul_r));
		_mm_store_ps(out_u + x / 2, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_and_si128(_mm_srli_epi32(px, 8), cmask)), cadd), cbmul_r));
		_mm_store_ps(out_y + x + 4, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_unpackhi_epi16(y, zero)), yadd), ymul_r));
		_mm_store_ps(out_v + x / 2, _mm_mul_ps(_mm_sub_ps(_mm_cvtepi32_ps(_mm_and_si128(_mm_srli_epi32(px, 24), cmask)), cadd), crmul_r));
	}

	if(x < width)
	{
		yuy2_to_yuv_row_c(table, in_yuy2 + x * 2, out_y + x, out_u + x / 2, out_v + x / 2, width - x);
	}
}

static void (*yuy2_to_yuv_row)(color::yuv_table const &table, std::uint8_t const* const in_yuy2, float* const out_y, float* const out_u, float* const out_v, color::dimension_type width) = color::yuy2_to_yuv_row_c;

void color::yuy2_to_yuv(yuv_table const &table, bitmap<std::uint8_t const> const &in_yuy2, bitmap<float> const &out_y, bitmap<float> const &out_u, bitmap<float> const &out_v)
{
	for(dimension_type y = 0; y < in_yuy2.height(); ++y)
	{
		dimension_type invy = in_yuy2.height() - y - 1;
		yuy2_to_yuv_row(table, in_yuy2.get_row(invy), out_y.get_row(y), out_u.get_row(y), out_v.get_row(y), in_yuy2.width());
	}
}

///////////////////////////////////////////////////////////
// yuv_to_linear_rgb
//

void color::yuv_to_linear_rgb_row_c(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		float cy = inout_y_r[x];
		float cu = inout_u_g[x];
		float cv = inout_v_b[x];

		float r = cv + cy;
		float b = cu + cy;
		float g = (cy - r * table.rscale - b * table.bscale) * table.gscale_r;

		inout_y_r[x] = srgb_to_linear(r);
		inout_u_g[x] = srgb_to_linear(g);
		inout_v_b[x] = srgb_to_linear(b);
	}
}

void color::yuv_to_linear_rgb_row_sse2(yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, dimension_type width)
{
	__m128 const rscale = table.mm_rscale, bscale = table.mm_bscale, gscale_r = table.mm_gscale_r;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128 cy = _mm_load_ps(inout_y_r + x);
		__m128 cu = _mm_load_ps(inout_u_g + x);
		__m128 cv = _mm_load_ps(inout_v_b + x);

		__m128 r = _mm_add_ps(cv, cy);
		__m128 b = _mm_add_ps(cu, cy);
		__m128 g = _mm_mul_ps(_mm_sub_ps(_mm_sub_ps(cy, _mm_mul_ps(r, rscale)), _mm_mul_ps(b, bscale)), gscale_r);

		_mm_store_ps(inout_y_r + x, srgb_to_linear(r));
		_mm_store_ps(inout_u_g + x, srgb_to_linear(g));
		_mm_store_ps(inout_v_b + x, srgb_to_linear(b));
	}

	if(x < width)
	{
		yuv_to_linear_rgb_row_c(table, inout_y_r + x, inout_u_g + x, inout_v_b + x, width - x);
	}
}

static void (*yuv_to_linear_rgb_row)(color::yuv_table const &table, float* const inout_y_r, float* const inout_u_g, float* const &inout_v_b, color::dimension_type width) = color::yuv_to_linear_rgb_row_c;

void color::yuv_to_linear_rgb(yuv_table const &table, bitmap<float> const &inout_y_r, bitmap<float> const &inout_u_g, bitmap<float> const &inout_v_b)
{
	for(dimension_type y = 0; y < inout_y_r.height(); ++y)
	{
		yuv_to_linear_rgb_row(table, inout_y_r.get_row(y), inout_u_g.get_row(y), inout_v_b.get_row(y), inout_y_r.width());
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_srgb24
//

void color::linear_rgb_to_srgb24_row_c(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		std::uint8_t *px = out_srgb + x * 3;

		px[0] = linear_to_srgb8(in_b[x]);
		px[1] = linear_to_srgb8(in_g[x]);
		px[2] = linear_to_srgb8(in_r[x]);
	}
}

void color::linear_rgb_to_srgb24_row_ssse3(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	__m128 const m255 = _mm_set1_ps(255.0f);

	__m128i const mask1 = _mm_set_epi8(-1, -1, -1, -1, 14, 13, 12, 10, 9, 8, 6, 5, 4, 2, 1, 0);
	__m128i const mask2 = _mm_set_epi8(4, 2, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
	__m128i const mask3 = _mm_set_epi8(-1, -1, -1, -1, -1, -1, -1, -1, 14, 13, 12, 10, 9, 8, 6, 5);
	__m128i const mask4 = _mm_set_epi8(9, 8, 6, 5, 4, 2, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1);
	__m128i const mask5 = _mm_set_epi8(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 14, 13, 12, 10);
	__m128i const mask6 = _mm_set_epi8(14, 13, 12, 10, 9, 8, 6, 5, 4, 2, 1, 0, -1, -1, -1, -1);

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)15); x += 16)
	{
		__m128i *out = (__m128i*)(out_srgb + x * 3);

		__m128i b1 = linear_to_srgb8(_mm_load_ps(in_b + x));
		__m128i g1 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x)), 8);
		__m128i r1 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x)), 16);
		__m128i p1 = _mm_or_si128(_mm_or_si128(b1, g1), r1);

		__m128i b2 = linear_to_srgb8(_mm_load_ps(in_b + x + 4));
		__m128i g2 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x + 4)), 8);
		__m128i r2 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x + 4)), 16);
		__m128i p2 = _mm_or_si128(_mm_or_si128(b2, g2), r2);

		_mm_store_si128(out, _mm_or_si128(_mm_shuffle_epi8(p1, mask1), _mm_shuffle_epi8(p2, mask2)));

		__m128i b3 = linear_to_srgb8(_mm_load_ps(in_b + x + 8));
		__m128i g3 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x + 8)), 8);
		__m128i r3 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x + 8)), 16);
		__m128i p3 = _mm_or_si128(_mm_or_si128(b3, g3), r3);

		_mm_store_si128(out + 1, _mm_or_si128(_mm_shuffle_epi8(p2, mask3), _mm_shuffle_epi8(p3, mask4)));

		__m128i b4 = linear_to_srgb8(_mm_load_ps(in_b + x + 12));
		__m128i g4 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x + 12)), 8);
		__m128i r4 = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x + 12)), 16);
		__m128i p4 = _mm_or_si128(_mm_or_si128(b4, g4), r4);

		_mm_store_si128(out + 2, _mm_or_si128(_mm_shuffle_epi8(p3, mask5), _mm_shuffle_epi8(p4, mask6)));
	}

	if(x < width)
	{
		linear_rgb_to_srgb24_row_c(in_r + x, in_g + x, in_b + x, out_srgb + x * 3, width - x);
	}
}

static void (*linear_rgb_to_srgb24_row)(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, color::dimension_type width) = color::linear_rgb_to_srgb24_row_c;

void color::linear_rgb_to_srgb24(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<std::uint8_t> const &out_srgb)
{
	for(dimension_type y = 0; y < in_r.height(); ++y)
	{
		linear_rgb_to_srgb24_row(in_r.get_row(y), in_g.get_row(y), in_b.get_row(y), out_srgb.get_row(y), out_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_srgb32
//

void color::linear_rgb_to_srgb32_row_c(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		std::uint8_t *px = out_srgb + x * 4;

		px[0] = linear_to_srgb8(in_b[x]);
		px[1] = linear_to_srgb8(in_g[x]);
		px[2] = linear_to_srgb8(in_r[x]);
		px[3] = 0xFF;
	}
}

void color::linear_rgb_to_srgb32_row_sse2(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, dimension_type width)
{
	__m128i const malpha = _mm_set1_epi32(std::int32_t(std::uint32_t(0xFF) << 24));

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128i b = linear_to_srgb8(_mm_load_ps(in_b + x));
		__m128i g = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x)), 8);
		__m128i r = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x)), 16);

		_mm_store_si128((__m128i*)(out_srgb + x * 4), _mm_or_si128(_mm_or_si128(b, g), _mm_or_si128(r, malpha)));
	}

	if(x < width)
	{
		linear_rgb_to_srgb32_row_c(in_r + x, in_g + x, in_b + x, out_srgb + x * 4, width - x);
	}
}

static void (*linear_rgb_to_srgb32_row)(float const* const in_r, float const* const in_g, float const* const in_b, std::uint8_t* const out_srgb, color::dimension_type width) = color::linear_rgb_to_srgb32_row_c;

void color::linear_rgb_to_srgb32(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<std::uint8_t> const &out_srgb)
{
	for(dimension_type y = 0; y < in_r.height(); ++y)
	{
		linear_rgb_to_srgb32_row(in_r.get_row(y), in_g.get_row(y), in_b.get_row(y), out_srgb.get_row(y), out_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// linear_rgba_to_srgb32
//

void color::linear_rgba_to_srgb32_row_c(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		std::uint8_t *px = out_srgb + x * 4;

		px[0] = linear_to_srgb8(in_b[x]);
		px[1] = linear_to_srgb8(in_g[x]);
		px[2] = linear_to_srgb8(in_r[x]);
		px[3] = std::uint8_t(in_a[x] * 255.0f + 0.5f);
	}
}

void color::linear_rgba_to_srgb32_row_sse2(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, dimension_type width)
{
	__m128 const m255 = _mm_set1_ps(255.0f);

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128i b = linear_to_srgb8(_mm_load_ps(in_b + x));
		__m128i g = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_g + x)), 8);
		__m128i r = _mm_slli_epi32(linear_to_srgb8(_mm_load_ps(in_r + x)), 16);
		__m128i a = _mm_slli_epi32(_mm_cvtps_epi32(_mm_mul_ps(_mm_load_ps(in_a + x), m255)), 24);

		_mm_store_si128((__m128i*)(out_srgb + x * 4), _mm_or_si128(_mm_or_si128(b, g), _mm_or_si128(r, a)));
	}

	if(x < width)
	{
		linear_rgba_to_srgb32_row_c(in_r + x, in_g + x, in_b + x, in_a + x, out_srgb + x * 4, width - x);
	}
}

static void (*linear_rgba_to_srgb32_row)(float const* const in_r, float const* const in_g, float const* const in_b, float const* const in_a, std::uint8_t* const out_srgb, color::dimension_type width) = color::linear_rgba_to_srgb32_row_c;

void color::linear_rgba_to_srgb32(bitmap<float const> const &in_r, bitmap<float const> const &in_g, bitmap<float const> const &in_b, bitmap<float const> const &in_a, bitmap<std::uint8_t> const &out_srgb)
{
	for(dimension_type y = 0; y < in_r.height(); ++y)
	{
		linear_rgba_to_srgb32_row(in_r.get_row(y), in_g.get_row(y), in_b.get_row(y), in_a.get_row(y), out_srgb.get_row(y), out_srgb.width());
	}
}

///////////////////////////////////////////////////////////
// yuv_to_yv12
//

void color::yuv_to_yv12_row_c(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width)
{
	for(color::dimension_type x = 0; x < (width - 1); x += 2)
	{
		out_y2[x] = std::uint8_t(in_y1[x] * table.ymul + table.yadd);
		out_y2[x + 1] = std::uint8_t(in_y1[x + 1] * table.ymul + table.yadd);
		out_y1[x] = std::uint8_t(in_y2[x] * table.ymul + table.yadd);
		out_y1[x + 1] = std::uint8_t(in_y2[x + 1] * table.ymul + table.yadd);
		out_cb[x / 2] = std::uint8_t(in_u[x / 2] * table.cbmul + table.cadd);
		out_cr[x / 2] = std::uint8_t(in_v[x / 2] * table.crmul + table.cadd);
	}
}

inline void yuv_to_yv12_cluster_sse2(std::uint8_t* const out, float const* const in, __m128 mul, __m128 add)
{
	__m128i a = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in), mul), add));
	__m128i b = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in + 4), mul), add));
	__m128i c = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in + 8), mul), add));
	__m128i d = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in + 12), mul), add));

	_mm_store_si128((__m128i*)out, _mm_packus_epi16(_mm_packs_epi32(a, b), _mm_packs_epi32(c, d)));
}

void color::yuv_to_yv12_row_sse2(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, dimension_type width)
{
	__m128 const yadd = table.mm_yadd, ymul = table.mm_ymul, cadd = table.mm_cadd, cbmul = table.mm_cbmul, crmul = table.mm_crmul;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)31); x += 32)
	{
		yuv_to_yv12_cluster_sse2(out_y2 + x, in_y1 + x, ymul, yadd);
		yuv_to_yv12_cluster_sse2(out_y2 + x + 16, in_y1 + x + 16, ymul, yadd);

		yuv_to_yv12_cluster_sse2(out_y1 + x, in_y2 + x, ymul, yadd);
		yuv_to_yv12_cluster_sse2(out_y1 + x + 16, in_y2 + x + 16, ymul, yadd);

		yuv_to_yv12_cluster_sse2(out_cb + x / 2, in_u + x / 2, cbmul, cadd);
		yuv_to_yv12_cluster_sse2(out_cr + x / 2, in_v + x / 2, crmul, cadd);
	}

	if(x < width)
	{
		yuv_to_yv12_row_c(table, in_y1 + x, in_y2 + x, in_u + x / 2, in_v + x / 2, out_y1 + x, out_y2 + x, out_cb + x / 2, out_cr + x / 2, width - x);
	}
}

static void (*yuv_to_yv12_row)(color::yuv_table const &table, float const* const in_y1, float const* const in_y2, float const* const in_u, float const* const in_v, std::uint8_t* const out_y1, std::uint8_t* const out_y2, std::uint8_t* const out_cb, std::uint8_t* const out_cr, color::dimension_type width) = color::yuv_to_yv12_row_c;

void color::yuv_to_yv12(yuv_table const &table, bitmap<float const> const &in_y, bitmap<float const> const &in_u, bitmap<float const> const &in_v, bitmap<std::uint8_t> const &out_y, bitmap<std::uint8_t> const &out_cb, bitmap<std::uint8_t> const &out_cr)
{
	for(dimension_type y = 0; y < in_y.height(); y += 2)
	{
		dimension_type invy = in_y.height() - y - 2;
		yuv_to_yv12_row(table, in_y.get_row(y), in_y.get_row(y + 1), in_u.get_row(y / 2), in_v.get_row(y / 2), out_y.get_row(invy), out_y.get_row(invy + 1), out_cb.get_row(invy / 2), out_cr.get_row(invy / 2), in_y.width());
	}
}

///////////////////////////////////////////////////////////
// yuv_to_yuy2
//

void color::yuv_to_yuy2_row_c(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width)
{
	for(color::dimension_type x = 0; x < (width - 1); x += 2)
	{
		std::uint8_t* const px = out_yuy2 + x * 2;

		px[0] = std::uint8_t(in_y[x] * table.ymul + table.yadd);
		px[1] = std::uint8_t(in_u[x / 2] * table.cbmul + table.cadd);
		px[2] = std::uint8_t(in_y[x + 1] * table.ymul + table.yadd);
		px[3] = std::uint8_t(in_v[x / 2] * table.crmul + table.cadd);
	}
}

void color::yuv_to_yuy2_row_sse2(yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, dimension_type width)
{
	__m128 const yadd = table.mm_yadd, ymul = table.mm_ymul, cadd = table.mm_cadd, cbmul = table.mm_cbmul, crmul = table.mm_crmul;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)7); x += 8)
	{
		__m128i ya = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in_y + x), ymul), yadd));
		__m128i yb = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in_y + x + 4), ymul), yadd));

		__m128i y = _mm_packs_epi32(ya, yb);
		__m128i cb = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in_u + x / 2), cbmul), cadd));
		__m128i cr = _mm_cvtps_epi32(_mm_add_ps(_mm_mul_ps(_mm_load_ps(in_v + x / 2), crmul), cadd));

		__m128i px = _mm_or_si128(_mm_or_si128(y, _mm_slli_epi32(cb, 8)), _mm_slli_epi32(cr, 24));

		_mm_store_si128((__m128i*)(out_yuy2 + x * 2), px);
	}

	if(x < width)
	{
		yuv_to_yuy2_row_c(table, in_y + x, in_u + x / 2, in_v + x / 2, out_yuy2 + x * 2, width - x);
	}
}

static void (*yuv_to_yuy2_row)(color::yuv_table const &table, float const* const in_y, float const* const in_u, float const* const in_v, std::uint8_t* const out_yuy2, color::dimension_type width) = color::yuv_to_yuy2_row_c;

void color::yuv_to_yuy2(yuv_table const &table, bitmap<float const> const &in_y, bitmap<float const> const &in_u, bitmap<float const> const &in_v, bitmap<std::uint8_t> const &out_yuy2)
{
	for(dimension_type y = 0; y < in_y.height(); ++y)
	{
		dimension_type invy = in_y.height() - y - 1;
		yuv_to_yuy2_row(table, in_y.get_row(y), in_u.get_row(y), in_v.get_row(y), out_yuy2.get_row(invy), in_y.width());
	}
}

///////////////////////////////////////////////////////////
// linear_rgb_to_yuv
//

void color::linear_rgb_to_yuv_row_c(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width)
{
	for(color::dimension_type x = 0; x < width; ++x)
	{
		float r = linear_to_srgb(inout_r_y[x]);
		float g = linear_to_srgb(inout_g_u[x]);
		float b = linear_to_srgb(inout_b_v[x]);

		float cy = r * table.rscale + g * table.gscale + b * table.bscale;
		float cu = b - cy;
		float cv = r - cy;

		inout_r_y[x] = cy;
		inout_g_u[x] = cu;
		inout_b_v[x] = cv;
	}
}

void color::linear_rgb_to_yuv_row_sse2(yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, dimension_type width)
{
	__m128 const rscale = table.mm_rscale, gscale = table.mm_gscale, bscale = table.mm_bscale;

	color::dimension_type x = 0;

	for(; x < (width & ~(dimension_type)3); x += 4)
	{
		__m128 r = linear_to_srgb(_mm_load_ps(inout_r_y + x));
		__m128 g = linear_to_srgb(_mm_load_ps(inout_g_u + x));
		__m128 b = linear_to_srgb(_mm_load_ps(inout_b_v + x));

		__m128 cy = _mm_add_ps(_mm_add_ps(_mm_mul_ps(r, rscale), _mm_mul_ps(g, gscale)), _mm_mul_ps(b, bscale));
		__m128 cu = _mm_sub_ps(b, cy);
		__m128 cv = _mm_sub_ps(r, cy);

		_mm_store_ps(inout_r_y + x, cy);
		_mm_store_ps(inout_g_u + x, cu);
		_mm_store_ps(inout_b_v + x, cv);
	}

	if(x < width)
	{
		linear_rgb_to_yuv_row_c(table, inout_r_y + x, inout_g_u + x, inout_b_v + x, width - x);
	}
}

static void (*linear_rgb_to_yuv_row)(color::yuv_table const &table, float* const inout_r_y, float* const inout_g_u, float* const inout_b_v, color::dimension_type width) = color::linear_rgb_to_yuv_row_c;

void color::linear_rgb_to_yuv(yuv_table const &table, bitmap<float> const &inout_r_y, bitmap<float> const &inout_g_u, bitmap<float> const &inout_b_v)
{
	for(dimension_type y = 0; y < inout_r_y.height(); ++y)
	{
		linear_rgb_to_yuv_row(table, inout_r_y.get_row(y), inout_g_u.get_row(y), inout_b_v.get_row(y), inout_r_y.width());
	}
}

///////////////////////////////////////////////////////////

void color::dither_linear_rgb_to_srgb(bitmap<float> const &in_r, bitmap<float> const &in_g, bitmap<float> const &in_b, bitmap<std::uint8_t> const &out_srgb)
{
	int l1 = 1;
	int r1 = -1;

	for(color::dimension_type y = 0; y < out_srgb.height(); ++y)
	{
		l1 = -l1;
		r1 = -r1;

		float* const row_r = in_r.get_row(y);
		float* const row_g = in_g.get_row(y);
		float* const row_b = in_b.get_row(y);

		for(color::dimension_type xx = 0; xx < out_srgb.width(); ++xx)
		{
			color::dimension_type x = (y & 1) ? (out_srgb.width() - xx - 1) : xx;

			float *rerr1 = row_r + x;
			float *rerr2 = rerr1 + in_r.row_size();
			float *gerr1 = row_g + x;
			float *gerr2 = gerr1 + in_g.row_size();
			float *berr1 = row_b + x;
			float *berr2 = berr1 + in_b.row_size();

			float oldr = std::max(0.0f, std::min(row_r[x], 1.0f));
			float newr = linear_to_srgb(oldr) * 255.0f + 0.5f;
			float quantr = oldr - srgb_to_linear(std::floor(newr) / 255.0f);

			float oldg = std::max(0.0f, std::min(row_g[x], 1.0f));
			float newg = linear_to_srgb(oldg) * 255.0f + 0.5f;
			float quantg = oldg - srgb_to_linear(std::floor(newg) / 255.0f);

			float oldb = std::max(0.0f, std::min(row_b[x], 1.0f));
			float newb = linear_to_srgb(oldb) * 255.0f + 0.5f;
			float quantb = oldb - srgb_to_linear(std::floor(newb) / 255.0f);

			if((xx + 1) < out_srgb.width())
			{
				rerr1[r1] += 7.0f / 16.0f * quantr;
				gerr1[r1] += 7.0f / 16.0f * quantg;
				berr1[r1] += 7.0f / 16.0f * quantb;
			}

			if((y + 1) < out_srgb.height())
			{
				if(xx > 0)
				{
					rerr2[l1] += 4.0f / 16.0f * quantr;
					gerr2[l1] += 4.0f / 16.0f * quantg;
					berr2[l1] += 4.0f / 16.0f * quantb;
				}

				rerr2[0] += 5.0f / 16.0f * quantr;
				gerr2[0] += 5.0f / 16.0f * quantg;
				berr2[0] += 5.0f / 16.0f * quantb;
			}

			std::uint8_t *out = out_srgb.get_row(y) + x * out_srgb.pixel_size();

			out[0] = (std::uint8_t)newb;
			out[1] = (std::uint8_t)newg;
			out[2] = (std::uint8_t)newr;

			if(out_srgb.pixel_size() == 4)
			{
				out[3] = 0xFF;
			}
		}
	}
}

void color::dither_linear_rgb_to_srgb32(bitmap<float> const &in_r, bitmap<float> const &in_g, bitmap<float> const &in_b, bitmap<float> const &in_a, bitmap<std::uint8_t> const &out_srgb)
{
	int l1 = 1;
	int r1 = -1;

	for(color::dimension_type y = 0; y < out_srgb.height(); ++y)
	{
		l1 = -l1;
		r1 = -r1;

		float* const row_r = in_r.get_row(y);
		float* const row_g = in_g.get_row(y);
		float* const row_b = in_b.get_row(y);
		float* const row_a = in_a.get_row(y);

		for(color::dimension_type xx = 0; xx < out_srgb.width(); ++xx)
		{
			color::dimension_type x = (y & 1) ? (out_srgb.width() - xx - 1) : xx;

			float *rerr1 = row_r + x;
			float *rerr2 = rerr1 + in_r.row_size();
			float *gerr1 = row_g + x;
			float *gerr2 = gerr1 + in_g.row_size();
			float *berr1 = row_b + x;
			float *berr2 = berr1 + in_b.row_size();
			float *aerr1 = row_a + x;
			float *aerr2 = aerr1 + in_a.row_size();

			float oldr = std::max(0.0f, std::min(row_r[x], 1.0f));
			float newr = linear_to_srgb(oldr) * 255.0f + 0.5f;
			float quantr = oldr - srgb_to_linear(std::floor(newr) / 255.0f);

			float oldg = std::max(0.0f, std::min(row_g[x], 1.0f));
			float newg = linear_to_srgb(oldg) * 255.0f + 0.5f;
			float quantg = oldg - srgb_to_linear(std::floor(newg) / 255.0f);

			float oldb = std::max(0.0f, std::min(row_b[x], 1.0f));
			float newb = linear_to_srgb(oldb) * 255.0f + 0.5f;
			float quantb = oldb - srgb_to_linear(std::floor(newb) / 255.0f);

			float olda = std::max(0.0f, std::min(row_a[x], 1.0f));
			float newa = olda * 255.0f + 0.5f;
			float quanta = olda - (std::floor(newa) / 255.0f);

			if((xx + 1) < out_srgb.width())
			{
				rerr1[r1] += 7.0f / 16.0f * quantr;
				gerr1[r1] += 7.0f / 16.0f * quantg;
				berr1[r1] += 7.0f / 16.0f * quantb;
				aerr1[r1] += 7.0f / 16.0f * quanta;
			}

			if((y + 1) < out_srgb.height())
			{
				if(xx > 0)
				{
					rerr2[l1] += 4.0f / 16.0f * quantr;
					gerr2[l1] += 4.0f / 16.0f * quantg;
					berr2[l1] += 4.0f / 16.0f * quantb;
					aerr2[l1] += 4.0f / 16.0f * quanta;
				}

				rerr2[0] += 5.0f / 16.0f * quantr;
				gerr2[0] += 5.0f / 16.0f * quantg;
				berr2[0] += 5.0f / 16.0f * quantb;
				aerr2[0] += 5.0f / 16.0f * quanta;
			}

			std::uint8_t *out = out_srgb.get_row(y) + x * out_srgb.pixel_size();

			out[0] = (std::uint8_t)newb;
			out[1] = (std::uint8_t)newg;
			out[2] = (std::uint8_t)newr;
			out[3] = (std::uint8_t)newa;
		}
	}
}

color::feature_flags color::get_features()
{
	feature_flags ret = 0;

	int info[4];
	__cpuid(info, 1);

#if _M_IX86_FP >= 1 || defined(_M_X64)
	ret |= sse;
#else
	if(info[3] & 0x2000000)
	{
		ret |= sse;
	}
#endif

#if _M_IX86_FP >= 2 || defined(_M_X64)
	ret |= sse2;
#else
	if(info[3] & 0x4000000)
	{
		ret |= sse2;
	}
#endif

	if(info[2] & 1)
	{
		ret |= sse3;
	}

	if(info[2] & 0x200)
	{
		ret |= ssse3;
	}

	if(info[2] & 0x080000)
	{
		ret |= sse41;
	}

	if(info[2] & 0x100000)
	{
		ret |= sse42;
	}

	if((info[2] & 0x18000000) == 0x18000000 && (_xgetbv(_XCR_XFEATURE_ENABLED_MASK) & 6) == 6)
	{
		ret |= avx;

		if(info[2] & 0x1000)
		{
			__cpuidex(info, 7, 0);

			if(info[1] & 0x20)
			{
				ret |= avx2_fma3;
			}
		}
	}

	__cpuid(info, 0x80000000);

	if(info[0] >= 0x80000001)
	{
		__cpuid(info, 0x80000001);

		if(info[2] & 0x10000)
		{
			ret |= fma4;
		}
	}

	return ret;
}

void color::init()
{
#if 1
	static bool is_initialized = false;

	if(is_initialized)
	{
		return;
	}

	feature_flags features = get_features();

	if(features & sse2)
	{
		srgb32_to_linear_rgb_row = srgb32_to_linear_rgb_row_sse2;
		srgb32_to_linear_rgba_row = srgb32_to_linear_rgba_row_sse2;
		yv12_to_yuv_row = yv12_to_yuv_row_sse2;
		yuy2_to_yuv_row = yuy2_to_yuv_row_sse2;
		yuv_to_linear_rgb_row = yuv_to_linear_rgb_row_sse2;

		linear_rgb_to_srgb32_row = linear_rgb_to_srgb32_row_sse2;
		linear_rgba_to_srgb32_row = linear_rgba_to_srgb32_row_sse2;
		yuv_to_yv12_row = yuv_to_yv12_row_sse2;
		yuv_to_yuy2_row = yuv_to_yuy2_row_sse2;
		linear_rgb_to_yuv_row = linear_rgb_to_yuv_row_sse2;
	}

	if(features & ssse3)
	{
		srgb24_to_linear_rgb_row = srgb24_to_linear_rgb_row_ssse3;
		linear_rgb_to_srgb24_row = linear_rgb_to_srgb24_row_ssse3;
	}

	if(features & avx)
	{
		srgb24_to_linear_rgb_row = srgb24_to_linear_rgb_row_avx;
		srgb32_to_linear_rgb_row = srgb32_to_linear_rgb_row_avx;
		srgb32_to_linear_rgba_row = srgb32_to_linear_rgba_row_avx;
		yv12_to_yuv_row = yv12_to_yuv_row_avx;
		yuy2_to_yuv_row = yuy2_to_yuv_row_avx;
		yuv_to_linear_rgb_row = yuv_to_linear_rgb_row_avx;

		linear_rgb_to_srgb24_row = linear_rgb_to_srgb24_row_avx;
		linear_rgb_to_srgb32_row = linear_rgb_to_srgb32_row_avx;
		linear_rgba_to_srgb32_row = linear_rgba_to_srgb32_row_avx;
		yuv_to_yv12_row = yuv_to_yv12_row_avx;
		yuv_to_yuy2_row = yuv_to_yuy2_row_avx;
		linear_rgb_to_yuv_row = linear_rgb_to_yuv_row_avx;
	}

	if(features & fma4)
	{
		srgb24_to_linear_rgb_row = srgb24_to_linear_rgb_row_fma4;
		srgb32_to_linear_rgb_row = srgb32_to_linear_rgb_row_fma4;
		srgb32_to_linear_rgba_row = srgb32_to_linear_rgba_row_fma4;
		yv12_to_yuv_row = yv12_to_yuv_row_fma4;
		yuy2_to_yuv_row = yuy2_to_yuv_row_fma4;
		yuv_to_linear_rgb_row = yuv_to_linear_rgb_row_fma4;

		linear_rgb_to_srgb24_row = linear_rgb_to_srgb24_row_fma4;
		linear_rgb_to_srgb32_row = linear_rgb_to_srgb32_row_fma4;
		linear_rgba_to_srgb32_row = linear_rgba_to_srgb32_row_fma4;
		yuv_to_yv12_row = yuv_to_yv12_row_fma4;
		yuv_to_yuy2_row = yuv_to_yuy2_row_fma4;
		linear_rgb_to_yuv_row = linear_rgb_to_yuv_row_fma4;
	}

	is_initialized = true;
#endif
}
