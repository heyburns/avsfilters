/*
	Resampler
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdafx.h"
#include "color.hpp"
#include "resample.hpp"

static const double PI = 3.14159265358979323846;
static const double RSQRT2	= 0.707106781186547524401; // 1/sqrt(2)

double resample::bilinear_kernel::weight(double value) const
{
	value = std::abs(value);
	return (value < 1.0) ? (1.0 - value) : 0.0;
}

resample::bicubic_kernel::bicubic_kernel(boost::optional<double> ob, boost::optional<double> oc)
{
	double b = get_optional_value_or(ob, 1.0 / 3.0);
	double c = get_optional_value_or(oc, 1.0 / 3.0);

	m_p0 = (   6.0 -  2.0 * b            ) / 6.0;
	m_p2 = ( -18.0 + 12.0 * b +  6.0 * c ) / 6.0;
	m_p3 = (  12.0 -  9.0 * b -  6.0 * c ) / 6.0;
	m_q0 = (          8.0 * b + 24.0 * c ) / 6.0;
	m_q1 = (       - 12.0 * b - 48.0 * c ) / 6.0;
	m_q2 = (          6.0 * b + 30.0 * c ) / 6.0;
	m_q3 = (       -        b -  6.0 * c ) / 6.0;
}

double resample::bicubic_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value < 1.0)
	{
		return m_p0 + value * value * (m_p2 + value * m_p3);
	}

	if(value < 2.0)
	{
		return m_q0 + value * (m_q1 + value * (m_q2 + value * m_q3));
	}

	return 0.0;
}

resample::catmull_rom_kernel::catmull_rom_kernel()
	: bicubic_kernel(0.0, 0.5)
{
}

resample::mitchell_netravali_kernel::mitchell_netravali_kernel()
	: bicubic_kernel(1.0 / 3.0, 1.0 / 3.0)
{
}

resample::softcubic_kernel::softcubic_kernel(boost::optional<double> softness)
	: bicubic_kernel(get_optional_value_or(softness, 100.0) * 0.01, 1.0 - get_optional_value_or(softness, 100.0) * 0.01)
{
}

resample::hermite_kernel::hermite_kernel()
	: bicubic_kernel(0.0, 0.0)
{
}

resample::robidoux_kernel::robidoux_kernel()
	: bicubic_kernel(0.3782, 0.3109)
{
}

resample::lanczos_kernel::lanczos_kernel(boost::optional<double> taps)
	: m_taps(get_optional_value_or(taps, 2.0))
{
}

double resample::lanczos_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value == 0.0)
	{
		return 1.0;
	}

	if(value >= m_taps)
	{
		return 0.0;
	}

	value *= PI;
	return m_taps * std::sin(value) * std::sin(value / m_taps) / (value * value);
}

resample::blackman_kernel::blackman_kernel(boost::optional<double> taps)
	: m_taps(std::max(1.0, std::min(get_optional_value_or(taps, 2.0), 100.0)))
{
}

double resample::blackman_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value == 0.0)
	{
		return 1.0;
	}

	if(value >= m_taps)
	{
		return 0.0;
	}

	value *= PI;

	return (std::sin(value) / value) * (0.42 + 0.5 * std::cos(value / m_taps) + 0.08 * std::cos(2.0 * value / m_taps));
}

double resample::spline16_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value < 1.0)
	{
		return (( value - 9.0 / 5.0 ) * value - 1.0 / 5.0 ) * value + 1.0;
	}

	if(value < 2.0)
	{
		return (( -1.0 / 3.0 * (value - 1.0) + 4.0 / 5.0 ) * (value - 1.0) - 7.0 / 15.0 ) * (value - 1.0);
	}

	return 0.0;
}

double resample::spline36_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value < 1.0)
	{
		return (( 13.0 / 11.0 * (value      ) - 453.0 / 209.0 ) * (value      ) -   3.0 / 209.0) * (value      ) + 1.0;
	}

	if(value < 2.0)
	{
		return (( -6.0 / 11.0 * (value - 1.0) + 270.0 / 209.0 ) * (value - 1.0) - 156.0 / 209.0) * (value - 1.0);
	}

	if(value < 3.0)
	{
		return ((  1.0 / 11.0 * (value - 2.0) -  45.0 / 209.0 ) * (value - 2.0) +  26.0 / 209.0) * (value - 2.0);
	}

	return 0.0;
}

double resample::spline64_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value < 1.0)
	{
		return (( 49.0 / 41.0 * (value      ) - 6387.0 / 2911.0) * (value      ) -    3.0 / 2911.0) * (value      ) + 1.0;
	}

	if(value < 2.0)
	{
		return ((-24.0 / 41.0 * (value - 1.0) + 4032.0 / 2911.0) * (value - 1.0) - 2328.0 / 2911.0) * (value - 1.0);
	}

	if(value < 3.0)
	{
		return ((  6.0 / 41.0 * (value - 2.0) - 1008.0 / 2911.0) * (value - 2.0) +  582.0 / 2911.0) * (value - 2.0);
	}

	if(value < 4.0)
	{
		return ((- 1.0 / 41.0 * (value - 3.0) +  168.0 / 2911.0) * (value - 3.0) -   97.0 / 2911.0) * (value - 3.0);
	}

	return 0.0;
}

resample::gaussian_kernel::gaussian_kernel(boost::optional<double> p)
	: m_p(std::max(0.1, std::min(get_optional_value_or(p, 30.0), 100.0)))
{
}

double resample::gaussian_kernel::weight(double value) const
{
	value = std::abs(value);
	return std::pow(2.0, -(m_p * 0.1) * value * value);
}

resample::sinc_kernel::sinc_kernel(boost::optional<double> taps)
	: m_taps(std::max(1.0, std::min(get_optional_value_or(taps, 2.0), 20.0)))
{
}

double resample::sinc_kernel::weight(double value) const
{
	value = std::abs(value);

	if(value > 0.0)
	{
		value *= PI;
		return std::sin(value) / value;
	}

	return 1.0;
}

void resample::resampler_1d::reset(dimension_type source_length, double source_crop_offset, double source_crop_length, dimension_type dest_length, double blur, kernel const &filter)
{
	m_srclen = source_length;
	m_dstlen = dest_length;
	m_program.clear();

	if(std::abs(blur) == 0.0)
	{
		blur = 1.0;
	}

	double const factor = dest_length / source_crop_length;
	double scale = (blur > 0.0) ? (std::min(factor, 1.0) / blur) : (1.0 / std::abs(blur));
	double support = filter.support() / scale;

	for(dimension_type di = 0; di < m_dstlen; ++di)
	{
		double center = (di + 0.5) / factor;

		dimension_type srcfirst = (dimension_type)std::max(0.0, std::min(source_crop_offset + center - support + 0.5, (double)source_length));
		dimension_type srclast = (dimension_type)std::max(0.0, std::min(source_crop_offset + center + support + 0.5, (double)source_length));

		assert(srcfirst != srclast);

		instruction pv;

		pv.d = srcfirst;
		m_program.push_back(pv);

		pv.d = srclast;
		m_program.push_back(pv);

		double filterpos = (srcfirst - source_crop_offset - center + 0.5) * scale, totalweight = 0.0;

		for(; srcfirst != srclast; ++srcfirst, filterpos += scale)
		{
			assert(srcfirst < source_length);

			float weight = (float)filter.weight(filterpos);

			pv.f = weight;
			m_program.push_back(pv);

			totalweight += weight;
		}

		pv.f = (totalweight != 0.0) ? (float)(1.0 / totalweight) : 1.0f;
		m_program.push_back(pv);
	}
}

void resample::resampler_1d::resample_horizontal(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	assert(!empty());
	assert(src.height() == dst.height());
	assert(src.width() == source_length());
	assert(dst.width() == dest_length());

	for(dimension_type y = 0; y < src.height(); ++y)
	{
		auto iter = m_program.cbegin();

		float const* const psrc = src.get_row(y);
		float* const pdst = dst.get_row(y);

		for(dimension_type di = 0; di < m_dstlen; ++di)
		{
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			float value = 0.0f;

			do
			{
				assert(srcfirst < source_length());

				value += psrc[srcfirst] * iter->f;
				++iter;
			}
			while(++srcfirst != srclast);

			assert(di < dest_length());

			pdst[di] = value * iter->f;
			++iter;
		}
	}
}

/*
	interleaves 4 smaller rows into 1 larger row.

	12345
	12345
	12345
	12345

	becomes:

	11112222333344445555
*/
inline void interleave(float const *src0, float const *src1, float const *src2, float const *src3, float *dst, std::size_t len)
{
	for(; len >= 4; len -= 4)
	{
		__m128 s0 = _mm_load_ps(src0); src0 += 4;
		__m128 s1 = _mm_load_ps(src1); src1 += 4;
		__m128 s2 = _mm_load_ps(src2); src2 += 4;
		__m128 s3 = _mm_load_ps(src3); src3 += 4;

		__m128 t0 = _mm_unpacklo_ps(s0, s1);
		__m128 t1 = _mm_unpackhi_ps(s0, s1);
		__m128 t2 = _mm_unpacklo_ps(s2, s3);
		__m128 t3 = _mm_unpackhi_ps(s2, s3);

		__m128 d0 = _mm_movelh_ps(t0, t2);
		__m128 d1 = _mm_movehl_ps(t2, t0);
		__m128 d2 = _mm_movelh_ps(t1, t3);
		__m128 d3 = _mm_movehl_ps(t3, t1);
	
		_mm_store_ps(dst, d0);
		_mm_store_ps(dst + 4, d1);
		_mm_store_ps(dst + 8, d2);
		_mm_store_ps(dst + 12, d3); dst += 16;
	}

	while(len--)
	{
		*(dst++) = *(src0++);
		*(dst++) = *(src1++);
		*(dst++) = *(src2++);
		*(dst++) = *(src3++);
	}
}

/*
	deinterleaves 1 larger row into 4 smaller rows

	11112222333344445555

	becomes:

	12345
	12345
	12345
	12345
*/
inline void deinterleave(float const *src, float *dst0, float *dst1, float *dst2, float *dst3, std::size_t len)
{
	for(; len > 4; len -= 4)
	{
		__m128 s0 = _mm_load_ps(src);
		__m128 s1 = _mm_load_ps(src + 4);
		__m128 s2 = _mm_load_ps(src + 8);
		__m128 s3 = _mm_load_ps(src + 12); src += 16;

		__m128 t0 = _mm_unpacklo_ps(s0, s1);
		__m128 t1 = _mm_unpackhi_ps(s0, s1);
		__m128 t2 = _mm_unpacklo_ps(s2, s3);
		__m128 t3 = _mm_unpackhi_ps(s2, s3);

		__m128 d0 = _mm_movelh_ps(t0, t2);
		__m128 d1 = _mm_movehl_ps(t2, t0);
		__m128 d2 = _mm_movelh_ps(t1, t3);
		__m128 d3 = _mm_movehl_ps(t3, t1);
	
		_mm_stream_ps(dst0, d0); dst0 += 4;
		_mm_stream_ps(dst1, d1); dst1 += 4;
		_mm_stream_ps(dst2, d2); dst2 += 4;
		_mm_stream_ps(dst3, d3); dst3 += 4;
	}

	while(len--)
	{
		*(dst0++) = *(src++);
		*(dst1++) = *(src++);
		*(dst2++) = *(src++);
		*(dst3++) = *(src++);
	}
}

void resample::resampler_1d::resample_horizontal_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst, alloc::bitmap<float> const &tmp1, alloc::bitmap<float> const &tmp2) const
{
	/*
		Four src rows at a time are interleaved into a single larger row in tmp1.  tmp1 is then
		resampled into tmp2, which is then de-interleaved into dst.
	*/

	assert(!empty());
	assert(src.height() == dst.height());
	assert(src.width() == source_length());
	assert(dst.width() == dest_length());
	assert(tmp1.width() == src.width() * 4);
	assert(tmp1.height() == 2);
	assert(tmp2.width() == dst.width() * 4);
	assert(tmp2.height() == 2);

	for(dimension_type y = 0; y < (src.height() & ~(dimension_type)7); y += 8)
	{
		// interleave src into srctmp.
		
		interleave(src.get_row(y), src.get_row(y + 1), src.get_row(y + 2), src.get_row(y + 3), tmp1.get_row(0), src.width());
		interleave(src.get_row(y + 4), src.get_row(y + 5), src.get_row(y + 6), src.get_row(y + 7), tmp1.get_row(1), src.width());

		// resample srctmp into dsttmp

		auto iter = m_program.cbegin();

		for(dimension_type x = 0; x < m_dstlen; ++x)
		{
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);
			
			__m128 value1 = _mm_setzero_ps();
			__m128 value2 = _mm_setzero_ps();

			do
			{
				assert(srcfirst < source_length());

				__m128 weight = _mm_set1_ps(iter->f);
				
				value1 = _mm_add_ps(value1, _mm_mul_ps(_mm_load_ps(tmp1.get_pixel(srcfirst * 4, 0)), weight));
				value2 = _mm_add_ps(value2, _mm_mul_ps(_mm_load_ps(tmp1.get_pixel(srcfirst * 4, 1)), weight));
				++iter;
			}
			while(++srcfirst != srclast);

			assert(x < dest_length());

			__m128 weight = _mm_set1_ps(iter->f);
			
			_mm_store_ps(tmp2.get_pixel(x * 4, 0), _mm_mul_ps(value1, weight));
			_mm_store_ps(tmp2.get_pixel(x * 4, 1), _mm_mul_ps(value2, weight));
			++iter;
		}

		// de-interleave dsttmp into dst.
		
		deinterleave(tmp2.get_row(0), dst.get_row(y), dst.get_row(y + 1), dst.get_row(y + 2), dst.get_row(y + 3), dst.width());
		deinterleave(tmp2.get_row(1), dst.get_row(y + 4), dst.get_row(y + 5), dst.get_row(y + 6), dst.get_row(y + 7), dst.width());
	}

	for(dimension_type y = src.height() & ~(dimension_type)7; y < src.height(); ++y)
	{
		auto iter = m_program.cbegin();

		float const* const psrc = src.get_row(y);
		float* const pdst = dst.get_row(y);

		for(dimension_type x = 0; x < m_dstlen; ++x)
		{
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			float value = 0.0f;

			for(; srcfirst != srclast; ++srcfirst, ++iter)
			{
				assert(srcfirst < source_length());
				value += psrc[srcfirst] * iter->f;
			}

			assert(x < dest_length());

			pdst[x] = value * iter->f;
			++iter;
		}
	}
	
	_mm_sfence(); // ensure streamed values are flushed.
}

void resample::resampler_1d::resample_vertical(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	// note: pixel positions along the Y axis are flipped, for src_top.

	assert(!empty());
	assert(src.width() == dst.width());
	assert(src.height() == source_length());
	assert(dst.height() == dest_length());

	for(dimension_type x = 0; x < src.width(); ++x)
	{
		auto iter = m_program.cbegin();

		for(dimension_type di = 0; di < m_dstlen; ++di)
		{
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			float value = 0.0f;

			for(; srcfirst != srclast; ++srcfirst, ++iter)
			{
				assert(srcfirst < source_length());
				value += src.get_pixel(x, src.height() - srcfirst - 1)[0] * iter->f;
			}

			assert(di < dest_length());

			dst.get_pixel(x, dst.height() - di - 1)[0] = value * iter->f;
			++iter;
		}
	}
}

void resample::resampler_1d::resample_vertical_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	// pixel positions along the Y axis are flipped, or cropping from src_top will crop from bottom.

	assert(!empty());
	assert(src.width() == dst.width());
	assert(src.height() == source_length());
	assert(dst.height() == dest_length());

	auto viter = m_program.cbegin();

	for(dimension_type y = 0; y < dst.height(); ++y)
	{
		auto iter = viter;

		for(dimension_type x = 0; x < (src.width() & ~(dimension_type)15); x += 16)
		{
			iter = viter;
			
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			__m128 value1 = _mm_setzero_ps();
			__m128 value2 = _mm_setzero_ps();
			__m128 value3 = _mm_setzero_ps();
			__m128 value4 = _mm_setzero_ps();
			
			do
			{
				__m128 const weight = _mm_set1_ps(iter->f); ++iter;
				float const* const psrc = src.get_pixel(x, src.height() - srcfirst - 1);

				value1 = _mm_add_ps(value1, _mm_mul_ps(_mm_load_ps(psrc), weight));
				value2 = _mm_add_ps(value2, _mm_mul_ps(_mm_load_ps(psrc + 4), weight));
				value3 = _mm_add_ps(value3, _mm_mul_ps(_mm_load_ps(psrc + 8), weight));
				value4 = _mm_add_ps(value4, _mm_mul_ps(_mm_load_ps(psrc + 12), weight));
			}
			while(++srcfirst != srclast);

			__m128 const weight = _mm_set1_ps(iter->f); ++iter;
			float* const pdst = dst.get_pixel(x, dst.height() - y - 1);

			_mm_stream_ps(pdst, _mm_mul_ps(value1, weight));
			_mm_stream_ps(pdst + 4, _mm_mul_ps(value2, weight));
			_mm_stream_ps(pdst + 8, _mm_mul_ps(value3, weight));
			_mm_stream_ps(pdst + 12, _mm_mul_ps(value4, weight));
		}

		for(dimension_type x = src.width() & ~(dimension_type)15; x < src.width(); ++x)
		{
			iter = viter;
			
			dimension_type srcfirst = iter->d; ++iter;
			dimension_type srclast = iter->d; ++iter;

			assert(srcfirst != srclast);

			float value = 0.0f;

			do
			{
				float weight = iter->f; ++iter;
				float const* const psrc = src.get_pixel(x, src.height() - srcfirst - 1);

				value += psrc[0] * weight;
			}
			while(++srcfirst != srclast);

			float weight = iter->f; ++iter;
			float* const pdst = dst.get_pixel(x, dst.height() - y - 1);

			pdst[0] = value * weight;
		}

		viter = iter;
	}

	_mm_sfence(); // ensure streamed values are flushed.
}

void resample::resampler_2d::reset(resampler_1d const &resampler_x, resampler_1d const &resampler_y)
{
	assert(!resampler_x.empty());
	assert(!resampler_y.empty());

	m_hfilter = &resampler_x;
	m_vfilter = &resampler_y;

	m_tmp.reset(source_width(), dest_height(), 1);
	m_htmp1.reset(source_width() * 4, 2);
	m_htmp2.reset(dest_width() * 4, 2);

#if 1
	// for SSE.

	if(!s_initialized)
	{
		color::feature_flags const flags = color::get_features();

		if(flags & color::avx)
		{
			s_resampler = &resampler_2d::resample_avx;
		}
		else if(flags & color::sse)
		{
			s_resampler = &resampler_2d::resample_sse;
		}

		s_initialized = true;
	}
#endif
}

void resample::resampler_2d::resample(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	(this->*s_resampler)(src, dst);
}

void resample::resampler_2d::resample_c(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	m_vfilter->resample_vertical(src, m_tmp);
	m_hfilter->resample_horizontal(m_tmp, dst);
}

void resample::resampler_2d::resample_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	m_vfilter->resample_vertical_sse(src, m_tmp);
	//m_hfilter->resample_horizontal(m_tmp, dst);
	m_hfilter->resample_horizontal_sse(m_tmp, dst, m_htmp1, m_htmp2);
}

void resample::resampler_2d::resample_avx(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const
{
	m_vfilter->resample_vertical_avx(src, m_tmp);
	//m_hfilter->resample_horizontal(m_tmp, dst);
	m_hfilter->resample_horizontal_sse(m_tmp, dst, m_htmp1, m_htmp2);
}

bool resample::resampler_2d::s_initialized = false;
void (resample::resampler_2d::* resample::resampler_2d::s_resampler)(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const = &resampler_2d::resample_c;
