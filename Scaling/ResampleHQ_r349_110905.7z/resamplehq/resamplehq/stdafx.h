/*
	Precompiled header
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_STDAFX_H
#define INT64_ORG_RESAMPLER_STDAFX_H

#ifdef _MSC_VER
#pragma once
#endif

#define INT64_RESAMPLER_EXPORTS

#include "targetver.hpp"

#include <intrin.h>

#include <cmath>
#include <cstdint>
#include <cstring>
#include <cassert>

#include <tuple>
#include <memory>
#include <algorithm>

#include <boost/optional/optional.hpp>

#include <Windows.h>

#endif
