/*
	Aligned memory allocation
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Caveat:
	This doesn't initialize allocated memory at all, so only POD types work.  It's intended for SSE
	types, so that's ok.
*/

#ifndef INT64_ORG_RESAMPLER_ALLOC_HPP
#define INT64_ORG_RESAMPLER_ALLOC_HPP

#ifdef _MSC_VER
#pragma once
#endif

#include <cassert>
#include <cstddef>
#include <new>
#include <memory>
#include <malloc.h>

namespace alloc
{

///////////////////////////////////////////////////////////
/// general aligned allocator

template<typename T>
inline T* aligned_new(std::size_t count, std::size_t alignment)
{
	void *ret = _aligned_malloc(count * sizeof(T), alignment);

	if(!ret)
	{
		throw std::bad_alloc();
	}

	return (T*)ret;
}

struct aligned_deleter
{
	template<typename T>
	inline void operator()(T *ptr) const { _aligned_free(ptr); }
};

///////////////////////////////////////////////////////////
/// SSE aligned allocator

template<typename T>
inline T* sse_new(std::size_t count)
{
	return aligned_new<T>(count, 64);
}

typedef aligned_deleter sse_deleter;

///////////////////////////////////////////////////////////
/// AVX aligned allocator

template<typename T>
inline T* avx_new(std::size_t count)
{
	return aligned_new<T>(count, 64);
}

typedef aligned_deleter avx_deleter;

///////////////////////////////////////////////////////////
/// SSE/AVX/Cache aligned bitmap storage.

template<typename T>
class bitmap
{
public:
	typedef std::uint_fast32_t dimension_type;
	typedef T value_type;

	inline bitmap(T *buf, dimension_type width, dimension_type height, dimension_type row_size, dimension_type pixel_size)
		: m_buf(buf)
		, m_width(width)
		, m_height(height)
		, m_row_size(row_size)
		, m_pixel_size(pixel_size)
	{
		assert(buf != 0);
		assert(width > 0);
		assert(height > 0);
		assert(row_size >= width);
		assert(pixel_size > 0);
	}

	inline value_type* get() const
	{
		return m_buf;
	}

	inline value_type* get_row(dimension_type y) const
	{
		assert(y < m_height);
		return m_buf + y * m_row_size;
	}

	inline value_type* get_pixel(dimension_type x, dimension_type y) const
	{
		assert(x < m_width);
		return get_row(y) + x;
	}

	inline dimension_type width() const { return m_width; }
	inline dimension_type height() const { return m_height; }
	inline dimension_type row_size() const { return m_row_size; }
	inline dimension_type pixel_size() const { return m_pixel_size; }
	inline dimension_type size() const { return m_row_size * m_height; }

private:
	T* const m_buf;
	dimension_type const m_width, m_height, m_row_size, m_pixel_size;
};

template<typename T>
class bitmap_storage
{
public:
	typedef std::uint_fast32_t dimension_type;
	typedef T value_type;

	inline bitmap_storage()
		: m_width()
		, m_height()
		, m_row_size()
		, m_pixel_size()
	{
	}

	inline bitmap_storage(dimension_type width, dimension_type height, dimension_type pixel_size = 1)
	{
		reset(width, height, pixel_size);
	}

	inline void reset(dimension_type width, dimension_type height, dimension_type pixel_size = 1)
	{
		// align to 32-byte boundaries, for AVX.

		dimension_type const align = 32;
		dimension_type const alignmask = align / sizeof(value_type) - 1;

		assert(width > 0);
		assert(height > 0);
		assert(pixel_size > 0);

		dimension_type row_size = (width * pixel_size + alignmask) & ~(dimension_type)alignmask;

		assert(row_size >= width);

		m_buf = ptr_type(alloc::aligned_new<value_type>(row_size * height, align));
		m_width = width;
		m_height = height;
		m_row_size = row_size;
		m_pixel_size = pixel_size;
	}

	inline value_type* get() const
	{
		assert(!empty());
		return m_buf.get();
	}

	inline value_type* get_row(dimension_type y) const
	{
		assert(!empty());
		assert(y < m_height);
		return m_buf.get() + y * m_row_size;
	}

	inline value_type& get_pixel(dimension_type x, dimension_type y) const
	{
		assert(x < m_width);
		return get_row(y)[x];
	}

	inline dimension_type width() const { return m_width; }
	inline dimension_type height() const { return m_height; }
	inline dimension_type row_size() const { return m_row_size; }
	inline dimension_type pixel_size() const { return m_pixel_size; }
	inline dimension_type size() const { return m_row_size * m_height; }

	inline bool empty() const
	{
		return !m_buf;
	}

	inline operator bitmap<value_type>() const
	{
		assert(!empty());
		return bitmap<value_type>(m_buf.get(), m_width, m_height, m_row_size, m_pixel_size);
	}

	inline operator bitmap<value_type const>() const
	{
		assert(!empty());
		return bitmap<value_type const>(m_buf.get(), m_width, m_height, m_row_size, m_pixel_size);
	}

private:
	typedef std::unique_ptr<value_type[], alloc::aligned_deleter> ptr_type;

	ptr_type m_buf;
	dimension_type m_width, m_height, m_row_size, m_pixel_size;
};

}

#endif
