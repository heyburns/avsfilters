/*
	Resampler
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_RESAMPLE_HPP
#define INT64_ORG_RESAMPLER_RESAMPLE_HPP

#ifdef _MSC_VER
#pragma once
#endif

#include <cassert>
#include <cstdint>
#include <vector>
#include <boost/optional/optional.hpp>
#include "alloc.hpp"

namespace resample
{

struct kernel
{
	virtual ~kernel() {}
	virtual double weight(double distance) const = 0;
	virtual double support() const = 0;
};

struct bilinear_kernel : kernel
{
	double weight(double value) const;
	double support() const { return 1.0; }
};

class bicubic_kernel : public kernel
{
public:
	bicubic_kernel(boost::optional<double> b, boost::optional<double> c);
	double weight(double value) const;
	double support() const { return 2.0; }

private:
  double m_p0, m_p2, m_p3, m_q0, m_q1, m_q2, m_q3;
};

struct catmull_rom_kernel : bicubic_kernel
{
	catmull_rom_kernel();
};

struct mitchell_netravali_kernel : bicubic_kernel
{
	mitchell_netravali_kernel();
};

struct softcubic_kernel : bicubic_kernel
{
	softcubic_kernel(boost::optional<double> softness);
};

struct hermite_kernel : bicubic_kernel
{
	hermite_kernel();
};

struct robidoux_kernel : bicubic_kernel
{
	robidoux_kernel();
};

struct spline16_kernel : kernel
{
	double weight(double value) const;
	double support() const { return 2.0; }
};

struct spline36_kernel : kernel
{
	double weight(double value) const;
	double support() const { return 3.0; }
};

struct spline64_kernel : kernel
{
	double weight(double value) const;
	double support() const { return 4.0; }
};

class lanczos_kernel : public kernel
{
public:
	lanczos_kernel(boost::optional<double> taps);
	double weight(double value) const;
	double support() const { return m_taps; }

private:
	double const m_taps;
};

class blackman_kernel : public kernel
{
public:
	blackman_kernel(boost::optional<double> taps);
	double weight(double value) const;
	double support() const { return m_taps; }

private:
	double const m_taps;
};

class gaussian_kernel : public kernel
{
public:
	gaussian_kernel(boost::optional<double> p);
	double weight(double value) const;
	double support() const { return 4.0; }

private:
	double const m_p;
};

class sinc_kernel : public kernel
{
public:
	sinc_kernel(boost::optional<double> taps);
	double weight(double value) const;
	double support() const { return m_taps; }

private:
	const double m_taps;
};

// resampler_1d is thread-safe and may be called concurrently.
class resampler_1d
{
public:
	typedef std::uint_fast32_t dimension_type;

	void reset(dimension_type source_length, double source_crop_offset, double source_crop_length, dimension_type dest_length, double blur, kernel const &filter);

	void resample_horizontal(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
	void resample_horizontal_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst, alloc::bitmap<float> const &tmp1, alloc::bitmap<float> const &tmp2) const;

	void resample_vertical(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
	void resample_vertical_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
	void resample_vertical_avx(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;

	inline dimension_type source_length() const { return m_srclen; }
	inline dimension_type dest_length() const { return m_dstlen; }

	inline bool empty() const { return m_program.empty(); }

private:
	union instruction
	{
		float f;
		dimension_type d;
	};

	std::vector<instruction> m_program;
	dimension_type m_srclen, m_dstlen;
};

// resampler_2d is not thread-safe and must not be called concurrently.
class resampler_2d
{
public:
	typedef resampler_1d::dimension_type dimension_type;

	void reset(resampler_1d const &resampler_x, resampler_1d const &resampler_y);

	void resample(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;

	inline dimension_type source_width() const { assert(m_hfilter != 0); return m_hfilter->source_length(); }
	inline dimension_type source_height() const { assert(m_vfilter != 0); return m_vfilter->source_length(); }
	inline dimension_type dest_width() const { assert(m_hfilter != 0); return m_hfilter->dest_length(); }
	inline dimension_type dest_height() const { assert(m_vfilter != 0); return m_vfilter->dest_length(); }

	inline bool empty() const { return !m_hfilter || m_hfilter->empty() || !m_vfilter || m_vfilter->empty(); }

private:
	alloc::bitmap_storage<float> m_tmp, m_htmp1, m_htmp2;
	resampler_1d const *m_vfilter, *m_hfilter;

	static bool s_initialized;
	static void (resampler_2d:: *s_resampler)(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;

	void resample_c(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
	void resample_sse(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
	void resample_avx(alloc::bitmap<float const> const &src, alloc::bitmap<float> const &dst) const;
};

}

#endif
