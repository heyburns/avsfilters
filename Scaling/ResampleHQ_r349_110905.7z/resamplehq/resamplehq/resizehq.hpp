/*
	ResampleHQ Avisynth resampler
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_RESIZEHQ_HPP
#define INT64_ORG_RESAMPLER_RESIZEHQ_HPP

#ifdef _MSC_VER
#pragma once
#endif

#include <cstdint>
#include <stack>
#include <memory>
#include <utility>
#include <boost/optional/optional.hpp>
#include "critical_section.hpp"
#include "color.hpp"
#include "resample.hpp"
#include "alloc.hpp"

#ifdef _M_X64
#include "avisynth-x64.h"
#else
#include "avisynth.h"
#endif

namespace resample
{

class ResizeHQ :
	public GenericVideoFilter
{
public:
	enum colorspace
	{
		cs_unknown,
		cs_unspecified,
		cs_rgb24,
		cs_rgb32,
		cs_yv12,
		cs_yuy2
	};

	typedef std::uint_fast32_t dimension_type;

	ResizeHQ(IScriptEnvironment *env, PClip const &child, char const *src_matrix, char const *dest_colorspace, char const *dest_matrix, boost::optional<int> dest_width, boost::optional<int> dest_height, bool dither, boost::optional<double> src_left, boost::optional<double> src_top, boost::optional<double> src_width, boost::optional<double> src_height, char const *kernel, boost::optional<double> karg1, boost::optional<double> karg2, double kblur_x, double kblur_y, char const *chroma_kernel, boost::optional<double> chroma_karg1, boost::optional<double> chroma_karg2);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);

private:
	struct plane
	{
		alloc::bitmap_storage<float> src, resized;
	};

	struct frame_state
	{
		plane r, g, b, a, cb_in, cr_in, cb_out, cr_out;
		resampler_2d resampler, in_chroma_resampler, out_chroma_resampler;
	};

	std::stack<std::unique_ptr<frame_state>> m_cache;
	critical_section m_cachelock;

	color::yuv_table const *m_matrix_in, *m_matrix_out;

	resampler_1d m_resize_x, m_resize_y, m_resize_src_chroma_x, m_resize_src_chroma_y, m_resize_target_chroma_x, m_resize_target_chroma_y;

	void (ResizeHQ::*m_read_func)(PVideoFrame const&, frame_state&);
	void (ResizeHQ::*m_write_func)(frame_state&, PVideoFrame&);

	std::unique_ptr<frame_state> get_state();
	void return_state(std::unique_ptr<frame_state> state);

	void read_rgb24(PVideoFrame const &src, frame_state &dst);
	void read_rgb32(PVideoFrame const &src, frame_state &dst);
	void read_rgba32(PVideoFrame const &src, frame_state &dst);
	void read_yv12(PVideoFrame const &src, frame_state &dst);
	void read_yuy2(PVideoFrame const &src, frame_state &dst);

	void write_rgb24(frame_state &src, PVideoFrame &dst);
	void write_rgb32(frame_state &src, PVideoFrame &dst);
	void write_rgba32(frame_state &src, PVideoFrame &dst);
	void write_yv12(frame_state &src, PVideoFrame &dst);
	void write_yuy2(frame_state &src, PVideoFrame &dst);

	void dither_rgb24(frame_state &src, PVideoFrame &dst);
	void dither_rgb32(frame_state &src, PVideoFrame &dst);
	void dither_rgba32(frame_state &src, PVideoFrame &dst);

	static colorspace get_colorspace(VideoInfo const &vi);
	static colorspace get_colorspace(char const *name);

	static color::yuv_table const* get_matrix(char const *name);

	static std::unique_ptr<kernel> get_kernel(char const *name, boost::optional<double> arg1, boost::optional<double> arg2);
};

}

#endif
