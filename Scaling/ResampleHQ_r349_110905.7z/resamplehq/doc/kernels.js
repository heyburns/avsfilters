function bilinear_kernel()
{
	this.support = 1.0;
	this.description = 'Simple, fast, purely linear filter with only a single lobe.';
	this.link = 'http://en.wikipedia.org/wiki/Bilinear_interpolation';
	this.weight = function(value)
	{
		value = Math.abs(value);
		return (value < 1.0) ? (1.0 - value) : 0.0;
	}
}

function bicubic_kernel(b, c, desc)
{
	this.support = 2.0;
	this.description = desc;
	this.link = 'http://en.wikipedia.org/wiki/Bicubic_interpolation';
	
	this.p0 = (   6.0 -  2.0 * b            ) / 6.0;
	this.p2 = ( -18.0 + 12.0 * b +  6.0 * c ) / 6.0;
	this.p3 = (  12.0 -  9.0 * b -  6.0 * c ) / 6.0;
	this.q0 = (          8.0 * b + 24.0 * c ) / 6.0;
	this.q1 = (       - 12.0 * b - 48.0 * c ) / 6.0;
	this.q2 = (          6.0 * b + 30.0 * c ) / 6.0;
	this.q3 = (       -        b -  6.0 * c ) / 6.0;
	
	this.weight = function(value)
	{
		value = Math.abs(value);
		
		if(value < 1.0)
		{
			return this.p0 + value * value * (this.p2 + value * this.p3);
		}
		
		if(value < 2.0)
		{
			return this.q0 + value * (this.q1 + value * (this.q2 + value * this.q3));
		}

		return 0.0;
	}
}

function spline16_kernel()
{
	this.support = 2.0;
	this.description = '2-lobe Spline filter from Avisynth.';
	this.link = 'http://avisynth.org/mediawiki/Resize#Spline_based_resizers';
	this.weight = function(value)
	{
		value = Math.abs(value);
		
		if(value < 1.0)
		{
			return (( value - 9.0 / 5.0 ) * value - 1.0 / 5.0 ) * value + 1.0;
		}
		
		if(value < 2.0)
		{
			return (( -1.0 / 3.0 * (value - 1.0) + 4.0 / 5.0 ) * (value - 1.0) - 7.0 / 15.0 ) * (value - 1.0);
		}
		
		return 0.0;
	}
}

function spline36_kernel()
{
	this.support = 3.0;
	this.description = '3-lobe Spline filter from Avisynth.';
	this.link = 'http://avisynth.org/mediawiki/Resize#Spline_based_resizers';
	this.weight = function(value)
	{
		value = Math.abs(value);
			
		if(value < 1.0)
		{
			return (( 13.0 / 11.0 * (value      ) - 453.0 / 209.0 ) * (value      ) -   3.0 / 209.0) * (value      ) + 1.0;
		}
		
		if(value < 2.0)
		{
			return (( -6.0 / 11.0 * (value - 1.0) + 270.0 / 209.0 ) * (value - 1.0) - 156.0 / 209.0) * (value - 1.0);
		}
		
		if(value < 3.0)
		{
			return ((  1.0 / 11.0 * (value - 2.0) -  45.0 / 209.0 ) * (value - 2.0) +  26.0 / 209.0) * (value - 2.0);
		}
			
		return 0.0;
	}
}

function spline64_kernel()
{
	this.support = 4.0;
	this.description = '4-lobe Spline filter from Avisynth.';
	this.link = 'http://avisynth.org/mediawiki/Resize#Spline_based_resizers';
	this.weight = function(value)
	{
		value = Math.abs(value);
		
		if(value < 1.0)
		{
			return (( 49.0 / 41.0 * (value      ) - 6387.0 / 2911.0) * (value      ) -    3.0 / 2911.0) * (value      ) + 1.0;
		}
		
		if(value < 2.0)
		{
			return ((-24.0 / 41.0 * (value - 1.0) + 4032.0 / 2911.0) * (value - 1.0) - 2328.0 / 2911.0) * (value - 1.0);
		}
		
		if(value < 3.0)
		{
			return ((  6.0 / 41.0 * (value - 2.0) - 1008.0 / 2911.0) * (value - 2.0) +  582.0 / 2911.0) * (value - 2.0);
		}
		
		if(value < 4.0)
		{
			return ((- 1.0 / 41.0 * (value - 3.0) +  168.0 / 2911.0) * (value - 3.0) -   97.0 / 2911.0) * (value - 3.0);
		}
		
		return 0.0;
	}
}

function lanczos_kernel(taps)
{
	this.support = taps;
	this.description = taps + '-lobe Lanczos filter.';
	this.link = 'http://en.wikipedia.org/wiki/Lanczos_resampling';
	this.weight = function(value)
	{
		value = Math.abs(value);

		if(value == 0.0)
		{
			return 1.0;
		}

		if(value >= this.support)
		{
			return 0.0;
		}

		value *= Math.PI;
		return this.support * Math.sin(value) * Math.sin(value / this.support) / (value * value);
	}
}

function blackman_kernel(taps)
{
	this.support = taps;
	this.description = taps + '-lobe Blackman filter.';
	this.link = 'http://en.wikipedia.org/wiki/Window_function#Blackman_windows';
	this.weight = function(value)
	{
		value = Math.abs(value);

		if(value == 0.0)
		{
			return 1.0;
		}

		if(value >= this.support)
		{
			return 0.0;
		}

		value *= Math.PI;
		
		return (Math.sin(value) / value) * (0.42 + 0.5 * Math.cos(value / this.support) + 0.08 * Math.cos(2.0 * value / this.support));
	}
}

function gaussian_kernel(p)
{
	this.support = 4.0;
	this.link = 'http://en.wikipedia.org/wiki/Window_function#Gaussian_windows';
	this.p = p;
	this.weight = function(value)
	{
		value = Math.abs(value);
		return Math.pow(2.0, -(this.p * 0.1) * value * value);
	}
}

function sinc_kernel(taps)
{
	this.support = taps;
	this.description = 'The perfect unwindowed Sinc filter, shown to 4 lobes.  Not really practical for much.'
	this.link = 'http://en.wikipedia.org/wiki/Sinc_function';
	this.weight = function(value)
	{
		value = Math.abs(value);

		if(value > 0.0)
		{
			value *= Math.PI;
			return Math.sin(value) / value;
		}

		return 1.0;
	}
}

var kernels =
{
	'Bilinear' : new bilinear_kernel(),
	'Blackman2' : new blackman_kernel(2.0),
	'Blackman3' : new blackman_kernel(3.0),
	'Blackman4' : new blackman_kernel(4.0),
	'Catmull-Rom' : new bicubic_kernel(0.0, 0.5, 'Bicubic with values b=0.0, c=0.5.'),
	'Gaussian' : new gaussian_kernel(30.0),
	'Hermite' : new bicubic_kernel(0.0, 0.0, 'Bicubic approximation of Bilinear with values b=0.0, c=0.0.'),
	'Mitchell-Netravali' : new bicubic_kernel(1.0 / 3.0, 1.0 / 3.0, 'The "standard" Bicubic, with values b=1/3, c=1/3.'),
	'Lanczos2' : new lanczos_kernel(2.0),
	'Lanczos3' : new lanczos_kernel(3.0),
	'Lanczos4' : new lanczos_kernel(4.0),
	'Robidoux' : new bicubic_kernel(0.3782, 0.3109, 'Bicubic with values b=0.3782, c=0.3109.'),
	'Sinc' : new sinc_kernel(4.0),
	'SoftCubic50' : new bicubic_kernel(0.5, 0.5, 'SoftCubic from MadVR.  Bicubic with values b=0.5, c=0.5.'),
	'SoftCubic75' : new bicubic_kernel(0.75, 0.25, 'SoftCubic from MadVR.  Bicubic with values b=0.75, c=0.25.'),
	'SoftCubic100' : new bicubic_kernel(1.0, 0.0, 'SoftCubic from MadVR.  Bicubic with values b=1.0, c=0.0.'),
	'Spline16' : new spline16_kernel(),
	'Spline36' : new spline36_kernel(),
	'Spline64' : new spline64_kernel()
};

// l between 0-100, c between 0-100, h between 0-360
function lch_to_rgb(l, c, h)
{
	l = l / 100.0;
	c = c / 100.0;
	h = h * (Math.PI / 180.0);
	
	// lch -> lab
	
	var a = c * Math.cos(h);
	var b = c * Math.sin(h);
	
	// lab -> xyz (approx.)
	
	var x = Math.pow(l + a / 5.0, 3);
	var y = Math.pow(l, 3);
	var z = Math.pow(l - b / 2.0, 3);
	
	// xyz -> rgb
	
	var r = ( 3.2410 * 0.9505) * x + (-1.5374) * y + (-0.4986 * 1.0890) * z;
	var g = (-0.9692 * 0.9505) * x + ( 1.8760) * y + ( 0.0416 * 1.0890) * z;
	var b = ( 0.0556 * 0.9505) * x + (-0.2040) * y + ( 1.0570 * 1.0890) * z;
	
	// rgb -> srgb (approx.)
	
	r = Math.pow(Math.min(Math.max(r, 0.0), 1.0), 1.0 / 2.2) * 100.0;
	g = Math.pow(Math.min(Math.max(g, 0.0), 1.0), 1.0 / 2.2) * 100.0;
	b = Math.pow(Math.min(Math.max(b, 0.0), 1.0), 1.0 / 2.2) * 100.0;
	
	return 'rgb(' + r + '%,' + g + '%,' + b + '%)';
}

function object_size(obj)
{
	var size = 0;
	
	for(var key in obj)
	{
		++size;
	}
	
	return size;
};

function clear_canvas(ctx)
{
	// yay browser incompatibilities... clear the canvas.
	
	var canvas = ctx.canvas;
	
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	var width = canvas.width;
	canvas.width = 1;
	canvas.width = width;
}

var textpad = 40;

function analyze_kernel(kernel)
{
	var bilinear = new bilinear_kernel();
	
	this.blurring = 0.0;
	this.sharpness = 0.0;
	this.ringing = 0.0;
	
	var max = kernel.weight(0.0);
	
	for(i = 0; i <= 200; ++i)
	{
		x = i / 200.0 * kernel.support;
		y = kernel.weight(x) / max;
		ya = Math.abs(y) * kernel.support;
		
		this.blurring += y - bilinear.weight(x);
		this.sharpness += ya;
		
		if(y < 0.0)
		{
			this.ringing += ya;
		}
	}
}

function draw_kernel(canvas, style, width, kernel)
{
	var scalex = 128.0;
	var scaley = -252.0 / kernel.weight(0.0);
	var translatex = textpad + 512.0;
	var translatey = 256.0;
	
	canvas.beginPath();
	canvas.moveTo(-kernel.support * scalex + translatex, kernel.weight(-kernel.support) * scaley + translatey);
	
	for(i = -199; i <= 200; ++i)
	{
		x = i / 200.0 * kernel.support;
		y = kernel.weight(x);
		canvas.lineTo(x * scalex + translatex, y * scaley + translatey);
	}
	
	canvas.lineWidth = width;
	canvas.strokeStyle = style;
	canvas.stroke();
}

function draw_legend(canvas)
{	
	// draw graph lines.
	
	canvas.beginPath();
	
	// vertical lines.
	
	canvas.moveTo(textpad + 128, 0);
	canvas.lineTo(textpad + 128, 320);
	canvas.moveTo(textpad + 256, 0);
	canvas.lineTo(textpad + 256, 320);
	canvas.moveTo(textpad + 384, 0);
	canvas.lineTo(textpad + 384, 320);
	canvas.moveTo(textpad + 512, 0);
	canvas.lineTo(textpad + 512, 320);
	canvas.moveTo(textpad + 640, 0);
	canvas.lineTo(textpad + 640, 320);
	canvas.moveTo(textpad + 768, 0);
	canvas.lineTo(textpad + 768, 320);
	canvas.moveTo(textpad + 896, 0);
	canvas.lineTo(textpad + 896, 320);
	
	// horizontal lines.
	
	canvas.moveTo(textpad + 0, 2);
	canvas.lineTo(textpad + 1024, 2);
	
	canvas.moveTo(textpad + 0, 128);
	canvas.lineTo(textpad + 1024, 128);
	
	canvas.moveTo(textpad + 0, 256);
	canvas.lineTo(textpad + 1024, 256);
	
	canvas.strokeStyle='rgb(220,220,220)';
	canvas.stroke();
	
	// vertical label.
	
	canvas.fillStyle = 'rgb(127,127,127)';
	canvas.font = '16px sans-serif';
	canvas.textAlign = 'center';
	canvas.textBaseline = 'top';
	
	canvas.save();
	canvas.rotate(90.01 * Math.PI / 180); // 90.01 because FF text is fugly at exactly 90 for some reason.
	canvas.fillText('Sample Weight', 160, -20);
	canvas.fillText('0.0', 256, -40);
	canvas.fillText('0.5', 128, -40);
	canvas.fillText('1.0', 12, -40);
	canvas.restore();
	
	// horizontal label.
	
	canvas.fillText('0.0', textpad + 512, 320);
	canvas.fillText('1.0', textpad + 384, 320);
	canvas.fillText('1.0', textpad + 640, 320);
	canvas.fillText('2.0', textpad + 256, 320);
	canvas.fillText('2.0', textpad + 768, 320);
	canvas.fillText('3.0', textpad + 128, 320);
	canvas.fillText('3.0', textpad + 896, 320);
	canvas.fillText('4.0', textpad + 10, 320);
	canvas.fillText('4.0', textpad + 1012, 320);
	canvas.fillText('Sample Distance', textpad + 512, 320 + textpad / 2);
}

var kernelcount;

function draw_bar_graph(name, selected, selector)
{
	var canvas = document.getElementById(name);
	var ctx = canvas.getContext('2d');
	
	clear_canvas(ctx);
	
	// draw legend and axis lines.
	
	var glen = kernelcount * 20;
	
	ctx.beginPath();
	
	ctx.moveTo(0, 36);
	ctx.lineTo(glen, 36);
	
	ctx.moveTo(0, 68);
	ctx.lineTo(glen, 68);
	
	ctx.moveTo(0, 100);
	ctx.lineTo(glen, 100);
	
	ctx.moveTo(0, 132);
	ctx.lineTo(glen, 132);
	
	ctx.strokeStyle='rgb(172,172,172)';
	ctx.stroke();
	
	ctx.fillStyle = 'rgb(127,127,127)';
	ctx.font = '16px sans-serif';
	ctx.textAlign = 'center';
	ctx.textBaseline = 'top';
	
	ctx.fillText(name, glen / 2.0, 140);
	
	// find min/max values and normalize.
	
	var min = Number.MAX_VALUE;
	var max = Number.MIN_VALUE;
	
	for(var name in kernels)
	{
		var kernel = kernels[name];
		var n = selector(kernel);
		
		if(n < min) min = n;
		if(n > max) max = n;
	}
	
	if(min > 0) max -= min;
	else min = 0;
	
	// draw the graph.
	
	for(var name in kernels)
	{
		var kernel = kernels[name];
		var pos = kernel.pos;
		var color = kernel.color;
		var hue = kernel.hue;
		
		var n = selector(kernel);
		var barsize = (n - min) / max * 128;
		
		if(name == selected)
		{
			ctx.fillStyle = lch_to_rgb(85, 25, hue);
			ctx.fillRect(pos * 20 - 3, 132 - barsize - 3, 21, Math.abs(barsize) + 6);
		}
		
		ctx.fillStyle = color;
		ctx.fillRect(pos * 20, 132 - barsize, 15, barsize);
	}
}

function draw_kernels(canvas, selected, scalex, scaley)
{
	clear_canvas(canvas);
	
	canvas.scale(scalex, scaley);
	
	draw_legend(canvas);
	
	// draw kernels.
	
	var i = 0, sel = null;
	
	for(var name in kernels)
	{
		var kernel = kernels[name];
		var an = kernel.analysis;
		var pos = kernel.pos;
		var hue = kernel.hue;
		var color = selected ? lch_to_rgb(85, 15, hue) : kernel.color;
		
		if(name != selected)
		{			
			draw_kernel(canvas, color, 2.0, kernel);
		}
		else
		{
			sel = kernel;
		}
	}
	
	var kerneldesc = document.getElementById('kerneldesc');
	
	while(kerneldesc.hasChildNodes())
	{
		kerneldesc.removeChild(kerneldesc.lastChild);
	}
	
	if(sel)
	{		
		draw_kernel(canvas, '#fff', 14.0, sel);
		draw_kernel(canvas, sel.color, 6.0, sel);
		
		if(sel.description)
		{
			kerneldesc.appendChild(document.createTextNode(sel.description));
		}
		
		/*if(sel.link)
		{
			kerneldesc.appendChild(document.createTextNode(' '));
			
			var a = document.createElement('a');
			a.href = sel.link;
			a.appendChild(document.createTextNode('More information'));
			
			kerneldesc.appendChild(a);
		}*/
	}
}

function redraw_all_kernels(selected)
{
	var canvas = document.getElementById('canvas');
	var ctx = canvas.getContext('2d');
	
	draw_kernels(ctx, selected, 1000/1064, 357/380);
	
	draw_bar_graph('Blurring', selected, function(k) { return k.analysis.blurring; });
	draw_bar_graph('Sharpness', selected, function(k) { return k.analysis.sharpness; });
	draw_bar_graph('Ringing', selected, function(k) { return k.analysis.ringing; });
}

function capture_redraw(name)
{
	return function(evt)
	{
		redraw_all_kernels(name);
	};
}

function draw_all_kernels()
{
	var legend = document.getElementById('legend');
	var descriptions = document.getElementById('kernels');
	
	kernelcount = object_size(kernels);
	
	// draw kernels.
	
	var i = 0;
	
	for(var name in kernels)
	{
		var pos = i++;
		var kernel = kernels[name];
		var hue = 360 * pos / kernelcount;
		var color = lch_to_rgb(50, 75, hue);
		
		kernel.analysis = new analyze_kernel(kernel);
		kernel.color = color;
		kernel.pos = pos;
		kernel.hue = hue;
		
		var p = document.createElement('p');
		p.style.color = color;
		p.onmouseover = capture_redraw(name);
		p.onmouseout = function(evt) { redraw_all_kernels(''); };
		p.appendChild(document.createTextNode(name));
		legend.appendChild(p);
	}
	
	redraw_all_kernels(null);
}

window['draw_all_kernels'] = draw_all_kernels;
