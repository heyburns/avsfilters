/*
	Benchmark tool
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "../resamplehq/targetver.hpp"
#include <cstdint>
#include <memory>
#include <random>
#include <fstream>
#include <iostream>
#include <Windows.h>
#include "../resamplehq/alloc.hpp"
#include "../resamplehq/color.hpp"
#include "benchmark.hpp"

#pragma comment(lib, "resamplehq.lib")

class stream_redirector
{
public:
	stream_redirector(std::ios &s, std::ios const &news) : m_stream(s) { m_orig = s.rdbuf(news.rdbuf()); }
	~stream_redirector() { m_stream.rdbuf(m_orig); }

private:
	std::ios &m_stream;
	std::streambuf *m_orig;
};

static bool has_sse2() { return (color::get_features() & color::sse2) != 0; }
static bool has_ssse3() { return (color::get_features() & color::ssse3) != 0; }
static bool has_avx() { return (color::get_features() & color::avx) != 0; }
static bool has_fma4() { return (color::get_features() & color::fma4) != 0; }

int main(int argc, char *argv[])
{
	SetProcessAffinityMask(GetCurrentProcess(), (DWORD_PTR)1 << SetThreadIdealProcessor(GetCurrentThread(), MAXIMUM_PROCESSORS));
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
	Sleep(0);

	try
	{
		std::ofstream fs(L"benchmark results.txt");

		if(!fs.is_open())
		{
			std::cerr << "unable to open results file." << std::endl;
			return 0;
		}

		stream_redirector sr(std::cout, fs);

		std::cerr
			<< "CPU features detected: " << std::endl
			<< "   SSE2:  " << (has_sse2() ? "yes" : "no") << std::endl
			<< "   SSSE3: " << (has_ssse3() ? "yes" : "no") << std::endl
			<< "   AVX:   " << (has_avx() ? "yes" : "no") << std::endl
			<< "   FMA4:  " << (has_fma4() ? "yes" : "no") << std::endl << std::endl;

		unsigned const pixel_count = 1920 * 1080;
		std::unique_ptr<float[], alloc::avx_deleter> r, g, b, a;
		std::unique_ptr<std::uint8_t[], alloc::avx_deleter> rgba;
		std::mt19937 rng;
		std::uniform_int_distribution<> irng(0, 255);
		std::uniform_real_distribution<float> frng;

		r.reset(alloc::avx_new<float>(pixel_count));
		g.reset(alloc::avx_new<float>(pixel_count));
		b.reset(alloc::avx_new<float>(pixel_count));
		a.reset(alloc::avx_new<float>(pixel_count));
		rgba.reset(alloc::avx_new<std::uint8_t>(pixel_count * 4));

		for(unsigned i = 0; i < pixel_count; ++i)
		{
			rgba[i * 3] = irng(rng);
			rgba[i * 3 + 1] = irng(rng);
			rgba[i * 3 + 2] = irng(rng);
		}

		multi_benchmark("RGB24 -> linear RGB")
			("C", [&]{ color::srgb24_to_linear_rgb_row_c(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("SSSE3", has_ssse3(), [&]{ color::srgb24_to_linear_rgb_row_ssse3(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::srgb24_to_linear_rgb_row_avx(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::srgb24_to_linear_rgb_row_fma4(rgba.get(), r.get(), g.get(), b.get(), pixel_count); });

		for(unsigned i = 0; i < pixel_count; ++i)
		{
			rgba[i * 4] = irng(rng);
			rgba[i * 4 + 1] = irng(rng);
			rgba[i * 4 + 2] = irng(rng);
			rgba[i * 4 + 3] = irng(rng);
		}

		multi_benchmark("RGB32 -> linear RGB")
			("C", [&]{ color::srgb32_to_linear_rgb_row_c(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::srgb32_to_linear_rgb_row_sse2(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::srgb32_to_linear_rgb_row_avx(rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::srgb32_to_linear_rgb_row_fma4(rgba.get(), r.get(), g.get(), b.get(), pixel_count); });

		multi_benchmark("RGB32 -> linear RGBA")
			("C", [&]{ color::srgb32_to_linear_rgba_row_c(rgba.get(), r.get(), g.get(), b.get(), a.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::srgb32_to_linear_rgba_row_sse2(rgba.get(), r.get(), g.get(), b.get(), a.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::srgb32_to_linear_rgba_row_avx(rgba.get(), r.get(), g.get(), b.get(), a.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::srgb32_to_linear_rgba_row_fma4(rgba.get(), r.get(), g.get(), b.get(), a.get(), pixel_count); });

		multi_benchmark("YV12 -> YUV")
			("C", [&]{ color::yv12_to_yuv_row_c(color::pc709, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, pixel_count); })
			("SSE2", has_sse2(), [&]{ color::yv12_to_yuv_row_sse2(color::pc709, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, pixel_count); })
			("AVX", has_avx(), [&]{ color::yv12_to_yuv_row_avx(color::pc709, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, pixel_count); })
			("FMA4", has_fma4(), [&]{ color::yv12_to_yuv_row_fma4(color::pc709, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, pixel_count); });

		multi_benchmark("YUY2 -> YUV")
			("C", [&]{ color::yuy2_to_yuv_row_c(color::pc709, rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::yuy2_to_yuv_row_sse2(color::pc709, rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::yuy2_to_yuv_row_avx(color::pc709, rgba.get(), r.get(), g.get(), b.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::yuy2_to_yuv_row_fma4(color::pc709, rgba.get(), r.get(), g.get(), b.get(), pixel_count); });

		for(unsigned i = 0; i < pixel_count; ++i)
		{
			r[i] = frng(rng);
			g[i] = frng(rng);
			b[i] = frng(rng);
			a[i] = frng(rng);
		}

		multi_benchmark("YUV -> linear RGB")
			("C", [&]{ color::yuv_to_linear_rgb_row_c(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::yuv_to_linear_rgb_row_sse2(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::yuv_to_linear_rgb_row_avx(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::yuv_to_linear_rgb_row_avx(color::pc709, r.get(), g.get(), b.get(), pixel_count); });

		for(unsigned i = 0; i < pixel_count; ++i)
		{
			r[i] = frng(rng);
			g[i] = frng(rng);
			b[i] = frng(rng);
		}

		multi_benchmark("linear RGB -> RGB24")
			("C", [&]{ color::linear_rgb_to_srgb24_row_c(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("SSSE3", has_ssse3(), [&]{ color::linear_rgb_to_srgb24_row_ssse3(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::linear_rgb_to_srgb24_row_avx(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::linear_rgb_to_srgb24_row_fma4(r.get(), g.get(), b.get(), rgba.get(), pixel_count); });

		multi_benchmark("linear RGB -> RGB32")
			("C", [&]{ color::linear_rgb_to_srgb32_row_c(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::linear_rgb_to_srgb32_row_sse2(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::linear_rgb_to_srgb32_row_avx(r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::linear_rgb_to_srgb32_row_fma4(r.get(), g.get(), b.get(), rgba.get(), pixel_count); });

		multi_benchmark("linear RGBA -> RGB32")
			("C", [&]{ color::linear_rgba_to_srgb32_row_c(r.get(), g.get(), b.get(), a.get(), rgba.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::linear_rgba_to_srgb32_row_sse2(r.get(), g.get(), b.get(), a.get(), rgba.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::linear_rgba_to_srgb32_row_avx(r.get(), g.get(), b.get(), a.get(), rgba.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::linear_rgba_to_srgb32_row_fma4(r.get(), g.get(), b.get(), a.get(), rgba.get(), pixel_count); });

		multi_benchmark("YUV -> YV12")
			("C", [&]{ color::yuv_to_yv12_row_c(color::pc709, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, pixel_count); })
			("SSE2", has_sse2(), [&]{ color::yuv_to_yv12_row_sse2(color::pc709, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, pixel_count); })
			("AVX", has_avx(), [&]{ color::yuv_to_yv12_row_avx(color::pc709, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, pixel_count); })
			("FMA4", has_fma4(), [&]{ color::yuv_to_yv12_row_fma4(color::pc709, r.get(), g.get(), b.get(), b.get() + pixel_count / 2, rgba.get(), rgba.get() + pixel_count, rgba.get() + pixel_count * 2, rgba.get() + pixel_count * 2 + pixel_count / 2, pixel_count); });

		multi_benchmark("YUV -> YUY2")
			("C", [&]{ color::yuv_to_yuy2_row_c(color::pc709, r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::yuv_to_yuy2_row_sse2(color::pc709, r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::yuv_to_yuy2_row_avx(color::pc709, r.get(), g.get(), b.get(), rgba.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::yuv_to_yuy2_row_fma4(color::pc709, r.get(), g.get(), b.get(), rgba.get(), pixel_count); });

		multi_benchmark("linear RGB -> YUV")
			("C", [&]{ color::linear_rgb_to_yuv_row_c(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("SSE2", has_sse2(), [&]{ color::linear_rgb_to_yuv_row_sse2(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("AVX", has_avx(), [&]{ color::linear_rgb_to_yuv_row_avx(color::pc709, r.get(), g.get(), b.get(), pixel_count); })
			("FMA4", has_fma4(), [&]{ color::linear_rgb_to_yuv_row_fma4(color::pc709, r.get(), g.get(), b.get(), pixel_count); });
	}
	catch(std::exception &ex)
	{
		std::cerr << "error: " << ex.what() << std::endl;
	}

	return 0;
}
