/*
	Poor-man's benchmarking
	Copyright (C) 2011 Cory Nelson (phrosty@gmail.com)

	This program is free software: you can redistribute it and/or modify
	it under the terms of version 3 of the GNU General Public License as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INT64_ORG_RESAMPLER_BENCHMARK_HPP
#define INT64_ORG_RESAMPLER_BENCHMARK_HPP

#ifdef _MSC_VER
#pragma once
#endif

#include <cstdint>
#include <string>
#include <limits>
#include <iostream>
#include <boost/optional/optional.hpp>
#include <Windows.h>

struct benchmark_result
{
	double min_time, max_time, avg_time;

	benchmark_result() {}
	benchmark_result(double min_time, double max_time, double avg_time) : min_time(min_time),max_time(max_time),avg_time(avg_time) {}
};

template<typename Func>
static benchmark_result benchmark(char const *name, Func func)
{
	LARGE_INTEGER start, end, freq;

	QueryPerformanceFrequency(&freq);

	std::cerr << name << ": warming up and measuring ballpark speed..." << std::flush;

	unsigned ballpark = 0;
	{
		QueryPerformanceCounter(&start);

		do
		{
			++ballpark;
			func();
			QueryPerformanceCounter(&end);
		}
		while((end.QuadPart - start.QuadPart) < (freq.QuadPart * 2));
	}

	std::cerr
		<< " done." << std::endl
		<< name << ": ballpark speed is " << (ballpark / 2.0) << " runs/second." << std::endl
		<< name << ": benchmarking..." << std::flush;

	LARGE_INTEGER mintime, maxtime, curtime;
	double avgtime = 0.0;
	unsigned avgcount = 0;

	mintime.QuadPart = (std::numeric_limits<LONGLONG>::max)();
	maxtime.QuadPart = 0;

	for(unsigned bestruns = 0; bestruns < 10; ++bestruns)
	{
		QueryPerformanceCounter(&start);

		for(unsigned i = 0; i < ballpark; ++i)
		{
			func();
		}

		QueryPerformanceCounter(&end);

		curtime.QuadPart = end.QuadPart - start.QuadPart;

		bool updated = false;

		if(curtime.QuadPart < mintime.QuadPart)
		{
			mintime.QuadPart = curtime.QuadPart;
			updated = true;
		}

		if(curtime.QuadPart > maxtime.QuadPart)
		{
			maxtime.QuadPart = curtime.QuadPart;
			updated = true;
		}

		avgtime += double(freq.QuadPart * ballpark) / curtime.QuadPart;
		++avgcount;

		if(updated)
		{
			bestruns = 0;
			std::cerr << '+' << std::flush;
		}
		else
		{
			std::cerr << '.' << std::flush;
		}
	}

	std::cerr << " done." << std::endl;

	double dmintime = double(freq.QuadPart * ballpark) / mintime.QuadPart;
	double dmaxtime = double(freq.QuadPart * ballpark) / maxtime.QuadPart;
	double davgtime = avgtime / avgcount;

	std::cout << name << ": (fastest/slowest/average) wall time speed is " << dmintime << '/' << dmaxtime << '/' << davgtime << " runs/second." << std::endl;

	return benchmark_result(dmintime, dmaxtime, davgtime);
}

class multi_benchmark
{
public:
	inline multi_benchmark(char const *name) : m_name(name) {}

	template<typename Func>
	inline multi_benchmark operator()(char const *variant, Func func)
	{
		return (*this)(variant, true, func);
	}

	template<typename Func>
	multi_benchmark operator()(char const *variant, bool run, Func func)
	{
		std::string const fullname = m_name + " " + variant;

		if(run)
		{
			benchmark_result res = benchmark(fullname.c_str(), func);

			if(!m_base)
			{
				m_base = res;
			}

			std::cout << fullname << " relative speed: " << (res.min_time / m_base->min_time) << "x." << std::endl;
		}
		else
		{
			std::cout << fullname << ": skipping." << std::endl;
		}

		return *this;
	}

private:
	std::string m_name;
	boost::optional<benchmark_result> m_base;
};

#endif
