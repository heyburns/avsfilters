// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)
#pragma once

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

class Random32 {
public:
	Random32(uint32_t seed) : m_seed(seed) {}
	inline uint32_t uint32() {
		return m_seed = 1664525ul * m_seed + 1013904223ul;
	}
	inline float float_1_1() {
		union {float f; uint32_t i;} ieee;
		ieee.i = (uint32() & 0x007ffffful) | 0x40000000ul; // [2.0..4.0) range
		return ieee.f - 3.0f;
	}
private:
	uint32_t m_seed;
};
