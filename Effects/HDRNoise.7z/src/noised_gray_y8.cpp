// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"
#include "random.hpp"

namespace NoisedGrayY8 {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
	Random32 random;
	Frame(int seed): random(seed) {}
};

struct Args {
	float amp;
	int seed;
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_8y(Args* args, Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.dst->GetPitch(PLANAR_Y);
	uint8_t* ptr = frame.dst->GetWritePtr(PLANAR_Y);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = 128.0f + frame.random.float_1_1() * args->amp + 0.5f;
			ptr[x] = clamp8(out);
		}
		ptr += pitch;
	}
}

void filter_8(Args* args, Frame& frame) {
	frame.dst = frame.env->NewVideoFrame(*frame.vi);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.dst->GetPitch(PLANAR_Y);
	uint8_t* ptr = frame.dst->GetWritePtr(PLANAR_Y);
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = 128.0f + frame.random.float_1_1() * args->amp + 0.5f;
			ptr[x] = clamp8(out);
		}
		ptr += pitch;
	}
	// Color channels
	const int planes[] = {PLANAR_U, PLANAR_V};
	const int pmax = frame.vi->IsY8() ? 0 : 2;
	for (int p=0; p<pmax; ++p) {
		const int plane = planes[p];
		uint8_t* dst = frame.dst->GetWritePtr(plane);
		const int dst_pitch = frame.dst->GetPitch(plane);
		const int heightp = frame.vi->height >> frame.vi->GetPlaneHeightSubsampling(plane);
		memset(dst, 128, dst_pitch*heightp);
	}
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame(n + m_args.seed);
	//frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("NoisedGrayY8: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("NoisedGrayY8: RGB is not supported.");

	int arg = 0;
	m_args.amp = (float)args[++arg].AsFloat(10.0);
	if (m_args.amp < 0)
		env->ThrowError("NoisedGrayY8: Incorrect amp<0\n");
	m_args.seed = args[++arg].AsInt(0);
	const bool uv = args[++arg].AsBool(true);
	const int bitdepth = args[++arg].AsInt(8);
	
	m_filter = uv ? filter_8 : filter_8y;
	if (bitdepth == 8) {
		;
	} else if (bitdepth == 88) {
		vi.height = vi.height>>1;
	} else if (bitdepth == 16) {
		vi.width = vi.width>>1;
	} else if (bitdepth == 32) {
		vi.width = vi.width>>2;
	} else {
		env->ThrowError("NoisedGrayY8: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_NoisedGrayY8(IScriptEnvironment* env)
{
	// NoisedGrayY8(amp=10.0, seed=0, uv=true, bitdepth=8)
    env->AddFunction("NoisedGrayY8", "c[amp]f[seed]i[uv]b[bitdepth]i", NoisedGrayY8::Create_Filter, 0);
}
