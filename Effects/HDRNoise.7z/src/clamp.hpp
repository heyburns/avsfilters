// Licensed under the MIT License. Copyright (c) 2015 Andrew Revvo (andrew.revvo~gmail~com)
#pragma once

#include <stdint.h>
#include <xmmintrin.h>

// Fast for SSE2-optimized build

inline uint8_t clamp8(float v) {
	int iv = (int)v;
	iv = iv > 255 ? 255 : iv;
	return iv < 0 ? 0 : uint8_t(iv);
}
inline uint16_t clamp16(float v) {
	int iv = (int)v;
	iv = iv > 65535 ? 65535 : iv;
	return iv < 0 ? 0 : uint16_t(iv);
}

// Universal and fast

inline uint8_t clamp_uint8(uint8_t v, const uint8_t a, const uint8_t b) {
	v = v > b ? b : v;
	return v < a ? a : v;
}

inline uint16_t clamp_uint16(uint16_t v, const uint16_t a, const uint16_t b) {
	v = v > b ? b : v;
	return v < a ? a : v;
}

inline int not_need_clamp_uint88(const uint8_t msb, const uint8_t a, const uint8_t b) {
	return (msb < b) && (msb >= a);
}

inline uint16_t clamp_uint88(const uint8_t msb, const uint8_t lsb, const uint16_t a, const uint16_t b) {
	uint16_t v = msb << 8 | lsb;
	v = v > b ? b : v;
	return v < a ? a : v;
}

inline float clamp_float(float v, const float a, const float b) {
	v = v > b ? b : v;
	return v < a ? a : v;
}
