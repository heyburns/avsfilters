// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"

namespace NoiseMix1Y {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	PVideoFrame noise;
	VideoInfo* vi;
	IScriptEnvironment* env;
};

struct Args {
	float amp;
	float ldiff;
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_8_truncate(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	const uint8_t* ptr_noise = frame.noise->GetReadPtr();
	const int pitch_noise = frame.noise->GetPitch();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			float noise = (float)(ptr_noise[x]-128) * args->amp;
			float out_amp = (out - 16.0f) * args->ldiff + 0.5f;
			out = noise * out_amp + out + 0.5f;
			ptr[x] = clamp8(out);
		}
		ptr += pitch;
		ptr_noise += pitch_noise;
	}
	frame.dst = frame.src;
}

void filter_8_sierra(Args* args, Frame& frame) {
	const size_t dither_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_w*2);
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	const uint8_t* ptr_noise = frame.noise->GetReadPtr();
	const int pitch_noise = frame.noise->GetPitch();
	float* dither_a = dither+2;
	float* dither_b = dither+2+width;
	memset(dither_a, 0, dither_w);
	for (int y = 0; y < height; ++y) {
		memset(dither_b, 0, dither_w);
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			float noise = (float)(ptr_noise[x]-128) * args->amp;
			float out_amp = (out - 16.0f) * args->ldiff + 0.5f;
			out = noise * out_amp + out;
			// Out Sierra 2-4A dithered
			out += dither_a[x+1];
			const uint8_t out_trunc = clamp8(out + 0.5f);
			const float dither_error = out - out_trunc;
			const float dither_error_050 = dither_error * 0.5f;
			const float dither_error_025 = dither_error * 0.25f;
			dither_a[x+2] += dither_error_050;
			dither_b[x]   += dither_error_025;
			dither_b[x+1] += dither_error_025;
			ptr[x] = out_trunc;
		}
		ptr += pitch;
		ptr_noise += pitch_noise;
		// Switch dither tables
		float* dither_temp = dither_b;
		dither_b = dither_a;
		dither_a = dither_temp;
	}
	frame.dst = frame.src;
}

void filter_88(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height >> 1;
	const int pitch = frame.src->GetPitch();
	uint8_t* msb = frame.src->GetWritePtr();
	uint8_t* lsb = msb + pitch*height;
	const uint8_t* ptr_noise = frame.noise->GetReadPtr();
	const int pitch_noise = frame.noise->GetPitch();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			uint16_t out_16 = msb[x]<<8 | lsb[x];
			float out = (float)out_16;
			float noise = (float)(ptr_noise[x]-128) * args->amp;
			float out_amp = (out*(1.0f/256.0f) - 16.0f) * args->ldiff + 0.5f;
			out = noise * out_amp * 256.0f + out + 0.5f;
			out_16 = clamp16(out);
			msb[x] = out_16 >> 8;
			lsb[x] = (uint8_t)out_16;
		}
		msb += pitch;
		lsb += pitch;
		ptr_noise += pitch_noise;
	}
	frame.dst = frame.src;
}

void filter_16(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 1;
	uint16_t* ptr = (uint16_t*)frame.src->GetWritePtr();
	const uint8_t* ptr_noise = frame.noise->GetReadPtr();
	const int pitch_noise = frame.noise->GetPitch();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			float noise = (float)(ptr_noise[x]-128) * args->amp;
			float out_amp = (out*(1.0f/256.0f) - 16.0f) * args->ldiff + 0.5f;
			out = noise * out_amp * 256.0f + out + 0.5f;
			ptr[x] = clamp16(out);
		}
		ptr += pitch;
		ptr_noise += pitch_noise;
	}
	frame.dst = frame.src;
}

void filter_32(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 2;
	float* ptr = (float*)frame.src->GetWritePtr();
	const uint8_t* ptr_noise = frame.noise->GetReadPtr();
	const int pitch_noise = frame.noise->GetPitch();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = ptr[x];
			float noise = (float)(ptr_noise[x]-128) * args->amp;
			float out_amp = (out - 16.0f) * args->ldiff + 0.5f;
			out = noise * out_amp + out;
			ptr[x] = out;
		}
		ptr += pitch;
		ptr_noise += pitch_noise;
	}
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	PClip m_noise;
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame;
	frame.src = child->GetFrame(n, env);
	frame.noise = m_noise->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("NoiseMix1Y: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("NoiseMix1Y: RGB is not supported.");

	int arg = 0;
	m_noise = args[++arg].AsClip();
	
	m_args.amp = (float)args[++arg].AsFloat(1.0);
	if (m_args.amp < 0)
		env->ThrowError("NoiseMix1Y: Incorrect amp<0\n");
	m_args.ldiff = (float)args[++arg].AsFloat(1.0);
	m_args.ldiff = m_args.ldiff/256.0f;
	
	const int mode = args[++arg].AsInt(1);
	const int bitdepth = args[++arg].AsInt(8);

	if (bitdepth == 8) {
		if (mode == 0) { // Truncate
			m_filter = filter_8_truncate;
		} else { // Dither
			m_filter = filter_8_sierra;
		}
	} else if (bitdepth == 88) {
		m_filter = filter_88;
	} else if (bitdepth == 16) {
		m_filter = filter_16;
	} else if (bitdepth == 32) {
		m_filter = filter_32;
	} else {
		env->ThrowError("NoiseMix1Y: Unsupported bitdepth %d\n", bitdepth);
	}
}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_NoiseMix1Y(IScriptEnvironment* env)
{
	// NoiseMix1Y(noise, amp=1.0, ldiff=1.0, mode=1, bitdepth=8)
    env->AddFunction("NoiseMix1Y", "cc[amp]f[ldiff]f[mode]i[bitdepth]i", NoiseMix1Y::Create_Filter, 0);
}
