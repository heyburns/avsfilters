// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <stdint.h>
#include <cmath>
#include <cfloat>

#include "clamp.hpp"
#include "dev.hpp"
#include "random.hpp"

namespace NoiseY {

struct Frame {
	PVideoFrame src;
	PVideoFrame dst;
	VideoInfo* vi;
	IScriptEnvironment* env;
	Random32 random;
	Frame(int seed): random(seed) {}
};

struct Args {
	float amp;
	int seed;
};

typedef void (*FilterFunc)(Args*, Frame&);

void filter_8_truncate(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			out = out + frame.random.float_1_1() * args->amp + 0.5f;
			ptr[x] = clamp8(out);
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_8_sierra(Args* args, Frame& frame) {
	const size_t dither_w = (frame.vi->width+2)*sizeof(float);
	float* dither = (float*)alloca(dither_w*2);
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch();
	uint8_t* ptr = frame.src->GetWritePtr();
	float* dither_a = dither+2;
	float* dither_b = dither+2+width;
	memset(dither_a, 0, dither_w);
	for (int y = 0; y < height; ++y) {
		memset(dither_b, 0, dither_w);
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			out = out + frame.random.float_1_1() * args->amp;
			// Out Sierra 2-4A dithered
			out += dither_a[x+1];
			const uint8_t out_trunc = clamp8(out + 0.5f);
			const float dither_error = out - out_trunc;
			const float dither_error_050 = dither_error * 0.5f;
			const float dither_error_025 = dither_error * 0.25f;
			dither_a[x+2] += dither_error_050;
			dither_b[x]   += dither_error_025;
			dither_b[x+1] += dither_error_025;
			ptr[x] = out_trunc;
		}
		ptr += pitch;
		// Switch dither tables
		float* dither_temp = dither_b;
		dither_b = dither_a;
		dither_a = dither_temp;
	}
	frame.dst = frame.src;
}

void filter_88(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width;
	const int height = frame.vi->height >> 1;
	const int pitch = frame.src->GetPitch();
	uint8_t* msb = frame.src->GetWritePtr();
	uint8_t* lsb = msb + pitch*height;
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			uint16_t out_16 = msb[x]<<8 | lsb[x];
			float out = (float)out_16;
			out = out + frame.random.float_1_1() * args->amp;
			out_16 = clamp16(out);
			msb[x] = out_16 >> 8;
			lsb[x] = (uint8_t)out_16;
		}
		msb += pitch;
		lsb += pitch;
	}
	frame.dst = frame.src;
}

void filter_16(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 1;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 1;
	uint16_t* ptr = (uint16_t*)frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = (float)ptr[x];
			out = out + frame.random.float_1_1() * args->amp;
			ptr[x] = clamp16(out);
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_32(Args* args, Frame& frame) {
	frame.env->MakeWritable(&frame.src);
	const int width = frame.vi->width >> 2;
	const int height = frame.vi->height;
	const int pitch = frame.src->GetPitch() >> 2;
	float* ptr = (float*)frame.src->GetWritePtr();
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			float out = ptr[x];
			out = out + frame.random.float_1_1() * args->amp;
			ptr[x] = out;
		}
		ptr += pitch;
	}
	frame.dst = frame.src;
}

void filter_none(Args* args, Frame& frame) {
	(void)args;
	frame.dst = frame.src;
}

class Filter : public GenericVideoFilter {
public:
	Filter(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
	FilterFunc m_filter;
	Args m_args;
};

PVideoFrame __stdcall Filter::GetFrame(int n, IScriptEnvironment* env)
{
	Frame frame(n + m_args.seed);
	frame.src = child->GetFrame(n, env);
	frame.vi = &vi;
	frame.env = env;
	//ba
	m_filter(&m_args, frame);
	//bb
	return frame.dst;
}

Filter::Filter(PClip child, AVSValue args, IScriptEnvironment* env) : GenericVideoFilter(child)
{
	if (vi.IsYUY2())
		env->ThrowError("NoiseY: YUY2 is not supported.");
	if (vi.IsRGB())
		env->ThrowError("NoiseY: RGB is not supported.");

	int arg = 0;
	const float amp = (float)args[++arg].AsFloat(10.0);
	if (amp < 0)
		env->ThrowError("NoiseY: Incorrect amp<0\n");
	const int seed = args[++arg].AsInt(0);
	const int mode = args[++arg].AsInt(1);
	const int bitdepth = args[++arg].AsInt(8);

	m_args.seed = seed;
	if (bitdepth == 8) {
		m_args.amp = amp;
		if (mode == 0) { // Truncate
			m_filter = filter_8_truncate;
		} else { // Dither
			m_filter = filter_8_sierra;
		}
	} else if (bitdepth == 88) {
		m_args.amp = amp * 256.0f;
		m_filter = filter_88;
	} else if (bitdepth == 16) {
		m_args.amp = amp * 256.0f;
		m_filter = filter_16;
	} else if (bitdepth == 32) {
		m_args.amp = amp;
		m_filter = filter_32;
	} else {
		env->ThrowError("NoiseY: Unsupported bitdepth %d\n", bitdepth);
	}
	if (fabs(amp - 0.0f) <= FLT_EPSILON)
		m_filter = filter_none;

}

AVSValue __cdecl Create_Filter(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Filter(args[0].AsClip(), args, env);
}

} // namespace

void Add_NoiseY(IScriptEnvironment* env)
{
	// NoiseY(amp=10.0, seed=0, mode=1, bitdepth=8)
    env->AddFunction("NoiseY", "c[amp]f[seed]i[mode]i[bitdepth]i", NoiseY::Create_Filter, 0);
}
