// Licensed under the MIT License. Copyright (c) 2015-2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"

extern void Add_NoiseY(IScriptEnvironment* env);
extern void Add_NoiseYM(IScriptEnvironment* env);
extern void Add_NoiseUV(IScriptEnvironment* env);
extern void Add_NoiseMix1Y(IScriptEnvironment* env);
extern void Add_NoiseMix2Y(IScriptEnvironment* env);
extern void Add_NoisedGrayY8(IScriptEnvironment* env);

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env)
{
	Add_NoisedGrayY8(env);
	Add_NoiseMix1Y(env);
	Add_NoiseMix2Y(env);
	Add_NoiseY(env);
	Add_NoiseYM(env);
	Add_NoiseUV(env);
    return "HDRNoise Library";
}
