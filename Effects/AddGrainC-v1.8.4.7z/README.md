### AddGrainC ###

An AviSynth plugin

AddGrain generates film like grain or other effects (like rain) by adding
random noise to a video clip.  This noise may optionally be horizontally 
or vertically correlated to cause streaking.

