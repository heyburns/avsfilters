http://forum.doom9.org/showpost.php?p=1864406&postcount=55
