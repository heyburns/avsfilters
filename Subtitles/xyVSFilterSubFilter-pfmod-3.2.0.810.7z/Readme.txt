To Install:
Right-click Install_XySubFilter.bat and select "Run as administrator"

To Uninstall:
Right-click Uninstall_XySubFilter.bat and select "Run as administrator"

Batch files are duplicated to the x86/x64 folders