#include <stdio.h>
#include <windows.h>
#include "avisynth.h"

/*void debug(const char* a, ...) {
  char string[1024];
	va_list args;

	va_start(args,a);
  vsprintf_s(string,a,args);
	va_end(args);

  OutputDebugString(string);
}*/

class waveform : public GenericVideoFilter {   
public:
	waveform(PClip _child, int _window, double _channel_heightf, bool _under, double _amplify, IScriptEnvironment* env);
  ~waveform();
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
private:
  int last_n;
  int channel_height;
  double channel_heightf;
  int src_height;
  int dst_height;
  int channels;
  int window;
  bool under;
  double amplify;
  int waveframes;
  int bytes_per_sample;
  int samples_per_frame;
  int samples_per_frame_over;
  int pixels_per_audioframe;
  int pixel_shift;
  int log_samples_per_pixel;
  int* first_sample;
  int** waves;
  void* buffer;
  int* total;
  float* ftotal;
  void fill_allframes(int n, IScriptEnvironment* env);
  void waveform::fill_frame(int n, int w, IScriptEnvironment* env);
	void temp(int n, IScriptEnvironment* env);
  int darker;
};

waveform::waveform(PClip _child, int _window, double _channel_heightf, bool _under, double _amplify, IScriptEnvironment* env) : GenericVideoFilter(_child), window(_window), channel_heightf(_channel_heightf), under(_under), amplify(_amplify) {
  int i,x;

  last_n=-2;

  src_height=vi.height;
  if (window<0) window=0;

  if (!vi.IsYV12() && !vi.IsYUY2() && !vi.IsRGB24() && !vi.IsRGB32()) env->ThrowError("waveform: colorspace currently not supported");

  channels=vi.AudioChannels();

  if (channel_heightf<=0) channel_heightf=0.333;

  if (channel_heightf<=1) channel_height=(int)((src_height*channel_heightf)/channels);
  else channel_height=(int)channel_heightf;

  if (channel_height<2) channel_height=2;

  if (!under && channel_height*channels>src_height) channel_height=src_height/channels;

  if (under) vi.height+=(channel_height*channels+1)&~1;
  dst_height=vi.height;

  waveframes=(window<<1)+1;
  pixels_per_audioframe=(int)(vi.width*(1.0/waveframes));
  if (pixels_per_audioframe*waveframes<vi.width) pixels_per_audioframe++;
  pixel_shift=(pixels_per_audioframe*waveframes-vi.width)>>1;

  bytes_per_sample=vi.BytesPerAudioSample();
  samples_per_frame=(int)vi.AudioSamplesFromFrames(1);

	log_samples_per_pixel=0;
  while (1<<log_samples_per_pixel<(samples_per_frame/pixels_per_audioframe)) log_samples_per_pixel++;

  first_sample=(int*)malloc(pixels_per_audioframe*sizeof(int));
  for (x=0; x<pixels_per_audioframe; x++) {
    first_sample[x]=(int)(x*(samples_per_frame*(1.0/pixels_per_audioframe))+0.5);
  }
  samples_per_frame_over=first_sample[x-1]+(1<<log_samples_per_pixel);

  waves=(int**)malloc(channels*sizeof(int*));
  waves[0]=(int*)malloc(pixels_per_audioframe*waveframes*channels*sizeof(int));
  for (i=1; i<channels; i++) waves[i]=waves[i-1]+pixels_per_audioframe*waveframes;

  buffer=(void*)malloc(samples_per_frame_over*bytes_per_sample*2);

  total=(int*)malloc(channels*sizeof(int));
  ftotal=(float*)malloc(channels*sizeof(float));

  darker=144;

  if (channels==0) {
    AVSValue args[4] = { child, "waveform: no audio", 5, 0x00ffffff };
    const char* names[4] = { 0, 0, "align", "text_color" };
    child=env->Invoke("subtitle",AVSValue(args,4),names).AsClip();
  }
}

waveform::~waveform() {
  free(waves[0]);
  free(waves);
  free(buffer);
  free(total);
  free(first_sample);
}

void waveform::fill_frame(int n, int w, IScriptEnvironment* env) {
  int x,c,s;
  int p;
  int offset=pixels_per_audioframe*w;
  double multiplier;
  int temp;

	child->GetAudio(buffer, vi.AudioSamplesFromFrames(n), samples_per_frame_over, env);

	if (vi.SampleType()==SAMPLE_INT8) {
    multiplier=channel_height*(1.0/256);

    for (x=0; x<pixels_per_audioframe; x++) {
      for (c=0; c<channels; c++) total[c]=0;
      p=first_sample[x]*channels;
      for (s=0; s<(1<<log_samples_per_pixel); s++) {
        for (c=0; c<channels; c++) total[c]+=((unsigned char*)buffer)[p++];
      }
      for (c=0; c<channels; c++) waves[c][offset+x]=max(0,min(channel_height,(int)((total[c]>>log_samples_per_pixel)*multiplier)));
    }
  } else if (vi.SampleType()==SAMPLE_INT16) {
    multiplier=channel_height*(1.0/65536)*amplify;

    for (x=0; x<pixels_per_audioframe; x++) {
      for (c=0; c<channels; c++) total[c]=0;
      p=first_sample[x]*channels;
      for (s=0; s<(1<<log_samples_per_pixel); s++) {
        for (c=0; c<channels; c++) total[c]+=((short*)buffer)[p++];
      }
      for (c=0; c<channels; c++) waves[c][offset+x]=max(0,min(channel_height,(int)((total[c]>>log_samples_per_pixel)*multiplier+channel_height*0.5)));
    }
  } else if (vi.SampleType()==SAMPLE_FLOAT) {
    multiplier=channel_height*0.5*(1.0/(1<<log_samples_per_pixel))*amplify;

    for (x=0; x<pixels_per_audioframe; x++) {
      for (c=0; c<channels; c++) ftotal[c]=0;
      p=first_sample[x]*channels;
      for (s=0; s<(1<<log_samples_per_pixel); s++) {
        for (c=0; c<channels; c++) {
          ftotal[c]+=((float*)buffer)[p++];
        }
      }
      for (c=0; c<channels; c++) waves[c][offset+x]=max(0,min(channel_height,(int)(ftotal[c]*multiplier+channel_height*0.5)));
    }
  } else if (vi.SampleType()==SAMPLE_INT32) {
    multiplier=channel_height*(1.0/65536)*amplify;

    for (x=0; x<pixels_per_audioframe; x++) {
      for (c=0; c<channels; c++) total[c]=0;
      p=first_sample[x]*channels;
      for (s=0; s<(1<<log_samples_per_pixel); s++) {
        for (c=0; c<channels; c++) total[c]+=((int*)buffer)[p++]>>16;
      }
      for (c=0; c<channels; c++) waves[c][offset+x]=max(0,min(channel_height,(int)((total[c]>>log_samples_per_pixel)*multiplier+channel_height*0.5)));
    }
  } else if (vi.SampleType()==SAMPLE_INT24) {
    multiplier=channel_height*(1.0/65536);

    for (x=0; x<pixels_per_audioframe; x++) {
      for (c=0; c<channels; c++) total[c]=0;
      p=first_sample[x]*channels*3;
      for (s=0; s<(1<<log_samples_per_pixel); s++) {
        for (c=0; c<channels; c++) {
          p++;
          temp=((char*)buffer)[p++];
          temp+=((char*)buffer)[p++]<<8;
          total[c]+=temp;
        }
      }
      for (c=0; c<channels; c++) waves[c][offset+x]=max(0,min(channel_height,(int)((total[c]>>log_samples_per_pixel)*multiplier+channel_height*0.5)));
    }
  }
}

void waveform::fill_allframes(int n, IScriptEnvironment* env) {
  for (int i=0; i<waveframes; i++) fill_frame(-window+n+i,i,env);
}

PVideoFrame __stdcall waveform::GetFrame(int n, IScriptEnvironment* env) {
  int x,y,c,i,ty;
  BYTE* p;
  unsigned int* ip;

  int col=darker;
  int l1=max(0,-pixel_shift+window*pixels_per_audioframe);
  int l2=min(vi.width,l1+pixels_per_audioframe);
  int ll=l1;

	PVideoFrame src=child->GetFrame(n,env);
  if (channels==0) return src;

  PVideoFrame dst=env->NewVideoFrame(vi);

  int cut_off=dst_height-channels*channel_height;

  if (n==last_n+1) { // one frame forward from last time
		memmove(waves[0],waves[0]+pixels_per_audioframe,pixels_per_audioframe*(channels*waveframes-1)*sizeof(int));
    fill_frame(n+window,waveframes-1,env);
  } else if (n==last_n-1) {// one frame back from last time
    memmove(waves[0]+pixels_per_audioframe,waves[0],pixels_per_audioframe*(channels*waveframes-1)*sizeof(int));
    fill_frame(n-window,0,env);
  } else {
    fill_allframes(n, env);
  }
  last_n=n;

  int row_bytes=src->GetRowSize();

/*************************************************************************
 * YV12
 *************************************************************************/

  if (vi.IsYV12()) {
    int src_pitch=src->GetPitch();
    int src_pitch_u=src->GetPitch(PLANAR_U);
    int src_pitch_v=src->GetPitch(PLANAR_V);
    const BYTE* srcp=src->GetReadPtr();
    const BYTE* srcp_u=src->GetReadPtr(PLANAR_U);
    const BYTE* srcp_v=src->GetReadPtr(PLANAR_V);

    int dst_pitch=dst->GetPitch();
    int dst_pitch_u=dst->GetPitch(PLANAR_U);
    int dst_pitch_v=dst->GetPitch(PLANAR_V);
    BYTE* dstp=dst->GetWritePtr();
    BYTE* dstp_u=dst->GetWritePtr(PLANAR_U);
    BYTE* dstp_v=dst->GetWritePtr(PLANAR_V);

// copy source luma
    for (y=0; y<cut_off; y++) {
      memcpy(dstp,srcp,row_bytes);
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    for (; y<src_height; y++) {
      for (x=0; x<row_bytes; x++) dstp[x]=srcp[x]>>1;
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    if (y!=dst_height) {
      memset(dstp,0,(dst_height-src_height)*src_pitch-(src_pitch-row_bytes));
    }

// draw lines
    dstp=dst->GetWritePtr();

    for (i=0; i<channels-1; i++) {
      p=dstp+(dst_height-(i+1)*channel_height)*dst_pitch;
      for (x=0; x<row_bytes; x++) *p+++=64;
    }

    if (window!=0) {
      for (i=-2; i<waveframes-1; i++) {
        if (i==-2) x=-pixel_shift+pixels_per_audioframe*(window)-4;
        else if (i==-1) x=-pixel_shift+pixels_per_audioframe*(window+1)+4;
        else x=-pixel_shift+pixels_per_audioframe*(i+1);

        p=dstp+x+cut_off*dst_pitch;
        for (y=cut_off; y<dst_height; y++) {
          *p+=32;
          p+=dst_pitch;
        }
      }
    }

// copy uv
    cut_off=cut_off>>1;

    for (y=0; y<cut_off; y++) {
      memcpy(dstp_u,srcp_u,src->GetRowSize(PLANAR_U));
      memcpy(dstp_v,srcp_v,src->GetRowSize(PLANAR_V));
      dstp_u+=dst_pitch_u; srcp_u+=src_pitch_u;
      dstp_v+=dst_pitch_v; srcp_v+=src_pitch_v;
    }

    for (; y<src_height>>1; y++) {
      for (x=0; x<src->GetRowSize(PLANAR_U); x++) {
        dstp_u[x]=0x40+(srcp_u[x]>>1);
        dstp_v[x]=0x40+(srcp_v[x]>>1);
      }
      dstp_u+=dst_pitch_u; srcp_u+=src_pitch_u;
      dstp_v+=dst_pitch_v; srcp_v+=src_pitch_v;
    }

    if (y!=dst_height>>1) {
      memset(dstp_u,0x80,((dst_height-src_height)>>1)*dst_pitch_u-(dst_pitch_u-dst->GetRowSize(PLANAR_U)));
      memset(dstp_v,0x80,((dst_height-src_height)>>1)*dst_pitch_v-(dst_pitch_v-dst->GetRowSize(PLANAR_V)));
    }

// draw waves
    for (c=0; c<channels; c++) {
      total[c]=(dst_height-1)-(channels-1-c)*channel_height-waves[c][pixel_shift+0];
    }

    x=0;
    while (x<vi.width) {
      if (x==l1) { col=255; ll=l2; }
      if (x==l2) { col=darker; ll=vi.width; }

      for (; x<ll; x++) {
        for (c=0; c<channels; c++) {
          y=(dst_height-1)-(channels-1-c)*channel_height-waves[c][pixel_shift+x];
          if (total[c]==y) dstp[y*dst_pitch+x]=col; else {
            if (total[c]<y) for (ty=total[c]+1; ty<=y; ty++) dstp[ty*dst_pitch+x]=col; else for (ty=y; ty<total[c]; ty++) dstp[ty*dst_pitch+x]=col;
            total[c]=y;
          }
        }
      }
    }
  }

/*************************************************************************
 * YUY2
 *************************************************************************/

  else if (vi.IsYUY2()) {
// copy/darker
    int src_pitch=src->GetPitch();
    const BYTE* srcp=src->GetReadPtr();

    int dst_pitch=dst->GetPitch();
    BYTE* dstp=dst->GetWritePtr();

    for (y=0; y<cut_off; y++) {
      memcpy(dstp,srcp,row_bytes);
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    for (; y<src_height; y++) {
      for (x=0; x<vi.width>>1; x++) {
        ((unsigned int*)dstp)[x]=((((unsigned int*)srcp)[x]>>1)&0x7f7f7f7f)+0x40004000;
      }
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    for (; y<dst_height; y++) {
      for (x=0; x<dst_pitch>>2; x++) {
        ((unsigned int*)dstp)[x]=0x80008000;
      }
      dstp+=dst_pitch;
    }

// lines
    dstp=dst->GetWritePtr();

    for (i=0; i<channels-1; i++) {
      ip=(unsigned int*)(dstp+(dst_height-(i+1)*channel_height)*dst_pitch);
      for (x=0; x<vi.width>>1; x++) *ip+++=0x00400040;
    }

    if (window!=0) {
      for (i=-2; i<waveframes-1; i++) {
        if (i==-2) x=-pixel_shift+pixels_per_audioframe*(window)-4;
        else if (i==-1) x=-pixel_shift+pixels_per_audioframe*(window+1)+4;
        else x=-pixel_shift+pixels_per_audioframe*(i+1);

        p=dstp+(x<<1)+cut_off*dst_pitch;
        for (y=cut_off; y<dst_height; y++) {
          *p+=32;
          p+=dst_pitch;
        }
      }
    }

// draw waves
    for (c=0; c<channels; c++) {
      total[c]=(dst_height-1)-(channels-1-c)*channel_height-waves[c][pixel_shift+0];
    }

    x=0;
    while (x<vi.width) {
      if (x==l1) { col=255; ll=l2; }
      if (x==l2) { col=darker; ll=vi.width; }
      for (; x<ll; x++) {
        for (c=0; c<channels; c++) {
          y=(dst_height-1)-(channels-1-c)*channel_height-waves[c][pixel_shift+x];
          if (total[c]==y) dstp[y*dst_pitch+(x<<1)]=col; else {
            if (total[c]<y) for (ty=total[c]+1; ty<=y; ty++) dstp[ty*dst_pitch+(x<<1)]=col; else for (ty=y; ty<total[c]; ty++) dstp[ty*dst_pitch+(x<<1)]=col;
            total[c]=y;
          }
        }
      }
    }
  }

/*************************************************************************
 * RGB24
 *************************************************************************/

  else if (vi.IsRGB24()) {
    int src_pitch=src->GetPitch();
    const BYTE* srcp=src->GetReadPtr();

    int dst_pitch=dst->GetPitch();
    BYTE* dstp=dst->GetWritePtr();

    for (y=dst_height-1; y>=src_height; y--) {
      memset(dstp,0,row_bytes);
      dstp+=dst_pitch;
    }

    for (; y>=cut_off; y--) {
      for (x=0; x<dst_pitch>>2; x++) {
        ((unsigned int*)dstp)[x]=(((unsigned int*)srcp)[x]>>1)&0x7f7f7f7f;
      }
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    for (; y>=0; y--) {
      memcpy(dstp,srcp,row_bytes);
      dstp+=dst_pitch; srcp+=src_pitch;
    }

// lines
    dstp=dst->GetWritePtr();

    for (i=0; i<channels-1; i++) {
      ip=(unsigned int*)(dstp+(i+1)*channel_height*dst_pitch);
      for (x=0; x<dst_pitch>>2; x++) *ip+++=0x40404040;
    }

    if (window!=0) {
      for (i=-2; i<waveframes-1; i++) {
        if (i==-2) x=-pixel_shift+pixels_per_audioframe*(window)-4;
        else if (i==-1) x=-pixel_shift+pixels_per_audioframe*(window+1)+4;
        else x=-pixel_shift+pixels_per_audioframe*(i+1);

        p=dstp+x*3;
        for (y=0; y<dst_height-cut_off; y++) {
          p[0]+=32; p[1]+=32; p[2]+=32;
          p+=dst_pitch;
        }
      }
    }

// draw waves
    for (c=0; c<channels; c++) {
      total[c]=c*channel_height+waves[c][pixel_shift+0];
    }

    x=0;
    while (x<vi.width) {
      if (x==l1) { col=255; ll=l2; }
      if (x==l2) { col=darker; ll=vi.width; }

      for (; x<ll; x++) {
        for (c=0; c<channels; c++) {
          y=c*channel_height+waves[c][pixel_shift+x];
          if (total[c]==y) {
            p=&dstp[y*dst_pitch+x*3];
            *p++=col; *p++=col; *p++=col;
          } else {
            if (total[c]<y) {
              for (ty=total[c]+1; ty<=y; ty++) {
                p=&dstp[ty*dst_pitch+x*3];
                *p++=col; *p++=col; *p++=col;
              }
            } else {
              for (ty=y; ty<total[c]; ty++) {
                p=&dstp[ty*dst_pitch+x*3];
                *p++=col; *p++=col; *p++=col;
              }
            }
            total[c]=y;
          }
        }
      }
    }
  }

/*************************************************************************
 * RGB32
 *************************************************************************/

  else if (vi.IsRGB32()) {
    int src_pitch=src->GetPitch();
    const BYTE* srcp=src->GetReadPtr();

    int dst_pitch=dst->GetPitch();
    BYTE* dstp=dst->GetWritePtr();

    for (y=dst_height-1; y>=src_height; y--) {
      memset(dstp,0,row_bytes);
      dstp+=dst_pitch;
    }

    for (; y>=cut_off; y--) {
      for (x=0; x<dst_pitch>>2; x++) {
        ((unsigned int*)dstp)[x]=(((unsigned int*)srcp)[x]>>1)&0x7f7f7f7f;
      }
      dstp+=dst_pitch; srcp+=src_pitch;
    }

    for (; y>=0; y--) {
      memcpy(dstp,srcp,row_bytes);
      dstp+=dst_pitch; srcp+=src_pitch;
    }

// lines
    dstp=dst->GetWritePtr();

    for (i=0; i<channels-1; i++) {
      ip=(unsigned int*)(dstp+(i+1)*channel_height*dst_pitch);
      for (x=0; x<dst_pitch>>2; x++) *ip+++=0x40404040;
    }

    if (window!=0) {
      for (i=-2; i<waveframes-1; i++) {
        if (i==-2) x=-pixel_shift+pixels_per_audioframe*(window)-4;
        else if (i==-1) x=-pixel_shift+pixels_per_audioframe*(window+1)+4;
        else x=-pixel_shift+pixels_per_audioframe*(i+1);

        ip=(unsigned int*)(dstp+(x<<2));
        for (y=0; y<dst_height-cut_off; y++) {
          *ip+=0x20202020;
          ip+=(dst_pitch>>2);
        }
      }
    }

// draw waves
    for (c=0; c<channels; c++) {
      total[c]=c*channel_height+waves[c][pixel_shift+0];
    }

    darker=darker<<8|darker;
    darker=darker<<16|darker;
    col=darker;

    x=0;
    while (x<vi.width) {
      if (x==l1) { col=0xffffffff; ll=l2; }
      if (x==l2) { col=darker; ll=vi.width; }

      for (; x<ll; x++) {
        for (c=0; c<channels; c++) {
          y=c*channel_height+waves[c][pixel_shift+x];
          if (total[c]==y) {
            ip=(unsigned int*)&dstp[y*dst_pitch+(x<<2)];
            *ip=col;
          } else {
            if (total[c]<y) {
              for (ty=total[c]+1; ty<=y; ty++) {
                ip=(unsigned int*)&dstp[ty*dst_pitch+(x<<2)];
                *ip=col;
              }
            } else {
              for (ty=y; ty<total[c]; ty++) {
                ip=(unsigned int*)&dstp[ty*dst_pitch+(x<<2)];
                *ip=col;
              }
            }
            total[c]=y;
          }
        }
      }
    }
  }

  return dst;
}

AVSValue __cdecl Create_waveform(AVSValue args, void* user_data, IScriptEnvironment* env) {
  return new waveform(
    args[0].AsClip(),
    args[1].AsInt(0),
    args[2].AsFloat(0),
    args[3].AsBool(false),
    args[4].AsFloat(1),
		env
  );
}

const AVS_Linkage *AVS_linkage = 0;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, AVS_Linkage* vectors) {
  env->AddFunction("waveform", "c[window]i[height]f[under]b[zoom]f", Create_waveform, 0);
  AVS_linkage = vectors;

  return "waveform";
}
