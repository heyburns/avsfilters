
#ifndef __FILTERED_EWA_RESIZE_H
#define __FILTERED_EWA_RESIZE_H

#pragma warning(push)
#pragma warning(disable: 4512 4244 4100 693)
#include "avisynth.h"
#pragma warning(pop)

#include <stdint.h>
#include "fftw3lite.h"
#include <windows.h>

static void _____cache_deleter_prototype(void* T);

// Standard direct-mapping cache code
template<typename T, size_t size>
class CacheManager
{
public:
  CacheManager(decltype(_____cache_deleter_prototype) *deleter)
    : deleter(deleter)
  {
    cache = new T*[size];
    ids = new size_t[size];
    for (int i = 0; i < size; i++) {
      ids[i] = SIZE_MAX;
      cache[i] = nullptr;
    }
  }

  ~CacheManager()
  {
    for (int i = 0; i < size; i++)
      if (ids[i] != SIZE_MAX)
        deleter(cache[i]);
    delete[] cache;
    delete[] ids;
  }

  void Put(size_t id, T* data)
  {
    const int mod_id = id % size;

    if (ids[mod_id] != SIZE_MAX)
      deleter(cache[mod_id]);

    cache[mod_id] = data;
    ids[mod_id] = id;
  }

  T* Get(size_t id)
  {
    const int mod_id = id % size;

    if (ids[mod_id] != id)
      return nullptr;
    return cache[mod_id];
  }


private:
  T** cache;
  size_t* ids;
  decltype(_____cache_deleter_prototype) *deleter;
};

class Spectrogram : public GenericVideoFilter
{
public:
  Spectrogram(PClip _child, int width, int height, bool transpose, IScriptEnvironment* env);
  virtual ~Spectrogram();
  PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env) override;

private:


  HINSTANCE hinstFFTW3;
  fftwf_malloc_proc fftwf_malloc;
  fftwf_free_proc fftwf_free;
  fftwf_destroy_plan_proc fftwf_destroy_plan;
  fftwf_execute_plan_proc fftwf_execute;
  fftwf_plan_dft_r2c_1d_proc fftwf_plan_dft_r2c_1d;

  int width, height;

  int bin_size;

  fftwf_complex* fft_output;
  float* fft_input;
  fftwf_plan plan;

  CacheManager<uint8_t, 8192> line_cache;
  CacheManager<float, 4096> aud_cache;

  bool transpose;
};

#endif
