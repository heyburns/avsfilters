    Spectrogram (clip, int width, int height, bool "transpose") 


        clip   =

            Input clip; audio must be float so use ConvertAudioToFloat() if needed. Video can be any colorspace but the output will always be Y8. 
            Frame rate of the spectrogram will always default to the frame rate of the input clip. If the input clip does not contain video then the frame rate will default to 24FPS. 


        int   =

            Width of the spectrogram. 


        int   =

            Height of the spectrogram. For best performance it's recommended that the height is a value of 2^n. 


        bool  transpose = false

            When set to true the spectrogram will be rendered vertically; recommended for larger dimensions. 
            Spectrogram(x, y, transpose=true).TurnLeft() is identical to Spectrogram(x, y, transpose=false) but faster. For better performance use the optimized FTurnLeft() function from the FTurn plugin. 


            Note: the first 3 parameters are unnamed and do not have a default so they must be specified. 

