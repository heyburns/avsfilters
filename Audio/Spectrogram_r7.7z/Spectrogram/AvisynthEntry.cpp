#include <windows.h>

#pragma warning(push)
#pragma warning(disable: 4512 4244 4100 693)
#include "avisynth.h"
#pragma warning(pop)

#include "Spectrogram.h"

AVSValue __cdecl Create_RealSpectrogram(PClip clip, int target_width, int target_height, bool transpose,const AVSValue* args, IScriptEnvironment* env)
{
  const auto& vi = clip->GetVideoInfo();
  
  if (!vi.HasAudio()) {
    env->ThrowError("Spectrogram: No audio available");
  } else if (!vi.IsSampleType(SAMPLE_FLOAT)) {
    env->ThrowError("Spectrogram: Please convert to float before calling this filter");
  }

  return new Spectrogram(clip, target_width, target_height, transpose, env);
}

AVSValue __cdecl Create_Spectrogram(AVSValue args, void* user_data, IScriptEnvironment* env)
{
  return Create_RealSpectrogram(args[0].AsClip(), args[1].AsInt(640), args[2].AsInt(480), args[3].AsBool(false), &args[4], env);
}

const AVS_Linkage *AVS_linkage = nullptr;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors)
{
  AVS_linkage = vectors;

  env->AddFunction("Spectrogram", "c[width]i[height]i[transpose]b", Create_Spectrogram, 0);

  return "Hey it is just a spectrogram!";
}