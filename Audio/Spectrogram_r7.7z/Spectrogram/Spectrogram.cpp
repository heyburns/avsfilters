#include "avisynth.h"
#include "Spectrogram.h"

#include "pmmintrin.h"

#include <stdlib.h>
#include <math.h>
#include <strstream>

static void fill_audio_sample_select(float* out, float* in, int channel, int all_channel, int n);
static void fill_video_line_select(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n);
static void fill_video_line_transpose_select(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n);
static void convert_to_byte_select(const fftwf_complex* data, uint8_t* out, int n);
static void clear_frame_y8(BYTE* buffer, int pitch, int width, int height);

static decltype(fill_audio_sample_select) *fill_audio_sample         = fill_audio_sample_select;
static decltype(fill_video_line_select)   *fill_video_line           = fill_video_line_select;
static decltype(fill_video_line_select)   *fill_video_line_transpose = fill_video_line_transpose_select;
static decltype(convert_to_byte_select)   *convert_to_byte           = convert_to_byte_select;

static int CPU_FLAG;

//////////////////////////////
// Utilities
//////////////////////////////

template<typename T>
T clamp(T a, T v, T b) {
  return v < a ? a : (v > b ? b : v);
}

static __int64 round_down_to_multiple_of(__int64 v, __int64 m) {
  return (v / m) * m;
}

static void aligned_deleter(void* s) {
  _aligned_free(s);
}


//////////////////////////////
// Functions
//////////////////////////////

static void clear_frame_y8(BYTE* buffer, int pitch, int width, int height)
{
  memset(buffer, 0, pitch*height);
}

static void fill_audio_sample_c(float* out, float* in, int channel, int all_channel, int n)
{
  for (int i = 0; i < n; i++) {
    out[i] = in[i*all_channel + channel];
  }
}

static void fill_audio_sample_mono(float* out, float* in, int channel, int all_channel, int n)
{
  memcpy(out, in, sizeof(float)*n);
}

static void fill_audio_sample_stereo(float* out, float* in, int channel, int all_channel, int n)
{
  for (int i = 0; i < n; i++) {
    out[i] = in[i * 2 + channel];
  }
}

static void fill_audio_sample_select(float* out, float* in, int channel, int all_channel, int n)
{
  if (all_channel == 1) {
    fill_audio_sample = fill_audio_sample_mono;
  } else if (all_channel == 2) {
    fill_audio_sample = fill_audio_sample_stereo;
  } else {
    fill_audio_sample = fill_audio_sample_c;
  }
  fill_audio_sample(out, in, channel, all_channel, n);
}

static void fill_video_line_c(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n)
{
  buffer += from_row*pitch;
  for (auto i = n - 1; i >= 0; i--) {
    buffer[column] = data[i];
    buffer += pitch;
  }
}

static void fill_video_line_select(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n)
{
  fill_video_line = fill_video_line_c;
  fill_video_line(data, buffer, pitch, from_row, column, n);
}

static void fill_video_line_transpose_c(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n)
{
  buffer += column*pitch;
  buffer += from_row;
  memcpy(buffer, data, n);
}

static void fill_video_line_transpose_select(const uint8_t* data, BYTE* buffer, int pitch, int from_row, int column, int n)
{
  fill_video_line_transpose = fill_video_line_transpose_c;
  fill_video_line(data, buffer, pitch, from_row, column, n);
}

static void convert_to_byte_c(const fftwf_complex* data, uint8_t* out, int n)
{
  for (int i = 0; i < n; i++) {
    out[i] = int(clamp(0.f, sqrt(data[i][0] * data[i][0] + data[i][1] * data[i][1]), 1.f) * 255.f + 0.5f);
  }
}

static void convert_to_byte_sse3(const fftwf_complex* data, uint8_t* out, int n)
{
  const auto mod4 = (n / 4) * 4;
  const auto factor = 255.f;

  const __m128i zero = _mm_setzero_si128();
  const __m128 mul_factor = _mm_load1_ps(&factor);

  for (int i = 0; i < mod4; i += 4) {
    __m128 a = _mm_load_ps(reinterpret_cast<const float*>(data + i));
    __m128 b = _mm_load_ps(reinterpret_cast<const float*>(data + i + 2));

    a = _mm_mul_ps(a, a);
    b = _mm_mul_ps(b, b);

    __m128 r = _mm_hadd_ps(a, b);
    r = _mm_sqrt_ps(r);
    r = _mm_mul_ps(r, mul_factor);

    // Convert to int
    __m128i ri = _mm_cvtps_epi32(r);
    ri = _mm_packs_epi32(ri, zero);
    ri = _mm_packus_epi16(ri, zero);

    // Store
    int result = _mm_cvtsi128_si32(ri);

    // Real store
    *((uint32_t*) (out + i)) = result;
  }

  for (auto i = mod4; i < n; i++) {
    out[i] = int(clamp(0.f, sqrt(data[i][0] * data[i][0] + data[i][1] * data[i][1]), 1.f) * 255.f + 0.5f);
  }
}

static void convert_to_byte_select(const fftwf_complex* data, uint8_t* out, int n)
{
  if (CPU_FLAG & CPUF_SSE3)
    convert_to_byte = convert_to_byte_sse3;
  else
    convert_to_byte = convert_to_byte_c;

  convert_to_byte(data, out, n);
}

//////////////////////////////
// Code
//////////////////////////////

Spectrogram::Spectrogram(PClip _child, int width, int height, bool transpose, IScriptEnvironment* env)
  : GenericVideoFilter(_child), width(width), height(height), line_cache(aligned_deleter), aud_cache(aligned_deleter), transpose(transpose)
{
  if (!vi.HasVideo()) {
    vi.fps_numerator = 24;
    vi.fps_denominator = 1;
    vi.SetFieldBased(false);
    vi.num_frames = int((vi.num_audio_samples / vi.audio_samples_per_second) * 24.f + 0.5f);
  }

  vi.width = width;
  vi.height = height;

  vi.pixel_type = VideoInfo::CS_Y8;

  if (transpose) {
    std::swap(this->width, this->height);
    std::swap(vi.width, vi.height);
  }

  hinstFFTW3 = ::LoadLibrary(L"libfftw3f-3.dll"); // delayed loading, original name
  if (hinstFFTW3 == NULL)
    hinstFFTW3 = ::LoadLibrary(L"fftw3.dll"); // delayed loading
  if (hinstFFTW3 == NULL)
  {
    env->ThrowError("Spectrogram: Can not load libfftw3f-3.dll or fftw3.DLL!");
  }

  fftwf_malloc = (fftwf_malloc_proc)GetProcAddress(hinstFFTW3, "fftwf_malloc");
  fftwf_free = (fftwf_free_proc)GetProcAddress(hinstFFTW3, "fftwf_free");
  fftwf_destroy_plan = (fftwf_destroy_plan_proc)GetProcAddress(hinstFFTW3, "fftwf_destroy_plan");
  fftwf_execute = (fftwf_execute_plan_proc)GetProcAddress(hinstFFTW3, "fftwf_execute");
  fftwf_plan_dft_r2c_1d = (fftwf_plan_dft_r2c_1d_proc)GetProcAddress(hinstFFTW3, "fftwf_plan_dft_r2c_1d");

  bin_size = 2 * height / vi.AudioChannels();

  fft_input = (float*) fftwf_malloc(sizeof(float) * bin_size);
  fft_output = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * (bin_size / 2 + 1));
  plan = fftwf_plan_dft_r2c_1d(bin_size, fft_input, fft_output, FFTW_PATIENT);

  CPU_FLAG = env->GetCPUFlags();
}

Spectrogram::~Spectrogram()
{
  fftwf_destroy_plan(plan);
  fftwf_free(fft_input);
  fftwf_free(fft_output);
}

PVideoFrame __stdcall Spectrogram::GetFrame(int n, IScriptEnvironment* env)
{
  PVideoFrame frame = env->NewVideoFrame(vi);
  float* buffer;

  // Clear frame
  clear_frame_y8(frame->GetWritePtr(), frame->GetPitch(), width, height);

  const int output_size = bin_size / 2;

  int current_column = (transpose ? height : width) - 1;
  __int64 current_sample = round_down_to_multiple_of(vi.AudioSamplesFromFrames(n) + vi.AudioSamplesFromFrames(1) - bin_size/2, bin_size);

  while (current_sample >= 0 && current_column >= 0) {
    // Fill audio buffer
    const int aud_cache_id = current_sample / bin_size;
    buffer = aud_cache.Get(aud_cache_id);

    const int channel = vi.AudioChannels();
    const int cache_id_base = aud_cache_id * channel;
    for (int i = 0; i < channel; i++) {
      uint8_t* data = line_cache.Get(cache_id_base + i);
      if (data == nullptr) {
        if (buffer == nullptr) {
          const int alloc_size = sizeof(float) * bin_size * vi.AudioChannels();
          buffer = (float*) _aligned_malloc(alloc_size, 16);

          child->GetAudio(buffer, current_sample, bin_size, env);
          aud_cache.Put(aud_cache_id, buffer);
        }
        fill_audio_sample(fft_input, buffer, i, channel, bin_size);
        fftwf_execute(plan);

        data = (uint8_t*) _aligned_malloc(sizeof(uint8_t) * output_size, 16);
        convert_to_byte(fft_output, data, output_size);

        // Store to cache
        line_cache.Put(cache_id_base + i, data);
      }

      if (transpose)
        fill_video_line_transpose(data, frame->GetWritePtr(), frame->GetPitch(), output_size*i, current_column, output_size);
      else
        fill_video_line(data, frame->GetWritePtr(), frame->GetPitch(), output_size*i, current_column, output_size);
    }

    // Loop
    current_sample -= bin_size;
    current_column--;
  }

  return frame;
}
