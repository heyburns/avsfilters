BassAudio.dll by BeHappy team:

BassAudio.dll   2.4.10   Interface to open Bass Audio libraries v2.4.10 in AviSynth

The rest of bass*.dll are included because problems with name and old versions,
if owners don't authorize this distribution I can delete the files.

The oficial releases v2.4 are in http://www.un4seen.com/bass.html

bass.dll        2.4.10   16/02/2013 Main bass library, to open WAVE_FORMAT_EXTENSIBLE, mp2, mp3, ogg, ...
bass_aac.dll    2.4.4    11/06/2013 Optional to read AAC/MA4/MP4.
bass_ape.dll    2.4.2    25/11/2014 Optional to read APE Monkey audio.
bass_cda.dll    2.4.6    11/06/2014 Optional to read CD Audio.
bass_flac.dll   2.4.2    28/11/2014 Optional to read Flac until v1.3
bass_mpc.dll    2.4.1.2  13/11/2013 Optional to read MPC, MusePack.
bass_spx.dll    2.4.3    11/12/2014 Optional to read SPX, MusePack.
bass_tta.dll    2.4.0    27/02/2008 Optional to read TTA, True Audio encoder.
bass_wma.dll    2.4.5    20/10/2014 Optional to read WMA, Windows Media Audio.
bass_wv.dll     2.4.5    22/07/2014 Optional to read WV, WavPack Audio.
bass_opus.dll   2.4.1.3  12/12/2013 Optional to read Opus.