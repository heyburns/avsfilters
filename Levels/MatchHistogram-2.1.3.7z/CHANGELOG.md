##### 2.1.3:
    Throw error for non-planar formats.

##### 2.1.2:
    Now clip3 is optional.
    Registered as MT_NICE_FILTER.

##### 2.1.1:
    Fixed memory misalignment for AviSynth 2.6.

##### 2.1.0:
    Added support for v8 interface.
    
##### 2.0.0:
    Port of the VapourSynth plugin MatchHistogram v2.