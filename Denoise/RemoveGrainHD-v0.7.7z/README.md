# RemoveGrainHD

A collection of  Avisynth denoising filters by Rainer Wittmann

Port of classic RemoveGrainHD 0.5 to Avisynth v2.6 interface (x86/x64)

Note: Previous v0.5 DLL version named RemoveGraindHDS.dll must be deleted to avoid collision


Avisynth wiki: http://avisynth.nl/index.php/RemoveGrainHD

