These files are provided as-is, they are not updated or organized in any way since ages.
Updating them is on a todo-list (August, 2019)