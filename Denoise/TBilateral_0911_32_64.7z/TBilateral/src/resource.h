//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TBilateral.rc
//
#define IDPREVIEW                       3
#define IDD_DIALOG1                     9
#define IDD_MAIN                        9
#define IDI_ICON1                       102
#define IDD_ADVANCED                    103
#define IDD_TABHOLD                     104
#define IDC_DIAMETERLS                  1001
#define IDC_DIAMETERL                   1002
#define IDC_DIAMETERLV                  1009
#define IDC_DIAMETERCS                  1010
#define IDC_DIAMETERCV                  1012
#define IDC_DIAMETERC                   1014
#define IDC_SDEVLS                      1016
#define IDC_SDEVL                       1017
#define IDC_SDEVLV                      1018
#define IDC_SDEVCS                      1019
#define IDC_SDEVC                       1020
#define IDC_SDEVCV                      1021
#define IDC_IDEVLS                      1022
#define IDC_IDEVL                       1023
#define IDC_IDEVLV                      1024
#define IDC_IDEVCS                      1025
#define IDC_IDEVC                       1026
#define IDC_IDEVCV                      1027
#define IDC_D2                          1028
#define IDC_CSCS                        1035
#define IDC_FPARAM                      1036
#define IDC_IDEVCP                      1041
#define IDC_IDEVCM                      1042
#define IDC_IDEVLP                      1043
#define IDC_IDEVLM                      1044
#define IDC_SDEVCP                      1045
#define IDC_SDEVCM                      1046
#define IDC_SDEVLP                      1047
#define IDC_SDEVLM                      1048
#define IDC_DIAMETERCP                  1049
#define IDC_DIAMETERCM                  1050
#define IDC_DIAMETERLP                  1051
#define IDC_DIAMETERLM                  1052
#define IDC_CHROMA                      1066
#define IDC_CSL                         1067
#define IDC_CSC                         1068
#define IDC_CSLS                        1069
#define IDC_PPCLIP                      1070
#define IDC_AVSSTRING                   1074
#define IDC_IKERND                      1076
#define IDC_SKERND                      1077
#define IDC_SKERNS                      1078
#define IDC_IKERNS                      1079
#define IDC_ADVGROUP                    1080
#define IDC_MAINGROUP                   1081
#define IDC_TABS                        1082
#define IDC_VERSION                     1083
#define IDC_AVGDROP                     1084
#define IDC_RESDROP                     1084
#define IDC_RESTYPES                    1085

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1086
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
