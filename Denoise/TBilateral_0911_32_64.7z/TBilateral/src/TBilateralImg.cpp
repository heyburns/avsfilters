/*
**               TBilateralFilter v0.9.11 for AviSynth 2.5.x
**
**   TBilateral is a spatial smoothing filter that uses the bilateral filtering
**   algorithm.  It does a nice job of smoothing while retaining picture structure.
**   It currently supports YV12 and YUY2 colorspaces.
**   
**   Copyright (C) 2004-2006 Kevin Stone
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 2 of the License, or
**   (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "TBilateral.h"

void TBilateral::ProcessFrameD1(bool guiCall)
{
	if (resType == 0) ProcessFrameD1_Mean(guiCall);
	else if (resType == 3) ProcessFrameD1_MLR(guiCall);
	else ProcessFrameD1_Med(guiCall);
}

void TBilateral::ProcessFrameD2(bool guiCall)
{
	if (resType == 0) ProcessFrameD2_Mean(guiCall);
	else if (resType == 3) ProcessFrameD2_MLR(guiCall);
	else ProcessFrameD2_Med(guiCall);
}

void TBilateral::ProcessFrameD1_Mean(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD1_Mean;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					for (int v=startx; v<=stopx; ++v, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD1_Mean:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}

void TBilateral::ProcessFrameD1_Med(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD1_Med;
	const bool cw = resType == 2 ? true : false;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		const int mid = j == 0 ? diameterL*radiusL+radiusL : diameterC*radiusC+radiusC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS)
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					for (int v=startx; v<=stopx; ++v, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD1_Med:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}

void TBilateral::ProcessFrameD1_MLR(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD1_MLR;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		const int wda = diameter*diameter*sizeof(double);
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		double *pixels = j == 0 ? pixelsL : pixelsC;
		double *weights = j == 0 ? weightsL : weightsC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					stopy-starty+1,0,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					diameter,startxr,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					for (int v=startx; v<=stopx; ++v, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]];
						pixels[w] = srcpT[v];
						weights[w] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					diameter,0,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					diameter,startxr,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					stopy-starty+1,0,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[cP-srcpT[v]];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD1_MLR:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}

void TBilateral::ProcessFrameD2_Mean(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD2_Mean;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			const unsigned char *srcpT2_saved = srcp_saved + stopy*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved;
				const unsigned char *srcpT2 = srcpT2_saved;
				const int cP = (tp[x]+255)<<1;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					int b = stopx;
					for (int v=startx; v<=stopx; ++v, --b, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]-srcpT2[b]];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
					srcpT2 -= src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];	
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double weightedSum = 0.0;
				double sumOfWeights = 0.0;
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						weightedSum += srcpT[v] * weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = int((weightedSum / sumOfWeights) + 0.5);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD2_Mean:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}

void TBilateral::ProcessFrameD2_Med(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD2_Med;
	const bool cw = resType == 2 ? true : false;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		const int mid = j == 0 ? diameterL*radiusL+radiusL : diameterC*radiusC+radiusC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			const unsigned char *srcpT2_saved = srcp_saved + stopy*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved;
				const unsigned char *srcpT2 = srcpT2_saved;
				const int cP = (tp[x]+255)<<1;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					int b = stopx;
					for (int v=startx; v<=stopx; ++v, --b, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]-srcpT2[b]];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
					srcpT2 -= src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				double sum = 0.0;
				memset(medA,0,256*sizeof(double));
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						medA[srcpT[v]] += weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) 
				{
					if (cw)
					{
						const double weight = spatialWeights[mid]*diffWeights[0]*(diameter-1);
						medA[tp[x]] += weight;
						sumOfWeights += weight;
					}
					sumOfWeights *= 0.5;
					int ws = 0;
					while (sum <= sumOfWeights) { sum += medA[ws]; ++ws; }
					dstp[x] = ws-1;
				}
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD2_Med:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}

void TBilateral::ProcessFrameD2_MLR(bool guiCall) 
{
	bool changed = buildTables();
	if (!changed && guiCall) goto finishD2_Mean;
	for (int j=0; j<3; ++j)
	{
		if (!chroma && j != 0) { srcPF->copyChromaTo(*dstPF); j = 3; continue; }
		const unsigned char *srcp = srcPF->GetPtr(j);
		unsigned char *dstp = dstPF->GetPtr(j);
		const int src_pitch = srcPF->GetPitch(j);
		const int dst_pitch = dstPF->GetPitch(j);
		const unsigned char *tp = usePPClip ? ppPF->GetPtr(j) : srcp;
		const int tp_pitch = usePPClip ? ppPF->GetPitch(j) : src_pitch;
		const int width = srcPF->GetWidth(j);
		const int height = srcPF->GetHeight(j);
		const int radius = j == 0 ? radiusL : radiusC;
		const int diameter = j == 0 ? diameterL : diameterC;
		const int wda = diameter*diameter*sizeof(double);
		int stopy = j == 0 ? radiusL : radiusC;
		int startyr = j == 0 ? radiusL*diameterL : radiusC*diameterC;
		const double *spatialWeights = j == 0 ? spatialWeightsL : spatialWeightsC;
		const double *diffWeights = j == 0 ? diffWeightsL : diffWeightsC;
		double *pixels = j == 0 ? pixelsL : pixelsC;
		double *weights = j == 0 ? weightsL : weightsC;
		const unsigned char *srcp_saved = srcp;
		int starty = 0;
		const int midP = width-radius;
		const int midPY = height-radius;
		for (int y=0; y<radius; ++y, startyr-=diameter, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved;
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					stopy-starty+1,0,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (; y<midPY; ++y, ++starty, ++stopy)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			const unsigned char *srcpT2_saved = srcp_saved + stopy*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					diameter,startxr,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (; x<midP; ++x, ++startx, ++stopx)  // free of all boundaries
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved;
				const unsigned char *srcpT2 = srcpT2_saved;
				const int cP = (tp[x]+255)<<1;
				int w = 0;
				for (int u=starty; u<=stopy; ++u)
				{
					int b = stopx;
					for (int v=startx; v<=stopx; ++v, --b, ++w)
					{
						const double weight = spatialWeights[w] * diffWeights[cP-srcpT[v]-srcpT2[b]];
						pixels[w] = srcpT[v];
						weights[w] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
					srcpT2 -= src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					diameter,0,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v] * weight;
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					diameter,startxr,0,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
		for (--stopy; y<height; ++y, ++starty)
		{
			const unsigned char *srcpT_saved = srcp_saved + starty*src_pitch;
			int startx = 0;
			int startxr = radius;
			int stopx = radius;
			for (int x=0; x<radius; ++x, --startxr, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];	
			}
			for (; x<midP; ++x, ++startx, ++stopx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,diameter,
					stopy-starty+1,0,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			for (--stopx; x<width; ++x, ++startx)
			{
				double sumOfWeights = 0.0;
				memset(pixels,0,wda);
				memset(weights,0,wda);
				const unsigned char *srcpT = srcpT_saved; 
				const int cP = tp[x] + 255;
				int w = startyr;
				for (int u=starty; u<=stopy; ++u, w+=diameter)
				{
					int b = startxr;
					for (int v=startx; v<=stopx; ++v, ++b)
					{
						const double weight = spatialWeights[w+b] * diffWeights[(cP-srcpT[v])<<1];
						pixels[w+b] = srcpT[v];
						weights[w+b] = weight;
						sumOfWeights += weight;
					}
					srcpT += src_pitch;
				}
				if (sumOfWeights >= MINS) dstp[x] = mlre(pixels,weights,stopx-startx+1,
					stopy-starty+1,startxr,radius+starty-y,radius,diameter);
				else dstp[x] = srcp[x];
			}
			srcp += src_pitch;
			dstp += dst_pitch;
			tp += tp_pitch;
		}
	}
finishD2_Mean:
	if (guiCall)
	{
		track -= 2;
		copyFrameForBMP();
	}
}