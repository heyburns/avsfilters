/*
**               TBilateralFilter v0.9.11 for AviSynth 2.5.x
**
**   TBilateral is a spatial smoothing filter that uses the bilateral filtering
**   algorithm.  It does a nice job of smoothing while retaining picture structure.
**   It currently supports YV12 and YUY2 colorspaces.
**   
**   Copyright (C) 2004-2006 Kevin Stone
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 2 of the License, or
**   (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "TBilateral.h"

int __stdcall SetCacheHints(int cachehints, int frame_range)
{
	return cachehints == CACHE_GET_MTMODE ? MT_NICE_FILTER : 0;
}


TBilateral::TBilateral(PClip _child, int _diameterL, int _diameterC, double _sDevL, double _sDevC, 
		double _iDevL, double _iDevC, double _csL, double _csC, bool _d2, bool _chroma, bool _gui, 
		PClip _ppClip, int _kernS, int _kernI, int _resType, IScriptEnvironment* env) : 
		GenericVideoFilter(_child), diameterL(_diameterL), diameterC(_diameterC), sDevL(_sDevL), 
		sDevC(_sDevC), iDevL(_iDevL), iDevC(_iDevC), csL(_csL), csC(_csC), d2(_d2), chroma(_chroma), 
		gui(_gui), ppClip(_ppClip), kernS(_kernS), kernI(_kernI), resType(_resType)
{
	diffWeightsL = diffWeightsC = NULL;
	spatialWeightsL = spatialWeightsC = NULL;
	disTableL = disTableC = NULL;
	srcPF = dstPF = ppPF = NULL;
	medA = NULL;
	pixelsL = weightsL = pixelsC = weightsC = NULL;
	if (!vi.IsYV12() && !vi.IsYUY2())
		env->ThrowError("TBilateral:  YV12 and YUY2 data only!");
	if (!(diameterL&1) || diameterL < 3)
		env->ThrowError("TBilateral:  diameterL must be an odd number greater than 1!");
	if (chroma && (!(diameterC&1) || diameterC < 3))
		env->ThrowError("TBilateral:  diameterC must be an odd number greater than 1!");
	if (sDevL < 0 || sDevC < 0 || iDevL < 0 || iDevC < 0)
		env->ThrowError("TBilateral:  all Dev settings must be greater than or equal to 0!");
	if (gui && (diameterL > 21 || diameterC > 21))
		env->ThrowError("TBilateral:  diameterL and diameterC must be less than or equal to 21 if using gui!");
	if (vi.width&1 || vi.height&1)
		env->ThrowError("TBilateral:  width and height must be a multiple of 2!");
	if (vi.width < diameterL)
		env->ThrowError("TBilateral:  diameterL must be less than the width of the luma plane!");
	if ((vi.width>>1) < diameterC && chroma)
		env->ThrowError("TBilateral:  diameterC must be less than the width of the chroma planes!");
	if (vi.height < diameterL)
		env->ThrowError("TBilateral:  diameterL must be less than the height of the luma plane!");
	if (chroma && ((vi.IsYV12() && (vi.height>>1) < diameterC) || (vi.IsYUY2() && vi.height < diameterC)))
		env->ThrowError("TBilateral:  diameterC must be less than the height of the chroma planes!");
	if (csL < 0 || csC < 0)
		env->ThrowError("TBilateral:  csL and csC must be greater than or equal to 0!");
	if (kernS < 0 || kernS > 9 || kernI < 0 || kernI > 9)
		env->ThrowError("TBilateral:  kernS and kernI must be between 0 and 9 (inclusive)!");
	if (resType < 0 || resType > 3)
		env->ThrowError("TBilateral:  resType must be set to 0, 1, 2, or 3!");
	srcPF = new PlanarFrame();
	if (srcPF == NULL) env->ThrowError("TBilateral:  planarframe allocation failure (srcPF)!");
	dstPF = new PlanarFrame();
	if (dstPF == NULL) env->ThrowError("TBilateral:  planarframe allocation failure (dstPF)!");
	srcPF->createFromProfile(vi);
	dstPF->createFromProfile(vi);
	medA = (double *)_aligned_malloc(256*sizeof(double), 16);
	if (!medA) env->ThrowError("TBilateral:  malloc failure (medA)!");
	usePPClip = false;
	if (ppClip)
	{
		VideoInfo vi2 = ppClip->GetVideoInfo();
		if (!vi2.IsSameColorspace(vi))
			env->ThrowError("TBilateral:  ppClip's colorspace does not match that of the base clip!");
		if (vi.height != vi2.height)
			env->ThrowError("TBilateral:  ppClip's height does not match that of the base clip!");
		if (vi.width != vi2.width)
			env->ThrowError("TBilateral:  ppClip's width does not match that of the base clip!");
		if (vi.num_frames != vi2.num_frames)
			env->ThrowError("TBilateral:  ppClip does not have the same number of frames as the base clip!");
		ppPF = new PlanarFrame();
		if (ppPF == NULL)
			env->ThrowError("TBilateral:  planarframe allocation failure (ppPF)!");
		ppPF->createFromProfile(vi2);
		usePPClip = true;
	}
	nfrms = vi.num_frames-1;
	diameterLT = diameterCT = -20;
	kernST = kernIT = resTypeT = -20;
	sDevLT = sDevCT = -20.0;
	iDevLT = iDevCT = -20.0;
	csLT = csCT = -20.0;
	chromaT = d2T = usePPClipT = -1;
	if (gui)
	{
		store = env->NewVideoFrame(vi);
		memset(&bi, 0, sizeof(bi));
		bi.biSize = sizeof(bi);
		bi.biWidth = vi.width;
		bi.biHeight = vi.height;
		bi.biPlanes = 1;
		bi.biBitCount = vi.BitsPerPixel();
		if (vi.IsYUY2()) bi.biCompression = '2YUY';
		else bi.biCompression = '21VY';
		bi.biSizeImage = vi.BMPSize();
		store = env->NewVideoFrame(vi);
		track = 894563;
		trackg = track-20;
		gdiameterL = diameterL;
		gdiameterC = diameterC;
		gkernS = kernS;
		gkernI = kernI;
		gresType = resType;
		giDevL = iDevL;
		giDevC = iDevC;
		gsDevL = sDevL;
		gsDevC = sDevC;
		gcsL = csL;
		gcsC = csC;
		gd2 = d2;
		gchroma = chroma;
		gppClip = usePPClip;
		if (hEventGetDone != NULL || hEventGUIDone != NULL)
			env->ThrowError("TBilateral:  gui instance already exists!");
		hEventGetDone = CreateEvent(NULL, TRUE, TRUE, NULL);
		hEventGUIDone = CreateEvent(NULL, TRUE, TRUE, NULL);
		srcPF->copyFrom(child->GetFrame(0, env), vi);
		if (ppClip) ppPF->copyFrom(ppClip->GetFrame(0, env), (VideoInfo)ppClip->GetVideoInfo());
		if (d2) ProcessFrameD2(false);
		else ProcessFrameD1(false);
		--track;
		copyFrameForBMP();
	}
}

TBilateral::~TBilateral()
{
	if (diffWeightsL != NULL) _aligned_free(diffWeightsL);
	if (diffWeightsC != NULL) _aligned_free(diffWeightsC);
	if (spatialWeightsL != NULL) _aligned_free(spatialWeightsL);
	if (spatialWeightsC != NULL) _aligned_free(spatialWeightsC);
	if (disTableL != NULL) _aligned_free(disTableL);
	if (disTableC != NULL) _aligned_free(disTableC);
	if (medA != NULL) _aligned_free(medA);
	if (pixelsL != NULL) _aligned_free(pixelsL);
	if (weightsL != NULL) _aligned_free(weightsL);
	if (pixelsC != NULL) _aligned_free(pixelsC);
	if (weightsC != NULL) _aligned_free(weightsC);
	if (srcPF != NULL) { srcPF->freePlanar(); delete srcPF; }
	if (dstPF != NULL) { dstPF->freePlanar(); delete dstPF; }
	if (ppPF != NULL) { ppPF->freePlanar(); delete ppPF; }
	if (gui)
	{
		if (hEventGetDone != NULL) { CloseHandle(hEventGetDone); hEventGetDone = NULL; }
		if (hEventGUIDone != NULL) { CloseHandle(hEventGUIDone); hEventGUIDone = NULL; }
		if (hThreadg != NULL && hDlgg != NULL) 
		{
			PDWORD_PTR lpdwResult = 0;
			SendMessageTimeout(hDlgg, WM_CLOSE, (WPARAM)0, (LPARAM)0, SMTO_ABORTIFHUNG | SMTO_BLOCK, 2000, lpdwResult);
		}
	}
}

void TBilateral::guiDisable()
{
	if (hEventGetDone != NULL) { CloseHandle(hEventGetDone); hEventGetDone = NULL; }
	if (hEventGUIDone != NULL) { CloseHandle(hEventGUIDone); hEventGUIDone = NULL; }
	gui = false;
}

bool TBilateral::buildTables()
{
	bool changed = false;
	int b, x, y, temp;
	if (diameterLT != diameterL || sDevLT != sDevL || csLT != csL || kernST != kernS)
	{
		changed = true;
		if (diameterLT != diameterL || spatialWeightsL == NULL)
		{
			windowL = diameterL * diameterL;
			radiusL = diameterL >> 1;
			if (spatialWeightsL != NULL) _aligned_free(spatialWeightsL);
			spatialWeightsL = (double*)_aligned_malloc(windowL*sizeof(double), 16);
			if (spatialWeightsL == NULL) ThrowError("TBilateral:  aligned malloc failure (spatialWeightsL)!");
			if (disTableL != NULL) _aligned_free(disTableL);
			disTableL = (double*)_aligned_malloc(windowL*sizeof(double), 16);
			if (disTableL == NULL) ThrowError("TBilateral:  aligned malloc failure (disTableL)!");
			if (pixelsL != NULL) _aligned_free(pixelsL);
			pixelsL = (double*)_aligned_malloc(windowL*sizeof(double), 16);
			if (pixelsL == NULL) ThrowError("TBilateral:  aligned malloc failure (pixelsL)!");
			if (weightsL != NULL) _aligned_free(weightsL);
			weightsL = (double*)_aligned_malloc(windowL*sizeof(double), 16);
			if (weightsL == NULL) ThrowError("TBilateral:  aligned malloc failure (weightsL)!");
			for (b=0, y=-radiusL; y<=radiusL; ++y) 
			{
				temp = y*y;
				for (x=-radiusL; x<=radiusL; ++x) disTableL[b++] = sqrt((double)(temp + x*x));
			}
		}
		for (x=0; x<windowL; ++x) spatialWeightsL[x] = kernelValue(disTableL[x], sDevL, kernS);
		spatialWeightsL[radiusL*diameterL+radiusL] *= csL;
		diameterLT = diameterL;
		sDevLT = sDevL;
		csLT = csL;
	}
	if (iDevLT != iDevL || d2T != int(d2) || kernIT != kernI)
	{
		changed = true;
		if (d2T != int(d2) || diffWeightsL == NULL)
		{
			if (diffWeightsL != NULL) _aligned_free(diffWeightsL);
			if (!d2) diffWeightsL = (double*)_aligned_malloc(511*sizeof(double), 16);
			else diffWeightsL = (double*)_aligned_malloc(1021*sizeof(double), 16);
			if (diffWeightsL == NULL) ThrowError("TBilateral:  aligned malloc failure (diffWeightsL)!");
		}
		if (!d2) for (x=0; x<256; ++x) diffWeightsL[255+x] = diffWeightsL[255-x] = kernelValue(x, iDevL, kernI);
		else for (x=0; x<511; ++x) diffWeightsL[510+x] = diffWeightsL[510-x] = kernelValue(x/2.0, iDevL, kernI);
		iDevLT = iDevL;
	}
	if (chroma && (diameterCT != diameterC || sDevCT != sDevC || csCT != csC || kernST != kernS || chromaT != int(chroma)))
	{
		changed = true;
		if (diameterCT != diameterC || spatialWeightsC == NULL)
		{
			windowC = diameterC * diameterC;
			radiusC = diameterC >> 1;
			if (spatialWeightsC != NULL) _aligned_free(spatialWeightsC);
			spatialWeightsC = (double*)_aligned_malloc(windowC*sizeof(double), 16);
			if (spatialWeightsC == NULL) ThrowError("TBilateral:  aligned malloc failure (spatialWeightsC)!");
			if (disTableC != NULL) _aligned_free(disTableC);
			disTableC = (double*)_aligned_malloc(windowC*sizeof(double), 16);
			if (disTableC == NULL) ThrowError("TBilateral:  aligned malloc failure (disTableC)!");
			if (pixelsC != NULL) _aligned_free(pixelsC);
			pixelsC = (double*)_aligned_malloc(windowC*sizeof(double), 16);
			if (pixelsC == NULL) ThrowError("TBilateral:  aligned malloc failure (pixelsC)!");
			if (weightsC != NULL) _aligned_free(weightsC);
			weightsC = (double*)_aligned_malloc(windowC*sizeof(double), 16);
			if (weightsC == NULL) ThrowError("TBilateral:  aligned malloc failure (weightsC)!");
			for (b=0, y=-radiusC; y<=radiusC; ++y) 
			{
				temp = y*y;
				for (x=-radiusC; x<=radiusC; ++x) disTableC[b++] = sqrt((double)(temp + x*x));
			}
		}
		for (x=0; x<windowC; ++x) spatialWeightsC[x] = kernelValue(disTableC[x], sDevC, kernS);
		spatialWeightsC[radiusC*diameterC+radiusC] *= csC;
		diameterCT = diameterC;
		sDevCT = sDevC;
		csCT = csC;
	}
	if (chroma && (iDevCT != iDevC || d2T != int(d2) || kernIT != kernI || chromaT != int(chroma)))
	{
		changed = true;
		if (d2T != int(d2) || diffWeightsC == NULL)
		{
			if (diffWeightsC != NULL) _aligned_free(diffWeightsC);
			if (!d2) diffWeightsC = (double*)_aligned_malloc(511*sizeof(double), 16);
			else diffWeightsC = (double*)_aligned_malloc(1021*sizeof(double), 16);
			if (diffWeightsC == NULL) ThrowError("TBilateral:  aligned malloc failure (diffWeightsC)!");
		}
		if (!d2) for (x=0; x<256; ++x) diffWeightsC[255+x] = diffWeightsC[255-x] = kernelValue(x, iDevC, kernI);
		else for (x=0; x<511; ++x) diffWeightsC[510+x] = diffWeightsC[510-x] = kernelValue(x/2.0, iDevC, kernI);
		iDevCT = iDevC;
	}
	if (usePPClipT != int(usePPClip)) { usePPClipT = usePPClip; changed = true; }
	if (resTypeT != resType) { resTypeT = resType; changed = true; }
	if (!chroma && chromaT != int(chroma)) changed = true;
	if (changed)
	{
		kernST = kernS;
		kernIT = kernI;
		d2T = d2;
		chromaT = chroma;
	}
	return changed;
}

double TBilateral::kernelValue(double x, double sigma, int kernel)
{
	switch (kernel)
	{
		case 0: // Andrews' wave
			if (x <= sigma) return ((sin((M_PI*x)/sigma)*sigma) / M_PI);
			return 0.0;
		case 1: // El Fallah Ford
			return (1.0 / sqrt(1.0+((x*x)/(sigma*sigma))));
		case 2: // Gaussian
			return (exp(-((x*x)/(2.0*sigma*sigma))));
		case 3: // Huber�s mini-max
			if (x <= sigma) return (1.0 / sigma);
			return (1.0 / x);
		case 4: // Lorentzian
			return (2.0 / (2.0*sigma*sigma + x*x));
		case 5: // Tukey bi-weight
			if (x <= sigma) return (0.5*pow((1.0-((x*x)/(sigma*sigma))), 2));
			return 0.0;
		case 6: // Linear descent
			if (x <= sigma) return (1.0 - (x/sigma));
			return 0.0;
		case 7: // Cosine
			if (x <= sigma) return (cos((M_PI*x)/(2.0*sigma)));
			return 0.0;
		case 8: // Flat
			if (x <= sigma) return (1.0 / sigma);
			return 0.0;
		case 9: // Inverse
			if (x <= sigma)
			{
				if (x != 0.0) return (1.0 / x);
				return 1.0;
			}
			return 0.0;
	}
	return 0.0;
}

int TBilateral::mlre(double *yi, double *wi, int lw, int lh, int cx, int cy, int radius, 
					 int diameter)
{
	wi += cy*diameter;
	yi += cy*diameter;

	const int la = lw*lh;
	const int lax2 = la*2;
	const int la2 = la*la;

	double *xlr = (double *)malloc(la*3*sizeof(double));
	double *wlr = (double *)malloc(la2*sizeof(double));
	double *ylr = (double *)malloc(la*sizeof(double));
	double *wxlr = (double *)malloc(la*3*sizeof(double));
	double *xtlr = (double *)malloc(la*3*sizeof(double));
	double *wylr = (double *)malloc(la*sizeof(double));
	double xtwx[9], xtwxi[9], xtwy[3], blr[3], wjlr[3], vlr[9];

	// compute w and y matrices
	int d = 0, h = 0;
	memset(wlr,0,la2*sizeof(double));
	for (int k=0; k<lh; ++k)
	{
		const int kt = k*diameter;
		for (int j=cx; j<lw+cx; ++j, ++h, d+=la+1)
		{
			wlr[d] = wi[kt+j];
			ylr[h] = yi[kt+j];
		}
	}

	// compute x and x' matrices
	d = 0;
	for (int j=0; j<lh; ++j)
	{
		const int jt = j*lw*3;
		for (int k=0; k<lw; ++k, ++d)
		{
			xlr[jt+k*3+0] = xtlr[d] = 1;
			xlr[jt+k*3+1] = xtlr[d+la] = j;
			xlr[jt+k*3+2] = xtlr[d+lax2] = k;
		}
	}

	// compute w*x matrix
	for (int j=0; j<la; ++j)
	{
		const int j3 = j*3;
		const int jl = j*la;
		for (int k=0; k<3; ++k)
		{
			wxlr[j3+k] = 0.0;
			for (int l=0; l<la; ++l)
				wxlr[j3+k] += wlr[jl+l]*xlr[l*3+k];
		}
	}

	// compute xt*wx matrix
	for (int j=0; j<3; ++j)
	{
		const int j3 = j*3;
		const int jl = j*la;
		for (int k=0; k<3; ++k)
		{
			xtwx[j3+k] = 0.0;
			for (int l=0; l<la; ++l)
				xtwx[j3+k] += xtlr[jl+l]*wxlr[l*3+k];
		}
	}

	// compute svd of xtwx = U*WJ*V'
	svdcmp(xtwx,wjlr,vlr);

	// compute wj inverse + zero small wj's
	for (int i=0; i<3; ++i)
	{
		if (fabs(wjlr[i]) <= FLT_EPSILON) wjlr[i] = 0;
		else wjlr[i] = 1.0/wjlr[i];
	}

	// compute wj^-1 * u'
	for (int j=0; j<3; ++j)
	{
		const int j3 = j*3;
		for (int k=j; k<3; ++k)
		{
			double temp = xtwx[j3+k];
			xtwx[j3+k] = xtwx[k*3+j]*wjlr[j];
			xtwx[k*3+j] = temp*wjlr[k];
		}
	}

	// compute xtwxi
	for (int j=0; j<3; ++j)
	{
		const int j3 = j*3;
		for (int k=0; k<3; ++k)
		{
			xtwxi[j3+k] = 0.0;
			for (int l=0; l<3; ++l)
				xtwxi[j3+k] += vlr[j*3+l]*xtwx[l*3+k];
		}
	}

	// compute wy matrix
	for (int j=0; j<la; ++j)
	{
		const int jl = j*la;
		wylr[j] = 0.0;
		for (int l=0; l<la; ++l)
			wylr[j] += wlr[jl+l]*ylr[l];
	}

	// compute xtwy matrix
	for (int j=0; j<3; ++j)
	{
		const int jl = j*la;
		xtwy[j] = 0.0;
		for (int l=0; l<la; ++l)
			xtwy[j] += xtlr[jl+l]*wylr[l];
	}

	// compute b matrix
	for (int j=0; j<3; ++j)
	{
		const int j3 = j*3;
		blr[j] = 0.0;
		for (int l=0; l<3; ++l)
			blr[j] += xtwxi[j3+l]*xtwy[l];
	}

	free(xlr);
	free(wlr);
	free(ylr);
	free(wxlr);
	free(xtlr);
	free(wylr);

	return min(max(int(blr[0]+blr[1]*(radius-cy)+blr[2]*(radius-cx)+0.5),0),255);
}

// Singular Value Decomposition routine
// taken from numerical recipes in C.

double pythag(double a, double b)
{
	double at = fabs(a), bt = fabs(b), ct;
	if (at > bt) { ct = bt/at; return at*sqrt(1.0 + ct*ct); }
	if (bt > 0.0) { ct = at/bt; return bt*sqrt(1.0 + ct*ct); }
	return 0.0;
}

void TBilateral::svdcmp(double *a, double *w, double *v)
{
  int flag, i, its, j, jj, k, l, nm;
  double c, f, h, s, x, y, z;
  double anorm = 0.0, g = 0.0, scale = 0.0;
  double rv1[3];
  for (i = 0; i < 3; i++) {
    l = i + 1;
    rv1[i] = scale * g;
    g = s = scale = 0.0;
    if (i < 3) {
      for (k = i; k < 3; k++)
        scale += fabs(a[k*3+i]);
      if(scale) {
        for (k = i; k < 3; k++) {
          a[k*3+i] = a[k*3+i]/scale;
          s += a[k*3+i]*a[k*3+i];
        }
        f = a[i*3+i];
        g = -SIGN(sqrt(s), f);
        h = f * g - s;
        a[i*3+i] = f - g;
        if (i != 2) {
          for (j = l; j < 3; j++) {
            for (s = 0.0, k = i; k < 3; k++)
              s += a[k*3+i] * a[k*3+j];
            f = s / h;
            for (k = i; k < 3; k++)
              a[k*3+j] += f * a[k*3+i];
          }
        }
        for (k = i; k < 3; k++)
          a[k*3+i] = a[k*3+i]*scale;
      }
    }
    w[i] = scale * g;
    g = s = scale = 0.0;
    if (i < 3 && i != 2) {
      for (k = l; k < 3; k++)
        scale += fabs(a[i*3+k]);
      if (scale) {
        for (k = l; k < 3; k++) {
          a[i*3+k] = a[i*3+k]/scale;
          s += a[i*3+k] * a[i*3+k];
        }
        f = a[i*3+l];
        g = -SIGN(sqrt(s), f);
        h = f * g - s;
        a[i*3+l] = f - g;
        for (k = l; k < 3; k++)
          rv1[k] = a[i*3+k] / h;
        if (i != 2) {
          for (j = l; j < 3; j++) {
            for (s = 0.0, k = l; k < 3; k++)
              s += (a[j*3+k] * a[i*3+k]);
            for (k = l; k < 3; k++)
              a[j*3+k] += s * rv1[k];
          }
        }
        for (k = l; k < 3; k++)
          a[i*3+k] = a[i*3+k]*scale;
      }
    }
    anorm = max(anorm, (fabs(w[i]) + fabs(rv1[i])));
  }
  for (i = 2; i >= 0; i--) {
    if (i < 2) {
      if (g) {
        for (j = l; j < 3; j++)
          v[j*3+i] = a[i*3+j] / a[i*3+l] / g;
        for (j = l; j < 3; j++) {
          for (s = 0.0, k = l; k < 3; k++)
            s += (a[i*3+k] * v[k*3+j]);
          for (k = l; k < 3; k++)
            v[k*3+j] += s * v[k*3+i];
        }
      }
      for (j = l; j < 3; j++)
        v[i*3+j] = v[j*3+i] = 0.0;
    }
    v[i*3+i] = 1.0;
    g = rv1[i];
    l = i;
  }
  for (i = 2; i >= 0; i--) {
    l = i + 1;
    g = w[i];
    if (i < 2)
      for (j = l; j < 3; j++)
        a[i*3+j] = 0.0;
    if (g) {
      g = 1.0 / g;
      if (i != 2) {
        for (j = l; j < 3; j++) {
          for (s = 0.0, k = l; k < 3; k++)
            s += (a[k*3+i] * a[k*3+j]);
          f = (s / a[i*3+i]) * g;
          for (k = i; k < 3; k++)
            a[k*3+j] += f * a[k*3+i];
        }
      }
      for (j = i; j < 3; j++)
        a[j*3+i] = a[j*3+i]*g;
    }
    else {
      for (j = i; j < 3; j++)
        a[j*3+i] = 0.0;
    }
    ++a[i*3+i];
  }
  for (k = 2; k >= 0; k--) {
    for (its = 0; its < 30; its++) {
      flag = 1;
      for (l = k; l >= 0; l--) {
        nm = l - 1;
        if (fabs(rv1[l]) + anorm == anorm) {
          flag = 0;
          break;
        }
        if (fabs(w[nm]) + anorm == anorm)
          break;
      }
      if (flag) {
        c = 0.0;
        s = 1.0;
        for (i = l; i <= k; i++) {
          f = s * rv1[i];
          if (fabs(f) + anorm != anorm) {
            g = w[i];
            h = pythag(f, g);
            w[i] = h;
            h = 1.0 / h;
            c = g * h;
            s = (- f * h);
            for (j = 0; j < 3; j++) {
              y = a[j*3+nm];
              z = a[j*3+i];
              a[j*3+nm] = y * c + z * s;
              a[j*3+i] = z * c - y * s;
            }
          }
        }
      }
      z = w[k];
      if (l == k) {
        if (z < 0.0) {
          w[k] = -z;
          for (j = 0; j < 3; j++)
            v[j*3+k] = -v[j*3+k];
        }
        break;
      }
      x = w[l];
      nm = k - 1;
      y = w[nm];
      g = rv1[nm];
      h = rv1[k];
      f = ((y - z) * (y + z) + (g - h) * (g + h)) / (2.0 * h * y);
      g = pythag(f, 1.0);
      f = ((x - z) * (x + z) + h * ((y / (f + SIGN(g, f))) - h)) / x;
      c = s = 1.0;
      for (j = l; j <= nm; j++) {
        i = j + 1;
        g = rv1[i];
        y = w[i];
        h = s * g;
        g = c * g;
        z = pythag(f, h);
        rv1[j] = z;
        c = f / z;
        s = h / z;
        f = x * c + g * s;
        g = g * c - x * s;
        h = y * s;
        y = y * c;
        for (jj = 0; jj < 3; jj++) {
          x = v[jj*3+j];
          z = v[jj*3+i];
          v[jj*3+j] = x * c + z * s;
          v[jj*3+i] = z * c - x * s;
        }
        z = pythag(f, h);
        w[j] = z;
        if (z) {
          z = 1.0 / z;
          c = f * z;
          s = h * z;
        }
        f = (c * g) + (s * y);
        x = (c * y) - (s * g);
        for (jj = 0; jj < 3; jj++) {
          y = a[jj*3+j];
          z = a[jj*3+i];
          a[jj*3+j] = y * c + z * s;
          a[jj*3+i] = z * c - y * s;
        }
      }
      rv1[l] = 0.0;
      rv1[k] = f;
      w[k] = x;
    }
  }
}

PVideoFrame __stdcall TBilateral::GetFrame(int n, IScriptEnvironment *env)
{
	if (gui)
	{
		DWORD error = WaitForSingleObject(hEventGUIDone, 5000);
		if (error != WAIT_OBJECT_0) env->ThrowError("TBilateral:  unknown thread sync error!");
		ResetEvent(hEventGetDone);
	}
	if (n < 0) n = 0;
	else if (n > nfrms) n = nfrms;
	if (gui) checkGUIVariables();
	srcPF->copyFrom(child->GetFrame(n, env), vi);
	if (ppClip) ppPF->copyFrom(ppClip->GetFrame(n, env), (VideoInfo)ppClip->GetVideoInfo());
	if (d2) ProcessFrameD2(false);
	else ProcessFrameD1(false);
	PVideoFrame dst = env->NewVideoFrame(vi);
	dstPF->copyTo(dst, vi);
	if (gui) 
	{
		--track;
		copyFrameForBMP();
		SetEvent(hEventGetDone);
	}
	return dst;
}

void TBilateral::ThrowError(const char* fmt) 
{
	char buf[8192];
	strcpy(buf, fmt);
	throw AvisynthError(buf);
}

AVSValue __cdecl Create_TBilateral(AVSValue args, void* user_data, IScriptEnvironment* env) 
{
	if (args[11].IsBool() && args[11].AsBool())
	{
		if (hThreadg == NULL && tMyFilter == NULL && hEventThreadCreated == NULL && 
			hEventThreadFinished == NULL && hEventGUIDone == NULL && hDlggMain == NULL &&
			hEventGetDone == NULL && hDlgg == NULL && hWndg == NULL && hDlggAdv == NULL) 
		{
			tMyFilter = new TBilateral(args[0].AsClip(),args[1].AsInt(5),args[2].AsInt(5),
				args[3].AsFloat(1.4),args[4].AsFloat(1.4),args[5].AsFloat(7.0),args[6].AsFloat(7.0),
				args[7].AsFloat(1.0),args[8].AsFloat(1.0),args[9].AsBool(false),args[10].AsBool(true),
				args[11].AsBool(false),args[12].IsClip()?args[12].AsClip():NULL,args[13].AsInt(2),
				args[14].AsInt(2),args[15].AsInt(0),env);
			hEventThreadCreated = CreateEvent(NULL, TRUE, FALSE, NULL);
			hEventThreadFinished = CreateEvent(NULL, TRUE, FALSE, NULL);
			hThreadg = CreateThread(NULL,10000,(DWORD(WINAPI *)(void *))startWindowTBilateral,0,0,&idg);
			if (hThreadg == NULL) env->ThrowError("TBilateral:  error creating gui thread!");
			DWORD error = WaitForSingleObject(hEventThreadCreated, 10000);
			CloseHandle(hEventThreadCreated);
			hEventThreadCreated = NULL;
			if (error != WAIT_OBJECT_0) 
				env->ThrowError("TBilateral:  error creating gui thread (10 second timeout)!");
			return tMyFilter;
		}
		else env->ThrowError("TBilateral:  only one instance of TBilateral with a gui is supported!");
	}
    return new TBilateral(args[0].AsClip(),args[1].AsInt(5),args[2].AsInt(5),args[3].AsFloat(1.4),
		args[4].AsFloat(1.4),args[5].AsFloat(7.0),args[6].AsFloat(7.0),args[7].AsFloat(1.0),
		args[8].AsFloat(1.0),args[9].AsBool(false),args[10].AsBool(true),args[11].AsBool(false),
		args[12].IsClip()?args[12].AsClip():NULL,args[13].AsInt(2),args[14].AsInt(2),args[15].AsInt(0),
		env);
}

const AVS_Linkage *AVS_linkage = 0;
extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors)
{
    AVS_linkage = vectors;
    env->AddFunction("TBilateral", "c[diameterL]i[diameterC]i[sDevL]f[sDevC]f[iDevL]f[iDevC]f[csL]f" \
					"[csC]f[d2]b[chroma]b[gui]b[ppClip]c[kernS]i[kernI]i[resType]i", Create_TBilateral, 0);
    return 0;
}