/*
**               TBilateralFilter v0.9.11 for AviSynth 2.5.x
**
**   TBilateral is a spatial smoothing filter that uses the bilateral filtering
**   algorithm.  It does a nice job of smoothing while retaining picture structure.
**   It currently supports YV12 and YUY2 colorspaces.
**   
**   Copyright (C) 2004-2006 Kevin Stone
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 2 of the License, or
**   (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define _USE_MATH_DEFINES

#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <commctrl.h>
#include <vfw.h>
#include <math.h>
#include <shlwapi.h>
#include <float.h>
#include "avs_headers\avisynth.h"
#include "PlanarFrame.h"
#include "resource.h"

class TBilateral;
DWORD WINAPI startWindowTBilateral();
BOOL APIENTRY DllMain(HANDLE hModule, ULONG ulReason, LPVOID lpReserved);
INT_PTR CALLBACK DialogProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

// global variables for GUI
static HINSTANCE hInstanceg;
extern "C" HANDLE hEventGUIDone, hEventGetDone, hThreadg;
extern "C" HANDLE hEventThreadFinished, hEventThreadCreated;
extern "C" HWND hDlgg, hWndg, hDlggMain, hDlggAdv;
extern "C" HDRAWDIB hddg;
extern "C" DWORD idg;
extern "C" BITMAPINFOHEADER bi;
extern "C" TBilateral *tMyFilter;
extern "C" DLGTEMPLATE *apRes[2];
extern "C" int gdiameterL, gdiameterC, trackg;
extern "C" int gDiaCScale, gDiaLScale;
extern "C" int gkernS, gkernI, gresType;
extern "C" double gsDevL, gsDevC; 
extern "C" double giDevL, giDevC;
extern "C" double gcsL, gcsC;
extern "C" bool gd2, gchroma, gppClip;
// end globals

#define MINS 0.00000000000001
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define SQR(a) (a == 0.0 ? 0.0 : a*a)

class TBilateral : public GenericVideoFilter
{
private:
	int diameterL, diameterC, diameterLT, diameterCT, track;
	int kernS, kernI, kernST, kernIT, resType, resTypeT;
	double sDevL, sDevC, sDevLT, sDevCT;
	double iDevL, iDevC, iDevLT, iDevCT;
	double csL, csC, csLT, csCT;
	double *pixelsL, *weightsL;
	double *pixelsC, *weightsC;
	bool d2, gui, chroma, usePPClip;
	int d2T, chromaT, usePPClipT;
	int radiusL, radiusC, windowL, windowC, nfrms;
	double *diffWeightsL, *spatialWeightsL, *diffWeightsC, *spatialWeightsC;
	double *disTableL, *disTableC, *medA;
	PlanarFrame *srcPF, *dstPF, *ppPF;
	PVideoFrame store;
	void TBilateral::checkGUIVariables();
	bool TBilateral::buildTables();
	void TBilateral::ProcessFrameD1(bool guiCall);
	void TBilateral::ProcessFrameD2(bool guiCall);
	void TBilateral::ProcessFrameD1_Mean(bool guiCall);
	void TBilateral::ProcessFrameD2_Mean(bool guiCall);
	void TBilateral::ProcessFrameD1_Med(bool guiCall);
	void TBilateral::ProcessFrameD2_Med(bool guiCall);
	void TBilateral::ProcessFrameD1_MLR(bool guiCall);
	void TBilateral::ProcessFrameD2_MLR(bool guiCall);
	void TBilateral::ThrowError(const char* fmt);
	void TBilateral::copyFrameForBMP();
	double TBilateral::kernelValue(double x, double sigma, int kern);
	int TBilateral::mlre(double *yi, double *wi, int lw, int lh, int cx, int cy, int radius, 
		int diameter);
	void TBilateral::svdcmp(double *a, double *w, double *v);

public:
	PClip ppClip;
	PVideoFrame __stdcall TBilateral::GetFrame(int n, IScriptEnvironment *env);
	TBilateral(PClip _child, int _diameterL, int _diameterC, double _sDevL, double _sDevC, 
		double _iDevL, double _iDevC, double _csL, double _csC, bool _d2, bool _chroma, 
		bool _gui, PClip _ppClip, int _kernS, int _kernI, int _resType, 
		IScriptEnvironment* env);
	TBilateral::~TBilateral();
	void TBilateral::redoFrame();
	void TBilateral::grabBMPFrame(bool force);
	void TBilateral::grabBMPFrameLimited();
	void TBilateral::guiDisable();
};