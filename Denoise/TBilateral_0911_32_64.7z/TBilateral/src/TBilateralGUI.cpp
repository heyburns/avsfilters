/*
**               TBilateralFilter v0.9.11 for AviSynth 2.5.x
**
**   TBilateral is a spatial smoothing filter that uses the bilateral filtering
**   algorithm.  It does a nice job of smoothing while retaining picture structure.
**   It currently supports YV12 and YUY2 colorspaces.
**   
**   Copyright (C) 2004-2006 Kevin Stone
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 2 of the License, or
**   (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "TBilateral.h"

// global variables for the gui
HANDLE hEventGUIDone = NULL, hEventGetDone = NULL, hThreadg = NULL;
HANDLE hEventThreadFinished = NULL, hEventThreadCreated = NULL;
HWND hDlgg = NULL, hDlggMain = NULL, hDlggAdv = NULL, hWndg = NULL;
HDRAWDIB hddg = NULL;
DWORD idg = NULL;
BITMAPINFOHEADER bi;
TBilateral *tMyFilter = NULL;
DLGTEMPLATE *apRes[2];
int gdiameterL, gdiameterC, trackg;
int gDiaCScale, gDiaLScale;
int gkernS, gkernI, gresType;
double gsDevL, gsDevC; 
double giDevL, giDevC;
double gcsL, gcsC;
bool gd2, gchroma, gppClip;
// end global variables

void TBilateral::checkGUIVariables()
{
	diameterL = gdiameterL;
	diameterC = gdiameterC;
	sDevL = gsDevL;
	sDevC = gsDevC;
	iDevL = giDevL;
	iDevC = giDevC;
	csL = gcsL;
	csC = gcsC;
	d2 = gd2;
	chroma = gchroma;
	usePPClip = gppClip;
	kernS = gkernS;
	kernI = gkernI;
	resType = gresType;
	char tbuf1[1024];
	sprintf(tbuf1,"TBilateral(diameterL=%d,diameterC=%d,sDevL=%3.3f,sDevC=%3.3f," \
		"iDevL=%3.3f,iDevC=%3.3f,csL=%3.3f,csC=%3.3f,d2=%s,chroma=%s,kernS=%d,kernI=%d,resType=%d)",
		gdiameterL,gdiameterC,gsDevL,gsDevC,giDevL,giDevC,gcsL,gcsC,gd2?"true":"false",
		gchroma?"true":"false",gkernS,gkernI,gresType);
	SetDlgItemText(hDlggAdv, IDC_AVSSTRING, tbuf1);
}

void TBilateral::grabBMPFrame(bool force)
{
	if (trackg != track || force)
	{
		++track;
		trackg = track;
		void *lpBuffer2 = (void*)store->GetReadPtr();
		HDC hDC = GetDC(hWndg);
		DrawDibDraw(hddg,hDC,0,0,bi.biWidth,bi.biHeight,&bi,lpBuffer2,0,0,bi.biWidth,bi.biHeight,NULL);
		ReleaseDC(hWndg, hDC);  // don't leak
	}
	else grabBMPFrameLimited();
}

void TBilateral::grabBMPFrameLimited()
{
	if (trackg == track)
	{
		void *lpBuffer2 = (void*)store->GetReadPtr();
		PAINTSTRUCT ps;
		HDC hDC = BeginPaint(hWndg, &ps);
		DrawDibDraw(hddg,hDC,0,0,bi.biWidth,bi.biHeight,&bi,lpBuffer2,0,0,bi.biWidth,bi.biHeight,NULL);
		EndPaint(hWndg, &ps);  // don't leak
	}
	else grabBMPFrame(true);
}

void TBilateral::copyFrameForBMP()
{
	dstPF->copyToForBMP(store, vi);
}

void TBilateral::redoFrame()
{
	DWORD error = WaitForSingleObject(hEventGetDone, 3000);
	if (error != WAIT_OBJECT_0) return; // probably busy with normal operation
	ResetEvent(hEventGUIDone);
	checkGUIVariables();
	if (d2) ProcessFrameD2(true);
	else ProcessFrameD1(true);
	grabBMPFrame(true);
	SetEvent(hEventGUIDone);
}

int getScale(double diameter)
{
	double ret, radius = double(int(diameter)>>1);
	switch (gkernS)
	{
		case 0: // Andrews' wave
			ret = sqrt(radius*radius*2);
			break;
		case 1: // El Fallah Ford
			ret = sqrt((diameter*diameter)/1.777777778);
			break;
		case 2: // Gaussian 
			ret = sqrt(0.5*(-((diameter*diameter)/(-0.510825623))));
			break;
		case 3: // Huber�s mini-max
			ret = sqrt(radius*radius*2);
			break;
		case 4: // Lorentzian
			ret = sqrt(((2.0/0.6)-diameter*diameter)*0.5);
			break;
		case 5: // Tukey bi-weight
			ret = sqrt(radius*radius*2);
			break;
		case 6: // Linear descent
			ret = sqrt(radius*radius*2);
			break;
		case 7: // Cosine
			ret = sqrt(radius*radius*2);
			break;
		case 8: // Flat
			ret = sqrt(radius*radius*2);
			break;
		case 9: // Inverse
			ret = sqrt(radius*radius*2);
			break;
	}
	int iret = int(ret+0.999)*100;
	if (iret < 700 && (gkernS == 1 || gkernS == 2 || gkernS == 4)) return 700;
	return iret;
}

void DoLockDlgRes() 
{ 
	HRSRC hrsrc = FindResource(hInstanceg, MAKEINTRESOURCE(IDD_MAIN), RT_DIALOG);
    HGLOBAL hglb = LoadResource(hInstanceg, hrsrc); 
    apRes[0] = (DLGTEMPLATE *)LockResource(hglb);
	hrsrc = FindResource(hInstanceg, MAKEINTRESOURCE(IDD_ADVANCED), RT_DIALOG); 
    hglb = LoadResource(hInstanceg, hrsrc); 
    apRes[1] = (DLGTEMPLATE *)LockResource(hglb); 
}

void initMain(HWND hdlg) 
{
	HWND hWnd;
	RECT rect;
	char tbuf1[256];
	GetWindowRect(GetDlgItem(hDlgg, IDC_TABS), &rect);
	SetWindowPos(hdlg, HWND_TOP, rect.left, rect.top, 0, 0, SWP_NOSIZE); 
	hWnd = GetDlgItem(hdlg, IDC_DIAMETERLS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, 10));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, gdiameterL/2);
	SetDlgItemInt(hdlg, IDC_DIAMETERLV, gdiameterL, TRUE);
	hWnd = GetDlgItem(hdlg, IDC_DIAMETERCS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, 10));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, gdiameterC/2);
	SetDlgItemInt(hdlg, IDC_DIAMETERCV, gdiameterC, TRUE);
	gDiaLScale = getScale(gdiameterL);
	if (gsDevL < 0.1) gsDevL = 0.1;
	else if (gsDevL > double(gDiaLScale)/100.0) gsDevL = double(gDiaLScale)/100.0;
	hWnd = GetDlgItem(hdlg, IDC_SDEVLS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaLScale));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100.0+0.5));
	sprintf(tbuf1,"%3.2f",gsDevL);
	SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
	gDiaCScale = getScale(gdiameterC);
	if (gsDevC < 0.1) gsDevC = 0.1;
	else if (gsDevC > double(gDiaCScale)/100.0) gsDevC = double(gDiaCScale)/100.0;
	hWnd = GetDlgItem(hdlg, IDC_SDEVCS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaCScale));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100.0+0.5));
	sprintf(tbuf1,"%3.2f",gsDevC);
	SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
	hWnd = GetDlgItem(hdlg, IDC_IDEVLS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, 2550));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, (int)(giDevL*10.0+0.5));
	sprintf(tbuf1,"%3.2f",giDevL);
	SetDlgItemText(hdlg, IDC_IDEVLV, tbuf1);
	hWnd = GetDlgItem(hdlg, IDC_IDEVCS);
	SendMessage(hWnd, TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, 2550));
	SendMessage(hWnd, TBM_SETPOS, (WPARAM)TRUE, (int)(giDevC*10.0+0.5));
	sprintf(tbuf1,"%3.2f",giDevC);
	SetDlgItemText(hdlg, IDC_IDEVCV, tbuf1);
}

void initAdv(HWND hdlg)
{
	HWND hWnd;
	RECT rect;
	char tbuf1[1024], tbuf2[256];
	GetWindowRect(GetDlgItem(hDlgg, IDC_TABS), &rect);
	SetWindowPos(hdlg, HWND_TOP, rect.left, rect.top, 0, 0, SWP_NOSIZE);
	if (gd2) SendDlgItemMessage(hdlg,IDC_D2,BM_SETCHECK,BST_CHECKED,0);
	else SendDlgItemMessage(hdlg,IDC_D2,BM_SETCHECK,BST_UNCHECKED,0);
	if (gchroma) SendDlgItemMessage(hdlg,IDC_CHROMA,BM_SETCHECK,BST_CHECKED,0);
	else SendDlgItemMessage(hdlg,IDC_CHROMA,BM_SETCHECK,BST_UNCHECKED,0);
	if (gppClip) SendDlgItemMessage(hdlg,IDC_PPCLIP,BM_SETCHECK,BST_CHECKED,0);
	else SendDlgItemMessage(hdlg,IDC_PPCLIP,BM_SETCHECK,BST_UNCHECKED,0);
	if (tMyFilter->ppClip == NULL) EnableWindow(GetDlgItem(hdlg,IDC_PPCLIP), FALSE);
	SendMessage(GetDlgItem(hdlg, IDC_CSC), EM_LIMITTEXT, (WPARAM)14, (LPARAM)0);
	SendMessage(GetDlgItem(hdlg, IDC_CSL), EM_LIMITTEXT, (WPARAM)14, (LPARAM)0);
	sprintf(tbuf1,"%3.3f",gcsC);
	sprintf(tbuf2,"%3.3f",gcsL);
	SetDlgItemText(hdlg, IDC_CSC, tbuf1);
	SetDlgItemText(hdlg, IDC_CSL, tbuf2);
	hWnd = GetDlgItem(hdlg, IDC_SKERND);
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"0 - Andrews' wave");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"1 - El Fallah Ford");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"2 - Gaussian");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"3 - Huber�s mini-max");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"4 - Lorentzian");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"5 - Tukey bi-weight");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"6 - Linear descent");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"7 - Cosine");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"8 - Flat");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"9 - Inverse");
	SendMessage(hWnd, CB_SETCURSEL, (WPARAM)gkernS, (LPARAM)FALSE);
	hWnd = GetDlgItem(hdlg, IDC_IKERND);
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"0 - Andrews' wave");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"1 - El Fallah Ford");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"2 - Gaussian");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"3 - Huber�s mini-max");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"4 - Lorentzian");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"5 - Tukey bi-weight");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"6 - Linear descent");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"7 - Cosine");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"8 - Flat");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"9 - Inverse");
	SendMessage(hWnd, CB_SETCURSEL, (WPARAM)gkernI, (LPARAM)FALSE);
	hWnd = GetDlgItem(hdlg, IDC_AVGDROP);
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"0 - Mean");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"1 - Median");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"2 - CW-Median");
	SendMessage(hWnd, CB_ADDSTRING, (WPARAM)FALSE, (LPARAM)"3 - MLR");
	SendMessage(hWnd, CB_SETCURSEL, (WPARAM)gresType, (LPARAM)FALSE);
	sprintf(tbuf1,"TBilateral(diameterL=%d,diameterC=%d,sDevL=%3.3f,sDevC=%3.3f," \
		"iDevL=%3.3f,iDevC=%3.3f,csL=%3.3f,csC=%3.3f,d2=%s,chroma=%s,kernS=%d,kernI=%d,resType=%d)",
		gdiameterL,gdiameterC,gsDevL,gsDevC,giDevL,giDevC,gcsL,gcsC,gd2?"true":"false",
		gchroma?"true":"false",gkernS,gkernI,gresType);
	SetDlgItemText(hdlg, IDC_AVSSTRING, tbuf1);
}

INT_PTR CALLBACK DialogProc(HWND hdlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char tbuf1[256], tbuf2[256];
	switch (uMsg) 
	{
		case WM_INITDIALOG:
		{
			if (hDlgg != NULL)
			{
				if (hDlggMain == NULL) initMain(hdlg);
				else if (hDlggAdv == NULL) initAdv(hdlg);
				return TRUE;
			}
			TabCtrl_DeleteAllItems(GetDlgItem(hdlg, IDC_TABS));
			TCITEM tie;
			tie.mask = TCIF_TEXT;
			tie.iImage = -1;
			tie.pszText = "Main";
			TabCtrl_InsertItem(GetDlgItem(hdlg, IDC_TABS), 0, &tie);
			tie.pszText = "Advanced";
			TabCtrl_InsertItem(GetDlgItem(hdlg, IDC_TABS), 1, &tie);
			SetWindowPos(GetDlgItem(hdlg,IDC_VERSION), HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
			char prog[MAX_PATH];
			char path[MAX_PATH];
			LPTSTR ptr;
			GetModuleFileName(hInstanceg, prog, MAX_PATH);
			GetFullPathName(prog, MAX_PATH, path, &ptr);
			*ptr = 0;
			strcat(path, "TBilateral - ReadMe.txt");
			if (PathFileExists(path)) EnableWindow(GetDlgItem(hdlg,IDHELP), TRUE);
			else EnableWindow(GetDlgItem(hdlg,IDHELP), FALSE);
			return TRUE;
		}
		case WM_COMMAND:
		{
			switch(wParam)
			{
				case IDOK:
				{
					if (hWndg != NULL)
					{
						ShowWindow(hWndg,SW_HIDE);
						DestroyWindow(hWndg);
						hWndg = NULL;
					}
					if (hDlggMain != NULL)
					{
						ShowWindow(hDlggMain, SW_HIDE);
						DestroyWindow(hDlggMain);
						hDlggMain = NULL;
					}
					if (hDlggAdv != NULL)
					{
						ShowWindow(hDlggAdv, SW_HIDE);
						DestroyWindow(hDlggAdv);
						hDlggAdv = NULL;
					}
					if (hDlgg != NULL)
					{
						ShowWindow(hDlgg,SW_HIDE);
						EndDialog(hDlgg, 1);
						hDlgg = NULL;
					}
					PostQuitMessage(0);
					tMyFilter->guiDisable();
					tMyFilter = NULL;
					return TRUE;
				}
				case IDPREVIEW:
				{
					if (IsWindowVisible(hWndg)) 
					{
						ShowWindow(hWndg, SW_HIDE);
						SetDlgItemText(hdlg, IDPREVIEW, "SHOW PREVIEW");
					}
					else 
					{
						ShowWindow(hWndg, SW_RESTORE);
						SetDlgItemText(hdlg, IDPREVIEW, "HIDE PREVIEW");
						tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDHELP:
				{
					char prog[MAX_PATH];
					char path[MAX_PATH];
					LPTSTR ptr;
					GetModuleFileName(hInstanceg, prog, MAX_PATH);
					GetFullPathName(prog, MAX_PATH, path, &ptr);
					*ptr = 0;
					strcat(path, "TBilateral - ReadMe.txt");
					if (PathFileExists(path))
					{
						ShellExecute(hdlg, "open", path, NULL, NULL, SW_SHOWNORMAL);
					}
					return TRUE;
				}
				case IDC_D2:
				{
					int i = (int)SendDlgItemMessage(hdlg,IDC_D2,BM_GETSTATE,0,0);
					if(i&BST_CHECKED) gd2 = true;
					else gd2 = false;
					if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					return TRUE;
				}
				case IDC_CHROMA:
				{
					int i = (int)SendDlgItemMessage(hdlg,IDC_CHROMA,BM_GETSTATE,0,0);
					if(i&BST_CHECKED) gchroma = true;
					else gchroma = false;
					if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					return TRUE;
				}
				case IDC_PPCLIP:
				{
					int i = (int)SendDlgItemMessage(hdlg,IDC_PPCLIP,BM_GETSTATE,0,0);
					if(i&BST_CHECKED) gppClip = true;
					else gppClip = false;
					if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					return TRUE;
				}
				case IDC_DIAMETERLP:
				{
					if (gdiameterL < 15)
					{
						gdiameterL += 2;
						SetDlgItemInt(hdlg, IDC_DIAMETERLV, gdiameterL, TRUE);
						SendMessage(GetDlgItem(hdlg, IDC_DIAMETERLS), TBM_SETPOS, (WPARAM)TRUE, gdiameterL/2);
						gDiaLScale = getScale(gdiameterL);
						if (gsDevL < 0.1) gsDevL = 0.1;
						else if (gsDevL > double(gDiaLScale)/100.0) gsDevL = double(gDiaLScale)/100.0;
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaLScale));
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100.0+0.5));
						sprintf(tbuf1,"%3.2f",gsDevL);
						SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_DIAMETERLM:
				{
					if (gdiameterL > 3)
					{
						gdiameterL -= 2;
						SetDlgItemInt(hdlg, IDC_DIAMETERLV, gdiameterL, TRUE);
						SendMessage(GetDlgItem(hdlg, IDC_DIAMETERLS), TBM_SETPOS, (WPARAM)TRUE, gdiameterL/2);
						gDiaLScale = getScale(gdiameterL);
						if (gsDevL < 0.1) gsDevL = 0.1;
						else if (gsDevL > double(gDiaLScale)/100.0) gsDevL = double(gDiaLScale)/100.0;
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaLScale));
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100.0+0.5));
						sprintf(tbuf1,"%3.2f",gsDevL);
						SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_DIAMETERCP:
				{
					if (gdiameterC < 15)
					{
						gdiameterC += 2;
						SetDlgItemInt(hdlg, IDC_DIAMETERCV, gdiameterC, TRUE);
						SendMessage(GetDlgItem(hdlg, IDC_DIAMETERCS), TBM_SETPOS, (WPARAM)TRUE, gdiameterC/2);
						gDiaCScale = getScale(gdiameterC);
						if (gsDevC < 0.1) gsDevC = 0.1;
						else if (gsDevC > double(gDiaCScale)/100.0) gsDevC = double(gDiaCScale)/100.0;
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaCScale));
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100.0+0.5));
						sprintf(tbuf1,"%3.2f",gsDevC);
						SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_DIAMETERCM:
				{
					if (gdiameterC > 3)
					{
						gdiameterC -= 2;
						SetDlgItemInt(hdlg, IDC_DIAMETERCV, gdiameterC, TRUE);
						SendMessage(GetDlgItem(hdlg, IDC_DIAMETERCS), TBM_SETPOS, (WPARAM)TRUE, gdiameterC/2);
						gDiaCScale = getScale(gdiameterC);
						if (gsDevC < 0.1) gsDevC = 0.1;
						else if (gsDevC > double(gDiaCScale)/100.0) gsDevC = double(gDiaCScale)/100.0;
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaCScale));
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100.0+0.5));
						sprintf(tbuf1,"%3.2f",gsDevC);
						SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_IDEVLP:
				{
					if (giDevL <= 254.9)
					{
						giDevL += 0.1;
						sprintf(tbuf1,"%3.2f",giDevL);
						SetDlgItemText(hdlg, IDC_IDEVLV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_IDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(giDevL*10+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_IDEVLM:
				{
					if (giDevL > 0.1)
					{
						giDevL -= 0.1;
						sprintf(tbuf1,"%3.2f",giDevL);
						SetDlgItemText(hdlg, IDC_IDEVLV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_IDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(giDevL*10+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_IDEVCP:
				{
					if (giDevC <= 254.9)
					{
						giDevC += 0.1;
						sprintf(tbuf1,"%3.2f",giDevC);
						SetDlgItemText(hdlg, IDC_IDEVCV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_IDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(giDevC*10+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_IDEVCM:
				{
					if (giDevC > 0.1)
					{
						giDevC -= 0.1;
						sprintf(tbuf1,"%3.2f",giDevC);
						SetDlgItemText(hdlg, IDC_IDEVCV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_IDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(giDevC*10+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_SDEVLP:
				{
					if (gsDevL <= (double(gDiaLScale)/100.0)-0.01)
					{
						gsDevL += 0.01;
						sprintf(tbuf1,"%3.2f",gsDevL);
						SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_SDEVLM:
				{
					if (gsDevL > 0.01)
					{
						gsDevL -= 0.01;
						sprintf(tbuf1,"%3.2f",gsDevL);
						SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_SDEVCP:
				{
					if (gsDevC <= (double(gDiaCScale)/100.0)-0.01)
					{
						gsDevC += 0.01;
						sprintf(tbuf1,"%3.2f",gsDevC);
						SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				case IDC_SDEVCM:
				{
					if (gsDevC > 0.01)
					{
						gsDevC -= 0.01;
						sprintf(tbuf1,"%3.2f",gsDevC);
						SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
						SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100+0.5));
						if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
					}
					return TRUE;
				}
				default:
				{
					switch (HIWORD(wParam))
					{
						case EN_UPDATE:
						{
							switch (LOWORD(wParam))
							{
								case IDC_CSC:
								{
									((short *)tbuf1)[0] = 256; 
									int temp = (int)SendMessage(GetDlgItem(hdlg, IDC_CSC), EM_LINELENGTH, (WPARAM)0, (LPARAM)0);
									SendMessage(GetDlgItem(hdlg, IDC_CSC), EM_GETLINE, (WPARAM)0, (LPARAM)tbuf1);
									char *p = tbuf1;
									memset(tbuf2,0,256);
									char *p2 = tbuf2;
									int ic = 0;
									for (int i=0; i<temp; ++i, *p++)
									{
										if ((*p < 48 || *p > 57) && *p != 46)
										{
											++ic;
											continue;
										}
										*p2++ = *p;
									}
									if (ic > 0) SetDlgItemText(hdlg, IDC_CSC, tbuf2);
									else 
									{
										gcsC = max(atof(tbuf2),0.0);
										if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
									}
									return TRUE;
								}
								case IDC_CSL:
								{
									((short *)tbuf1)[0] = 256;
									int temp = (int)SendMessage(GetDlgItem(hdlg, IDC_CSL), EM_LINELENGTH, (WPARAM)0, (LPARAM)0);
									SendMessage(GetDlgItem(hdlg, IDC_CSL), EM_GETLINE, (WPARAM)0, (LPARAM)tbuf1);
									char *p = tbuf1;
									memset(tbuf2,0,256);
									char *p2 = tbuf2;
									int ic = 0;
									for (int i=0; i<temp; ++i, *p++)
									{
										if ((*p < 48 || *p > 57) && *p != 46)
										{
											++ic;
											continue;
										}
										*p2++ = *p;
									}
									if (ic > 0) SetDlgItemText(hdlg, IDC_CSL, tbuf2);
									else 
									{
										gcsL = max(atof(tbuf2),0.0);
										if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
									}
									return TRUE;
								}
							}
							break;
						}
						case CBN_SELCHANGE:
						{
							switch(LOWORD(wParam))
							{
								case IDC_IKERND:
								{
									gkernI = (int)SendMessage((HWND)lParam, CB_GETCURSEL, (WPARAM)FALSE, (LPARAM)FALSE);
									if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
									return TRUE;
								}
								case IDC_SKERND:
								{
									gkernS = (int)SendMessage((HWND)lParam, CB_GETCURSEL, (WPARAM)FALSE, (LPARAM)FALSE);
									gDiaLScale = getScale(gdiameterL);
									if (gsDevL < 0.1) gsDevL = 0.1;
									else if (gsDevL > double(gDiaLScale)/100.0) gsDevL = double(gDiaLScale)/100.0;
									SendMessage(GetDlgItem(hDlggMain, IDC_SDEVLS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaLScale));
									SendMessage(GetDlgItem(hDlggMain, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100.0+0.5));
									sprintf(tbuf1,"%3.2f",gsDevL);
									SetDlgItemText(hDlggMain, IDC_SDEVLV, tbuf1);
									gDiaCScale = getScale(gdiameterC);
									if (gsDevC < 0.1) gsDevC = 0.1;
									else if (gsDevC > double(gDiaCScale)/100.0) gsDevC = double(gDiaCScale)/100.0;
									SendMessage(GetDlgItem(hDlggMain, IDC_SDEVCS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaCScale));
									SendMessage(GetDlgItem(hDlggMain, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100.0+0.5));
									sprintf(tbuf1,"%3.2f",gsDevC);
									SetDlgItemText(hDlggMain, IDC_SDEVCV, tbuf1);
									if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
									return TRUE;
								}
								case IDC_RESDROP:
								{
									gresType = (int)SendMessage((HWND)lParam, CB_GETCURSEL, (WPARAM)FALSE, (LPARAM)FALSE);
									if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
									return TRUE;
								}
							}
							break;
						}
					}
					break;
				}
				break;
			}
			break;
		}
		case WM_HSCROLL:
		{
			if ((HWND) lParam == GetDlgItem(hdlg, IDC_DIAMETERLS))
			{
				gdiameterL = (int)SendMessage(GetDlgItem(hdlg, IDC_DIAMETERLS), TBM_GETPOS, 0, 0) * 2 + 1;
				SetDlgItemInt(hdlg, IDC_DIAMETERLV, gdiameterL, TRUE);
				gDiaLScale = getScale(gdiameterL);
				if (gsDevL < 0.1) gsDevL = 0.1;
				else if (gsDevL > double(gDiaLScale)/100.0) gsDevL = double(gDiaLScale)/100.0;
				SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaLScale));
				SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevL*100.0+0.5));
				sprintf(tbuf1,"%3.2f",gsDevL);
				SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}
			else if ((HWND) lParam == GetDlgItem(hdlg, IDC_DIAMETERCS))
			{
				gdiameterC = (int)SendMessage(GetDlgItem(hdlg, IDC_DIAMETERCS), TBM_GETPOS, 0, 0) * 2 + 1;
				SetDlgItemInt(hdlg, IDC_DIAMETERCV, gdiameterC, TRUE);
				gDiaCScale = getScale(gdiameterC);
				if (gsDevC < 0.1) gsDevC = 0.1;
				else if (gsDevC > double(gDiaCScale)/100.0) gsDevC = double(gDiaCScale)/100.0;
				SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETRANGE, (WPARAM)TRUE, MAKELONG(1, gDiaCScale));
				SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_SETPOS, (WPARAM)TRUE, (int)(gsDevC*100.0+0.5));
				sprintf(tbuf1,"%3.2f",gsDevC);
				SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}
			else if ((HWND) lParam == GetDlgItem(hdlg, IDC_IDEVLS))
			{
				giDevL = ((double)(SendMessage(GetDlgItem(hdlg, IDC_IDEVLS), TBM_GETPOS, 0, 0)))/10.0;
				sprintf(tbuf1,"%3.2f",giDevL);
				SetDlgItemText(hdlg, IDC_IDEVLV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}
			else if ((HWND) lParam == GetDlgItem(hdlg, IDC_IDEVCS))
			{
				giDevC = ((double)(SendMessage(GetDlgItem(hdlg, IDC_IDEVCS), TBM_GETPOS, 0, 0)))/10.0;
				sprintf(tbuf1,"%3.2f",giDevC);
				SetDlgItemText(hdlg, IDC_IDEVCV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}			
			else if ((HWND) lParam == GetDlgItem(hdlg, IDC_SDEVLS))
			{
				gsDevL = ((double)(SendMessage(GetDlgItem(hdlg, IDC_SDEVLS), TBM_GETPOS, 0, 0)))/100.0;
				sprintf(tbuf1,"%3.2f",gsDevL);
				SetDlgItemText(hdlg, IDC_SDEVLV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}
			else if ((HWND) lParam == GetDlgItem(hdlg, IDC_SDEVCS))
			{
				gsDevC = ((double)(SendMessage(GetDlgItem(hdlg, IDC_SDEVCS), TBM_GETPOS, 0, 0)))/100.0;
				sprintf(tbuf1,"%3.2f",gsDevC);
				SetDlgItemText(hdlg, IDC_SDEVCV, tbuf1);
				if (IsWindowVisible(hWndg)) tMyFilter->redoFrame();
				return TRUE;
			}
			break;
		}
		case WM_CLOSE:
		{
			if (hWndg != NULL)
			{
				ShowWindow(hWndg,SW_HIDE);
				DestroyWindow(hWndg);
				hWndg = NULL;
			}
			if (hDlggMain != NULL)
			{
				ShowWindow(hDlggMain, SW_HIDE);
				DestroyWindow(hDlggMain);
				hDlggMain = NULL;
			}
			if (hDlggAdv != NULL)
			{
				ShowWindow(hDlggAdv, SW_HIDE);
				DestroyWindow(hDlggAdv);
				hDlggAdv = NULL;
			}
			if (hDlgg != NULL)
			{
				ShowWindow(hDlgg,SW_HIDE);
				EndDialog(hDlgg, 1);
				hDlgg = NULL;
			}
			PostQuitMessage(0);
			tMyFilter->guiDisable();
			tMyFilter = NULL;
			return TRUE;
		}
		case WM_NOTIFY:
		{
			LPNMHDR pnmh = (LPNMHDR)lParam;
			switch (pnmh->code)
			{
				case TCN_SELCHANGE:
				{
					int iSel = TabCtrl_GetCurSel(GetDlgItem(hDlgg, IDC_TABS));
					if (iSel == 0)
					{
						ShowWindow(hDlggAdv, SW_HIDE);
						ShowWindow(hDlggMain, SW_SHOW);
					}
					else
					{
						ShowWindow(hDlggMain, SW_HIDE);
						ShowWindow(hDlggAdv, SW_SHOW);
					}
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_COMMAND:
			break;
		case WM_DESTROY:
			break;
		case WM_ERASEBKGND:
		{
			if (hWnd == hWndg) return 1;  // don't flicker
			break;
		}
		case WM_PAINT:
		{
			if (hWnd == hWndg && IsWindowVisible(hWnd)) 
			{
				if (GetForegroundWindow() == hWndg) tMyFilter->grabBMPFrame(false);
				else tMyFilter->grabBMPFrameLimited();
			}
			break;
		}
		case WM_CLOSE:
		{
			if (hWnd == hWndg)
			{
				ShowWindow(hWnd, SW_HIDE);
				SetDlgItemText(hDlgg, IDPREVIEW, "SHOW PREVIEW");
			}
			break;
		}
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
    }
	return 0;
}

DWORD WINAPI startWindowTBilateral() 
{
	MSG msg;
	HICON hIcon1;
	WNDCLASSEX wcex;
	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstanceg;
	wcex.hIcon			= LoadIcon(NULL, MAKEINTRESOURCE(IDI_ICON1));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= "TBilateral";
	wcex.hIconSm		= LoadIcon(NULL, MAKEINTRESOURCE(IDI_ICON1));
	RegisterClassEx(&wcex);
	hDlgg = CreateDialog(hInstanceg,MAKEINTRESOURCE(IDD_TABHOLD),NULL,DialogProc);
	DoLockDlgRes();
	hDlggMain = CreateDialogIndirect(hInstanceg, apRes[0], hDlgg, DialogProc);
	hDlggAdv = CreateDialogIndirect(hInstanceg, apRes[1], hDlgg, DialogProc);
	hWndg = CreateWindow("TBilateral", "TBilateral - Real Time Preview", 
			WS_OVERLAPPED|WS_CAPTION|WS_MINIMIZEBOX|WS_SYSMENU,
			0, 0, bi.biWidth+GetSystemMetrics(SM_CXBORDER)*6, 
			bi.biHeight+GetSystemMetrics(SM_CYCAPTION)+GetSystemMetrics(SM_CYBORDER)*6, 
			NULL, NULL, hInstanceg, NULL);
	hIcon1 = LoadIcon(hInstanceg, MAKEINTRESOURCE(IDI_ICON1));
	SendMessage(hWndg, WM_SETICON, (WPARAM)ICON_SMALL, (LPARAM)hIcon1);
	SendMessage(hDlgg, WM_SETICON, (WPARAM)ICON_SMALL, (LPARAM)hIcon1);
	SendMessage(hWndg, WM_SETICON, (WPARAM)ICON_BIG, (LPARAM)hIcon1);
	SendMessage(hDlgg, WM_SETICON, (WPARAM)ICON_BIG, (LPARAM)hIcon1);
	RECT r;
	GetWindowRect(hDlgg,&r);
	SetWindowPos(hWndg,NULL,r.right,r.top,0,0,SWP_NOZORDER|SWP_NOSIZE);
	UpdateWindow(hWndg);
	UpdateWindow(hDlgg);
	ShowWindow(hDlgg, SW_SHOW);
	ShowWindow(hDlggAdv, SW_HIDE);
	ShowWindow(hDlggMain, SW_SHOW);
	ShowWindow(hWndg, SW_HIDE);
	SetEvent(hEventThreadCreated);
    while (GetMessage(&msg, NULL, 0, 0) > 0)
	{
		if (NULL == hDlgg || !IsDialogMessage(hDlgg, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	UnregisterClass(wcex.lpszClassName, wcex.hInstance);
	idg = NULL;
	SetEvent(hEventThreadFinished);
	return (DWORD)0;
}

BOOL APIENTRY DllMain(HANDLE hModule, ULONG ulReason, LPVOID lpReserved) 
{
	switch(ulReason)
	{
		case DLL_PROCESS_ATTACH:
			hInstanceg = (HINSTANCE)hModule;
			hddg = DrawDibOpen();
			break;
		case DLL_PROCESS_DETACH:
			hInstanceg = NULL;
			tMyFilter = NULL;
			if (hddg != NULL) { DrawDibClose(hddg); hddg = NULL; }
			if (hThreadg != NULL)
			{
				WaitForSingleObject(hEventThreadFinished, INFINITE);
				CloseHandle(hThreadg);
				hThreadg = NULL;
				CloseHandle(hEventThreadFinished);
				hEventThreadFinished = NULL;
			}
			break;
	}
    return TRUE;
}