##### 1.2.1:
    Improved luma spatial and temporal check (SIMD) resulting to a bit faster code.

##### 1.2.0:
    Throw error for non-planar formats.
    Added support for 10..16-bit clips.
    Separated SSE2 code.
    Added AVX2 code.
    Added parameter opt.

##### 1.1.0:
    Fixed memory misalignment issue.
    
##### 1.0.0:
    Port of the VapourSynth plugin DeDot.
