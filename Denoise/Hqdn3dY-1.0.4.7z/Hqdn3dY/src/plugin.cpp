/// Hqdn3dY by Andrew Revvo, based on Hqdn3d

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"

extern void Add_Hqdn3d16Y(IScriptEnvironment* env);
extern void Add_Hqdn3dY(IScriptEnvironment* env);

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env)
{
	Add_Hqdn3d16Y(env);
	Add_Hqdn3dY(env);
    return "Hqdn3dY Library";
}
