/// Hqdn3dY by Andrew Revvo, based on Hqdn3d
/// Copyright (C) 2015-2016 Andrew Revvo, http://www.snovidenie.com/

/// Original Code Copyright (C) 2003 Daniel Moreno <comac@comac.darktech.org>
/// Avisynth port (C) 2005 Loren Merritt <lorenm@u.washington.edu>
/// Licensed under the terms of the GNU General Public License v.2

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"
#include <cmath>

namespace Hqdn3dY_16 {

inline unsigned int LowPassMul(unsigned int PrevMul, unsigned int CurrMul, int* Coef){
	int dMul= PrevMul-CurrMul;
	int d=((dMul+0x10007FF)/(65536/16));
	return CurrMul + Coef[d];
}

inline void denoise(const unsigned short* src, unsigned short* dst,
                    unsigned int* LineAnt, unsigned short* FrameAnt,
                    int width, int height, int sStride, int dStride,
                    int* Horizontal, int* Vertical, int* Temporal)
{
	int sLineOffs = 0, dLineOffs = 0;
	unsigned int PixelAnt;
	int PixelDst;

	// First pixel has no left nor top neightbour. Only previous frame
	LineAnt[0] = PixelAnt = src[0]<<8;
	PixelDst = LowPassMul(FrameAnt[0]<<8, PixelAnt, Temporal);
	FrameAnt[0] = (unsigned short)((PixelDst+0x1000007F)/256);
	dst[0]= (unsigned short)((PixelDst+0x1000007F)/256);

	// Fist line has no top neightbour. Only left one for each pixel and last frame
	for (int x = 1; x < width; x++){
		LineAnt[x] = PixelAnt = LowPassMul(PixelAnt, src[x]<<8, Horizontal);
		PixelDst = LowPassMul(FrameAnt[x]<<8, PixelAnt, Temporal);
		FrameAnt[x] = (unsigned short)((PixelDst+0x1000007F)/256);
		dst[x]= (unsigned short)((PixelDst+0x1000007F)/256);
	}

	for (int y = 1; y < height; y++){
		unsigned short* LinePrev=&FrameAnt[y*width];
		sLineOffs += sStride, dLineOffs += dStride;
		// First pixel on each line doesn't have previous pixel
		PixelAnt = src[sLineOffs]<<8;
		LineAnt[0] = LowPassMul(LineAnt[0], PixelAnt, Vertical);
		PixelDst = LowPassMul(LinePrev[0]<<8, LineAnt[0], Temporal);
		LinePrev[0] = (unsigned short)((PixelDst+0x1000007F)/256);
		dst[dLineOffs]= (unsigned short)((PixelDst+0x1000007F)/256);

		for (int x = 1; x < width; x++){
			// The rest are normal
			PixelAnt = LowPassMul(PixelAnt, src[sLineOffs+x]<<8, Horizontal);
			LineAnt[x] = LowPassMul(LineAnt[x], PixelAnt, Vertical);
			PixelDst = LowPassMul(LinePrev[x]<<8, LineAnt[x], Temporal);
			LinePrev[x] = (unsigned short)((PixelDst+0x1000007F)/256);
			dst[dLineOffs+x]= (unsigned short)((PixelDst+0x1000007F)/256);
		}
	}
}

#define ABS(A) ( (A) > 0 ? (A) : -(A) )

inline void PrecalcCoefs(int *Ct, double Dist25)
{
	const double Gamma = log(0.25) / log(1.0 - Dist25/255.0 - 0.00001);
	for (int i = -255*16; i < 256*16; i++) {
		const double Simil = 1.0 - ABS(i) / (16*255.0);
		const double C = pow(Simil, Gamma) * 65536.0 * (double)i / 16.0;
		Ct[16*256+i] = (int)((C<0) ? (C-0.5) : (C+0.5));
	}
}

class Hqdn3dY : public GenericVideoFilter {
public:
	~Hqdn3dY();
	Hqdn3dY(PClip child, AVSValue args, IScriptEnvironment* env);
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);

private:
	int restart_lap; // how many frames back we look when seeking
	PVideoFrame cache;
	int Coefs[2][512*16];
	unsigned int *Line;
	unsigned short *Frame;
	int prev_frame;
	int w, h;
	PVideoFrame filterFrame(PVideoFrame cur, IScriptEnvironment* env);
};

Hqdn3dY::~Hqdn3dY() {
	_aligned_free(Line);
	_aligned_free(Frame);
}

Hqdn3dY::Hqdn3dY(PClip child, AVSValue args, IScriptEnvironment* env)
	: GenericVideoFilter(child)
{
	if(!vi.IsPlanar())
		env->ThrowError("Hqdn3d16Y: requires a planar source");

	double LumSpac = args[1].AsFloat(-1);
	double LumTmp = args[2].AsFloat(-1);
	if(LumSpac < 0)
		LumSpac = 4.0;
	if(LumTmp < 0)
		LumTmp = 1.5 * LumSpac;
	LumSpac = __min(254.9, LumSpac);
	LumTmp = __min(254.9, LumTmp);

	restart_lap = __max(2, (int)(LumTmp+1));
	PrecalcCoefs(Coefs[0], LumSpac);
	PrecalcCoefs(Coefs[1], LumTmp);
	prev_frame = -99999;

	w= vi.width >> 1;
	h= vi.height;

	Line = (unsigned int*)_aligned_malloc(w*sizeof(unsigned int), 16);
	Frame = (unsigned short*)_aligned_malloc(w*h*sizeof(unsigned short), 16);
}

PVideoFrame Hqdn3dY::filterFrame(PVideoFrame cur, IScriptEnvironment* env)
{
	PVideoFrame newframe = env->NewVideoFrame(vi);
	denoise((const unsigned short*)cur->GetReadPtr(PLANAR_Y), (unsigned short*)newframe->GetWritePtr(PLANAR_Y),
			Line, Frame, w, h,
			cur->GetPitch(PLANAR_Y) >> 1, newframe->GetPitch(PLANAR_Y) >> 1,
			Coefs[0], Coefs[0], Coefs[1]);
	return newframe;
}

PVideoFrame __stdcall Hqdn3dY::GetFrame(int n, IScriptEnvironment* env)
{
	if(n == prev_frame)
		return cache;
	// if we skip some frames, filter the gap anyway
	else if(n > prev_frame+1 && n - prev_frame <= restart_lap+1 && prev_frame >= 0) {
		for(int i=prev_frame+1; i<n; i++)
			filterFrame(child->GetFrame(i, env), env);
	}
	// if processing out of sequence, filter several previous frames to minimize seeking problems
	else if(n == 0 || n != prev_frame+1) {
		int sn = __max(0, n - restart_lap);
		PVideoFrame sf = child->GetFrame(sn, env);
		//int x;
		int y;
		int sStride = sf->GetPitch(PLANAR_Y) >> 1;
		const unsigned short* srcp = (const unsigned short*)sf->GetReadPtr(PLANAR_Y);
		// 16 bit clip
		for(y = 0; y < h; y++) {
			unsigned short* dst=&Frame[y*w];
			const unsigned short* src=srcp+y*sStride;
			memcpy((void*)dst, (void*)src, w*sizeof(unsigned short)); //for(x = 0; x < w; x++) dst[x]=src[x];
		}
		for(int i=sn+1; i<n; i++)
			filterFrame(child->GetFrame(i, env), env);
	}
	prev_frame = n;
	cache = filterFrame(child->GetFrame(n, env), env);
	return cache;
}

AVSValue __cdecl Create_Hqdn3dY(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	(void)user_data;
	return new Hqdn3dY(args[0].AsClip(), args, env);
}

} // namespace

void Add_Hqdn3d16Y(IScriptEnvironment* env)
{
	// Hqdn3d16Y(sp=10.0, tp=0.0)
	env->AddFunction("Hqdn3d16Y", "c[sp]f[tp]f", Hqdn3dY_16::Create_Hqdn3dY, 0);
}
