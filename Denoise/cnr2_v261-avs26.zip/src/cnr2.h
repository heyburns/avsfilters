//
//	chroma noise reduction II (version 2.6.1) - Avisynth filter reducing noise on chroma
//	Copyright (C) 2002 Marc Fauconneau
//
//	Inspired by :
//  chroma noise reduction (version 1.1) - VirtualDub filter reducing noise on chroma
//  Copyright (C) 2000 Gilles Mouchard
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//  Please contact me for any bugs or questions.
//  marc.fd@libertysurf.fr
//
//  Change log :
//         30/06/2004 - ver 2.6.1 - YUY2 opts as I had slowed it down - tritical 
//         29/06/2004 - ver 2.6  - Some bug fixes and some code cleanup 
//                                 and rewriting (tritical - kes25c@mizzou.edu)
//         18/11/2003 - ver 2.51 - Further bug fixes (by Klaus Post)
//         13/11/2003 - ver 2.5  - Bug fixes (by Klaus Post)
//         15/12/2002 - ver 2.4  - Bug fixes
//         13/11/2002 - ver 2.3  - YV12 mode, scd (scenechange detection)
//         01/08/2002 - ver 2.2  - Ugly bug fixed
//         31/07/2002 - ver 2.1  - Bug Fixes (thx to dividee ;)
//         20/07/2002 - ver 2.0  - Avisynth filter coded (from scratch)

#define WIN32_LEAN_AND_MEAN
#define VC_EXTRALEAN
#define NOGDI
#include <windows.h>
#include <stdio.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <avisynth.h>

#pragma warning(disable: 4996)

class Cnr2 : public GenericVideoFilter 
{
private:
	PVideoFrame prev;
	unsigned char *py, *py_saved, *cy, *cy_saved;
	unsigned char lt[513];
	unsigned char ut[513];
	unsigned char vt[513];
	const char *mode;
	double scdthr;
	int ln, lm;
	int un, um;
	int vn, vm;
	bool sceneChroma, log;
	int nfrms, keepTrack;
	unsigned int diffmax;
	char buf[256];
	void Cnr2::downSampleYV12(unsigned char *dst, PVideoFrame &src);
	void Cnr2::CopyFrameYV12(PVideoFrame &dst, PVideoFrame &src, IScriptEnvironment *env);
	void Cnr2::CopyFrameYUY2(PVideoFrame &dst, PVideoFrame &src, IScriptEnvironment *env);
	PVideoFrame __stdcall Cnr2::GetFrameYV12(int n, IScriptEnvironment* env);
	PVideoFrame __stdcall Cnr2::GetFrameYUY2(int n, IScriptEnvironment* env);

public:
	PVideoFrame __stdcall Cnr2::GetFrame(int n, IScriptEnvironment* env);

	Cnr2(PClip _child, const char* _mode, double _scdthr, int _ln, int _lm, int _un, int _um, int _vn, 
		int _vm, bool _log, bool _sceneChroma, IScriptEnvironment* env) : GenericVideoFilter(_child), 
		mode(_mode), scdthr(_scdthr), ln(_ln), lm(_lm), un(_un), um(_um), vn(_vn), vm(_vm), log(_log), 
		sceneChroma(_sceneChroma)
	{
		if (!vi.IsYUY2() && !vi.IsYV12())
			env->ThrowError("Cnr2:  YV12 and YUY2 colorspace only!");
		if (ln < 0 || lm < 0 || un < 0 || um < 0 || vn < 0 || vm < 0)
			env->ThrowError("Cnr2:  all n and m settings must be at least 0!");
		if (ln > 255 || lm > 255 || un > 255 || um > 255 || vn > 255 || vm > 255)
			env->ThrowError("Cnr2:  all n and m settings must be less than 256!");
		if (strlen(mode) != 3)
			env->ThrowError("Cnr2:  mode is a 3 character long string!");
		py_saved = py = cy_saved = cy = NULL;
		if (vi.IsYV12()) 
		{
			py = new unsigned char[(vi.width*vi.height)>>2];
			py_saved = py;
			cy = new unsigned char[(vi.width*vi.height)>>2];
			cy_saved = cy;
		}
		prev = env->NewVideoFrame(vi);
		if (sceneChroma)
		{
			if (vi.IsYV12()) diffmax = (int)((scdthr*vi.height*vi.width*331.0f) / 100.0f);
			else diffmax = (int)((scdthr*vi.height*vi.width*443.0f) / 100.0f);
		}
		else diffmax = (int)((scdthr*vi.height*vi.width*219.0f) / 100.0f);
		memset(lt,0,513);  // for safety
		memset(ut,0,513);
		memset(vt,0,513);
		keepTrack = -39482;
		nfrms = vi.num_frames - 1;

		const double pi = M_PI;
		bool Y = true, U = true, V = true;
		if (mode[0] == 'x') Y = false;
		if (mode[1] == 'x') U = false;
		if (mode[2] == 'x') V = false;
		int i, j;
		for (i=-256; i<256; ++i) lt[i+256] = 0;
		for(j=-ln; j<=ln; ++j) 
		{
			if (Y) lt[j+256] = (int)((lm/2) * (1 + cos((j*j*pi)/(ln*ln))));
			else lt[j+256] = (int)((lm/2) * (1 + cos((j*pi)/ ln)));
		}
		for (i=-256; i<256; ++i) ut[i+256] = 0;
		for(j=-un; j<=un; ++j) 
		{
			if (U) ut[j+256] = (int)((um/2) * (1 + cos((j*j*pi)/(un*un))));
			else ut[j+256] = (int)((um/2) * (1 + cos((j*pi)/ un)));
		}
		for (i=-256; i<256; ++i) vt[i+256] = 0;
		for(j=-vn; j<=vn; ++j)
		{
			if (V) vt[j+256] = (int)((vm/2) * (1 + cos((j*j*pi)/(vn*vn))));
			else vt[j+256] = (int)((vm/2) * (1 + cos((j*pi)/ vn)));
		}
		if (log)
		{
			sprintf(buf,"Cnr2 v2.6.1 - (6/30/2004)");
			OutputDebugString(buf);
		}
	}
	Cnr2::~Cnr2()
	{
		if (py_saved != NULL) delete[] py_saved;
		if (cy_saved != NULL) delete[] cy_saved;
	}
};