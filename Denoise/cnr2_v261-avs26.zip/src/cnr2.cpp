//
//	chroma noise reduction II (version 2.6.1) - Avisynth filter reducing noise on chroma
//	Copyright (C) 2002 Marc Fauconneau
//
//	Inspired by :
//  chroma noise reduction (version 1.1) - VirtualDub filter reducing noise on chroma
//  Copyright (C) 2000 Gilles Mouchard
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//  Please contact me for any bugs or questions.
//  marc.fd@libertysurf.fr
//
//  Change log :
//         30/06/2004 - ver 2.6.1 - YUY2 opts as I had slowed it down - tritical 
//         29/06/2004 - ver 2.6  - Some bug fixes and some code cleanup 
//                                 and rewriting (tritical - kes25c@mizzou.edu)
//         18/11/2003 - ver 2.51 - Further bug fixes (by Klaus Post)
//         13/11/2003 - ver 2.5  - Bug fixes (by Klaus Post)
//         15/12/2002 - ver 2.4  - Bug fixes
//         13/11/2002 - ver 2.3  - YV12 mode, scd (scenechange detection)
//         01/08/2002 - ver 2.2  - Ugly bug fixed
//         31/07/2002 - ver 2.1  - Bug Fixes (thx to dividee ;)
//         20/07/2002 - ver 2.0  - Avisynth filter coded (from scratch)

#include "cnr2.h"

PVideoFrame __stdcall Cnr2::GetFrame(int n, IScriptEnvironment* env) 
{
    if (n < 0) n = 0;
    else if (n > nfrms) n = nfrms;
    if (vi.IsYV12()) return(GetFrameYV12(n, env));
    else return(GetFrameYUY2(n, env));
}

PVideoFrame __stdcall Cnr2::GetFrameYV12(int n, IScriptEnvironment* env) 
{
    if (n < 1) return child->GetFrame(n, env);
    PVideoFrame src = child->GetFrame(n, env);
    const unsigned char *srcpY = src->GetReadPtr(PLANAR_Y);
    const unsigned char *srcpU = src->GetReadPtr(PLANAR_U);
    const unsigned char *srcpV = src->GetReadPtr(PLANAR_V);
    const unsigned char *srcp;
    int src_pitchY = src->GetPitch(PLANAR_Y);
    int src_pitchUV = src->GetPitch(PLANAR_V);
    int heightY = src->GetHeight(PLANAR_Y);
    int heightUV = src->GetHeight(PLANAR_V);
    int widthY = src->GetRowSize(PLANAR_Y);
    int widthYd2 = widthY >> 1;
    int widthUV = src->GetRowSize(PLANAR_V);
    downSampleYV12(cy, src);
    if (keepTrack != n) 
    {
        keepTrack = n;
        CopyFrameYV12(prev, child->GetFrame(n-1, env), env);
        downSampleYV12(py, prev);
    }
    PVideoFrame dst = env->NewVideoFrame(vi);
    unsigned char *dstpY = dst->GetWritePtr(PLANAR_Y);
    unsigned char *dstpU = dst->GetWritePtr(PLANAR_U);
    unsigned char *dstpV = dst->GetWritePtr(PLANAR_V);
    unsigned char *dstp, *prevy, *prevp, *curry, *t, *swap;
    int dst_pitchY = dst->GetPitch(PLANAR_Y);
    int dst_pitchUV = dst->GetPitch(PLANAR_V);
    int y, x, ydiff, uvdiff, cr;
    unsigned int difft = 0;
    const int off = 256;
    env->BitBlt(dstpY, dst_pitchY, srcpY, src_pitchY, widthY, heightY);
    // U plane (we add the luma plane diff to difft here not on v)
    prevy = py;
    curry = cy;
    t = ut;
    srcp = srcpU;
    dstp = dstpU;
    prevp = prev->GetWritePtr(PLANAR_U);
    int prev_pitchUV = prev->GetPitch(PLANAR_V);
    if (sceneChroma)
    {
        for (y=0; y<heightUV; ++y) 
        {
            for (x=0; x<widthUV; ++x) 
            {
                ydiff = curry[x]-prevy[x];
                uvdiff = srcp[x]-prevp[x];
                difft += abs(uvdiff) + abs(ydiff<<2);
                cr = (lt[ydiff+off] * t[uvdiff+off]);
                dstp[x] = prevp[x] = (cr*prevp[x] + (65536-cr)*srcp[x] + 32768) >> 16;
            }
            if (difft > diffmax) { goto exit; }
            srcp += src_pitchUV;
            dstp += dst_pitchUV;
            prevp += prev_pitchUV;
            curry += widthYd2;
            prevy += widthYd2;
        }
    }
    else
    {
        for (y=0; y<heightUV; ++y) 
        {
            for (x=0; x<widthUV; ++x) 
            {
                ydiff = curry[x]-prevy[x];
                uvdiff = srcp[x]-prevp[x];
                difft += abs(ydiff<<2);
                cr = (lt[ydiff+off] * t[uvdiff+off]);
                dstp[x] = prevp[x] = (cr*prevp[x] + (65536-cr)*srcp[x] + 32768) >> 16;
            }
            if (difft > diffmax) { goto exit; }
            srcp += src_pitchUV;
            dstp += dst_pitchUV;
            prevp += prev_pitchUV;
            curry += widthYd2;
            prevy += widthYd2;
        }
    }
    // V plane
    prevy = py;
    curry = cy;
    t = vt;
    srcp = srcpV;
    dstp = dstpV;
    prevp = prev->GetWritePtr(PLANAR_V);
    if (sceneChroma)
    {
        for (y=0; y<heightUV; ++y) 
        {
            for (x=0; x<widthUV; ++x) 
            {
                ydiff = curry[x]-prevy[x];
                uvdiff = srcp[x]-prevp[x];
                difft += abs(uvdiff);
                cr = (lt[ydiff+off] * t[uvdiff+off]);
                dstp[x] = prevp[x] = (cr*prevp[x] + (65536-cr)*srcp[x] + 32768) >> 16;
            }
            if (difft > diffmax) { goto exit; }
            srcp += src_pitchUV;
            dstp += dst_pitchUV;
            prevp += prev_pitchUV;
            curry += widthYd2;
            prevy += widthYd2;
        }
    }
    else
    {
        for (y=0; y<heightUV; ++y) 
        {
            for (x=0; x<widthUV; ++x) 
            {
                ydiff = curry[x]-prevy[x];
                uvdiff = srcp[x]-prevp[x];
                cr = (lt[ydiff+off] * t[uvdiff+off]);
                dstp[x] = prevp[x] = (cr*prevp[x] + (65536-cr)*srcp[x] + 32768) >> 16;
            }
            srcp += src_pitchUV;
            dstp += dst_pitchUV;
            prevp += prev_pitchUV;
            curry += widthYd2;
            prevy += widthYd2;
        }
    }
exit:
    if (log) 
    {
        sprintf(buf,"Cnr2 log>  frame %d:  acc/max %u/%u  \t ratio %3.5f", n, difft, diffmax, (float)difft/(float)diffmax);
        OutputDebugString(buf);
        if (difft > diffmax)
        {
            sprintf(buf,"Cnr2 log>  frame %d:  Scene Change Detected!!", n);
            OutputDebugString(buf);
        }
    }
    if (difft > diffmax) return src;
    ++keepTrack;
    swap = py;
    py = cy;
    cy = swap;
    return dst;
}

PVideoFrame __stdcall Cnr2::GetFrameYUY2(int n, IScriptEnvironment* env)
{
    if (n < 1) return child->GetFrame(n, env);
    PVideoFrame src = child->GetFrame(n, env);
    const unsigned char *srcp = src->GetReadPtr();
    int src_pitch = src->GetPitch();
    int height = src->GetHeight();
    int width = src->GetRowSize();
    if (keepTrack != n) 
    {
        keepTrack = n;
        CopyFrameYUY2(prev, child->GetFrame(n-1, env), env);
    }
    unsigned char *prevp = prev->GetWritePtr();
    int prev_pitch = prev->GetPitch();
    int ydiff, udiff, vdiff, chroma1_ratio, chroma2_ratio, x, y;
    unsigned int difft = 0;
    const int off = 256;
    if (sceneChroma)
    {
        for (y=0; y<height; ++y) 
        {
            for (x=0; x<width; x+=4)
            {
                udiff = srcp[x+1] - prevp[x+1];
                vdiff = srcp[x+3] - prevp[x+3];
                ydiff = (srcp[x]+srcp[x+2]-prevp[x]-prevp[x+2])>>1;
                difft += abs(ydiff<<1) + abs(udiff) + abs(vdiff);
                chroma1_ratio = (lt[ydiff+off] * ut[udiff+off]);
                chroma2_ratio = (lt[ydiff+off] * vt[vdiff+off]);
                prevp[x+1] = (chroma1_ratio*prevp[x+1] + (65536-chroma1_ratio)*srcp[x+1] + 32768) >> 16;
                prevp[x+3] = (chroma2_ratio*prevp[x+3] + (65536-chroma2_ratio)*srcp[x+3] + 32768) >> 16;
                prevp[x] = srcp[x];
                prevp[x+2] = srcp[x+2];
            }
            if (difft > diffmax) { goto exit2; }
            srcp += src_pitch;
            prevp += prev_pitch;
        }
    }
    else
    {
        for (y=0; y<height; ++y) 
        {
            for (x=0; x<width; x+=4)
            {
                udiff = srcp[x+1] - prevp[x+1];
                vdiff = srcp[x+3] - prevp[x+3];
                ydiff = (srcp[x]+srcp[x+2]-prevp[x]-prevp[x+2])>>1;
                difft += abs(ydiff<<1);
                chroma1_ratio = (lt[ydiff+off] * ut[udiff+off]);
                chroma2_ratio = (lt[ydiff+off] * vt[vdiff+off]);
                prevp[x+1] = (chroma1_ratio*prevp[x+1] + (65536-chroma1_ratio)*srcp[x+1] + 32768) >> 16;
                prevp[x+3] = (chroma2_ratio*prevp[x+3] + (65536-chroma2_ratio)*srcp[x+3] + 32768) >> 16;
                prevp[x] = srcp[x];
                prevp[x+2] = srcp[x+2];
            }
            if (difft > diffmax) { goto exit2; }
            srcp += src_pitch;
            prevp += prev_pitch;
        }
    }
exit2:
    if (log) 
    {
        sprintf(buf,"Cnr2 log>  frame %d:  acc/max %u/%u  \t ratio %3.3f", n, difft, diffmax, (float)difft/(float)diffmax);
        OutputDebugString(buf);
        if (difft > diffmax)
        {
            sprintf(buf,"Cnr2 log>  frame %d:  Scene Change Detected!!", n);
            OutputDebugString(buf);
        }
    }
    if (difft > diffmax) return src;
    ++keepTrack;
    PVideoFrame dst = env->NewVideoFrame(vi);
    CopyFrameYUY2(dst, prev, env);
    return dst;
}

void Cnr2::downSampleYV12(unsigned char *dst, PVideoFrame &src)
{
    unsigned char *temp = dst;
    const unsigned char *srcpY = src->GetReadPtr(PLANAR_Y);
    int src_pitchY = src->GetPitch(PLANAR_Y) << 1;
    const unsigned char *srcpnY = srcpY + (src_pitchY>>1);
    int widthY = src->GetRowSize(PLANAR_Y) >> 1;
    int heightY = src->GetHeight(PLANAR_Y) >> 1;
    int x, y, temp1;
    for (y=0; y<heightY; ++y) 
    {
        for (x=0; x<widthY; ++x) 
        {
            temp1 = x<<1;
            temp[x] = (srcpY[temp1]+srcpY[temp1+1]+srcpnY[temp1]+srcpnY[temp1+1]+2)>>2;
        }
        srcpY += src_pitchY;
        srcpnY += src_pitchY;
        temp += widthY;
    }
}

void Cnr2::CopyFrameYUY2(PVideoFrame &dst, PVideoFrame &src, IScriptEnvironment *env)
{
    const unsigned char *srcp = src->GetReadPtr();
    int src_pitch = src->GetPitch();
    int width = src->GetRowSize(PLANAR_Y_ALIGNED);
    int height = src->GetHeight();
    unsigned char *dstp = dst->GetWritePtr();
    int dst_pitch = dst->GetPitch();
    env->BitBlt(dstp, dst_pitch, srcp, src_pitch, width, height);
}

void Cnr2::CopyFrameYV12(PVideoFrame &dst, PVideoFrame &src, IScriptEnvironment *env)
{
    const unsigned char *srcpY = src->GetReadPtr(PLANAR_Y);
    const unsigned char *srcpU = src->GetReadPtr(PLANAR_U);
    const unsigned char *srcpV = src->GetReadPtr(PLANAR_V);
    int src_pitchY = src->GetPitch(PLANAR_Y);
    int src_pitchUV = src->GetPitch(PLANAR_V);
    int widthY = src->GetRowSize(PLANAR_Y_ALIGNED);
    int widthUV = src->GetRowSize(PLANAR_V_ALIGNED);
    int heightY = src->GetHeight(PLANAR_Y);
    int heightUV = src->GetHeight(PLANAR_V);
    unsigned char *dstpY = dst->GetWritePtr(PLANAR_Y);
    unsigned char *dstpU = dst->GetWritePtr(PLANAR_U);
    unsigned char *dstpV = dst->GetWritePtr(PLANAR_V);
    int dst_pitchY = dst->GetPitch(PLANAR_Y);
    int dst_pitchUV = dst->GetPitch(PLANAR_V);
    env->BitBlt(dstpY, dst_pitchY, srcpY, src_pitchY, widthY, heightY);
    env->BitBlt(dstpU, dst_pitchUV, srcpU, src_pitchUV, widthUV, heightUV);
    env->BitBlt(dstpV, dst_pitchUV, srcpV, src_pitchUV, widthUV, heightUV);
}

AVSValue __cdecl Create_Cnr2(AVSValue args, void* user_data, IScriptEnvironment* env)
{
    char *mode = "oxx";
    float scdthr = 10.0f;
    int ln = 35;
    int lm = 192;
    int un = 47;
    int um = 255;
    int vn = 47; 
    int vm = 255;
    bool log = false;
    bool sceneChroma = false;
    return new Cnr2(args[0].AsClip(),
                    args[1].AsString(mode),
                    args[2].AsFloat(scdthr),
                    args[3].AsInt(ln),
                    args[4].AsInt(lm),
                    args[5].AsInt(un),
                    args[6].AsInt(um),
                    args[7].AsInt(vn),
                    args[8].AsInt(vm),
                    args[9].AsBool(log),
                    args[10].AsBool(sceneChroma),
                    env);
}

static const AVS_Linkage* AVS_linkage = nullptr;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors) 
{
    AVS_linkage = vectors;
    env->AddFunction("Cnr2", "c[mode]s[scdthr]f[ln]i[lm]i[un]i[um]i[vn]i[vm]i[log]b[sceneChroma]b", Create_Cnr2, 0);
    return "`Cnr2' Chroma Noise Reducer 2.6.1 for avs2.6/avs+";
}