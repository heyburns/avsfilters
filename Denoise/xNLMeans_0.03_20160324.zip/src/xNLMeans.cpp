/*
**					This file is part of
**           xNLMeans for Avisynth 2.6 / Avisynth+
**
**   xNLMeans is an implementation of the NL-means denoising algorithm.
**
**	 Copyright (C) 2015,2016 martin53 at doom9
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 3 of the License, or
**   (at your option) any later version.
**   Please obtain your copy of the GPLv3 license from
**   https://www.gnu.org/licenses/licenses.en.html
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
*/

#include "xNLMeans.h"
#include ".\DebugPrintf.cpp"

//=============================================================================
//=============================================================================
//=============================================================================

xNLMeans::xNLMeans(PClip _child, int _a, int _s, int _d, float_t _h, float_t _sdev, int _planes, bool _lsb, PClip _mask, PClip _rclip, float_t _digits, float_t _diffout, float_t _lcomp, float_t _vcomp, float_t _wmin, float_t _dw, int _threads, PClip _hclip, IScriptEnvironment *env) :
	GenericVideoFilter(_child), a(_a), s(_s), d(_d), h_par(_h), sdev_par(_sdev), planes(_planes), lsb(_lsb), mask(_mask), rclip(_rclip), xdigits(_digits), diffout(_diffout), lcomp_par(_lcomp), vcomp_par(_vcomp), wmin_par(_wmin), dw_par(_dw), threads(_threads), hclip(_hclip)
{
	if (!vi.IsPlanar() && !vi.IsY8())
		env->ThrowError("xNLMeans: only planar input. (%d)", vi.pixel_type);
	if (width > 0x7fff)
		env->ThrowError("xNLMeans: width must be < 32768. Tile larger images. (%d)", width);
	if (height > 0x7fff)
		env->ThrowError("xNLMeans: height must be < 32768. Tile larger images. (%d)", height);
	if (h_par < 0)
		env->ThrowError("xNLMeans: 'h' must be >= 0. (%d)", h_par);
	if (a < 0)
		env->ThrowError("xNLMeans: 'a' must be >= 0. (%d)", a);
	if (s < 0)
		env->ThrowError("xNLMeans: 's' must be >= 0. (%d)", s);
	if (d < 0 || d > 2)
		env->ThrowError("xNLMeans: 'd' must be [0...2] (%d)", d);
	if (planes < 0 || planes > 7)
		env->ThrowError("xNLMeans: 'planes' must be [0...7]. (%d)", planes);
	if (vi.width < a + a + 1)
		env->ThrowError("xNLMeans: frame width must be >= 2*a+1. (%d < %d)", vi.width, a + a + 1);
	if ((lsb ? (vi.height >> 1) : vi.height) < a + a + 1)
		env->ThrowError("xNLMeans: frame height must be >= 2*a+1. (%d < %d)", vi.height, a + a + 1);
	if (threads < 0)
		env->ThrowError("xNLMeans: 'threads' must be >= 0 (%d)", threads);

	if (d)
		rclip ? rclip->SetCacheHints(CACHE_WINDOW, d) : child->SetCacheHints(CACHE_WINDOW, d);

	num_frames = vi.num_frames;
	h_exec = h_par < 0 ? -h_par : h_par;

	wmin_exec1 = wmin_par;
	wmin_exec2 = 0;
	dw_exec = dw_par;
	lcomp_exec = lcomp_par;
	vcomp_exec = vcomp_par;


	if (mask) {
		VideoInfo vi2 = mask->GetVideoInfo();
		if (!vi.IsYV24() && !vi.IsY8() && !planes == 1)
			env->ThrowError("xNLMeans:  only YV24 or Y8 source when mask is used, except with planes=1. (%d)", vi2.pixel_type);
		if (!vi2.IsPlanar() && !vi2.IsY8())
			env->ThrowError("xNLMeans:  only planar mask. (%d)", vi2.pixel_type);
		if (vi.width != vi2.width || (vi.height >> (lsb ? 1 : 0)) != vi2.height)
			env->ThrowError("xNLMeans:  mask must match clip dimensions. (%d!=%d or %d!=%d)", vi.width, vi2.width, (vi.height >> (lsb ? 1 : 0)), vi2.height);
		if (vi.num_frames != vi2.num_frames)
			env->ThrowError("xNLMeans:  mask must match clip length. (%d!=%d)", vi.num_frames, vi2.num_frames);
	}

	if (rclip) {
		VideoInfo vi2 = rclip->GetVideoInfo();
		if (vi.width != vi2.width || vi.height != vi2.height)
			env->ThrowError("xNLMeans:  rclip must match clip dimensions. (%d!=%d or %d!=%d)", vi.width, vi2.width, vi.height, vi2.height);
		if (vi.num_frames != vi2.num_frames)
			env->ThrowError("xNLMeans:  rclip must match clip length. (%d!=%d)", vi.num_frames, vi2.num_frames);
		if (vi.pixel_type != vi2.pixel_type)
			env->ThrowError("xNLMeans:  rclip must match pixel_type. (%d!=%d)", vi.pixel_type, vi2.pixel_type);
	}

	if (hclip) {
		VideoInfo vi2 = hclip->GetVideoInfo();
		if (!vi2.IsPlanar() && !vi2.IsY8())
			env->ThrowError("xNLMeans:  only planar hclip. (%d)", vi2.pixel_type);
		if (vi.num_frames != vi2.num_frames)
			env->ThrowError("xNLMeans:  hclip must match clip length. (%d!=%d)", vi.num_frames, vi2.num_frames);
	}

	/*
	gweight1[] is a prepared array with the size of one neighborhood row or column. It contains the geometrical weights used in the calculation of the similarity
	of neighborhoods: pixels towards the border are weighted less to the unsimilarity than center pixels.

	For xNLMeans, this neighborhood weight function f(radius) should be a row|column separable function which meets the restriction for coordinate (x,y) in the
	neighborhood, where radius=sqrt(x�+y�): f(x) * f(y) = f(sqrt(x�+y�)).
	If this requirement is met, the weighting separation into x- and y-axes still weights pixels in the neighborhood strictly by their distance, regardless
	of their direction (i.e. horizontal|vertical vs. diagnoal).
	The Gauss function f(x) = exp(x�/2s�) and, as a special case of it, the flat function f(x) = 1 meet this requirement.
	*/
	int sgw = min(s, S_SD1);
	gweight1 = (float_t *)_aligned_malloc(2 * (sgw + sgw + 1)*sizeof(float_t), 64);
	if (!gweight1) env->ThrowError("xNLMeans: memory allocation failure (gweight1).");
	//gweight2 = (float_t *)_aligned_malloc(2 * (s + s + 1)*sizeof(float_t), 64);
	//if (!gweight2) env->ThrowError("xNLMeans: memory allocation failure (gweight2).");

	sdev_exec = sdev_par;
	if (sdev_par < 0)
		sdev_exec = -sdev_par * powf(h_exec, AUTO_SDEV_K0);		// automatic s
	if (sdev_exec > 0) {
		int w = 0;
		float_t sdevinv1_2 = -1.0f / (2 * sdev_exec * sdev_exec);
		//float_t sdevinv2_2 = -2.0f;
		for (int j = -sgw; j <= sgw; j++) {
			gweight1[w]   = expf(j * j * sdevinv1_2);
			//gweight2[w] = expf(j * j * sdevinv2_2);
			w++;
		}
		for (int j = -sgw; j <= sgw; j++) {						// later need a 2nd weight scale copy for simplified index access
			gweight1[w]   = expf(j * j * sdevinv1_2);
			//gweight2[w] = expf(j * j * sdevinv2_2);
			w++;
		}
	}

	// determine how many threads to use
	if (!_threads) {
		SYSTEM_INFO si;
		GetSystemInfo(&si);
		threads = si.dwNumberOfProcessors;
	}
#ifdef _DEBUG
	threads = 1;
#endif

	tP = (threadParams*)malloc(sizeof(threadParams) * threads);
	if (!tP) env->ThrowError("xNLMeans: memory allocation failure (thread parameters).");

	//make sure one strip is at least 'a'+1 pixels wide
	while (vi.width / threads < a + 1 && threads > 1) threads--;

	for (int i = 0; i < threads; i++) {
		tP[i].pThis = this;

		tP[i].threadnumber = i;
		tP[i].xstart = vi.width * i / threads;
		tP[i].xstopp = vi.width * (i + 1) / threads;

		maxheight = vi.height;
		if (lsb) maxheight >>= 1;
		tP[i].row_stat = (stat_t *)_aligned_malloc(maxheight * sizeof(stat_t), 64);				// array size threads*(s+s+1) would be sufficient but vi.height saves some index calculations
		if (!tP[i].row_stat) env->ThrowError("xNLMeans: memory allocation failure (row_stat).");
	}
	//InitializeCriticalSection(&Avisynth_CritSect);
}	// end of constructor function

//=============================================================================
//=============================================================================
//=============================================================================

xNLMeans::~xNLMeans()
{
	//DeleteCriticalSection(&Avisynth_CritSect);
	if (varinv) _aligned_free(varinv);
	if (wstats) _aligned_free(wstats);
	for (int i = threads - 1; i >= 0; i--) {
		if (tP && tP[i].row_stat) _aligned_free(tP[i].row_stat);
	}
	if (tP) free(tP);
	//if (gweight2) _aligned_free(gweight2);
	if (gweight1) _aligned_free(gweight1);
}	// end of destructor function

//=============================================================================
//=============================================================================
//=============================================================================

PVideoFrame __stdcall xNLMeans::GetFrame(int current_frame, IScriptEnvironment *env)
{
	// Main process thread, start work on actual frame //

	PVideoFrame src = child->GetFrame(current_frame, env);
	PVideoFrame dst = env->NewVideoFrame(vi);
	PVideoFrame ref = rclip ? rclip->GetFrame(current_frame, env) : src;

	PVideoFrame ref_add1 = NULL;
	PVideoFrame ref_add2 = NULL;
	PVideoFrame ref_sub1 = NULL;
	PVideoFrame ref_sub2 = NULL;
	if (d >= 1 && current_frame + 1 < vi.num_frames) ref_add1 = rclip ? rclip->GetFrame(current_frame + 1, env) : child->GetFrame(current_frame + 1, env);
	if (d == 2 && current_frame + 2 < vi.num_frames) ref_add2 = rclip ? rclip->GetFrame(current_frame + 2, env) : child->GetFrame(current_frame + 2, env);
	if (d >= 1 && current_frame > 0)                 ref_sub1 = rclip ? rclip->GetFrame(current_frame - 1, env) : child->GetFrame(current_frame - 1, env);
	if (d == 2 && current_frame > 1 )                ref_sub2 = rclip ? rclip->GetFrame(current_frame - 2, env) : child->GetFrame(current_frame - 2, env);

	if (mask) {
		PVideoFrame msk = mask->GetFrame(current_frame, env);
		mskp = msk->GetReadPtr(PLANAR_Y);
		mskpitch = msk->GetPitch(PLANAR_Y);
	}

	for (int b = 0; b < (vi.IsY8() ? 1 : 3); ++b) {							// PLANES LOOP b: plane index 0..2
		pl = 1 << b;														// pl: plane as Avisynth likes it: Y=1, U=2, V=4
		srcp = src->GetReadPtr(pl);
		srcpitch = src->GetPitch(pl);
		width = src->GetRowSize(pl);
		height = src->GetHeight(pl);
		dstp = dst->GetWritePtr(pl);
		dstpitch = dst->GetPitch(pl);

		if (!(pl & planes)) {
			if (diffout > 0) {
				memset(dstp, 0x80, dstpitch * height * sizeof(char));
				if (lsb) memset(dstp + (height>>1) * dstpitch, 0x00, dstpitch * (height>>1) * sizeof(char));
			} else
				env->BitBlt(dstp, dstpitch, srcp, srcpitch, width, height);
		} else {
			refp = ref->GetReadPtr(pl);
			refpitch = ref->GetPitch(pl);

			if (lsb) height >>= 1;
			if (maxheight < height) env->ThrowError("xNLMeans:  height failure (growing after graph compilation)!");
			if (maxpitch < srcpitch) {
				if (varinv) _aligned_free(varinv);
				if (wstats) _aligned_free(wstats);
				maxpitch = srcpitch;
				// wstats[0] = adds up the intensities of neighbors.
				// wstats[1] = adds up weight counts of neighbor pixels (normalizer).
				// wstats[2] = stores maximum found neighbor weight, to give destination pixel the same weight.
				wstats = (float_t *)_aligned_malloc(maxpitch * maxheight * 3 * sizeof(float_t), 64);
				if (!wstats) env->ThrowError("xNLMeans:  malloc failure (wstats)!");
				if (vcomp_par) {
					varinv = (float_t *)_aligned_malloc(maxpitch * maxheight * sizeof(float_t), 64);
					if (!varinv) env->ThrowError("xNLMeans:  malloc failure (varinv)!");
				}
			}

			if (hclip) {
				PVideoFrame hcl = hclip->GetFrame(current_frame, env);
				const unsigned char * hclp = hcl->GetReadPtr(PLANAR_Y);
				h_exec = (float_t)hclp[0] / 25;

				// autmatic setting of all parameters that are derived from h
				if (h_exec > 0 && sdev_par < 0)
					sdev_exec = -sdev_par * powf(h_exec, AUTO_SDEV_K0);
				if (h_exec > 0 && sdev_exec > 0) {
					int w = 0;
					float_t sdevinv2 = -1.0f / (2 * sdev_exec * sdev_exec);
					for (int j = -s; j <= s; j++)
						gweight1[w++] = expf(j*j * sdevinv2);
					for (int j = -s; j <= s; j++)
						gweight1[w++] = expf(j*j * sdevinv2);
				}
			}
			hinv2 = h_exec ? -1.f / (h_exec * h_exec) : -1;
			if (wmin_par < 0) {
				wmin_exec1 = -wmin_par * AUTO_WMIN_K0 * powf(h_exec, AUTO_WMIN_K1);
				wmin_exec2 = (xdigits >= 0 ? powf(10, -xdigits) : powf(10, xdigits * max(AUTO_DIGITS_K0 + AUTO_DIGITS_K1 * h_exec + AUTO_DIGITS_K2 * h_exec * h_exec, 1)));
				max_wmin = AUTO_MAX_WMIN_K0 * powf(h_exec, AUTO_MAX_WMIN_K1);
			}

			if (dw_par < 0) dw_exec = -dw_par * AUTO_DW_K0 * powf(h_exec, AUTO_DW_K1);
			if (lcomp_par < -1) lcomp_exec = -(lcomp_par + 1) * AUTO_LCOMP_K0 * powf(h_exec, AUTO_LCOMP_K1);
			if (vcomp_par < 0) vcomp_exec = -vcomp_par * max(min((h_exec - 5.f) / 10.f, 0.1f), 0.f);

			memset(wstats, 0, srcpitch * height * 3 * sizeof(float_t));

			refp_add1 = NULL;
			refp_add2 = NULL;
			refp_sub1 = NULL;
			refp_sub2 = NULL;
			if (d >= 1 && current_frame + 1 < vi.num_frames) refp_add1 = ref_add1->GetReadPtr(pl);
			if (d == 2 && current_frame + 2 < vi.num_frames) refp_add2 = ref_add2->GetReadPtr(pl);
			if (d >= 1 && current_frame > 0)                 refp_sub1 = ref_sub1->GetReadPtr(pl);
			if (d == 2 && current_frame > 1)                 refp_sub2 = ref_sub2->GetReadPtr(pl);

			// ******************************************************************
			// Start pixel column threads
			// ******************************************************************

			int selector = (d ? 0 : 32) + (lsb ? 16 : 0) + (lcomp_exec ? 8 : 0) + (mask ? 4 : 0) + (vcomp_exec ? 2 : 0) + (sdev_exec > 0 ? 1 : 0);
			for (int i = 0; i < threads; i++)
			{
				tP[i].selector = selector;
				tP[i].current_frame = current_frame;
				tP[i].env = env;
				tP[i].hdl = (HANDLE)_beginthreadex(NULL, 0, xNLMeans::thClassGetFrame, &tP[i], 0, NULL);
				if (tP[i].hdl == NULL) env->ThrowError("xNLMeans: unable to establish thread handles.");
				//DEBUGPRINTF("Master %x class thread call %d", this, i);
			}

			//DEBUGPRINTF("Master sleeps");
			for (int i = 0; i < threads; i++)
			{
				WaitForSingleObject(tP[i].hdl, INFINITE);
				GetExitCodeThread(tP[i].hdl, &tP[i].exitcode);
				CloseHandle(tP[i].hdl);
			}
			//DEBUGPRINTF("Master woke up");
			for (int i = 0; i < threads; i++)
				if (tP[i].exitcode != 0) {
					//DEBUGPRINTF("Thread %d exit code %x", i, tP[i].exitcode);
					env->ThrowError("xNLMeans: thread %d exited with code %x", i, tP[i].exitcode);
				}

			// ******************************************************************
			// threads end here
			// ******************************************************************

		}	// end of conditional plane processing
	}		// END OF PLANES LOOP
	return dst;
}

/*	CLASS FUNCTION	*/
unsigned __stdcall xNLMeans::thClassGetFrame(void * ptr)
{
	threadParams * pThread = (threadParams *)ptr;
	//DEBUGPRINTF("Thread %d: selector %d class start", pThread->threadnumber, pThread->selector);
	//Class function uses the 'this' pointer to call the instance function of the instance that called the class.
	xNLMeans * pInstance = pThread->pThis;
	int ret;
	switch (pThread->selector) {
	//										   FLDMVS
	case 0:		ret = pInstance->thInstGetFrame______(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;	//Instance function runs in instance context
	case 1:		ret = pInstance->thInstGetFrame_____S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 2:		ret = pInstance->thInstGetFrame____V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 3:		ret = pInstance->thInstGetFrame____VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 4:		ret = pInstance->thInstGetFrame___M__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 5:		ret = pInstance->thInstGetFrame___M_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 6:		ret = pInstance->thInstGetFrame___MV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 7:		ret = pInstance->thInstGetFrame___MVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 8:		ret = pInstance->thInstGetFrame__D___(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 9:		ret = pInstance->thInstGetFrame__D__S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 10:	ret = pInstance->thInstGetFrame__D_V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 11:	ret = pInstance->thInstGetFrame__D_VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 12:	ret = pInstance->thInstGetFrame__DM__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 13:	ret = pInstance->thInstGetFrame__DM_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 14:	ret = pInstance->thInstGetFrame__DMV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 15:	ret = pInstance->thInstGetFrame__DMVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 16:	ret = pInstance->thInstGetFrame_L____(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 17:	ret = pInstance->thInstGetFrame_L___S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 18:	ret = pInstance->thInstGetFrame_L__V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 19:	ret = pInstance->thInstGetFrame_L__VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 20:	ret = pInstance->thInstGetFrame_L_M__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 21:	ret = pInstance->thInstGetFrame_L_M_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 22:	ret = pInstance->thInstGetFrame_L_MV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 23:	ret = pInstance->thInstGetFrame_L_MVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 24:	ret = pInstance->thInstGetFrame_LD___(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 25:	ret = pInstance->thInstGetFrame_LD__S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 26:	ret = pInstance->thInstGetFrame_LD_V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 27:	ret = pInstance->thInstGetFrame_LD_VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 28:	ret = pInstance->thInstGetFrame_LDM__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 29:	ret = pInstance->thInstGetFrame_LDM_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 30:	ret = pInstance->thInstGetFrame_LDMV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 31:	ret = pInstance->thInstGetFrame_LDMVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 32:	ret = pInstance->thInstGetFrameF_____(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 33:	ret = pInstance->thInstGetFrameF____S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 34:	ret = pInstance->thInstGetFrameF___V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 35:	ret = pInstance->thInstGetFrameF___VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 36:	ret = pInstance->thInstGetFrameF__M__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 37:	ret = pInstance->thInstGetFrameF__M_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 38:	ret = pInstance->thInstGetFrameF__MV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 39:	ret = pInstance->thInstGetFrameF__MVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 40:	ret = pInstance->thInstGetFrameF_D___(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 41:	ret = pInstance->thInstGetFrameF_D__S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 42:	ret = pInstance->thInstGetFrameF_D_V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 43:	ret = pInstance->thInstGetFrameF_D_VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 44:	ret = pInstance->thInstGetFrameF_DM__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 45:	ret = pInstance->thInstGetFrameF_DM_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 46:	ret = pInstance->thInstGetFrameF_DMV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 47:	ret = pInstance->thInstGetFrameF_DMVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 48:	ret = pInstance->thInstGetFrameFL____(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 49:	ret = pInstance->thInstGetFrameFL___S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 50:	ret = pInstance->thInstGetFrameFL__V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 51:	ret = pInstance->thInstGetFrameFL__VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 52:	ret = pInstance->thInstGetFrameFL_M__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 53:	ret = pInstance->thInstGetFrameFL_M_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 54:	ret = pInstance->thInstGetFrameFL_MV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 55:	ret = pInstance->thInstGetFrameFL_MVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 56:	ret = pInstance->thInstGetFrameFLD___(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 57:	ret = pInstance->thInstGetFrameFLD__S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 58:	ret = pInstance->thInstGetFrameFLD_V_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 59:	ret = pInstance->thInstGetFrameFLD_VS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 60:	ret = pInstance->thInstGetFrameFLDM__(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 61:	ret = pInstance->thInstGetFrameFLDM_S(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 62:	ret = pInstance->thInstGetFrameFLDMV_(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	case 63:	ret = pInstance->thInstGetFrameFLDMVS(pThread->current_frame, pThread->env, pThread->threadnumber, pThread->xstart, pThread->xstopp, pThread->row_stat); break;
	}


	//DEBUGPRINTF("Thread %d: class end", pThread->threadnumber);
	return ret;
}

#define FASTMODE					// LSBMODE flags that weight can be used for two pixels at a time
#define LSBMODE						// LSBMODE flags that vertically stacked msb/lsb clip is processed as defined in dither package
#define LCOMPMODE					// LCOMPMODE flags that the lcomp luma compensation should be used
#define MASKMODE					// MASKMODE flags that a mmask is used
#define VCOMPMODE					// VCOMPMODE flags that variance compensation should be used
#define SDEVMODE					// SDEVMODE flags that a geometrical weight function is used
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LSBMODE
#define LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef FASTMODE
#define LSBMODE
#define LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LSBMODE
#define LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef LCOMPMODE
#define MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef MASKMODE
#define VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef VCOMPMODE
#define SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"
#undef SDEVMODE
#include "xNLMeans_GetFrameXX.cpp"

AVSValue __cdecl xNLMeans_VersionNumber(AVSValue args, void* user_data, IScriptEnvironment* env) {
	double v = VERSION_NUMBER;
	return  v;
}

AVSValue __cdecl Create_xNLMeans(AVSValue args, void* user_data, IScriptEnvironment* env)
{
	PClip srcclip = NULL, hclip = NULL, maskclip = NULL, refclip = NULL;
	float_t h_par = DEF_H;

	if (!args[0].IsClip())
		env->ThrowError("xNLMeans: first argument must be a clip!");

	srcclip = args[0].AsClip();

	//if YUY2 input: convert to YV16
	if (args[0].AsClip()->GetVideoInfo().IsYUY2())
	{
		try
		{
			AVSValue iargs[5] = { args[0].AsClip(), false, "", "", "" };
			srcclip = env->Invoke("ConvertToYV16", AVSValue(iargs, 5)).AsClip();
		}
		catch (IScriptEnvironment::NotFound)
		{
			env->ThrowError("xNLMeans: unable to invoke YUY2->ConvertToYV16()!");
		}
	}
	if (args[8].Defined()) maskclip = args[8].AsClip();						//mask
	if (args[9].Defined()) refclip = args[9].AsClip();						//rclip

	if (args[4].IsClip())													//h
		hclip = args[4].AsClip();
	else
		h_par = (float_t)args[4].AsFloat(DEF_H);

	if (args[0].AsClip()->GetVideoInfo().IsRGB24() || args[0].AsClip()->GetVideoInfo().IsRGB32())
	{
		PClip redclip, grnclip, bluclip, aclip, outclip;
		try
		{
			AVSValue iargs[2] = { args[0].AsClip(), "Y8" };
			redclip = new xNLMeans(env->Invoke("ShowRed", AVSValue(iargs, 2)).AsClip(),
				args[1].AsInt(DEF_A),
				args[2].AsInt(DEF_S),
				args[3].AsInt(DEF_D),
				h_par,
				args[5].AsFloat(DEF_SDEV),
				1,															//planes
				args[7].AsBool(DEF_LSB),
				maskclip,													//mask
				refclip,													//rclip
				args[10].AsFloat(DEF_DIGITS),
				args[11].AsFloat(DEF_DIFFOUT),
				args[12].AsFloat(DEF_LCOMP),
				args[13].AsFloat(DEF_VCOMP),
				args[14].AsFloat(DEF_WMIN),
				args[15].AsFloat(DEF_DW),
				args[16].AsInt(DEF_THREADS),
				hclip,
				env);
			grnclip = new xNLMeans(env->Invoke("ShowGreen", AVSValue(iargs, 2)).AsClip(),
				args[1].AsInt(DEF_A),
				args[2].AsInt(DEF_S),
				args[3].AsInt(DEF_D),
				h_par,
				args[5].AsFloat(DEF_SDEV),
				1,															//planes
				args[7].AsBool(DEF_LSB),
				maskclip,													//mask
				refclip,													//rclip
				args[10].AsFloat(DEF_DIGITS),
				args[11].AsFloat(DEF_DIFFOUT),
				args[12].AsFloat(DEF_LCOMP),
				args[13].AsFloat(DEF_VCOMP),
				args[14].AsFloat(DEF_WMIN),
				args[15].AsFloat(DEF_DW),
				args[16].AsInt(DEF_THREADS),
				hclip,
				env);
			bluclip = new xNLMeans(env->Invoke("ShowBlue", AVSValue(iargs, 2)).AsClip(),
				args[1].AsInt(DEF_A),
				args[2].AsInt(DEF_S),
				args[3].AsInt(DEF_D),
				h_par,
				args[5].AsFloat(DEF_SDEV),
				1,															//planes
				args[7].AsBool(DEF_LSB),
				maskclip,													//mask
				refclip,													//rclip
				args[10].AsFloat(DEF_DIGITS),
				args[11].AsFloat(DEF_DIFFOUT),
				args[12].AsFloat(DEF_LCOMP),
				args[13].AsFloat(DEF_VCOMP),
				args[14].AsFloat(DEF_WMIN),
				args[15].AsFloat(DEF_DW),
				args[16].AsInt(DEF_THREADS),
				hclip,
				env);
			if (args[0].AsClip()->GetVideoInfo().IsRGB32())
			{
				aclip = env->Invoke("ShowAlpha", AVSValue(iargs, 2)).AsClip();
				AVSValue iargs[4] = { aclip, redclip, grnclip, bluclip };
				return env->Invoke("MergeARGB", AVSValue(iargs, 4)).AsClip();
			}
			else
			{
				AVSValue iargs[4] = { redclip, grnclip, bluclip, "RGB24" };
				return env->Invoke("MergeRGB", AVSValue(iargs, 4)).AsClip();
			}
		}
		catch (IScriptEnvironment::NotFound)
		{
			env->ThrowError("xNLMeans: sorry, unable to process RGB frame!");
		}
	}
	else
	{
		return new xNLMeans(srcclip,
			args[1].AsInt(DEF_A),
			args[2].AsInt(DEF_S),
			args[3].AsInt(DEF_D),
			h_par,
			args[5].AsFloat(DEF_SDEV),
			args[6].AsInt(DEF_PLANES),
			args[7].AsBool(DEF_LSB),
			maskclip,															//mask
			refclip,															//rclip
			args[10].AsFloat(DEF_DIGITS),
			args[11].AsFloat(DEF_DIFFOUT),
			args[12].AsFloat(DEF_LCOMP),
			args[13].AsFloat(DEF_VCOMP),
			args[14].AsFloat(DEF_WMIN),
			args[15].AsFloat(DEF_DW),
			args[16].AsInt(DEF_THREADS),
			hclip,
			env);
	}
	/*
	arg	default	param
	0	-		source clip
	1	 6		a		- area radius where to compare similarity neighborhoods
	2	 4		s		- similarity neigborhood radius
	3	 0		d		- temporal neigborhood, only [0...2]
	4	 1.		h		- filter strength, can be float or clip
	5	-1.		sdev	- gaussian Standard deviation for neighborhood weighting
	6	 1		planes	- bitmask which planes to process: y=1,u=2,v=4
	7	false	lsb		- process stacked 16 bit clip
	8	 -		mask	- clip to restrict processed pixels
	9	 -		rclip	- alternative metric clip
	10	-1.		digits	- weight limit for neighbor weights (in decimal digits)
	11	 0.		diffout - display difference between input and output instead of filtered output
	12	-2.		lcomp	- luma offset compensation
	13	 0.		vcomp	- neighborhood variance compensation
	14	-1.		wmin	- minimum found weight to fill up with original pixel
	15	-1.		dw		- weight delta to prev. step to stop further filtering
	16	 0		threads	- number of CPU threads to use (0=automatic)
	(17)		hclip, not exposed
	(18)		env, not exposed
	*/
}

const AVS_Linkage *AVS_linkage = NULL;

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors)
{
	AVS_linkage = vectors;
	env->AddFunction("xNLMeans_VersionNumber", "", xNLMeans_VersionNumber, 0);
	env->AddFunction("xNLMeans", "c[a]i[s]i[d]i[h].[sdev]f[planes]i[lsb]b[mask]c[rclip]c[digits]f[diffout]f[lcomp]f[vcomp]f[wmin]f[dw]f[threads]i", Create_xNLMeans, 0);
	return 0;
}
