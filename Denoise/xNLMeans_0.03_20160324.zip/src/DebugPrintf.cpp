#ifdef DEBUGNAME
#include <cstdio>		//needed by OutputDebugString()

int debugprintf(char* fmt, ...) {
	const char*nam = DEBUGNAME;
	char printString[4096] = "";
	char *p = printString;
	while (*p++ = *nam++);
	--p;                                        // @ nul term
	va_list argp;
	va_start(argp, fmt);
	vsprintf_s(p, sizeof(printString) + printString - p, fmt, argp);
	va_end(argp);
	for (; *p++;);
	--p;                                        // @ nul term
	if (printString == p || p[-1] != '\n') {
		p[0] = '\n';                          // append n/l if not there already
		p[1] = '\0';
	}
	OutputDebugString(printString);
	return p - printString;                       // strlen printString
}
#define DEBUGPRINTF(fmt, ...)   debugprintf(fmt, ##__VA_ARGS__)
#else
#define DEBUGPRINTF(fmt,...)        /* fmt */
#endif
