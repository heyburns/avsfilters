// frame row loop
__int16 yf = max(0, -yshift);
__int16 startrow = yf;
__int16 yfmaxx = min(height, height - yshift);		// Keep �n shifted pixel neighborhood in frame.
__int16 y2f = yf + yshift;
#ifdef MASKMODE
const unsigned char * mskp_ = mskp + yf * mskpitch;
#endif
const unsigned char * refp_ = refp + yf  * refpitch + xf;
const unsigned char * ref2Zp_ = refZp + y2f * refpitch + x2f;
float_t * wstatsp = wstats + 3 * (yf * srcpitch + xf);
#ifdef VCOMPMODE
float_t * varinvp = varinv + yf * srcpitch + xf;
#ifdef FASTMODE
float_t * varinv2p = varinv + y2f * srcpitch + x2f;
#endif
#endif
#ifdef LSBMODE
const unsigned char * refLp_ = refp_ + height * refpitch;
const unsigned char * ref2LZp_ = ref2Zp_ + height * refpitch;
#endif
#ifdef FASTMODE
float_t * wstats2p = wstats + 3 * (y2f * srcpitch + x2f);
#endif
for (; yf < yfmaxx; yf++, y2f++, refp_ += refpitch, ref2Zp_ += refpitch, wstatsp += 3 * srcpitch
#ifdef LSBMODE
	, refLp_ += refpitch, ref2LZp_ += refpitch
#endif
#ifdef FASTMODE
	, wstats2p += 3 * srcpitch
#endif
#ifdef MASKMODE
	, mskp_ += mskpitch
#endif
#ifdef VCOMPMODE
	, varinvp += srcpitch
#ifdef FASTMODE
	, varinv2p += srcpitch
#endif
#endif
	)

{
#ifdef MASKMODE
	// avoid processing of masked pixels
	bool refMask = mskp_[xf] > 0;
#ifdef FASTMODE
	bool cmpMask = mskp[y2f * mskpitch + x2f] > 0;
	if (!refMask && !cmpMask) continue;				// referenxe pixel and compared pixel not in mask?
#else
	if (!refMask) continue;							// center pixel not in mask?
#endif							
#endif
	float_t gw = 0;
	const unsigned char *refp__, *ref2Zp__;
#ifdef LSBMODE
	const unsigned char *refLp__, *ref2LZp__;
#endif

	//neighborhood columns loop - aggregated difference values
	__int16 yj = max(yf - s, startrow);				// start after last processed row, but only s rows up
	__int16 yjmaxx = yf + min(s + 1, height - max(yf, y2f));// stop s rows after yf row, but not beyond frame border
	__int16 y2j = yj + yshift;
	refp__ = refp + yj * refpitch;
	ref2Zp__ = refZp + y2j * refpitch;
#ifdef LSBMODE
	refLp__ = refp__ + height * refpitch;
	ref2LZp__ = ref2Zp__ + height * refpitch;
	for (; yj < yjmaxx; yj++, y2j++, refp__ += refpitch, ref2Zp__ += refpitch, refLp__ += refpitch, ref2LZp__ += refpitch)
#else
	for (; yj < yjmaxx; yj++, y2j++, refp__ += refpitch, ref2Zp__ += refpitch)
#endif
	{
		// neighborhood row loop - direct pixel evaluation
		__int16 i = max(-s, max(-xf, -x2f));		// column i is relative to xf_
		__int16 imax = min(s, width - 1 - max(xf, x2f));
		__int16 xfi = xf + i;
		__int16 x2fi = x2f + i;
		__int16 si = s + i;
		float_t d2;
		float_t diff_sdx = 0;
		float_t mean_sdx = 0;
		float_t gweights_sdx = 0;
#ifdef SDEVMODE
		float_t diff_sd2 = 0;
		float_t mean_sd2 = 0;
		float_t gweights_sd2 = 0;
		float_t diff_sd1 = 0;
		float_t mean_sd1 = 0;
		float_t gweights_sd1 = 0;
#endif
		for (; i <= imax; i++, xfi++, x2fi++, si++)
		{
#ifdef LSBMODE
			d2 = (float_t)(ref2Zp__[x2fi]) + 1.f / 256 * ref2LZp__[x2fi] - refp__[xfi] + 1.f / 256 * refLp__[xfi];
#else
			d2 = (float_t)ref2Zp__[x2fi] - refp__[xfi];
#endif
			diff_sdx += d2 * d2;
#ifdef LCOMPMODE
			mean_sdx += d2;
#endif
			gweights_sdx++;
#ifdef SDEVMODE
			if (i >= -S_SD1 && i <= S_SD1) {
				if (s > S_SD1) {
					diff_sd2 += d2 * d2;
#ifdef LCOMPMODE
					mean_sd2 += d2;
#endif
					gweights_sd2++;
				}
				gw = gweight1[si];
				diff_sd1 += gw * d2 * d2;				// variance of luminosity difference, weighted with pixel location in neighborhood
#ifdef LCOMPMODE
				mean_sd1 += gw * d2;
#endif
				gweights_sd1 += gw;						// gweights: adds up all pixel location weights
			}
#endif
		}
		row_stat[yj].diff_sdx = (float_t)diff_sdx / gweights_sdx;
#ifdef LCOMPMODE
		row_stat[yj].mean_sdx = (float_t)mean_sdx / gweights_sdx;
#endif
#ifdef SDEVMODE
		if (s > S_SD1) row_stat[yj].diff_sd2 = (float_t)diff_sd2 / gweights_sd2;
		row_stat[yj].diff_sd1 = (float_t)diff_sd1 / gweights_sd1;
#ifdef LCOMPMODE
		if (s > S_SD1) row_stat[yj].mean_sd2 = (float_t)mean_sd2 / gweights_sd2;
		row_stat[yj].mean_sd1 = (float_t)mean_sd1 / gweights_sd1;
#endif
#endif
	}
	startrow = yjmaxx;

	// neighborhood column-aggregates-row loop
	float_t gweights_sdx = 0;
	float_t mean_sdx = 0;
	float_t diff_sdx = 0;
#ifdef SDEVMODE
	float_t gweights_sd2 = 0;
	float_t mean_sd2 = 0;
	float_t diff_sd2 = 0;
	float_t gweights_sd1 = 0;
	float_t mean_sd1 = 0;
	float_t diff_sd1 = 0;
#endif

#if defined(VCOMPMODE) && defined(FASTMODE)
	float_t diff2 = 0;
#endif
	yj = max(yf - s, max(0, -yshift));
	__int16 j = yj - yf;
	__int16 sj = s + j;
	for (; yj < yjmaxx; yj++, j++, sj++)
	{
		diff_sdx += row_stat[yj].diff_sdx;
#ifdef LCOMPMODE
		mean_sdx += row_stat[yj].mean_sdx;
#endif
		gweights_sdx++;
#ifdef SDEVMODE
		if (j >= -S_SD1 && j <= S_SD1) {
			if (s > S_SD1) {
				diff_sd2 += row_stat[yj].diff_sd2;
#ifdef LCOMPMODE
				mean_sd2 += row_stat[yj].mean_sd2;
#endif
				gweights_sd2++;
			}
			gw = gweight1[sj];
			diff_sd1 += gw * row_stat[yj].diff_sd1;
#ifdef LCOMPMODE
			mean_sd1 += gw * row_stat[yj].mean_sd1;
#endif
			gweights_sd1 += gw;
		}
#endif
	}

	float_t weight = 1.0, weight2 = 1.0;
	if (diff_sdx > 0)								// not a bug that it is checked here already - all later manipulations will also be 0 if it is 0 here
	{
		diff_sdx /= gweights_sdx;
#ifdef LCOMPMODE
		mean_sdx /= gweights_sdx;
		diff_sdx += lcomp_exec * mean_sdx * mean_sdx;
#endif
#ifdef SDEVMODE
		if (s > S_SD1) diff_sd2 /= gweights_sd2;
		diff_sd1 /= gweights_sd1;
#ifdef LCOMPMODE
		if (s > S_SD1) {
			mean_sd2 /= gweights_sd2;
			diff_sd2 += lcomp_exec * mean_sd2 * mean_sd2;
		}
		mean_sd1 /= gweights_sd1;
		diff_sd1 += lcomp_exec * mean_sd1 * mean_sd1;
#endif
		if (s > S_SD1 && diff_sd2 < diff_sdx) diff_sdx = diff_sd2;
		if (diff_sd1 < diff_sdx) diff_sdx = diff_sd1;					// to reduce halos close to object edge: prefer small patch close to edge
#endif
#ifdef VCOMPMODE
#ifdef FASTMODE
		diff2 = diff_sdx * varinv2p[0];
#endif
		diff_sdx *= varinvp[0];
#else
		diff_sdx *= hinv2_;
#endif
		weight = expf(diff_sdx);
#ifdef DEBUGNAME
		if (weight > 1.001) {
			DEBUGPRINTF("xNLMeans error: weight > 1. %d diff=%f", weight, diff_sdx);
			return 0x0815;
		}
#endif
#ifdef FASTMODE
#ifdef VCOMPMODE
		weight2 = expf(diff2);
#ifdef DEBUGNAME
		if (weight2 > 1.001) {
			DEBUGPRINTF("xNLMeans error: weight2 > 1. %d diff2=%f", weight2, diff2);
			return 0x0815;
		}
#endif
#else
		weight2 = weight;
#endif
#ifdef MASKMODE
		if (!refMask) weight = 0;					// only in fastmode: at least one of the masks must be open
		if (!cmpMask) weight2 = 0;
#endif
#endif
	}
	if (weight > min_weight)
	{
#ifdef LSBMODE
		wstatsp[0] += weight * ((float_t)ref2Zp_[0] + 1.f / 256 * ref2LZp_[0]);
#else
		wstatsp[0] += weight * ref2Zp_[0];
#endif
		wstatsp[1] += weight;						// weights count and sum for destination pixel are increased by values from compared pixel.
		if (weight > wstatsp[2]) wstatsp[2] = weight;
		weightsumplane += weight;
	}
#ifdef FASTMODE
	if (weight2 > min_weight)
	{
#ifdef LSBMODE
		wstats2p[0] += weight2 * ((float_t)refp_[0] + 1.f / 256 * refLp_[0]);
#else
		wstats2p[0] += weight2 * refp_[0];
#endif
		wstats2p[1] += weight2;						// weights count and sum for compared pixel are increased by values from destination pixel in fastmode.
		if (weight2 > wstats2p[2]) wstats2p[2] = weight2;
		weightsumplane += weight2;
	}
#endif
}
// end of frame row loop
