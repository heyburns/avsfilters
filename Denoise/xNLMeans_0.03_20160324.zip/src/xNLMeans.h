/*
**					This file is part of
**           xNLMeans for Avisynth 2.6 / Avisynth+
**
**   xNLMeans is an implementation of the NL-means denoising algorithm.
**
**	 Copyright (C) 2015,2016 martin53 at doom9
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 3 of the License, or
**   (at your option) any later version.
**   Please obtain your copy of the GPLv3 license from
**   https://www.gnu.org/licenses/licenses.en.html
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
*/

#include <windows.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <malloc.h>
#include <float.h>
#include "avisynth.h"
#include <process.h>														// for _beginthreadex()
#include <stdio.h>

//#define DEBUGNAME "xNLMeans: "
#define VERSION_NUMBER (double)0.03

#define DEF_A 6
#define DEF_S 4
#define DEF_D 0
#define DEF_H 1.f
#define DEF_SDEV -1.f
#define DEF_PLANES 1
#define DEF_LSB false
#define DEF_DIGITS -1.f
#define DEF_DIFFOUT 0.f
#define DEF_LCOMP -2.f
#define DEF_VCOMP 0.f
#define DEF_WMIN -1.f
#define DEF_DW -1.f
#define DEF_THREADS 0

#define DEF_FRACTION 0.f
#define DEF_MINCOUNT 0

#define S_SD1 3
#define AUTO_H_K0 0.055/0.259
#define AUTO_H_K1 1./0.259
#define AUTO_H_MIN 0.3f
#define AUTO_H_MAX 7.f
#define AUTO_SDEV_K0 0.18f
#define AUTO_WMIN_K0 1.789f
#define AUTO_WMIN_K1 0.0631f
#define AUTO_MAX_WMIN_K0 2.3345f
#define AUTO_MAX_WMIN_K1 0.1845f
#define AUTO_LCOMP_K0 0.83f
#define AUTO_LCOMP_K1 0.31f
#define AUTO_DIGITS_K0 0.6336f
#define AUTO_DIGITS_K1 0.333f
#define AUTO_DIGITS_K2 -0.0275f
#define AUTO_DW_K0 0.00135f
#define AUTO_DW_K1 -0.21f

#define STATS_RESOLUTION 16
#define STATS_ARRSIZE 20*16
#define STATS_ARRSIZEM1 (STATS_ARRSIZE - 1)

#define float_t float
#define abs_(x) (x < 0 ? -x : x)

class xNLMeans : public GenericVideoFilter
{
private:
	int a;																	// area radius where to look for for comparable pixels
	int s;																	// similarity neighborhood radius: pixels are compareble if they share similar neighborhoods (regarding luminosity)
	int d;
	float_t h_par;
	float_t sdev_par;
	int planes;
	bool lsb;
	PClip mask;
	PClip rclip;
	float_t xdigits;
	float_t diffout;
	float_t lcomp_par;
	float_t vcomp_par;
	float_t wmin_par;
	float_t dw_par;															// weight limit
	int threads;
	PClip hclip;

	// derived from parameters
	float_t h_exec;
	float_t hinv2;
	float_t wmin_exec1 = -1;												// -1: just to find bugs more easily
	float_t wmin_exec2 = 0;
	float_t dw_exec;
	float_t sdev_exec;
	float_t lcomp_exec;
	float_t vcomp_exec;

	// clip related
	int num_frames;															// clip framecount
	int width = 0;
	int height = 0;
	const unsigned char *srcp = NULL;
	int srcpitch = 0;
	const unsigned char *refp = NULL;
	int refpitch = 0;
	const unsigned char *refp_add1 = NULL;
	const unsigned char *refp_add2 = NULL;
	const unsigned char *refp_sub1 = NULL;
	const unsigned char *refp_sub2 = NULL;
	const unsigned char *mskp = NULL;
	int mskpitch = 0;
	unsigned char *dstp = NULL;
	int dstpitch = 0;

	// processing related
	int pl;																	// current plane
	int maxpitch = 0;
	int maxheight = 0;
	float_t *gweight1 = NULL;
	//float_t *gweight2 = NULL;
	float_t *varinv = NULL;
	float_t *wstats = NULL;
	float_t min_weight;
	float_t max_wmin = 1;

	//CRITICAL_SECTION Avisynth_CritSect;

	//IScriptEnvironment *env;
	struct stat_t {
		float_t mean_sdx;
		float_t diff_sdx;
		float_t mean_sd2;
		float_t diff_sd2;
		float_t mean_sd1;
		float_t diff_sd1;
	};

	struct threadParams {
		xNLMeans * pThis;
		int selector;
		int current_frame;
		IScriptEnvironment *env;
		int threadnumber;
		int xstart;
		int xstopp;
		stat_t * row_stat = NULL;
		HANDLE hdl;
		DWORD exitcode;
	};

	threadParams * tP;

public:
	xNLMeans::xNLMeans(PClip _child, int _a, int _s, int _d, float_t _h, float_t _sdev, int _planes, bool _lsb, PClip _mask, PClip _rclip, float_t _digits, float_t _diffout, float_t _lcomp, float_t _vcomp, float_t _wmin, float_t _dw, int _threads, PClip _hclip, IScriptEnvironment *env);
	xNLMeans::~xNLMeans();
	PVideoFrame __stdcall xNLMeans::GetFrame(int current_frame, IScriptEnvironment *env);

	static unsigned __stdcall xNLMeans::thClassGetFrame(void * ptr);

	int xNLMeans::thInstGetFrame______(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_____S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame____V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame____VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame___M__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame___M_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame___MV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame___MVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__D___(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__D__S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__D_V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__D_VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__DM__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__DM_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__DMV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame__DMVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L____(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L___S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L__V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L__VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L_M__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L_M_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L_MV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_L_MVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LD___(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LD__S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LD_V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LD_VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LDM__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LDM_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LDMV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrame_LDMVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_____(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF____S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF___V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF___VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF__M__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF__M_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF__MV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF__MVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_D___(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_D__S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_D_V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_D_VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_DM__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_DM_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_DMV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameF_DMVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL____(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL___S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL__V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL__VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL_M__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL_M_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL_MV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFL_MVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLD___(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLD__S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLD_V_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLD_VS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLDM__(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLDM_S(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLDMV_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
	int xNLMeans::thInstGetFrameFLDMVS(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat);
};
