/*
**					This file is part of
**           xNLMeans for Avisynth 2.6 / Avisynth+
**
**   xNLMeans is an implementation of the NL-means denoising algorithm.
**
**	 Copyright (C) 2015,2016 martin53 at doom9
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 3 of the License, or
**   (at your option) any later version.
**   Please obtain your copy of the GPLv3 license from
**   https://www.gnu.org/licenses/licenses.en.html
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
*/

/*
This file is included several times with different preprocessor symbols
to create multiple fast versions of the function with as few 'if' clauses as possible
*/

/*================================================================================================================================

										Worker Threads

================================================================================================================================*/

#undef thInstGetFrame_MODE_

#ifdef FASTMODE
#ifdef LSBMODE
#ifdef LCOMPMODE
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFLDMVS
#else
#define thInstGetFrame_MODE_ thInstGetFrameFLDMV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFLDM_S
#else
#define thInstGetFrame_MODE_ thInstGetFrameFLDM__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFLD_VS
#else
#define thInstGetFrame_MODE_ thInstGetFrameFLD_V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFLD__S
#else
#define thInstGetFrame_MODE_ thInstGetFrameFLD___
#endif
#endif
#endif
#else
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFL_MVS
#else
#define thInstGetFrame_MODE_ thInstGetFrameFL_MV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFL_M_S
#else
#define thInstGetFrame_MODE_ thInstGetFrameFL_M__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFL__VS
#else
#define thInstGetFrame_MODE_ thInstGetFrameFL__V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameFL___S
#else
#define thInstGetFrame_MODE_ thInstGetFrameFL____
#endif
#endif
#endif
#endif
#else
#ifdef LCOMPMODE
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF_DMVS
#else
#define thInstGetFrame_MODE_ thInstGetFrameF_DMV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF_DM_S
#else
#define thInstGetFrame_MODE_ thInstGetFrameF_DM__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF_D_VS
#else
#define thInstGetFrame_MODE_ thInstGetFrameF_D_V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF_D__S
#else
#define thInstGetFrame_MODE_ thInstGetFrameF_D___
#endif
#endif
#endif
#else
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF__MVS
#else
#define thInstGetFrame_MODE_ thInstGetFrameF__MV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF__M_S
#else
#define thInstGetFrame_MODE_ thInstGetFrameF__M__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF___VS
#else
#define thInstGetFrame_MODE_ thInstGetFrameF___V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrameF____S
#else
#define thInstGetFrame_MODE_ thInstGetFrameF_____
#endif
#endif
#endif
#endif
#endif
#else
#ifdef LSBMODE
#ifdef LCOMPMODE
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_LDMVS
#else
#define thInstGetFrame_MODE_ thInstGetFrame_LDMV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_LDM_S
#else
#define thInstGetFrame_MODE_ thInstGetFrame_LDM__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_LD_VS
#else
#define thInstGetFrame_MODE_ thInstGetFrame_LD_V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_LD__S
#else
#define thInstGetFrame_MODE_ thInstGetFrame_LD___
#endif
#endif
#endif
#else
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_L_MVS
#else
#define thInstGetFrame_MODE_ thInstGetFrame_L_MV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_L_M_S
#else
#define thInstGetFrame_MODE_ thInstGetFrame_L_M__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_L__VS
#else
#define thInstGetFrame_MODE_ thInstGetFrame_L__V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_L___S
#else
#define thInstGetFrame_MODE_ thInstGetFrame_L____
#endif
#endif
#endif
#endif
#else
#ifdef LCOMPMODE
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame__DMVS
#else
#define thInstGetFrame_MODE_ thInstGetFrame__DMV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame__DM_S
#else
#define thInstGetFrame_MODE_ thInstGetFrame__DM__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame__D_VS
#else
#define thInstGetFrame_MODE_ thInstGetFrame__D_V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame__D__S
#else
#define thInstGetFrame_MODE_ thInstGetFrame__D___
#endif
#endif
#endif
#else
#ifdef MASKMODE
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame___MVS
#else
#define thInstGetFrame_MODE_ thInstGetFrame___MV_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame___M_S
#else
#define thInstGetFrame_MODE_ thInstGetFrame___M__
#endif
#endif
#else
#ifdef VCOMPMODE
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame____VS
#else
#define thInstGetFrame_MODE_ thInstGetFrame____V_
#endif
#else
#ifdef SDEVMODE
#define thInstGetFrame_MODE_ thInstGetFrame_____S
#else
#define thInstGetFrame_MODE_ thInstGetFrame______
#endif
#endif
#endif
#endif
#endif
#endif

/*	GetFrame() Instance Thread Function    */
int xNLMeans::thInstGetFrame_MODE_(int current_frame, IScriptEnvironment *env, int threadnumber, int xstart, int xstopp, stat_t * row_stat)
{
	//DEBUGPRINTF("Thread %d: instance start, instance %x", threadnumber, this);
	float_t weightoldplane = 0;
	float_t hinv2_ = hinv2;
	float_t min_weight = 0.001f * wmin_exec2;
	const unsigned char *refZp = NULL;
#ifdef LSBMODE
	const unsigned char *refLp = NULL;
	const unsigned char *refLZp = NULL;
#endif
#ifdef VCOMPMODE
	// If variance compensation is active, the variance for each pixel is stored in an array of frame size to avoid repeated calculation
	// Geometrical weight and neighborhood size are same as with similarity search below

	// frame column loop
	for (__int16 xf = xstart; xf < (h_exec ? xstopp : 0); xf++)
	{
		// frame row loop
		float_t mean_sdx, diff_sdx, gweights_sdx;
#ifdef SDEVMODE
		float_t mean_sd1, diff_sd1, gweights_sd1;
		float_t mean_sd2, diff_sd2, gweights_sd2;
#endif
		__int16 startrow = 0;
#ifdef MASKMODE
		const unsigned char * mskp_ = mskp;
#endif
		float_t * varinvp = varinv + xf;
		for (__int16 yf = 0; yf < height; yf++, varinvp += srcpitch
#ifdef MASKMODE
			, mskp_ += mskpitch
#endif
			)
		{
#ifdef MASKMODE
			// no processing of masked pixels
			if (mskp_[xf] == 0) continue;									// center pixel not in mask?
#endif
#ifdef SDEVMODE
			float_t gw = 0;
#endif
			__int16 yj = max(yf - s, startrow);								// start after last processed row, but only s rows up
			__int16 yjmaxx = yf + min(s + 1, height - yf);					// stop s rows after yf row, but not beyond frame border
			for (; yj < yjmaxx; yj++)										// row yj is absolute
			{
				// neighborhood row loop - direct pixel evaluation
				__int16 i = max(-xf, -s);									// column i is relative to xf_
				__int16 imax = min(s, width - 1 - xf);
				const unsigned char * refp_ = refp + yj * refpitch + xf + i;
				__int16 si = s + i;
				diff_sdx = 0;
				mean_sdx = 0;
				gweights_sdx = 0;
#ifdef SDEVMODE
				if (s > S_SD1) {
					diff_sd2 = 0;
					mean_sd2 = 0;
					gweights_sd2 = 0;
				}
				diff_sd1 = 0;
				mean_sd1 = 0;
				gweights_sd1 = 0;
#endif
				for (; i <= imax; i++, si++, refp_++)
				{
					__int16 d = (__int16)refp_[0];
					diff_sdx += d * d;
					mean_sdx += d;
					gweights_sdx++;
#ifdef SDEVMODE
					if (i >= -S_SD1 && i <= S_SD1) {
						if (s > S_SD1) {
							diff_sd2 += d * d;
							mean_sd2 += d;
							gweights_sd2++;
						}
						gw = gweight1[si];
						diff_sd1 += gw * d * d;								// variance of luminosity difference, weighted with pixel location in neighborhood
						mean_sd1 += gw * d;
						gweights_sd1 += gw;									// gweights: adds up all pixel location weights
					}
#endif
				}
				row_stat[yj].diff_sdx = diff_sdx / gweights_sdx;
				row_stat[yj].mean_sdx = mean_sdx / gweights_sdx;
#ifdef SDEVMODE
				if (s > S_SD1) {
					row_stat[yj].diff_sd2 = diff_sd2 / gweights_sd2;
					row_stat[yj].mean_sd2 = mean_sd2 / gweights_sd2;
				}
				row_stat[yj].diff_sd1 = diff_sd1 / gweights_sd1;
				row_stat[yj].mean_sd1 = mean_sd1 / gweights_sd1;
#endif
			}
			startrow = yjmaxx;

			// neighborhood column-aggregates-row loop
			// calculate the values for the neighborhood square from the aggregated column values
			diff_sdx = 0;
			mean_sdx = 0;
			gweights_sdx = 0;
#ifdef SDEVMODE
			if (s > S_SD1) {
				diff_sd2 = 0;
				mean_sd2 = 0;
				gweights_sd2 = 0;
			}
			diff_sd1 = 0;
			mean_sd1 = 0;
			gweights_sd1 = 0;
#endif
			yj = max(yf - s, 0);
			__int16 j = yj - yf;
			__int16 sj = s + j;
			for (; yj < yjmaxx; yj++, j++, sj++)
			{
				diff_sdx += row_stat[yj].diff_sdx;
				mean_sdx += row_stat[yj].mean_sdx;
				gweights_sdx++;
#ifdef SDEVMODE
				if (j >= -S_SD1 && j <= S_SD1) {
					if (s > S_SD1) {
						diff_sd2 += row_stat[yj].diff_sd2;
						mean_sd2 += row_stat[yj].mean_sd2;
						gweights_sd2++;
					}
					gw = gweight1[sj];
					diff_sd1 += gw * row_stat[yj].diff_sd1;
					mean_sd1 += gw * row_stat[yj].mean_sd1;
					gweights_sd1 += gw;
				}
#endif
			}

			// store local variance
			mean_sdx /= gweights_sdx;
			diff_sdx /= gweights_sdx;
			diff_sdx -= mean_sdx * mean_sdx;
#ifdef SDEVMODE
			if (s > S_SD1) {
				mean_sd2 /= gweights_sd2;
				diff_sd2 /= gweights_sd2;
				diff_sd2 -= mean_sd2 * mean_sd2;
			}
			mean_sd1 /= gweights_sd1;
			diff_sd1 /= gweights_sd1;
			diff_sd1 -= mean_sd1 * mean_sd1;
			if (s > S_SD1 && diff_sd2 < diff_sdx) diff_sdx = diff_sd2;
			if (diff_sd1 < diff_sdx) diff_sdx = diff_sd1;
#endif

			varinvp[0] = powf((diff_sdx + 1.f) / h_exec, -vcomp_exec) * hinv2_;	// (diff+1) avoids numerical problem of pow(0,-1)

		}	// end of frame row loop
	}	// end of frame column loop
#endif

/*
	How it Works

	outmost loop in frame is a radius, starting from one, ending with parameter a, or earlier when weight w is reached.
	Inside this loop, xshift (column) and yshift (row) loops control how a 'offset vector' walks thru these values: (1,0), (-1,1) (0,1) (1,1), (-2,1) (2,1) (-2,2) (-1,2) (0,2) (1,2) (2,2)
	i,e always starting with row delta = 0 and increasing distance from the origin to the right: 1, 2 etc and then the next lower row(s) -/+ the distance, finally a complete row below that.
	So a growing half square is filled right to the origin and below of it.
	This is true for FASTMODE.
	In normal mode, the row starts 'radius' lines above, i.e. *upper and* lower half square around the pixel.

	The offset vector represents the offset between the in/out frame and the potentially pixels in the region +-a around them.
	Two pointers are established, to point to the source frame, and shifted as described, the frame again (or a neighbor frame).

	If both pointers step 1 increment downwards, the new neighborhood contains one new row at the bottom and it lacks one rot at the top, compared to the previous pointer settings.
	This allows to read in one row at a time and calculate its properties for the two pixels (i.e. the column-weighted differences), but not yet row-weighted.
	The row values are stored in the vector row_diff.
	The column and row pixel weights (more distant pixels shall weigh less for the comparison of the neighborhoods) are regarded as being 'separable': The column weight is biggest at the center
	and lower at top and bottom. The row weight is formed the same way: bigger at the center and lower to left and right ends.

	To evaluate the difference value of the whole neighborhood, first a all weighted aggregated row values are stored in the vector (running line by line, only one new row has to be added).
	Then the vector values are added up again with weights.
	*/

	bool done = false;

	// frame number loop
	for (__int16 zshift = 0; zshift <= d; zshift = zshift > 0 ? -zshift : -zshift + 1)
	{
		if (done) continue;

		// radius loop
		for (__int16 r = 0; r <= (h_exec ? a : -1); r++)
		{
			if (done) continue;

			if (current_frame + zshift < 0 || current_frame + zshift >= num_frames) continue;
			if (r == 0 && zshift == 0) continue;							// don't compare pixel with itself - always shift inside frame or in time

			switch (zshift) {												// set source frame
			case -2:	refZp = refp_sub2;	break;
			case -1:	refZp = refp_sub1;	break;
			case  0:	refZp = refp;		break;
			case  1:	refZp = refp_add1;	break;
			case  2:	refZp = refp_add2;	break;
			}
#ifdef LSBMODE
			refLZp = refZp + height * refpitch;
#endif
			// vertical shift loop
			for (__int16 yshift = -r; yshift <= r; yshift++)
			{
				if (done) continue;
				__int16 xinc = r << 1;
				if (abs(yshift) == r) xinc = 1;								// process all columns of first+last rows of radius square

				// horizontal shift loop
				for (__int16 xshift = -r; xshift <= r; xshift += xinc)
				{
					if (done) continue;

					// frame column loop
					float_t weightsumplane = 0;
					__int16 xf = max(0 - xshift, xstart);
					__int16 xfmaxx = min(width - xshift, xstopp);

					__int16 x2f = xf + xshift;
#ifdef FASTMODE
					if (xshift < 0)
					{
						//omit writing to sibling's memory if it belongs to other thread:
						for (; x2f < xstart; xf++, x2f++)
						{
#undef FASTMODE
#include "xNLMeans_GetFrameXX_FrameLoop.cpp"
						}

					}
					else
						if (xshift > 0 || (xshift == 0 && yshift > 0))
						{
							//FASTMODE: only siblings rightward or in same column and downward, weight added to both pixels
							for (; x2f < xstopp; xf++, x2f++)
							{
#define FASTMODE
#include "xNLMeans_GetFrameXX_FrameLoop.cpp"
							}
							//omit writing to sibling's memory if it belongs to other thread:
							for (; xf < xfmaxx; xf++, x2f++)
							{
#undef FASTMODE
#include "xNLMeans_GetFrameXX_FrameLoop.cpp"
							}
							if (weightsumplane < dw_exec * weightoldplane) done = true;
							weightoldplane += weightsumplane;
						}
#define FASTMODE
#else
					for (; xf < xfmaxx; xf++, x2f++)
					{
#include "xNLMeans_GetFrameXX_FrameLoop.cpp"
					}
					if (weightsumplane < dw_exec * weightoldplane) done = true;
					weightoldplane += weightsumplane;
#endif
					// end of frame column loop
				}
				// end of horizontal shift loop
			}
			// end of vertical shift loop
		}
		// end of radius
	}
	// end of frame number loop

	//==========================================================================	
	//fill the output frame plane
	//==========================================================================	

	//refp, srcp, mskp, dstp must still point to their resp. plane starts!
	const unsigned char * refp_ = refp;
	const unsigned char * srcp_ = srcp;
	unsigned char * dstp_ = dstp;
	float_t dst;
#ifdef MASKMODE
	const unsigned char * mskp_ = mskp;
#endif
#ifdef LSBMODE
	const unsigned char * refLp_ = refp + height * refpitch;
	const unsigned char * srcLp_ = srcp + height * srcpitch;
	unsigned char * dstLp_ = dstp + height * dstpitch;
	float_t src;
#else
	__int16 src;
#endif

	for (__int16 yf = 0; yf < height; yf++) {							// y: absolute row of destination pixel
		float_t * wstatsp = wstats + 3 * (yf * srcpitch + xstart);
		for (__int16 xf = xstart; xf < xstopp; xf++, wstatsp += 3) {	// x: absolute column of destination pixel
			if (wstatsp[1] <= FLT_MIN) {								// this also implicitly applies with mask when pixel ist masked i.e. blend == 0
				if (diffout <= 0) {
					dstp_[xf]  = srcp_[xf];
#ifdef LSBMODE
					dstLp_[xf] = srcLp_[xf];
#endif
				}
			}
			else {
				src = srcp_[xf];
#ifdef LSBMODE
				src += 1.f / 256 * srcLp_[xf];
#endif
#ifdef LSBMODE
				if (rclip) wstatsp[0] += wstatsp[1] * (src - refp_[xf] - 1.f / 256 * refLp_[xf]);
#else
				if (rclip) wstatsp[0] += wstatsp[1] * (src - refp_[xf]);
#endif
				float_t w = 0;
				if (wmin_exec2)
					w = wmin_exec1 * wstatsp[2] * min(wmin_exec2 / wstatsp[2], max_wmin);
				else
					w = wmin_exec1 * wstatsp[2];
				dst =  wstatsp[0];
				dst += w * src;
				w   += wstatsp[1];
				dst /= w;
				if (diffout > 0) {
					dst -= src;
					dst *= diffout;
					dst += 128;
				}
#ifdef MASKMODE
				float_t blend = mskp_[xf];
				if (blend < 255) dst = 1.f / 255 * ((255.f - blend) * src + blend * dst);
				if (blend > 0)
#endif
				{
#ifdef LSBMODE
					unsigned __int16 d = max(min(int(256 * dst + 0.499999), 0xffff), 0);
					dstp_[xf] = d >> 8;
					dstLp_[xf] = d & 0xff;
#else
					dstp_[xf] = max(min(int(dst + 0.499999), 0xff), 0);
#endif
				}
			}
		}	// end of xf loop
		srcp_ += srcpitch;												// update pointers by one row for processing of next destination pixel
		dstp_ += dstpitch;
		if (rclip) refp_ += refpitch;
#ifdef MASKMODE
		mskp_ += mskpitch;
#endif
#ifdef LSBMODE
		srcLp_ += srcpitch;
		dstLp_ += dstpitch;
		if (rclip) refLp_ += refpitch;
#endif
	}	// end of yf loop

	//DEBUGPRINTF("Thread %d: instance end", threadnumber);
	return 0;
}
