/*
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

// ----------------------------------------------------------------
//	Compiling for Avisynth v2.58 & v2.60/x86, v2.60/x64, under VS2008
//
// For AVS+, also need additional Avisynth+ headers somewhere in an AVS directory,
//
// AVS
//   alignment.h
//   avisynth.h
//   capi.h
//   config.h
//   cpuid.h
//   minmax.h
//   types.h
//   win.h
//
// Point Menu/Tools/Options/Projects and Solutions/VC Directories/ :Include Files: Win32 and x64, to the AVS Parent.
//
// For x64, add '_WIN64' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//        (Do NOT delete any 'WIN32' entry).
// For Avs v2.5, Add 'AVISYNTH_PLUGIN_25' to Preprocessor Definitions (for both C++/Preprocessor & Resources/General).
//   Avs v2.5 includes AVISYNTH_INTERFACE_VERSION=3 as avisynth25.h
//   Avs+ v2.6/x86/x64 includes AVISYNTH_INTERFACE_VERSION=6 as avisynth.h
// ----------------------------------------------------------------


/*
	v0.01, First release. 2.60 only.
	v0.02, 15 Jan 2019. Moved to VS2008, Added Version Resource + v2.58 + x64.
			Added bool arg TV_YUV;
	v0.03, 15 Jan 2019. BugFix version, fixed TV_YUV rounding.
*/

//#define BUG

#include "compiler.h"

#include <windows.h>
#include <stdio.h>

#ifdef AVISYNTH_PLUGIN_25
	#include "Avisynth25.h"
#else
	#include "Avisynth.h"
#endif



#ifdef BUG
	int __cdecl dprintf(char* fmt, ...) {
		char printString[2048]="FredAverage: ";							// Must be nul Termed, eg "Test: " or ""
		char *p=printString;
		for(;*p++;);
		--p;															// @ null term
		va_list argp;
		va_start(argp, fmt);
		vsprintf(p, fmt, argp);
		va_end(argp);
		for(;*p++;);
		--p;															// @ null term
		if(printString == p || p[-1] != '\n') {
			p[0]='\n';													// append n/l if not there already
			p[1]='\0';
		}
		OutputDebugString(printString);
		return int(p-printString);											// strlen printString
	}
#endif


class FredAverage : public GenericVideoFilter {
	const bool invert;
	const bool tvy;
public:
	FredAverage(PClip _child,bool _invert,bool _tvy, IScriptEnvironment* env) : GenericVideoFilter(_child), invert(_invert), tvy(_tvy) {}
	~FredAverage(){}
	PVideoFrame __stdcall GetFrame(int n, IScriptEnvironment* env);
};


PVideoFrame __stdcall FredAverage::GetFrame(int n, IScriptEnvironment* env) {
	n = (n<0) ? 0 : (n>= vi.num_frames) ? vi.num_frames - 1 : n;	// range limit n

	PVideoFrame src	   = child->GetFrame(n, env);
	const int rowsize  = src->GetRowSize(PLANAR_Y);					// PLANAR_Y no effect on RGB or YUY2
	const int pitch    = src->GetPitch(PLANAR_Y);
	const int height   = src->GetHeight(PLANAR_Y);
	const BYTE * srcp  = src->GetReadPtr(PLANAR_Y);
	//
	PVideoFrame	dst	   = env->NewVideoFrame(vi);
	const int drowsize = dst->GetRowSize(PLANAR_Y);
	const int dpitch   = dst->GetPitch(PLANAR_Y);
	const int dheight  = dst->GetHeight(PLANAR_Y);
	BYTE * dstp	       = dst->GetWritePtr(PLANAR_Y);

	const int samples = vi.width * vi.height;
	int x,y;
	//
	if(vi.IsPlanar()) {		// Planar
		__int64 acc      = 0;
		unsigned int sum = 0;

		for(y=height;--y>=0;) {								// sum luma
			for(x=rowsize;--x>=0;) {
				sum += srcp[x];
			}
			if(sum & 0x80000000) { acc += sum; sum=0; }
			srcp += pitch;
		}
		acc += sum;

		int ave;
		double ave_D = double(acc) / samples;											// luma average
		
		if(invert) {	// invert ?
			if(tvy) {
				ave = int(-(ave_D - 125.5) + 125.5 + 0.5);								// TV_YUV Y mid = 125.5, invert, and Round
			} else {
				ave = int(ave_D + 0.5) ^ 0xFF;											// PC_YUV Y mid = 127.5, symmetrical about 127.5
			}
		} else {
			ave = int(ave_D + 0.5);
		}
		ave = max( min( ave, 255) ,0);

		for(y=dheight;--y>=0;) {														// set return clip luma
			for(x=drowsize;--x>=0;) {
				dstp[x] = ave;
			}
			dstp += dpitch;
		}

		const int srowsizeUV = src->GetRowSize(PLANAR_U);
		if(srowsizeUV) {																// Not Y8
			const int spitchUV	= src->GetPitch(PLANAR_U);
			const int sheightUV	= src->GetHeight(PLANAR_U);
			const BYTE * srcpU	= src->GetReadPtr(PLANAR_U);
			const BYTE * srcpV	= src->GetReadPtr(PLANAR_V);

			const int drowsizeUV= dst->GetRowSize(PLANAR_U);
			const int dpitchUV	= dst->GetPitch(PLANAR_U);
			const int dheightUV	= dst->GetHeight(PLANAR_U);
			BYTE * dstpU        = dst->GetWritePtr(PLANAR_U);
			BYTE * dstpV        = dst->GetWritePtr(PLANAR_V);

			__int64 accU=0,accV=0;
			unsigned int sumU=0,sumV=0;
		
			for(y=sheightUV;--y>=0;) {							// sum u and v
				for(x=srowsizeUV;--x>=0;) {
					sumU += srcpU[x];
					sumV += srcpV[x];
				}
				if(sumU & 0x80000000) { accU += sumU; sumU=0; }
				if(sumV & 0x80000000) { accV += sumV; sumV=0; }
				srcpU += spitchUV;
				srcpV += spitchUV;
			}
			accU += sumU;
			accV += sumV;

			const int samplesUV = srowsizeUV * sheightUV;

			int aveU = int(double(accU) / samplesUV + 0.5);		// u an v averages
			int aveV = int(double(accV) / samplesUV + 0.5);

			if(invert) {										// Invert ?
				aveU ^= 0xFF ;
				aveV ^= 0xFF;
			}

			for(y=dheightUV;--y>=0;) {							// set return clip U and V to rounded average of source.
				for(x=drowsizeUV;--x>=0;) {
					dstpU[x] = aveU;
					dstpV[x] = aveV;
				}
				dstpU += dpitchUV;
				dstpV += dpitchUV;
			}
		}
	} else if(vi.IsYUY2()) {	// YUY2
		__int64 acc=0,accU=0,accV=0;
		unsigned int sum=0,sumU=0,sumV=0;

		for(y=height;--y>=0;) {								// sum luma
			for(x=rowsize;(x-=4)>=0;) {
				sum += srcp[x + 0];
				sumU+= srcp[x + 1];
				sum += srcp[x + 2];
				sumV+= srcp[x + 3];
			}
			if(sum  & 0x80000000)	{ acc  += sum;  sum =0; }
			if(sumU & 0x80000000)	{ accU += sumU; sumU=0; }
			if(sumV & 0x80000000)	{ accV += sumV; sumV=0; }
			srcp += pitch;
		}
		acc  += sum;
		accU += sumU;
		accV += sumV;

		const int samplesUV = samples / 2;

		int ave;
		double ave_D = double(acc)  / samples;					// Luma Ave
		int aveU = int(double(accU) / samplesUV + 0.5);			// U ave
		int aveV = int(double(accV) / samplesUV + 0.5);			// V ave

		if(invert) {	// invert ?
			if(tvy) {
				ave = int(-(ave_D - 125.5) + 125.5 + 0.5);								// TV_YUV Y mid = 125.5, invert, and Round
			} else {
				ave = int(ave_D + 0.5) ^ 0xFF;											// PC_YUV Y mid = 127.5, symmetrical about 127.5
			}
			aveU ^= 0xFF;
			aveV ^= 0xFF;
		} else {
			ave = int(ave_D + 0.5);
		}
		ave = max( min( ave, 255) ,0);

		for(y=dheight;--y>=0;) {								// set return clip
			for(x=drowsize;(x-=4)>=0;) {
				dstp[x + 0] = ave;
				dstp[x + 1] = aveU;
				dstp[x + 2] = ave;
				dstp[x + 3] = aveV;
			}
			dstp += dpitch;
		}

	} else {		// RGB
		__int64  accR=0,accG=0,accB=0;
		unsigned int sumR=0,sumG=0,sumB=0;
		if(vi.IsRGB24()) {
			for(y=height;--y>=0;) {								// sum
				for(x=rowsize;(x-=3)>=0;) {
					sumB += srcp[x + 0];
					sumG += srcp[x + 1];
					sumR += srcp[x + 2];
				}
				if(sumB & 0x80000000) { accB += sumB; sumB=0; }
				if(sumG & 0x80000000) { accG += sumG; sumG=0; }
				if(sumR & 0x80000000) { accR += sumR; sumR=0; }
				srcp += pitch;
			}
		} else {
			for(y=height;--y>=0;) {								// sum
				for(x=rowsize;(x-=4)>=0;) {
					sumB += srcp[x + 0];
					sumG += srcp[x + 1];
					sumR += srcp[x + 2];
				}
				if(sumB & 0x80000000) { accB += sumB; sumB=0; }
				if(sumG & 0x80000000) { accG += sumG; sumG=0; }
				if(sumR & 0x80000000) { accR += sumR; sumR=0; }
				srcp += pitch;
			}
		}

		accB += sumB;
		accG += sumG;
		accR += sumR;

		int aveB = int(double(accB) / samples + 0.5);		// blu ave
		int aveG = int(double(accG) / samples + 0.5);		// grn ave
		int aveR = int(double(accR) / samples + 0.5);		// red ave

		if(invert) {										// Invert ?
			aveB ^= 0xFF;
			aveG ^= 0xFF;
			aveR ^= 0xFF;
		}

		if(vi.IsRGB24()) {
			for(y=dheight;--y>=0;) {						// set return clip 
				for(x=drowsize;(x-=3)>=0;) {
					dstp[x + 0] = aveB;
					dstp[x + 1] = aveG;
					dstp[x + 2] = aveR;
				}
				dstp += dpitch;
			}
		} else {
			for(y=dheight;--y>=0;) {						// set return clip 
				for(x=drowsize;(x-=4)>=0;) {
					dstp[x + 0] = aveB;
					dstp[x + 1] = aveG;
					dstp[x + 2] = aveR;
					dstp[x + 3] = 0;						// alpha = 0
				}
				dstp += dpitch;
			}
		}
	}
	//
	return dst;
}


AVSValue __cdecl Create_FredAverage(AVSValue args, void* user_data, IScriptEnvironment* env) {
	PClip child = args[0].AsClip();
	const VideoInfo &vi = child->GetVideoInfo();
	const char * myName="FredAverage: ";
    #ifdef AVISYNTH_PLUGIN_25
		if(vi.IsPlanar() || vi.IsYUY2() || vi.IsRGB24() || vi.IsRGB32()) {
			if( vi.IsPlanar()) {
				if( vi.pixel_type!=0xA0000008 &&    // YV12
					vi.pixel_type!=0xE0000000       // Y8
				) {
						env->ThrowError("%sColorSpace unsupported for in v2.5 dll\n",myName);
				}
			}
		} else 
			env->ThrowError("%sYV12, Y8, YUY2, RGB24, and RGB32 Only",myName);
	#else
		if(!
			(vi.IsYV12() || vi.IsYV16() || vi.IsYV24() || vi.IsY8() || vi.IsYV411() || vi.IsYUY2() || vi.IsRGB24() || vi.IsRGB32())
			)	env->ThrowError("%sYV12, YV16, YV24, YV411, Y8, YUY2, RGB24, and RGB32 Only",myName);
	#endif
	bool invert=args[1].AsBool(false);
	bool tvy=args[2].AsBool(false);
    return new FredAverage(child,invert,tvy,env); 
}



// The following function is the function that actually registers the filter in AviSynth
// It is called automatically, when the plugin is loaded to see which functions this filter contains.
#ifdef AVISYNTH_PLUGIN_25
	extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) {
#else
	/* New 2.6 requirement!!! */
	// Declare and initialise server pointers static storage.
	const AVS_Linkage *AVS_linkage = 0;

	/* New 2.6 requirement!!! */
	// DLL entry point called from LoadPlugin() to setup a user plugin.
	extern "C" __declspec(dllexport) const char* __stdcall
			AvisynthPluginInit3(IScriptEnvironment* env, const AVS_Linkage* const vectors) {

	/* New 2.6 requirment!!! */
	// Save the server pointers.
	AVS_linkage = vectors;
#endif
	// The AddFunction has the following paramters:
	// AddFunction(Filtername , Arguments, Function to call,0);

    env->AddFunction("FredAverage",  "c[invert]b[TV_YUV]b", Create_FredAverage, 0);

	// Arguments is a string that defines the types and optional nicknames of the arguments for you filter.
	// c - Video Clip
	// i - Integer number
	// f - Float number
	// s - String
	// b - boolean
	// . - Any type (dot)
	//      Array Specifiers
	// i* - Integer Array, zero or more
	// i+ - Integer Array, one or more
	// .* - Any type Array, zero or more
	// .+ - Any type Array, one or more
	//      Etc

    return "'FredAverage' FredAverage plugin";
	// A freeform name of the plugin.
}
