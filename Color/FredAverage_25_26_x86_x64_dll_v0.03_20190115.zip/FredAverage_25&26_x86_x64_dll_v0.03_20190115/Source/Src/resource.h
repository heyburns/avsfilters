#ifndef IDC_STATIC
   #define IDC_STATIC (-1)   // ssS, This dont seem necessary, added by ResEdit. We keep it here anyway.
#endif

#include "Version.h"

