// Licensed under the MIT License. Copyright (c) 2016 Andrew Revvo (andrew.revvo~gmail~com)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avisynth_mt.h"

extern void Add_UnsharpMask8Y(IScriptEnvironment* env);
extern void Add_UnsharpMask16Y(IScriptEnvironment* env);

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env)
{
	Add_UnsharpMask8Y(env);
	Add_UnsharpMask16Y(env);
    return "HDRSharp Library";
}
