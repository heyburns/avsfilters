Release_clang versions are build with clang llvm 17.0.5.
Others are build with VS2019 Update 11.31.

Get x64 redistribuable package for Visual Studio 2015-2022.
https://aka.ms/vs/17/release/VC_redist.x64.exe

"XP" versions are build with Windows XP support.
"W7" versions are build without Windows XP support.
